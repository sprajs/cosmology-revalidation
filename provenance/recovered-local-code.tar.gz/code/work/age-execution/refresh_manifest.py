from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
root=Path.cwd();base=root/'studies/host_ages';topics=['age_reconciliation','age_recovery','environment_validation','population_transport']
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def record(paths):return {str(p.relative_to(root)):sha(p) for p in sorted(set(paths))}
records=[p for topic in topics for p in (base/'results'/topic).glob('*.json')]
code=[p for topic in topics for p in (base/'code'/topic).glob('*') if p.suffix in {'.py','.json'}]
docs=[root/'README.md',root/'docs/age-correction-results.md',root/'docs/age-correction-plan.md',root/'docs/age-correction-evidence.md',base/'README.md',root/'provenance/README.md',root/'validation/README.md']+list((base/'notes').glob('*-results.md'))+list((base/'code/environment_validation').glob('README.md'))
x={
 'schema':'cosmology-age-correction-execution-v1',
 'recorded_utc':datetime.now(timezone.utc).isoformat(),
 'base_repository_commit':'6cbf5e21eb68a36ab7fb5b244b808b9fdca9f431',
 'question':'Does an age-dependent luminosity effect require an additional correction after modern standardization, or is the proposed full template partly already accounted for?',
 'scope':'New observational calculations, conditional known-design recovery and population-transport sensitivity. Neither universal correction completeness nor a physical residual age correction is identified. The full selected-survey physical programme remains incomplete.',
 'manuscript':'docs/age-correction-results.md',
 'branches':{
  'A':{'directory':'studies/host_ages/code/age_reconciliation','executed':['Original Gupta quality-cut reconstruction; exact 175-object/70-young counts','Signed residual/correction accounting on 196 physical SNe with full released covariance','Shared young-trend covariance, cross-fitting and paired bootstrap','Conditional Gaussian age-error profiles and grouped held-out predictions','Direct updated-posterior and mock-code availability checks'], 'limits':['Exact Park regression configuration not recovered','Updated joint host posterior/likelihood and priors unavailable','Age-profile coverage near scatter boundary not calibrated']},
  'B':{'directory':'studies/host_ages/code/age_recovery','executed':['Actual nonlinear cosmology plus nuisance fitting for paired zero/negative-age injections, 500 noise realizations per amplitude','1728 calibrated-flux intervention/event/noise combinations with recomputed synthetic selection','Separate native sncosmo and SciPy flux integrals; independent adaptive cosmology fit checks','Shape-specific cosmological precision budgets and current public simulation-file availability'], 'limits':['Known age coordinates are not uncertain physical ages','Fixed trained SALT3 surface, released covariance and priors','Previously accepted cadences and synthetic detection, not actual discovery/classification/BBC selection','250 required Dovekie files unavailable at checked endpoints; classifier equivalence remains unresolved']},
  'C':{'directory':'studies/host_ages/code/environment_validation','executed':['DustPedia local/global and aperture-age comparisons','Cepheid-distance brightness contrast for 11 SNe in 9 hosts with full released covariance','ZTF mass/colour/environment fits and held-out prediction','401-object TITAN-summary/ZTF incremental age comparison','600 fitted-working-model coverage/power draws and redshift-bin offset sensitivity','DES/Dovekie and optical/NIR age-overlap inventory'], 'limits':['SED posterior summaries and missing joint age/dust/metallicity covariance','Public ZTF brightness/blinding and calibration boundaries','No certified physical age inference or survey cosmology from the internal contrasts']},
  'D':{'directory':'studies/host_ages/code/population_transport','executed':['Acquisition and reconstruction of older public 8610-host TITAN snapshot','Held-out nonlinear host-to-model-derived-delay mapping','Observed low/high-redshift age support and selection-weight sensitivity','Affine/scatter compensation identities and nonlinear/selection counterexamples','36 SFH/DTD/clock/selection scenarios with independent quadrature','New cousins-paper source/availability audit and public group-data feasibility'], 'limits':['Old snapshot differs from final 6983-host sample; joint SFH samples unavailable','Model-derived delays are not independent physical age measurements','No compatible observed high-redshift distribution for survey-selected transport']}
 },
 'protocol_history':'Designs preserve their initial choices and explicitly label exploratory extensions and implementation corrections. The final flux campaign uses native Model.bandflux inference after independent review found shared quadrature in the first implementation. All 1728 combinations were rerun. Prior diagnostic outputs remain local; current records identify final code.',
 'new_public_input':{'repository':'https://github.com/SterlingYM/age-of-titans','commit':'9b9ed9e5faf8b2f6267c0dce8cea97704d9b95ea','acquisition_code':'studies/host_ages/code/population_transport/acquire_titan.py','not_final_paper_sample':True},
 'reproduction':'Execute the commands in the four linked scientific notes using the locked environment. Each result identifies source paths and hashes. The common-sample restoration helper avoids needing the original local archive for its six numerical inputs. Other study inputs have documented acquisition/archive overrides. Downloaded author products and generated object tables/draws remain ignored.',
 'validation_report':'validation/reports/age-correction-execution.json',
 'baseline_cosmology':'No new physical age correction applied. Existing 29 reference-run output identities are reverified separately; those earlier scientific runs were not rerun in this campaign.',
 'code_and_design_sha256':record(code+[root/'validation/age_correction_checks.py']),
 'compact_result_sha256':record(records),
 'documentation_sha256':record(docs),
 'environment_sha256':record([root/'pyproject.toml',root/'uv.lock']),
 'publication_policy':'First-party code, designs, concise scientific notes and compact result/provenance JSON only. Downloadable third-party code/data, bulk arrays and regenerable object-level tables are not versioned.',
 'author_contact_made':False,
 'new_physical_cosmology_claim':False
}
(root/'provenance/age-correction-execution.json').write_text(json.dumps(x,indent=2)+'\n')
print('Execution manifest:',len(code),'code/design files;',len(records),'result records;',len(docs),'documents')
