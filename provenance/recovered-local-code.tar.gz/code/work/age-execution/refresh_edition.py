from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
r=Path.cwd()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=r/'provenance/edition.json';e=json.loads(p.read_text());x=json.loads((r/'provenance/age-correction-execution.json').read_text())
e['updated_utc']=datetime.now(timezone.utc).isoformat()
e['scope']='Current manuscript, primary analysis code, topic-organized original research and September 27 age-correction experiments. The new studies contain observational comparisons and conditional recovery/transport tests, not a completed survey-wide physical age correction. Historical source preservation does not imply successful reproduction of every native or unfinished study.'
for path in e['documentation_sha256']:e['documentation_sha256'][path]=sha(r/path)
e['documentation_sha256'].update(x['documentation_sha256'])
e['study_tools_sha256']['validation/age_correction_checks.py']=sha(r/'validation/age_correction_checks.py')
e['age_correction_execution_manifest']={'path':'provenance/age-correction-execution.json','sha256':sha(r/'provenance/age-correction-execution.json'),'scope':x['scope']}
p.write_text(json.dumps(e,indent=2)+'\n')
for k in ['environment_sha256','code_sha256','documentation_sha256','study_tools_sha256','repository_policy_sha256']:
 for path,h in e[k].items():assert sha(r/path)==h,path
for k in ['code_and_design_sha256','compact_result_sha256','documentation_sha256','environment_sha256']:
 for path,h in x[k].items():assert sha(r/path)==h,path
for k in ['study_source_manifest','study_inputs_manifest','age_correction_literature_manifest','age_correction_execution_manifest']:
 v=e[k];assert sha(r/v['path'])==v['sha256'],v['path']
v=json.loads((r/'validation/manifest.json').read_text())
for k in ['audit_sha256','audit_code_sha256']:
 for path,h in v[k].items():assert sha(r/path)==h,path
print('Edition, execution and validation inventories agree with current files.')
