from pathlib import Path
import json,hashlib,io,collections
import numpy as np
import pandas as pd
from scipy.special import expit
R=Path.cwd(); B=R/'studies/host_ages/results/survey_physics'; W=R/'.work/survey-physics/scaled-bbc'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def native(p):
 lines=Path(p).read_text().splitlines(); names=next(s.split()[1:] for s in lines if s.startswith('VARNAMES:'))
 rows=[s.split()[1:] for s in lines if s.startswith('SN:')]
 d=pd.DataFrame(rows,columns=names).set_index('CID'); return d.apply(pd.to_numeric,errors='coerce')
def tokens(p):
 lines=Path(p).read_text().splitlines(); names=next(s.split()[1:] for s in lines if s.startswith('VARNAMES:'))
 return names,{s.split()[1]:s.split()[2:] for s in lines if s.startswith('SN:')}
def eq(a,b):
 a=np.asarray(a,float);b=np.asarray(b,float);assert np.allclose(a,b,rtol=1e-11,atol=1e-13),(a,b)
 return float(np.max(abs(a-b))) if a.size else 0.
def slope(f,y,w):
 bins=np.searchsorted([.05,.3,.5,.7,.9,1.2],f.zHD,side='right')-1
 top=0.;bot=0.;n=0;means=[];y=y-np.average(y,weights=w)
 for j in range(5):
  k=bins==j
  means.append(float(np.average(y[k],weights=w[k])) if sum(k)>=10 else None)
  if sum(k)>=10:
   x=f.SIM_HOSTLIB_SN_age.to_numpy()[k];ww=w[k];x=x-np.average(x,weights=ww);yy=y[k]-np.average(y[k],weights=ww)
   top+=sum(ww*x*yy);bot+=sum(ww*x*x);n+=sum(k)
 return top/bot if n>=30 and bot>0 else None,means
labels=['frozen_nominal','age_nominal','age_literal','age_retained']
def vec(r,k):
 d=r['contrasts'].get(k+'_all_cases',{})
 return [b['mean_mag'] for b in d['centered_redshift_means'][:4]] if d.get('slope_mag_per_Gyr') is not None else None
out={'status':'passed','method':'Independent raw-token identity, weighted within-bin covariance slope, globally centered bin means and empirical sample covariance/percentile reconstruction. Producer summarization functions are not imported.','dependencies':{},'bootstrap':{},'raw_output_audits':[]}
red=load(B/'scaled-redshift-summary-k016.json')
for variant in ['common-fixed','common-highmass-gauge']:
 for mode in ['joint','training_only']:
  p=B/f'scaled-bootstrap-{mode}-k016-{variant}.json';s=load(p);out['dependencies'][str(p.relative_to(R))]=sha(p)
  reps=[]
  for i,h in s['replicate_result_hashes'].items():
   rp=W/'bootstrap'/f'k016-{variant}'/mode/f'r{int(i):03d}'/'result.json';assert sha(rp)==h;reps.append(load(rp))
  assert len(reps)==s['replicates'];assert dict(collections.Counter(r['status'] for r in reps))==s['replicate_status_counts']
  err=0.;nsummary=0
  for label,z in s['summary'].items():
   valid=[r['contrasts'][label] for r in reps if r['contrasts'].get(label,{}).get('slope_mag_per_Gyr') is not None]
   assert len(valid)==z['supported_replicates'];x=[r['slope_mag_per_Gyr'] for r in valid]
   if len(x)>1:
    err=max(err,eq(np.std(x,ddof=1),z['slope_sd_mag_per_Gyr']),eq(np.quantile(x,[.025,.975]),z['percentile_95_mag_per_Gyr']));nsummary+=1
   for i,binrec in enumerate(z['redshift_means']):
    m=[r['centered_redshift_means'][i]['mean_mag'] for r in valid if r['centered_redshift_means'][i]['mean_mag'] is not None]
    assert len(m)==binrec['supported_replicates']
    if len(m)>1:err=max(err,eq(np.std(m,ddof=1),binrec['sd_mag']),eq(np.quantile(m,[.025,.975]),binrec['percentile_95_mag']))
   c=z['centered_bin_covariance'];inds=c['baseline_supported_bin_indices'];a=np.array([[r['centered_redshift_means'][i]['mean_mag'] for i in inds] for r in valid if inds and all(r['centered_redshift_means'][i]['mean_mag'] is not None for i in inds)])
   assert len(a)==c['complete_replicates']
   if len(a)>1:
    ac=a-a.mean(axis=0);cov=ac.T@ac/(len(a)-1);err=max(err,eq(cov,c['covariance_mag2']))
  highlow={k:[] for k in labels};changes={'retained_minus_frozen':[],'retained_minus_nominal_refit':[]};complete=[]
  for r in reps:
   v={k:vec(r,k) for k in labels};hl={k:x[3]-x[0] for k,x in v.items() if x is not None and x[0] is not None and x[3] is not None}
   for k,x in hl.items(): highlow[k].append(x)
   for key,old in [('retained_minus_frozen','frozen_nominal'),('retained_minus_nominal_refit','age_nominal')]:
    if 'age_retained' in hl and old in hl:changes[key].append(hl['age_retained']-hl[old])
   if all(x is not None and all(q is not None for q in x) for x in v.values()):complete.append([q for k in labels for q in v[k]])
  rs=red['variants'][variant]['bootstrap'][mode]
  for group,x in [('high_minus_low',highlow),('paired_changes',changes)]:
   for k,a in x.items():
    z=rs[group][k];assert len(a)==z['supported_replicates']
    if len(a)>1:err=max(err,eq(np.std(a,ddof=1),z['sd_mag']),eq(np.quantile(a,[.025,.975]),z['percentile_95_mag']))
  a=np.array(complete);ac=a-a.mean(axis=0);cov=ac.T@ac/(len(a)-1);err=max(err,eq(cov,rs['joint_bin_covariance']['covariance_mag2']));assert len(a)==rs['joint_bin_covariance']['complete_replicates']
  out['bootstrap'][variant+':'+mode]={'replicates':len(reps),'status_counts':s['replicate_status_counts'],'summary_sets_checked':nsummary,'all_case_slope_supported':s['summary']['age_retained_all_cases']['supported_replicates'],'high_low_supported':len(highlow['age_retained']),'full_16bin_covariance_supported':len(a),'max_summary_difference':err,'min_joint_covariance_eigenvalue_mag2':float(np.linalg.eigvalsh(cov).min()),'retained_minus_frozen_high_low':rs['paired_changes']['retained_minus_frozen']}
  # Deterministic SHA-selected raw output check: eight supported all-case replicates.
  selected=sorted([r for r in reps if r['contrasts'].get('age_retained_all_cases',{}).get('slope_mag_per_Gyr') is not None],key=lambda r:hashlib.sha256(f'{variant}:{mode}:{r["index"]}'.encode()).hexdigest())[:8]
  for r in selected:
   base=W/'bootstrap'/f'k016-{variant}'/mode/f'r{r["index"]:03d}';frames={k:native(base/k/'bbc.FITRES') for k in ['nominal','age_nominal','age_literal','age_retained']};ids=set.intersection(*(set(f.index) for f in frames.values()));ids=sorted(ids);nom=frames['nominal'].loc[ids];weight=1/nom.MUERR.to_numpy()**2;maximum=0.
   for k in labels:
    f=frames['age_nominal' if k=='frozen_nominal' else k].loc[ids]
    if k=='frozen_nominal':
     pars=r['native_cases']['nominal']['parameters'];aa,bb,gg=[pars[q]['value'] for q in ['alpha0','beta0','gamma0']];mu=-2.5*np.log10(f.x0)+aa*f.x1-bb*f.c-gg*(.5-expit((f.HOST_LOGMASS-10)/.001))-f.biasCor_mu
    else:mu=f.MU
    y=(mu-f.SIM_DLMAG)-(nom.MU-nom.SIM_DLMAG);m,means=slope(nom,y.to_numpy(),weight);z=r['contrasts'][k+'_all_cases'];maximum=max(maximum,eq(m,z['slope_mag_per_Gyr']))
    for j,a in enumerate(means):
     b=z['centered_redshift_means'][j]['mean_mag'];assert (a is None)==(b is None)
     if a is not None:maximum=max(maximum,eq(a,b))
   out['raw_output_audits'].append({'variant':variant,'mode':mode,'replicate':r['index'],'common_n':len(ids),'max_slope_or_bin_difference':maximum})
# Literal/retained table identity, all tokens, before interpreting numerical values.
r=load(B/'scaled-inputs-k016.json');n,a=tokens(r['tables']['age_literal']['path']);nn,b=tokens(r['tables']['age_retained_age']['path']);assert n==nn and a.keys()==b.keys();j=n.index('SIM_gammaDM')-1;t=n.index('TRUE_AGE_MAGSHIFT')-1;changed=0
for k in a:
 assert all(x==y for i,(x,y) in enumerate(zip(a[k],b[k])) if i!=j);assert float(b[k][j])==0;assert a[k][j]==a[k][t];changed+=a[k][j]!=b[k][j]
out['target_table_identity']={'age_training_rows':len(a),'only_changed_column':'SIM_gammaDM','changed_rows':changed,'all_other_tokens_identical':True,'TRUE_AGE_MAGSHIFT_equals_original_gamma':True}
# Gauge selection independently from unfiltered evaluation IDs.
n=native(r['tables']['eval_nominal']['path']);a=native(r['tables']['eval_age']['path']);ids=n.index.intersection(a.index);good=ids[(n.loc[ids].HOST_LOGMASS>=10.04)&(a.loc[ids].HOST_LOGMASS>=10.04)];g=load(B/'scaled-bbc-k016-common-highmass-gauge.json')
for name in ['eval_nominal','eval_age']:assert set(native(g['tables'][name]['path']).index)==set(good)
out['gauge_selection']={'pre_BBC_common':len(ids),'mass_selected':len(good),'removed':len(ids)-len(good),'removed_ids':sorted(set(ids)-set(good))}
# Raw token identity on all five cloned tables for four predetermined replicates.
clonechecks=[]
for variant in ['common-fixed','common-highmass-gauge']:
 for mode in ['joint','training_only']:
  q=load(W/'bootstrap'/f'k016-{variant}'/mode/'r037/result.json');num=0
  for key,rec in q['inputs'].items():
   names,parent=tokens(rec['parent_table']['path']);names2,child=tokens(rec['path']);assert names==names2;idx=names.index('ORIGINAL_CID')-1
   for cid,row in child.items():assert row==parent[str(int(row[idx]))];num+=1
  clonechecks.append({'variant':variant,'mode':mode,'replicate':37,'rows_token_identical_except_CID':num})
out['bootstrap_clone_token_checks']=clonechecks
# Capacity evidence: actual preserved bytes and exact abort diagnostics.
q=load(B/'scaled-native-capacity-replay.json');checks=[]
for rec in q['records']:
 old=Path(rec['original_log']['path']);new=Path(rec['replay']['folder']);assert sha(old)==rec['original_log']['sha256'];original=old.read_text();replay=(new/'bbc.log').read_text()
 if rec['original_success']:
  x=[s for s in old.with_name('bbc.FITRES').read_text().splitlines() if s.startswith('SN:')];y=[s for s in (new/'bbc.FITRES').read_text().splitlines() if s.startswith('SN:')];assert x==y and old.with_name('bbc.COV').read_bytes()==(new/'bbc.COV').read_bytes();status='science_and_covariance_bytes_identical'
 else:
  capacity='NBIN_SIGINT=100 exceeds bound MXSTORE_PULL=100' in original
  if capacity:assert 'Graceful Program Exit' in replay or rec['replay']['graceful'];status='capacity_fixed_at_original_scatter_floor'
  else:assert 'Invalid stdPull = 0.000000' in original and 'Invalid stdPull = 0.000000' in replay;status='genuine_zero_MAD_failure_persists'
 checks.append({'label':rec['label'],'status':status,'expanded_scan_cells':rec.get('expanded_scan_cells',[])})
out['capacity_replay_checks']=checks
for p in [B/'scaled-redshift-summary-k016.json',B/'scaled-inputs-k016.json',B/'scaled-native-capacity-replay.json',B/'scaled-native-capacity-build.json']:out['dependencies'][str(p.relative_to(R))]=sha(p)
out['audit_script_sha256']=sha(__file__)
Path('.work/scaled-bbc-independent-review/final-review.json').write_text(json.dumps(out,indent=2)+'\n')
p=R/'studies/host_ages/results/galaxy_validation/scaled-bbc-method-review.json';old=load(p);old['k016_final_bootstrap_and_target_review']=out;old['status']='Native source, final k016 points, target identity, capacity repair and final bootstrap independently audited; conditional support and simulation limits preserved';p.write_text(json.dumps(old,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['dependencies','raw_output_audits']},indent=2))
