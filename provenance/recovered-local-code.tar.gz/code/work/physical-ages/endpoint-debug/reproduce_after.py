import sys,json,time
from pathlib import Path
import numpy as np
root=Path('/home/szymon/Documents/ChatGPT/supernova');sys.path.insert(0,str(root/'studies/host_ages/code/physical_ages'))
import fit,model
out=root/'.work/physical-ages/endpoint-debug'; original=fit.age_bound;records=[];calls=0

def audit(matrix,flux,error,ages,threshold,maximize=False,inequalities=None,diagnostics=None):
 global calls
 calls+=1;dd=[]
 value=original(matrix,flux,error,ages,threshold,maximize,inequalities,dd)
 if diagnostics is not None:diagnostics.extend(dd)
 if value is None and not (dd and dd[-1].get('status')=='PrimalInfeasible'):
  label=f'after-failure-{calls}'
  np.savez(out/(label+'.npz'),matrix=matrix,flux=flux,error=error,ages=ages,threshold=threshold,maximize=maximize,inequalities=np.empty((0,len(ages))) if inequalities is None else inequalities)
  record={'label':label,'diagnostics':dd,'max':maximize,'joint':inequalities is not None,'age_range':[float(ages.min()),float(ages.max())]};records.append(record);print(json.dumps(record),flush=True)
 return value
fit.age_bound=audit
start=time.time();items,_,_=fit.inputs('sdss');item=next(x for x in items if x['id']=='2059441137659176960');fit.initialize();rows=fit.fit_one(item)
r={'calls':calls,'seconds':time.time()-start,'rows':rows,'failures':records};(out/'after.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
