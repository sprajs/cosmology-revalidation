import sys,json,hashlib
from pathlib import Path
import numpy as np
root=Path('/home/szymon/Documents/ChatGPT/supernova');sys.path.insert(0,str(root/'studies/host_ages/code/physical_ages'))
import model
work=root/'.work/physical-ages/endpoint-debug';fixture=work/'failure-426.npz';f=np.load(fixture);d=[]
result=model.age_bound(f['matrix'],f['flux'],f['error'],f['ages'],float(f['threshold']),bool(f['maximize']),f['inequalities'],d)
assert result is not None and result['retries']==2
u=np.array(result['weights']);m=u*result['amplitude'];chi2=float(np.sum(((f['matrix']@m-f['flux'])/f['error'])**2));slack=float(np.max(f['inequalities']@u/np.linalg.norm(f['inequalities'],axis=1)))
assert chi2<=float(f['threshold'])+2e-5 and slack<1e-7 and np.min(u)>=0 and abs(u.sum()-1)<1e-6 and result['duality_gap']<1e-5
factory=model.clarabel.DefaultSolver;alternate_calls=0
def alternate(*args):
 global alternate_calls
 settings=args[-1];settings.tol_gap_abs=settings.tol_gap_rel=settings.tol_feas=1e-9 if alternate_calls==0 else 1e-8
 alternate_calls+=1
 return factory(*args)
model.clarabel.DefaultSolver=alternate;da=[]
alt=model.age_bound(f['matrix'],f['flux'],f['error'],f['ages'],float(f['threshold']),bool(f['maximize']),f['inequalities'],da)
assert alt is not None
r={'object_id':'2059441137659176960','source_id':'ZTF19aaksrlb','scope':'One reproduced object and captured failed cone; full-sample rerun remains the parent task.','failure_type':'Joint maximum-age endpoint at0.03mag floor; prior retry stopped at AlmostSolved before original-unit validation.','unchanged_acceptance_checks':{'minimum_weight':-1e-7,'simplex_sum_tolerance':1e-6,'photometry_threshold_slack':2e-5,'normalized_inequality_slack':1e-7,'duality_gap':1e-5},'before':json.loads((work/'before.json').read_text()),'after':json.loads((work/'after.json').read_text()),'successful_cone':{k:v for k,v in result.items() if k!='weights'},'failed_attempts_before_success':d,'direct_validation':{'chi2':chi2,'threshold':float(f['threshold']),'inequality_slack':slack,'minimum_weight':float(u.min()),'sum_weights':float(u.sum()),'objective_from_weights':float(f['ages']@u)},'solver_tolerance_comparison':{'retained_strict_tolerance':1e-9,'alternate_tolerance':1e-8,'alternate_age':alt['age'],'age_difference':alt['age']-result['age'],'alternate_retries':alt['retries'],'reason':'Both solve the captured failure at1e-6 regularization; keep stricter original requested tolerance rather than relax during fallback.'},'fixture_path':str(fixture.relative_to(root)),'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),'prior_model_sha256':hashlib.sha256((work/'model-before.py').read_bytes()).hexdigest(),'current_model_sha256':hashlib.sha256(Path(model.__file__).read_bytes()).hexdigest(),'diagnostic_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
out=root/'studies/host_ages/results/physical_ages/endpoint-retry-regression.json';out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ['successful_cone','direct_validation','solver_tolerance_comparison','current_model_sha256']},indent=2))
