import sys,json
from pathlib import Path
import numpy as np
root=Path('/home/szymon/Documents/ChatGPT/supernova');sys.path.insert(0,str(root/'studies/host_ages/code/physical_ages'))
import model
out=root/'.work/physical-ages/endpoint-debug';f=np.load(out/'failure-426.npz');factory=model.clarabel.DefaultSolver
records=[]
for regularization,tolerance in [(1e-8,1e-9),(1e-10,1e-9),(1e-6,1e-9),(1e-10,1e-10),(1e-6,1e-10),(1e-10,1e-11)]:
 solutions=[]
 def make(*args):
  settings=args[-1];settings.static_regularization_constant=regularization
  settings.tol_gap_abs=settings.tol_gap_rel=settings.tol_feas=tolerance;settings.max_iter=500
  solver=factory(*args)
  class Wrap:
   def solve(self):
    sol=solver.solve();solutions.append({'status':str(sol.status),'gap':sol.obj_val-sol.obj_val_dual,'iterations':sol.iterations,'r_prim':sol.r_prim,'r_dual':sol.r_dual});return sol
  return Wrap()
 model.clarabel.DefaultSolver=make
 d=[];v=model.age_bound(f['matrix'],f['flux'],f['error'],f['ages'],float(f['threshold']),bool(f['maximize']),f['inequalities'],d)
 r={'regularization':regularization,'tolerance':tolerance,'solutions':solutions,'diagnostics':d,'result':v};records.append(r);print(json.dumps({k:v for k,v in r.items() if k!='result'}),v and {k:v[k] for k in ['age','primal_value','duality_gap','chi2','inequality_max']})
(out/'retry-probe.json').write_text(json.dumps(records,indent=2))
