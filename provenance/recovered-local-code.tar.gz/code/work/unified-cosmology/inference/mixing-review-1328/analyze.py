from pathlib import Path
import json,hashlib,sys
import numpy as np
from scipy.linalg import eigh
import arviz as az
ROOT=Path.cwd();SRC=ROOT/'.work/unified-cosmology/inference/modern-cpl-none-dovekie-official_planck-fast-metropolis-scale1p6-7316f91342ee';OUT=Path(__file__).parent
manifest=json.loads((SRC/'run-0.json').read_text()); names=[k for k,v in manifest['target_identity']['configuration']['params'].items()if isinstance(v,dict)and'prior'in v]
raw=[];inputs={}
for rank in range(1,5):
 p=SRC/f'chain.{rank}.txt';data=p.read_bytes();lines=data.decode().splitlines();columns=lines[0].lstrip('#').split();complete=[l for l in lines[1:]if len(l.split())==len(columns)];saved=OUT/p.name;saved.write_text(lines[0]+'\n'+'\n'.join(complete)+'\n');inputs[str(saved.relative_to(ROOT))]=hashlib.sha256(saved.read_bytes()).hexdigest();raw.append(np.loadtxt(saved))
ix=[columns.index(n)for n in names]

def generalized(chains,weights,ns):
 means=np.array([np.average(x,axis=0,weights=w)for x,w in zip(chains,weights)])
 covs=np.array([np.cov(x.T,fweights=w.astype(int),ddof=0)for x,w in zip(chains,weights)])
 W=np.average(covs,axis=0,weights=ns);B=np.cov(means.T);eig,vec=eigh(B,W);order=np.argsort(eig)[::-1];eig=eig[order];vec=vec[:,order]
 return dict(eigenvalues=eig.tolist(),scalar_B_over_W=dict(zip(names,(np.diag(B)/np.diag(W)).tolist())),W=W,B=B,means=means,vec=vec)

def compact(g):
 W=g['W'];v=g['vec'][:,0];sd=np.sqrt(np.diag(W));v=v*(1 if v[names.index('H0')]>=0 else -1)
 return dict(eigenvalues=g['eigenvalues'][:3],max_scalar_B_over_W=max(g['scalar_B_over_W'].values()),scalar_B_over_W=g['scalar_B_over_W'],leading_standardized_coefficients=dict(zip(names,(v*sd).tolist())),leading_within_parameter_correlations=dict(zip(names,((W@v)/sd).tolist())),chain_means_along_leading=(g['means']@v).tolist(),unit_within_SD=True)

Ns=np.array([7333,8320,7289,6551]);assert all(len(x)>=n for x,n in zip(raw,Ns))
cp=[x[n//2:n]for x,n in zip(raw,Ns)];g=generalized([x[:,ix]for x in cp],[x[:,0]for x in cp],Ns)
expanded=[np.repeat(x[:,ix],x[:,0].astype(int),axis=0)for x in raw];tails=[x[int(.3*len(x)):]for x in expanded];L=min(map(len,tails));eq=np.array([x[-L:]for x in tails]);geq=generalized(list(eq),[np.ones(L)]*4,[L]*4)
proj=eq@geq['vec'][:,-1] # overwritten below; eigvectors already descending
proj=eq@geq['vec'][:,0]
metric=lambda x:{'Rhat_rank':float(az.rhat(x,method='rank')),'ESS_bulk':float(az.ess(x,method='bulk')),'ESS_tail':float(az.ess(x,method='tail'))}
segments={}
for f in [1.,.75,.5,.25]:
 n=int(L*f);segment=eq[:,-n:];gg=generalized(list(segment),[np.ones(n)]*4,[n]*4);segments[str(f)]={'weighted_draws_per_chain':n,**compact(gg),'fixed_full_tail_contrast_metrics':metric(segment@geq['vec'][:,0])}
np.savez(OUT/'arrays.npz',equal=eq,names=names,raw_columns=columns,leading=geq['vec'][:,0])
report={'scope':'Read-only moving chains frozen into complete-row snapshots; diagnostic only, not posterior qualification.','checkpoint_Ns':Ns.tolist(),'logged_Rminus1':.059492,'reconstructed_checkpoint':compact(g),'actual_complete_rows':list(map(len,raw)),'expanded_rows':list(map(len,expanded)),'common_after30percent':L,'equal_tail':compact(geq),'leading_direction_metrics':metric(proj),'marginal_metrics':{name:metric(eq[:,:,j])for j,name in enumerate(names)},'tail_fractions':segments,'source_parameters':manifest['target_identity']['configuration'],'input_sha256':inputs}
(OUT/'diagnosis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k]for k in ['checkpoint_Ns','reconstructed_checkpoint','equal_tail','leading_direction_metrics']},indent=2))
