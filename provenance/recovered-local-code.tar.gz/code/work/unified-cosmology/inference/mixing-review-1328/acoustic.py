from pathlib import Path
import json,numpy as np,sys
from scipy.linalg import eigh
import camb
WORK=Path(__file__).parent;a=json.load(open(WORK/'diagnosis.json'));f=np.load(WORK/'arrays.npz');allx=f['equal'];names=list(f['names']);v=f['leading'];n=allx.shape[1]
rng=np.random.default_rng(928277);ix=np.floor((np.arange(100)[None,:]+rng.random((4,100)))*n/100).astype(int);x=np.array([allx[c,ix[c]]for c in range(4)])
extra=a['source_parameters']['theory']['spectral_surrogate']['extra_args']
angles=[]
for j,row in enumerate(x.reshape(-1,len(names))):
 d=dict(zip(names,row));kwargs={k:d[k]for k in ['H0','ombh2','omch2','ns','tau','w','wa']};kwargs['As']=1e-10*np.exp(d['logA']);p=camb.set_params(**kwargs,**extra);background=camb.get_background(p);angles.append(100*background.cosmomc_theta())
angles=np.array(angles).reshape(4,100)

def joint(y):
 means=y.mean(axis=1);W=np.mean([np.cov(r.T,ddof=0)for r in y],axis=0);B=np.cov(means.T);eval,evec=eigh(B,W);return {'largest_joint_ratio':float(eval[-1]),'three_eigenvalues':eval[-3:][::-1].tolist()}
transformed=x.copy();transformed[:,:,names.index('H0')]=angles
flat=x.reshape(-1,len(names));cx=flat[:,:8];standard=(cx-cx.mean(0))/cx.std(0);linear=np.c_[np.ones(400),standard]
quad=np.c_[linear,*[standard[:,i]*standard[:,j]for i in range(8)for j in range(i,8)]]
theta=angles.ravel();sigma=theta.std();resids={};coeff={}
for label,design in [('linear',linear),('quadratic',quad)]:
 prediction=np.zeros(400)
 for c in range(4):
  mask=np.arange(400)//100!=c;b=np.linalg.lstsq(design[mask],theta[mask],rcond=None)[0];prediction[~mask]=design[~mask]@b
 resids[label]={'leave_one_chain_out_RMSE_over_theta_SD':float(np.sqrt(np.mean((prediction-theta)**2))/sigma),'leave_one_chain_out_max_error_over_theta_SD':float(np.max(abs(prediction-theta))/sigma)}
coeff=np.linalg.lstsq(quad,theta,rcond=None)[0]
# Interpolation diagnosis only; no likelihood or cosmological measurement uses this predictor.
std=(allx.reshape(-1,len(names))[:,:8]-cx.mean(0))/cx.std(0);design=np.c_[np.ones(len(std)),std,*[std[:,i]*std[:,j]for i in range(8)for j in range(i,8)]]
fulltheta=(design@coeff).reshape(allx.shape[:2]);approx=allx.copy();approx[:,:,0]=fulltheta
out={'native_background_evaluations':400,'native_spectrum_evaluations':0,'seed':928277,'within_chain_stratified_points':100,'exact_theta_SD':float(sigma),'full_tail_leading_contrast_vs_exact_theta_correlation_400':float(np.corrcoef((x@v).ravel(),theta)[0,1]),'subset_original_coordinates':joint(x),'subset_acoustic_coordinates':joint(transformed),'angle_linear_curvature_validation':resids,'full_tail_quadratic_angle_proxy':joint(approx),'proxy_status':'Diagnostic interpolation only; exact leave-one-chain-out errors recorded. Does not alter target or chains.'}
np.savez(WORK/'acoustic-400.npz',point_indices=ix,points=x,theta=angles,names=names)
(WORK/'acoustic.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
