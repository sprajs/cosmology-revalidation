import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
 os.environ[key]='1'
import sys,json,hashlib,time,datetime
from pathlib import Path
import numpy as np
import camb
ROOT=Path.cwd()
CODE=ROOT/'studies/unified_cosmology/code/inference'
sys.path.insert(0,str(CODE))
from spectral_surrogate import coordinates,polynomial,SPECTRA,COORDINATES
WORK=ROOT/'.work/unified-cosmology/inference/gpu-runtime-diagnosis'
MODEL=ROOT/'.work/unified-cosmology/inference/quartic-spectral/surrogate-quartic-v1.npz'
def sha(b): return hashlib.sha256(b).hexdigest()
def digest(p):return sha(Path(p).read_bytes())
snapshot=WORK/'snapshot.json'
if not snapshot.exists():
 inputs=[]
 for family,seed in [('linear',272812),('smooth01',272813)]:
  folder=MODEL.parent.parent/f'modern-cpl-{family}-dovekie-official_planck-fast-gpu-blocked-f1-scale1p6-seed{seed}-dfff858fc0d4'
  for rank in range(1,5):
   path=folder/f'chain.{rank}.txt'
   raw=path.read_bytes();lines=raw.decode().splitlines();names=lines[0].lstrip('#').split()
   complete=[line for line in lines[1:] if len(line.split())==len(names)]
   assert len(complete)>=25
   rows=[dict(zip(names,map(float,line.split()))) for line in complete[-25:]]
   inputs.append(dict(family=family,rank=rank,path=str(path.relative_to(ROOT)),source_bytes_sha256=sha(raw),source_bytes=len(raw),source_complete_rows=len(complete),chain_input_sha256=digest(folder/'chain.input.yaml'),first_retained_row_1based=len(complete)-24,rows=rows))
  (WORK/f'{family}-chain.input.yaml').write_bytes((folder/'chain.input.yaml').read_bytes())
 design=dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Fixed last25 accepted file rows per four ranks in each of two active chains; no rejected proposals or posterior claims. Rejection multiplicities retained as metadata only.',sources=inputs,model_sha256=digest(MODEL),script_sha256=digest(__file__),source_sha256={str((CODE/n).relative_to(ROOT)):digest(CODE/n) for n in ['spectral_surrogate.py','modern_gpu.py']},native_spectra_calls_permitted=0,gpu_contexts_permitted=0,threads=1)
 snapshot.write_text(json.dumps(design,indent=2)+'\n')
 print(json.dumps({'snapshot_frozen':str(snapshot),'snapshot_sha256':digest(snapshot),'rows':sum(len(v['rows']) for v in inputs)}),flush=True)
else:design=json.loads(snapshot.read_text())
assert digest(MODEL)==design['model_sha256']
model=np.load(MODEL);centre=model['centre'];chol=model['coordinate_cholesky'];coeff=model['coefficients'];exponents=model['exponents'];scale=model['output_scale'];length=int(model['length'])
# No likelihood initialized. This is the same finalized native extra_args as
# recorded by the independently acquired training/validation provider contract.
ref=MODEL.parent/'holdout_original/0000.json'
refdata=json.loads(ref.read_text())
import yaml
current_yaml=(WORK/'linear-chain.input.yaml').read_text()
extra=yaml.safe_load(current_yaml.split('    extra_args:\n',1)[1].split('    exact_mode:',1)[0])
extra['lmax']=max(extra['lmax'],refdata['finalized_theory_extra_args']['lmax'])
other_yaml=(WORK/'smooth01-chain.input.yaml').read_text()
other_extra=yaml.safe_load(other_yaml.split('    extra_args:\n',1)[1].split('    exact_mode:',1)[0])
assert all(extra[k]==v for k,v in other_extra.items() if k!='lmax')
rows=[]
for cohort in design['sources']:
 for i,p in enumerate(cohort['rows']):
  physical={name:p[name] for name in ['H0','ombh2','omch2','ns','tau','w','wa']};physical['As']=np.exp(p['logA'])*1e-10
  started=time.perf_counter();pars=camb.set_params(**physical,**extra);background=camb.get_background(pars);background_seconds=time.perf_counter()-started
  point=coordinates(pars,background);x=np.linalg.solve(chol,point-centre)
  started=time.perf_counter();out=(polynomial(x,exponents)@coeff)*scale;spectra=out.reshape(5,length);polynomial_seconds=time.perf_counter()-started
  nonfinite=[name for name,arr in zip(SPECTRA,spectra) if np.any(~np.isfinite(arr))]
  nonpositive={name:dict(count=int(np.sum(spectra[SPECTRA.index(name),2:]<=0)),minimum=float(spectra[SPECTRA.index(name),2:].min()),first_ell=int(np.where(spectra[SPECTRA.index(name),2:]<=0)[0][0]+2) if np.any(spectra[SPECTRA.index(name),2:]<=0) else None) for name in ['tt','ee','pp']}
  outside=np.max(abs(x))>4
  rows.append(dict(family=cohort['family'],rank=cohort['rank'],snapshot_row=i,chain_row_1based=cohort['first_retained_row_1based']+i,weight=p['weight'],physical=physical,coordinates=point.tolist(),whitened=x.tolist(),max_abs_whitened=float(np.max(abs(x))),outside_coordinates=[COORDINATES[j] for j in range(8) if abs(x[j])>4],outside_envelope=bool(outside),nonfinite_spectra=nonfinite,nonpositive_spectra=nonpositive,actual_fallback_reason='outside_envelope' if outside else ('nonfinite' if nonfinite else ('nonpositive' if any(v['count'] for v in nonpositive.values()) else None)),background_seconds=background_seconds,polynomial_cpu_seconds=polynomial_seconds))
  if len(rows)%25==0:print(json.dumps({'evaluated':len(rows),'latest_family':cohort['family'],'latest_rank':cohort['rank'],'fallbacks_in_latest25':sum(r['actual_fallback_reason'] is not None for r in rows[-25:])}),flush=True)
summary=[]
for family in ['linear','smooth01']:
 for rank in [None,1,2,3,4]:
  group=[r for r in rows if r['family']==family and (rank is None or r['rank']==rank)]
  summary.append(dict(family=family,rank=rank,n=len(group),outside_envelope=sum(r['outside_envelope'] for r in group),nonpositive_inside_envelope=sum(not r['outside_envelope'] and any(v['count'] for v in r['nonpositive_spectra'].values()) for r in group),nonfinite_inside_envelope=sum(not r['outside_envelope'] and bool(r['nonfinite_spectra']) for r in group),fallbacks=sum(r['actual_fallback_reason'] is not None for r in group),outside_coordinate_counts={name:sum(name in r['outside_coordinates'] for r in group) for name in COORDINATES},maximum_abs_whitened=max(r['max_abs_whitened'] for r in group),background_seconds_quantiles=np.quantile([r['background_seconds'] for r in group],[0,.5,.95,1]).tolist(),polynomial_cpu_seconds_quantiles=np.quantile([r['polynomial_cpu_seconds'] for r in group],[0,.5,.95,1]).tolist(),w_range=[min(r['physical']['w'] for r in group),max(r['physical']['w'] for r in group)],wa_range=[min(r['physical']['wa'] for r in group),max(r['physical']['wa'] for r in group)]))
result=dict(status='completed_fixed_accepted_state_runtime_diagnostic',snapshot_sha256=digest(snapshot),script_sha256=digest(__file__),model_sha256=digest(MODEL),finalized_extra_args=extra,extra_args_source=str(ref.relative_to(ROOT)),extra_args_source_sha256=digest(ref),native_spectra_calls=0,gpu_contexts_created=0,summary=summary,rows=rows,limitations='Accepted file rows only, last25/rank at a fixed instant. Rejected proposals are not observed; acceptance multiplicities are not fallback counts. CPU diagnostic background and polynomial timings are measured under concurrent load and do not estimate GPU theory-call runtime. No posterior inference, likelihood evaluation, initial-only conclusion or native-spectra calculation.')
(WORK/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'summary':[v for v in summary if v['rank'] is None]},indent=2),flush=True)
