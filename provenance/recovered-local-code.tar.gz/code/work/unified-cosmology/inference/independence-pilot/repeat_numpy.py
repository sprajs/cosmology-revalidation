"""Authorized exact frozen400-candidate replay on baseline NumPy backend."""
import importlib.util,hashlib,json,os,shutil,datetime
from pathlib import Path
ROOT=Path.cwd();OLD=ROOT/'.work/unified-cosmology/inference/independence-pilot'
NEW=ROOT/'.work/unified-cosmology/inference/independence-pilot-numpy'
assert not NEW.exists();NEW.mkdir()
for name in ['design.json','snapshot.json','training.json','proposal.npz','controls.json','run-0.json']:
 shutil.copyfile(OLD/name,NEW/name)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert os.environ['CLIPY_NOJAX']=='1'
(NEW/'runtime-design.json').write_text(json.dumps({'declared_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'purpose':'Repeat the frozen400-candidate pilot unchanged on actual baseline NumPy backend after failed cross-backend closure; preserve original failure.',
 'source_sha256':sha(__file__),'prototype_sha256':sha(OLD/'prototype.py'),'parent_result_sha256':sha(OLD/'pilot-result.json'),
 'failed_closure_sha256':sha(OLD/'backend-closure.json'),'target_call_cap':400,
 'environment':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','CLIPY_NOJAX']},
 'proposal_and_acceptance_seeds':'unchanged273222and273223; exactlysamecandidatevectors, allowing paired component-density and accept/reject checks'},indent=2)+'\n')
spec=importlib.util.spec_from_file_location('pilot',OLD/'prototype.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
module.HERE=NEW
module.pilot()
