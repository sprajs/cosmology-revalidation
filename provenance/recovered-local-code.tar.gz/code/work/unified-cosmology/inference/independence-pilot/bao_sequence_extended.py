"""Bounded BAO state diagnostic, frozen physical source unmodified."""
import os,sys,json,hashlib,time
from pathlib import Path
import numpy as np
ROOT=Path.cwd();HERE=ROOT/'.work/unified-cosmology/inference/independence-pilot'
sys.path.insert(0,str(ROOT/'studies/unified_cosmology/code/inference'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
records=[json.loads(x) for x in (HERE/'pilot-records.jsonl').read_text().splitlines()]
design={'sequence':[286,6,286,95,286,164,286], 'cached':False,'reason':'fixedP cold and after three distinct actual native-fallback points6,95,164; test one-time versus recurring drag initialization',
 'source_sha256':sha(__file__),'records_sha256':sha(HERE/'pilot-records.jsonl'),'environment':dict((k,os.environ.get(k)) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','CLIPY_NOJAX'])}
(HERE/'bao-sequence-extended-design.json').write_text(json.dumps(design,indent=2)+'\n')
from modern_fast import configuration
from cobaya.model import get_model
s=json.loads((HERE/'run-0.json').read_text())['arguments']
info=configuration(s['model'],s['evolution'],s['sample'],s['calibration'],Path(s['surrogate']))
out=[]
with get_model(info) as m:
 bao=m.likelihood['bao.desi_dr2'];theory=m.theory['spectral_surrogate']
 for idx in design['sequence']:
  start=time.perf_counter();v=m.logposterior(records[idx]['point'],cached=False);elapsed=time.perf_counter()-start
  vector=np.array([bao.theory_fun(z,o) for z,o in zip(bao.data['z'],bao.data['observable'])]).ravel()
  manual=float(bao.logpdf(vector));like=dict(zip(m.likelihood,map(float,v.loglikes)))
  zz=np.unique(bao.data['z'].values);cls=theory.get_Cl(ell_factor=True)
  row={'index':idx,'seconds':elapsed,'loglikes':like,'target_logpost':float(v.logpost),
       'rdrag_provider':float(m.provider.get_param('rdrag')),'rdrag_background':float(theory.current_state['background'].get_derived_params()['rdrag']),
       'H':m.provider.get_Hubble(zz).tolist(),'DA':m.provider.get_angular_diameter_distance(zz).tolist(),'z':zz.tolist(),
       'BAO_theory_vector':vector.tolist(),'manual_BAO_loglike':manual,'BAO_loglike_closure':manual-like['bao.desi_dr2'],
       'spectra_sha256':{k:hashlib.sha256(np.asarray(cls[k]).tobytes()).hexdigest() for k in ['tt','ee','te','pp']},
       'native_calls_total':theory.exact_calls,'surrogate_calls_total':theory.surrogate_calls}
  out.append(row);print(json.dumps(row),flush=True)
result={'status':'completed_diagnostic_not_a_closure_claim','design_sha256':sha(HERE/'bao-sequence-extended-design.json'),'source_sha256':sha(__file__),'records':out}
(HERE/'bao-sequence-extended.json').write_text(json.dumps(result,indent=2)+'\n')
