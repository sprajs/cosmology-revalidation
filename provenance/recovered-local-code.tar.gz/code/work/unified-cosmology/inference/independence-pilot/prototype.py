"""Ignored bounded frozen independence-MH pilot: no scientific target edits."""
import argparse,datetime,hashlib,io,json,os,sys,time
from pathlib import Path
import numpy as np
from scipy.linalg import solve_triangular
from scipy.special import gammaln,logsumexp
from scipy.stats import multivariate_normal,multivariate_t
ROOT=Path.cwd()
HERE=ROOT/'.work/unified-cosmology/inference/independence-pilot'
SCI=ROOT/'studies/unified_cosmology/code/inference'
sys.path.insert(0,str(SCI))
PARENT=ROOT/'.work/unified-cosmology/inference/modern-lcdm-none-dovekie-official_planck-fast-metropolis-scale1p6-seed272672-7316f91342ee'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(name,x):
 p=HERE/name;assert not p.exists(),p
 p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def load(name):return json.loads((HERE/name).read_text())
def relative(p):return str(Path(p).resolve().relative_to(ROOT))
class Proposal:
 def __init__(self,mean,cov):
  self.mean=np.asarray(mean);self.cov=np.asarray(cov);self.d=len(mean)
  self.L=np.linalg.cholesky(cov);self.ld=2*np.log(np.diag(self.L)).sum()
  self.nu=5.;self.fg=1.05**2;self.ft=2.**2*(self.nu-2)/self.nu
 def logpdf(self,x):
  y=solve_triangular(self.L,(np.atleast_2d(x)-self.mean).T,lower=True).T
  r2=(y*y).sum(axis=1)
  g=-.5*(self.d*np.log(2*np.pi)+self.ld+self.d*np.log(self.fg)+r2/self.fg)
  t=gammaln((self.nu+self.d)/2)-gammaln(self.nu/2)-.5*(self.d*np.log(self.nu*np.pi)+self.ld+self.d*np.log(self.ft))-(self.nu+self.d)/2*np.log1p(r2/self.ft/self.nu)
  return np.logaddexp(np.log(.9)+g,np.log(.1)+t)
 def draw(self,rng,n):
  component=rng.random(n)>=.9;u=rng.normal(size=(n,self.d))
  u[~component]*=np.sqrt(self.fg)
  count=component.sum()
  u[component]*=np.sqrt(self.ft*self.nu/rng.chisquare(self.nu,count))[:,None]
  return self.mean+u@self.L.T,component.astype(int)
def freeze():
 assert not (HERE/'design.json').exists()
 design={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'source_sha256':sha(__file__),'parent':relative(PARENT),'training_segments':'integer-frequency expanded chains: [floor(.5*n),floor(.9*n)); last 10% withheld descriptive shape check',
  'mean_covariance':'pooled frequency-weighted population moments, covariance plus 1e-8 times its diagonal',
  'proposal':'0.9 N(mean,1.05^2 C) + 0.1 t_5(mean,scale=(2^2)*(5-2)/5*C)',
  'scale_semantics':'1.05 and 2 multiply marginal standard deviations. Student-t covariance=nu/(nu-2)*scale, hence tail covariance=4 C.',
  'support':'mixture positive on all R^d; target prior/domain rejections retained, no candidate redraw',
  'seeds':{'controls':273221,'proposals':273222,'acceptance':273223},'full_target_call_cap':400,
  'initialization':'first finite independent q draw, before it there is no chain state; all calls count and are retained',
  'MH':'min(1,exp(logtarget(y)-logtarget(x)+logq(x)-logq(y)))',
  'learning':'freeze before new target calls; no adaptation/retraining/holdout fitting',
  'scope':'efficiency pilot only, unchanged numerical surrogate target; native correction and independent convergence still required',
  'decisions':'descriptive shape, acceptance, candidate raw importance ESS/max weight, holding-time concentration, noisy fixed-coordinate ESS and evaluation timing; no cosmological estimates'}
 put('design.json',design)
 snapshots=[]
 for p in [PARENT/'run-0.json',*sorted(PARENT.glob('chain.[0-9].txt'))]:
  data=p.read_bytes()
  if p.suffix=='.txt':data=data[:data.rfind(b'\n')+1]
  dest=HERE/p.name;dest.write_bytes(data)
  snapshots.append({'path':relative(dest),'source_path':relative(p),'sha256':sha(dest),'bytes':len(data)})
 put('snapshot.json',{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'design_sha256':sha(HERE/'design.json'),'inputs':snapshots})
 print('frozen',snapshots,flush=True)
def train():
 design=load('design.json');assert sha(__file__)==design['source_sha256']
 snap=load('snapshot.json')
 for row in snap['inputs']:assert sha(ROOT/row['path'])==row['sha256']
 manifest=load('run-0.json');config=manifest['target_identity']['configuration']
 names=[k for k,v in config['params'].items() if isinstance(v,dict) and 'prior' in v]
 trains=[];tests=[];sizes=[];indices=[]
 for p in sorted(HERE.glob('chain.[0-9].txt')):
  headers=p.open().readline().lstrip('#').split();a=np.loadtxt(p,ndmin=2)
  weights=a[:,0];assert np.all(weights==weights.astype(int)) and min(weights)>0
  # Expansion exactly restores rejected-proposal holding times; no resampling.
  ix=[headers.index(k) for k in names];expanded=np.repeat(a[:,ix+[1]],weights.astype(int),axis=0)
  n=len(expanded);tr=expanded[int(.5*n):int(.9*n)];te=expanded[int(.9*n):]
  trains.append(tr);tests.append(te);sizes.append({'file':p.name,'accepted_rows':len(a),'frequency_draws':n,'training':len(tr),'test':len(te)})
 x=np.concatenate(trains)[:,:-1];mean=x.mean(0);center=x-mean
 cov=center.T@center/len(x);cov+=1e-8*np.diag(np.diag(cov))
 q=Proposal(mean,cov);np.savez(HERE/'proposal.npz',mean=mean,cov=cov,names=names)
 shape=[]
 for k,t in enumerate(tests):
  white=solve_triangular(q.L,(t[:,:-1]-mean).T,lower=True).T
  lw=-t[:,-1]-q.logpdf(t[:,:-1]);ww=np.exp(lw-logsumexp(lw))
  sd=white.std(0);z=(white-white.mean(0))/sd
  shape.append({'chain':k,'coordinate_standardized_mean_range':[float(white.mean(0).min()),float(white.mean(0).max())],
   'max_absolute_skew':float(abs((z**3).mean(0)).max()),'max_absolute_excess_kurtosis':float(abs((z**4).mean(0)-3).max()),
   'r2_quantiles':np.quantile((white**2).sum(1),[.5,.9,.99,1]).tolist(),
   'logtarget_minus_logq_sd':float(lw.std()),'logtarget_minus_logq_range':float(np.ptp(lw)),
   'descriptive_weight_ess_fraction':float(1/(ww@ww)/len(ww)),
   'caution':'held-out correlated parent states; these are not iid proposal importance diagnostics or posterior qualification'})
 put('training.json',{'design_sha256':sha(HERE/'design.json'),'snapshot_sha256':sha(HERE/'snapshot.json'),'proposal_sha256':sha(HERE/'proposal.npz'),
  'names':names,'dimensions':len(names),'sizes':sizes,'covariance_correlation_condition_number':float(np.linalg.cond(cov/np.sqrt(np.outer(np.diag(cov),np.diag(cov))))),'heldout_shape':shape})
 print(json.dumps(load('training.json'),indent=2),flush=True)
def controls():
 rng=np.random.default_rng(load('design.json')['seeds']['controls'])
 q=Proposal(np.array([.2,-.3,.4]),np.array([[1.,.2,.1],[.2,1.4,-.2],[.1,-.2,.8]]))
 points,components=q.draw(rng,200000)
 independent=np.logaddexp(np.log(.9)+multivariate_normal.logpdf(points[:1000],q.mean,q.cov*q.fg),np.log(.1)+multivariate_t.logpdf(points[:1000],q.mean,q.cov*q.ft,df=q.nu))
 err=float(max(abs(q.logpdf(points[:1000])-independent)));assert err<1e-12
 expected=.9*q.fg*q.cov+.1*4*q.cov
 cerr=float(np.max(abs(np.cov(points,rowvar=False)-expected)/np.sqrt(np.outer(np.diag(expected),np.diag(expected)))))
 assert cerr<.04
 targetmean=np.array([-.1,.1,.2]);tcov=np.eye(3)
 logp=multivariate_normal.logpdf(points,targetmean,tcov);logq=q.logpdf(points)
 loga=np.minimum(0,np.diff(logp)-np.diff(logq))
 logar=np.minimum(0,-np.diff(logp)+np.diff(logq))
 db=float(max(abs((logp[:-1]+logq[1:]+loga)-(logp[1:]+logq[:-1]+logar))))
 assert db<1e-11
 logu=np.log(rng.random(len(points)-1));idx=0;occ=[]
 for i in range(1,len(points)):
  if logu[i-1]<min(0,logp[i]-logp[idx]+logq[idx]-logq[i]):idx=i
  occ.append(idx)
 sample=points[np.array(occ)[5000:]];meanerr=float(max(abs(sample.mean(0)-targetmean)));sderr=float(max(abs(sample.std(0)-1)))
 assert meanerr<.025 and sderr<.025
 assert np.isfinite(q.logpdf(np.array([1e6,-1e6,1e6]))).all()
 put('controls.json',{'status':'passed','density_max_error':err,'proposal_empirical_covariance_scaled_error':cerr,'detailed_balance_log_error':db,
  'Gaussian_MH_mean_error':meanerr,'Gaussian_MH_sd_error':sderr,'draws':len(points),'full_real_support':True,'source_sha256':sha(__file__)})
 print(json.dumps(load('controls.json'),indent=2),flush=True)
def pilot():
 design=load('design.json');assert sha(__file__)==design['source_sha256']
 traininfo=load('training.json');assert sha(HERE/'proposal.npz')==traininfo['proposal_sha256']
 assert load('controls.json')['status']=='passed'
 manifest=load('run-0.json')
 from measurement_summary import verify_current_target
 identity_inputs=verify_current_target(manifest)
 from modern_fast import configuration,identify
 from late_geometry import sample_path
 settings=manifest['arguments'];info=configuration(settings['model'],settings['evolution'],settings['sample'],settings['calibration'],Path(settings['surrogate']))
 assert identify(info,sample_path(settings['sample']),Path(settings['surrogate']))==manifest['target_identity']
 a=np.load(HERE/'proposal.npz');q=Proposal(a['mean'],a['cov']);names=a['names'].tolist()
 points,comp=q.draw(np.random.default_rng(design['seeds']['proposals']),design['full_target_call_cap'])
 logqs=q.logpdf(points);logu=np.log(np.random.default_rng(design['seeds']['acceptance']).random(len(points)))
 np.savez(HERE/'pilot-requests.npz',points=points,components=comp,logq=logqs,logu=logu,names=names)
 put('pilot-lineage.json',{'target_identity':manifest['target_identity']['identity'],'inputs':identity_inputs,'source_sha256':sha(__file__),
  'design_sha256':sha(HERE/'design.json'),'training_sha256':sha(HERE/'training.json'),'proposal_sha256':sha(HERE/'proposal.npz'),'requests_sha256':sha(HERE/'pilot-requests.npz')})
 from cobaya.model import get_model
 records=[];occupied=[];current=None;lp=[]
 start=time.perf_counter()
 with get_model(info) as model:
  setup=time.perf_counter()-start
  assert list(model.parameterization.sampled_params())==names
  for i,x in enumerate(points):
   t=time.perf_counter();point=dict(zip(names,map(float,x)))
   value=model.logposterior(point);elapsed=time.perf_counter()-t
   logp=float(value.logpost);finite=np.isfinite(logp);lp.append(logp)
   if current is None:accept=bool(finite);la=None
   else:
    la=min(0.,logp-lp[current]+float(logqs[current]-logqs[i]));accept=bool(finite and logu[i]<la)
   if accept:current=i
   occupied.append(current)
   row={'index':i,'point':point,'component':'t5' if comp[i] else 'Gaussian','logq':float(logqs[i]),'target_logpost':logp if finite else None,
        'finite_target':bool(finite),'seconds':elapsed,'accepted':accept,'log_acceptance':la if la is None or np.isfinite(la) else None,
        'log_uniform':float(logu[i]),'occupied_candidate':current,'loglikes':[float(v) if np.isfinite(v) else None for v in value.loglikes]}
   records.append(row)
   with (HERE/'pilot-records.jsonl').open('a') as f:f.write(json.dumps(row,allow_nan=False)+'\n')
   if (i+1)%25==0:print('CALL',i+1,'finite',sum(r['finite_target'] for r in records),'accepted',sum(r['accepted'] for r in records),'seconds',sum(r['seconds'] for r in records),flush=True)
 elapsed=time.perf_counter()-start
 for name,want in identity_inputs.items():assert sha(ROOT/name)==want
 assert sha(__file__)==design['source_sha256']
 finite=np.isfinite(lp);lw=np.asarray(lp)-logqs;weights=np.exp(lw-logsumexp(lw))
 occ=np.array([i for i in occupied if i is not None]);unique,counts=np.unique(occ,return_counts=True)
 hold=[];last=None
 for i in occ:
  if i==last:hold[-1]+=1
  else:hold.append(1);last=i
 import arviz as az
 coordinates={name:{'ess_identity':float(az.ess(points[occ,j],method='identity')),
                    'ess_bulk':float(az.ess(points[occ,j],method='bulk'))} for j,name in enumerate(names)}
 summary={'scope':'bounded sampling-efficiency pilot; no posterior qualification or cosmological estimate',
  'calls':len(points),'finite_targets':int(finite.sum()),'setup_seconds':setup,'wall_seconds':elapsed,'evaluation_seconds':sum(r['seconds'] for r in records),
  'evaluation_rate_per_second':len(points)/sum(r['seconds'] for r in records),
  'evaluation_time_quantiles':np.quantile([r['seconds'] for r in records],[0,.5,.9,.99,1]).tolist(),
  'accepted_including_initialization':sum(r['accepted'] for r in records),'acceptance_excluding_initialization':(sum(r['accepted'] for r in records)-1)/(len(points)-1),
  'unique_occupied_states':len(unique),'longest_hold':max(hold),'largest_occupancy_fraction':float(counts.max()/len(occ)),
  'occupancy_effective_states':float(len(occ)**2/(counts@counts)),'iid_q_candidate_raw_importance_ESS':float(1/(weights@weights)),
  'iid_q_candidate_max_normalized_weight':float(weights.max()),'finite_logtarget_minus_logq_quantiles':np.quantile(lw[finite],[0,.5,.9,.99,1]).tolist(),
  'coordinate_pilot_ESS_noisy_short_single_chain':coordinates,
  'inputs_sha256':{p.name:sha(p) for p in [HERE/'design.json',HERE/'snapshot.json',HERE/'proposal.npz',HERE/'pilot-requests.npz',HERE/'pilot-records.jsonl',HERE/'pilot-lineage.json']}}
 put('pilot-result.json',summary);print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','train','controls','pilot']);globals()[p.parse_args().action]()
