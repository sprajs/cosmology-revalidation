import json,hashlib,sys
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
from scipy.stats import multivariate_normal,multivariate_t,norm
ROOT=Path.cwd();OLD=ROOT/'.work/unified-cosmology/inference/independence-pilot';NEW=OLD.with_name('independence-pilot-numpy')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
rows=lambda p:[json.loads(x) for x in Path(p).read_text().splitlines()]
a,b=rows(OLD/'pilot-records.jsonl'),rows(NEW/'pilot-records.jsonl');assert len(a)==len(b)==400
names=load(OLD/'training.json')['names'];manifest=load(OLD/'run-0.json');component_names=list(manifest['target_identity']['configuration']['likelihood'])
q=np.load(OLD/'proposal.npz');mean,cov=q['mean'],q['cov']
errors=[];decisions=[];prior_errors=[];component_delta={n:[] for n in component_names}
current=None;occupied=[]
for i,(old,new) in enumerate(zip(a,b)):
 assert old['point']==new['point'] and old['component']==new['component'] and old['logq']==new['logq'] and old['log_uniform']==new['log_uniform']
 x=np.array([new['point'][n] for n in names]);scale=np.sqrt(np.diag(cov));z=(x-mean)/scale;corr=cov/np.outer(scale,scale)
 independent=np.logaddexp(np.log(.9)+multivariate_normal.logpdf(z,np.zeros(len(z)),1.05**2*corr),np.log(.1)+multivariate_t.logpdf(z,np.zeros(len(z)),2.4*corr,df=5))-np.log(scale).sum()
 errors.append(abs(independent-new['logq']))
 prior=0.
 for n,v in new['point'].items():
  p=manifest['target_identity']['configuration']['params'][n]['prior']
  if p.get('dist')=='norm':prior+=norm.logpdf(v,p['loc'],p['scale'])
  elif p['min']<=v<=p['max']:prior-=np.log(p['max']-p['min'])
  else:prior=-np.inf;break
 if new['finite_target']:
  prior_errors.append(abs(sum(new['loglikes'])+prior-new['target_logpost']))
  for n,d in zip(component_names,np.array(new['loglikes'])-old['loglikes']):component_delta[n].append(float(d))
 else:assert not np.isfinite(prior)
 if current is None:accept=new['finite_target']
 elif not new['finite_target']:accept=False
 else:accept=new['log_uniform']<min(0,new['target_logpost']-b[current]['target_logpost']+b[current]['logq']-new['logq'])
 assert accept==new['accepted']
 if accept:current=i
 assert current==new['occupied_candidate'];occupied.append(current);decisions.append(old['accepted']==new['accepted'])
assert max(errors)<1e-11 and max(prior_errors)<1e-10
component_summary={n:{'max_absolute_difference':max(map(abs,v)),'median_difference':float(np.median(v))} for n,v in component_delta.items()}
summary=load(NEW/'pilot-result.json')
slow=[r for r in b if r['seconds']>1]
lw=np.array([r['target_logpost']-r['logq'] if r['finite_target'] else -np.inf for r in b]);w=np.exp(lw-logsumexp(lw))
assert abs(1/(w@w)-summary['iid_q_candidate_raw_importance_ESS'])<1e-10
initial=next(i for i,r in enumerate(b) if r['accepted']);assert initial==0
report={'status':'passed_independent_pilot_arithmetic','source_sha256':sha(__file__),'candidate_count':400,
 'requests_exactly_same_between_backends':True,'acceptance_decisions_unchanged':all(decisions),
 'mixture_logdensity_error':max(errors),'independent_prior_plus_components_error':max(prior_errors),
 'prior_rejections':sum(not r['finite_target'] for r in b),'component_backend_difference':component_summary,
 'runtime_difference_cannot_be_called_roundoff_closure':True,'slow_full_target_calls_above1second':[{k:r[k] for k in ['index','component','seconds']} for r in slow],
 'slow_call_seconds_sum':sum(r['seconds'] for r in slow),'remaining_call_median_seconds':float(np.median([r['seconds'] for r in b if r['seconds']<=1])),
 'numpy_pilot_result_sha256':sha(NEW/'pilot-result.json'),'numpy_records_sha256':sha(NEW/'pilot-records.jsonl'),'original_records_sha256':sha(OLD/'pilot-records.jsonl'),
 'interpretation':'Promising frozen-proposal efficiency on baseline backend, not qualified cosmological inference; cross-backend numerical closure failed and is preserved.'}
(NEW/'independent-arithmetic.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
