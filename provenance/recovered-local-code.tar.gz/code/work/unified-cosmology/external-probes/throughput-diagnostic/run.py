"""Fixed-seed proposal-cost diagnostic; no native spectra or active-file changes."""
from pathlib import Path
import hashlib, json, io, sys, time
from collections import Counter
import numpy as np
ROOT=Path.cwd();D=ROOT/'.work/unified-cosmology/external-probes/throughput-diagnostic'
sys.path.insert(0,str(ROOT/'studies/unified_cosmology/code/inference'))
sys.path.insert(0,str(ROOT/'studies/unified_cosmology/code/external_probes'))
from modern_fast import configuration
from spectral_surrogate import coordinates, polynomial, SPECTRA
from cobaya.model import get_model
from cobaya.samplers.mcmc.proposal import BlockedProposer
import camb
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
RUN=ROOT/'.work/unified-cosmology/inference/modern-cpl-none-dovekie-official_planck-fast-metropolis-7316f91342ee'
MODEL=ROOT/'.work/unified-cosmology/inference/surrogate/cubic-0509.npz'
# Capture immutable snapshots, so a repeated diagnostic uses identical centres.
if not (D/'chain.covmat').exists():
 (D/'chain.covmat').write_bytes((RUN/'chain.covmat').read_bytes())
 for p in sorted(RUN.glob('chain.*.txt')):
  content=p.read_text();lines=content.splitlines();n=len(lines[0].lstrip('#').split())
  good=[v for v in lines[1:] if len(v.split())==n]
  if good:(D/p.name).write_text(lines[0]+'\n'+'\n'.join(good)+'\n')
names=(D/'chain.covmat').read_text().splitlines()[0].lstrip('# ').split();cov=np.loadtxt(D/'chain.covmat')
centres=[]
for p in sorted(D.glob('chain.*.txt')):
 cols=p.read_text().splitlines()[0].lstrip('# ').split();data=np.atleast_2d(np.loadtxt(p))
 for i in np.unique(np.floor(np.array([.25,.75])*(len(data)-1)).astype(int)):
  centres.append({'chain':p.name,'row':int(i),'point':{k:float(data[i,cols.index(k)]) for k in names}})
assert len(centres)>=4
n=192;scales=[2.4,1.6,1.2];seed=2727766
source=[ROOT/'studies/unified_cosmology/code/inference/spectral_surrogate.py',ROOT/'studies/unified_cosmology/code/inference/modern_fast.py',ROOT/'studies/unified_cosmology/code/external_probes/fast_lensing.py',ROOT/'studies/unified_cosmology/code/external_probes/modern_adapter.py']
source_hash={str(p.relative_to(ROOT)):sha(p) for p in source}
design={'seed':seed,'proposals_per_scale':n,'scales':scales,'centres':centres,'covariance_sha256':sha(D/'chain.covmat'),'model_sha256':sha(MODEL),'source_sha256':source_hash,'proposal':'Actual Cobaya single-block radial mixture and random-rotation proposer; identical unit displacements across scales; cycling fixed accepted centres, not a Markov chain.','scope':'Conditional throughput diagnostic, not posterior or ESS measurement; no full CAMB spectra permitted.'}
(D/'design.json').write_text(json.dumps(design,indent=2)+'\n')
info=configuration(surrogate=MODEL);info['timing']=True
start=time.perf_counter();m=get_model(info);construct=time.perf_counter()-start
assert list(m.parameterization.sampled_params())==names
T=m.theory['spectral_surrogate'];extra=dict(T.extra_args);extra['lmax']=max(extra.get('lmax',0),max(T.required_cls.values(),default=0))
# Prevent any accidental expensive fallback in this separate diagnostic process.
def forbidden(*args,**kw):raise RuntimeError('Native spectral call is forbidden in throughput diagnostic')
camb.get_results=forbidden
proposer=BlockedProposer([list(range(len(names)))],np.random.default_rng(seed),oversampling_factors=[1],proposal_scale=1.)
proposer.set_covariance(cov);deltas=[]
for i in range(n):
 q=np.zeros(len(names));proposer.get_proposal(q);deltas.append(q)
records=[]
for scale in scales:
 for i,delta in enumerate(deltas):
  base=centres[i%len(centres)];point={k:float(base['point'][k]+scale*delta[j]) for j,k in enumerate(names)}
  r={'scale':scale,'draw':i,'centre':i%len(centres),'point':point}
  lp=m.logpriors(point)
  if not np.isfinite(lp).all():r['category']='prior_reject';records.append(r);continue
  params={k:point[k] for k in ['H0','ombh2','omch2','ns','tau','w','wa']};params['As']=1e-10*np.exp(point['logA'])
  t=time.perf_counter()
  try:
   pars=camb.set_params(**params,**extra);background=camb.get_background(pars)
  except camb.CAMBError as e:r.update(category='background_failure',error=str(e));records.append(r);continue
  r['background_seconds']=time.perf_counter()-t
  coord=coordinates(pars,background);x=np.linalg.solve(T.chol,coord-T.centre)
  r['max_whitened']=float(max(abs(x)));r['max_coordinate']=int(np.argmax(abs(x)));r['whitened']=x.tolist()
  t=time.perf_counter();flat=(polynomial(x,T.exponents)@T.coefficients)*T.output_scale;cl=flat.reshape(5,T.length)
  r['polynomial_seconds']=time.perf_counter()-t
  r['nonfinite_spectra']=bool(not np.isfinite(cl).all())
  r['negative_spectra']=[s for j,s in enumerate(SPECTRA) if s in ['tt','ee','pp'] and np.any(cl[j,2:]<=0)]
  r['category']='envelope_fallback' if max(abs(x))>T.envelope else ('spectrum_fallback' if r['nonfinite_spectra'] or r['negative_spectra'] else 'fast')
  records.append(r)
 (D/'partial.json').write_text(json.dumps({'records':records},indent=2)+'\n')
 print('classified',scale,Counter(r['category'] for r in records if r['scale']==scale),flush=True)
# Instrument separate in-memory components. No source or active chain mutation.
component_times={};current={}
for name,comp in list(m.theory.items())+list(m.likelihood.items()):
 original=comp.calculate
 def wrap(*args,_f=original,_name=name,**kw):
  t=time.perf_counter()
  try:return _f(*args,**kw)
  finally:current.setdefault(_name,[]).append(time.perf_counter()-t)
 comp.calculate=wrap
bench=[]
fast=[r for r in records if r['scale']==2.4 and r['category']=='fast']
for i in np.linspace(0,len(fast)-1,9).astype(int):
 current={};t=time.perf_counter();result=m.logposterior(fast[i]['point'],cached=False);dt=time.perf_counter()-t
 assert np.isfinite(result.logpost)
 bench.append({'draw':fast[i]['draw'],'seconds':dt,'logpost':float(result.logpost),'component_seconds':{k:sum(v) for k,v in current.items()}})
assert T.exact_calls==0
summary={}
for scale in scales:
 rr=[r for r in records if r['scale']==scale];counts=Counter(r['category'] for r in rr)
 finite=[r for r in rr if 'max_whitened' in r]
 summary[str(scale)]={'counts':dict(counts),'attempts':len(rr),'fallback_fraction_all_proposals':sum(counts[k] for k in ['envelope_fallback','spectrum_fallback'])/len(rr),'envelope_excursion_coordinate_counts':dict(Counter(str(r['max_coordinate']) for r in finite if r['max_whitened']>4)),'negative_polynomial_spectra_anywhere_count':sum(bool(r['negative_spectra']) or r['nonfinite_spectra'] for r in finite),'max_whitened_quantiles':np.quantile([r['max_whitened'] for r in finite],[0,.5,.9,.95,1]).tolist(),'hypothetical_envelope_counts':{str(e):sum(r['max_whitened']>e for r in finite) for e in [3,4,5,6]}}
# Exclude first evaluation from warm timing summaries, retain its full record.
median=float(np.median([r['seconds'] for r in bench[1:]]))
for rec in summary.values():
 p=rec['fallback_fraction_all_proposals'];rec['conditional_mean_seconds_if_fallback_30s']=float((1-p)*median+p*30)
for p in source:assert sha(p)==source_hash[str(p.relative_to(ROOT))]
out={'status':'completed','design_sha256':sha(D/'design.json'),'script_sha256':sha(__file__),'construction_seconds':construct,'summary':summary,'benchmark':bench,'warm_median_seconds':median,'warm_component_median_seconds':{k:float(np.median([r['component_seconds'].get(k,0) for r in bench[1:]])) for k in bench[-1]['component_seconds']},'exact_spectrum_calls':T.exact_calls,'records':records,'limitations':['Conditional fixed-centre diagnostic, not actual chain fallback telemetry.','Proposal direction sequence and radius are native, but centres cycle instead of following accept/reject updates.','Identical displacement draws across scales; rates are correlated sensitivity estimates.','Envelope extension counts are diagnostic only; no interpolation accuracy beyond current envelope certified.','30-second cost is a scenario based on observed production fallback, not measured here.','Acceptance probabilities and ESS per time not measured; no proposal or envelope changes made.']}
(D/'result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['records','benchmark']},indent=2))
m.close()
