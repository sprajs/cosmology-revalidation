from pathlib import Path
from hashlib import sha256
import json
r=Path.cwd(); w=r/'.work/unified-cosmology/calibration-source-review'; rev='c447f0fea703fcd0fff57de5000947b5ca81286b'
raw=f'https://raw.githubusercontent.com/PantheonPlusSH0ES/DataRelease/{rev}/'
api='https://api.github.com/repos/PantheonPlusSH0ES/DataRelease/'
entries=[
 ('distance_release_readme',w/'README-distance.txt',raw+'Pantheon%2B_Data/4_DISTANCES_AND_COVAR/README', 'The release states that the Cepheid distance uncertainty is included in the supplied covariance; the same README describes STATONLY principally in SN terms.','uncertainty is incorporated in covariance matrix .cov'),
 ('Brout2022_v2',r/'.work/unified-cosmology/calibration-interface/Brout2022v2.html','https://arxiv.org/html/2202.04077v2#S2.SS3','Equation15 adds the SN covariance and a Cepheid covariance once. It does not publish the numerical host-to-lightcurve expansion algorithm.',None),
 ('Riess2022_v3',r/'.work/unified-cosmology/distance-ladder/Riess2022v3.pdf','https://arxiv.org/pdf/2112.04510v3','Figure16 describes37host covariance without SN data; section5.2 proposes using that first-two-rung factor with consistently standardized SNe. Table6 distinguishes leave-one-host-SN-out and all-SN-free means.','derived only from the first two rungs and without the use of any SN Ia data'),
 ('Scolnic2022_v2',w/'Scolnic2022v2.pdf','https://arxiv.org/pdf/2112.03863','Section3.1 finds no evidence for a shared intrinsic SN distance residual among siblings; section3.2 shares intrinsic scatter among repeated observations of the same SN. This distinction does not remove their common Cepheid distance.','no covariance should be given for measurements of SN distances in the same galaxy'),
 ('pipeline',w/'PPLUS.yml',raw+'Pantheon%2B_Data/7_PIPPIN/PPLUS.yml','Lines4126-4133 list external duplicate-scatter and peculiar-velocity inputs; NOSYS selects DEFAULT+DUP_SIGINT. The active blocks do not specify the later Cepheid-covariance expansion into the public file.',None),
 ('issue6_author_comments',w/'issue6-comments.json',api+'issues/6/comments','Dillon Brout confirms that plotted diagonal errors exclude Cepheid distance covariance. The available reply does not identify the sibling-block construction.','the diagonal errors reported do not include the cepheid distance covariance'),
 ('stat_path_history',w/'cov-stat-history.json',api+'commits?path=Pantheon%2B_Data%2F4_DISTANCES_AND_COVAR%2FPantheon%2BSH0ES_STATONLY.cov&per_page=100','One returned commit at this exact path:7fc680548d1ea9fe6ee983a89d8b5635bb5784a8,2022-07-05T23:26:36Z. This is file-path history, not complete provenance of its external construction.',None),
 ('total_path_history',w/'cov-total-history.json',api+'commits?path=Pantheon%2B_Data%2F4_DISTANCES_AND_COVAR%2FPantheon%2BSH0ES_STAT%2BSYS.cov&per_page=100','The same single initial upload appears; no later tracked update at this path explains the measured contrast.',None),
 ('official_tree',r/'.work/unified-cosmology/distance-ladder/official-tree.json',f'https://api.github.com/repos/PantheonPlusSH0ES/DataRelease/git/trees/{rev}?recursive=1','Pinned release tree contains the matrices, data, cosmology readers and PPLUS.yml, but no named Cepheid-to-SN covariance construction program or v6_9_duplicate_cid.cov.',None),
 ('issue4_comments',w/'issue4-comments.json',api+'issues/4/comments','The request for separated SN/Cepheid matrices has comments but no construction answer in the inspected public record.',None)]
sha=lambda p:sha256(p.read_bytes()).hexdigest()
sources=[]
for key,p,url,statement,quote in entries:
 if quote: assert len(quote.split())<=25
 sources.append(dict(id=key,path=str(p.relative_to(r)),url=url,sha256=sha(p),bytes=p.stat().st_size,statement=statement,short_quote=quote))
screen=json.loads((w/'numerical-screen.json').read_text())
result=dict(status='unresolved_release_construction_with_verified_sibling_pattern',scope='Independent bounded primary-source and four-host matrix audit. No covariance modified, cosmology fitted, or author contacted.',upstream_commit=rev,sources=sources,numerical_screen=screen,
            numerical_screen_sha256=sha(w/'numerical-screen.json'),
            findings=[
              'Four distinct-SN sibling blocks reproduce shared STATONLY covariance 1.97248-1.99790 times the independently reconstructed SN-free host variance.',
              'A single uncertain shared host distance contributes one host variance to each sibling covariance: Cov(m_i-u,m_j-u)=Cov(m_i,m_j)+Var(u) when the SN and host measurements are independent. Two siblings do not themselves imply twice that term.',
              'The paper-level model and source data do not establish which exact host covariance, version, mapping or additional term built the released arrays. A doubled embedding, another release version, and an undocumented additional term cannot be distinguished by the inspected public evidence.',
              'The README label STATONLY is not a guarantee of a diagonal or Cepheid-free matrix. Do not add a second Cepheid factor to the released matrix or subtract the independently reconstructed factor and declare an exact SN-only covariance.',
              'Preserve the official released joint likelihood as a conditional route. An independently rebuilt likelihood needs the exact SN-only covariance and original host-to-row expansion/mean construction, or a full from-observable reconstruction.'
            ],support_boundaries=dict(production_embedding_recovered=False,implementation_error_established=False,independent_host_factor_proven_identical_to_release=False,release_changed_after_initial_path_upload=False,statistical_significance_or_H0_shift_estimated=False),
            review_source_sha256={str(Path(__file__).relative_to(r)):sha(Path(__file__))})
out=r/'studies/unified_cosmology/results/distance_ladder/calibration-source-review.json';assert not out.exists();out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(out,sha(out))
