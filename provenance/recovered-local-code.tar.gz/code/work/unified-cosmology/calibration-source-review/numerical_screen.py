import os
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
from pathlib import Path
import numpy as np,pandas as pd,json,hashlib
root=Path.cwd(); work=root/'.work/unified-cosmology/calibration-source-review'
data=root/'.work/unified-cosmology/inference/pantheon/Pantheon+SH0ES.dat'
stat=root/'.work/unified-cosmology/calibration-interface/Pantheon+SH0ES_STATONLY.cov'
factor=root/'.work/unified-cosmology/distance-ladder/cepheid-host-factor.npz'
d=pd.read_csv(data,sep=r'\s+');x=np.loadtxt(stat);assert int(x[0])==len(d)==1701;c=x[1:].reshape(1701,1701)
f=np.load(factor);hosts=f['host'].tolist();h=f['covariance_mu'];m=f['mean_mu']
examples={'N1448':['2001el','2021pit'],'N3147':['1997bq','2008fv_comb','2021hpr'],'N5468':['1999cp','2002cr'],'N5643':['2013aa','2017cbv']}
rows=[]
for host,names in examples.items():
 j=hosts.index(host);ii=np.flatnonzero(d.CID.isin(names));pairs=[]
 for i in ii:
  for k in ii:
   if i>=k or d.CID[i]==d.CID[k]:continue
   pairs.append(dict(row_i=int(i),row_j=int(k),SN_i=d.CID[i],SN_j=d.CID[k],covariance=float(c[i,k])))
 values=[p['covariance'] for p in pairs]
 assert len(set(values))==1
 rows.append(dict(host=host,SNe=names,lightcurve_rows=ii.tolist(),distinct_SN_pairs=pairs,STATONLY_shared_covariance=values[0],independent_SN_free_host_variance=float(h[j,j]),ratio=float(values[0]/h[j,j]),difference_from_two_host_variances=float(values[0]-2*h[j,j]),released_CEPH_DIST=sorted(set(d.CEPH_DIST[ii])),independent_host_mean=float(m[j])))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=dict(status='verified_four_distinct_sibling_host_blocks',rows=rows,source_sha256={str(Path(__file__).relative_to(root)):sha(Path(__file__))},input_sha256={str(p.relative_to(root)):sha(p) for p in [data,stat,factor]},units='mag^2 for covariance; mag for distance modulus',scope='Exact distinct-SN pairs, preserving all lightcurve rows. Not a reconstruction of the unpublished Cepheid-embedding code and not a correction to released covariance.')
(work/'numerical-screen.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
