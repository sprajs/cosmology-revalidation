"""Finite continuation of the four current inference computations, no scheduler."""
import argparse,json,os,subprocess,time
from pathlib import Path
ROOT=Path.cwd();CODE=ROOT/'studies/unified_cosmology/code/inference';OUT=ROOT/'studies/unified_cosmology/results/inference'
PYTHON=ROOT/'.work/unified-cosmology/external-probes/.modern-venv/bin/python'
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('label');p.add_argument('--pid',type=int,required=True);a=p.parse_args()
folder=a.folder.resolve();proc=Path(f'/proc/{a.pid}/stat')
start=proc.read_text().split()[21] if proc.exists() else None
assert start is not None,'Named current audit process must still be running.'
status=folder/'sensitivity-continuation-status.json'
def report(stage,**kw):
 record=dict(stage=stage,time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**kw)
 status.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
report('waiting_for_this_existing_audit_process',pid=a.pid,process_start_tick=start)
deadline=time.monotonic()+24*3600
while proc.exists() and proc.read_text().split()[21]==start:
 if time.monotonic()>deadline:raise TimeoutError('Current finite computation exceeded24hours; no retry.')
 time.sleep(30)
assert json.loads((folder/'native-audits-status.json').read_text())['stage']=='finite_native_audits_finished','Parent audit execution failed.'
summary=OUT/(a.label+'-exact-correction.json')
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CLIPY_NOJAX='1')
def run(name,*args):
 report(name)
 subprocess.run([str(PYTHON),str(CODE/name),*map(str,args)],env=env,check=True)
for omission in ['sn','bao','lensing']:
 run('probe_omission.py','--chain-folder',folder,'--correction-summary',summary,'--omit',omission,'--cache',folder/('omit-'+omission),'--output',OUT/(a.label+'-omit-'+omission+'.json'))
if json.loads((folder/'run-0.json').read_text())['arguments']['evolution']=='smooth01':
 run('luminosity_bridge.py','--chain-folder',folder,'--correction-summary',summary,'--target','smooth03','--cache',folder/'smooth03-bridge','--output',OUT/(a.label+'-to-smooth03.json'))
precision=json.loads((OUT/('native-posterior-precision-'+a.label+'.json')).read_text())
if precision['status']!='no_large_variation_detected_on_fixed32':
 report('native_precision_needs_review_before_more_native_spectra',precision_status=precision['status'])
 raise SystemExit(0)
run('joint_lensing_bridge.py','--chain-folder',folder,'--correction-summary',summary,'--cache',folder/'joint-lensing-bridge','--execute-native','--workers',4,'--output',OUT/(a.label+'-joint-lensing.json'))
report('finite_sensitivities_finished',note='All variant status fields still require inspection. Completion alone is not qualification.')
