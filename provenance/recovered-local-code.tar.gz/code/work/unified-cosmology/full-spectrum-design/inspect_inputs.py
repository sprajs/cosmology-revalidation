"""Read-only inventory of native DESI spectra, no age fits or new FSPS calls."""
import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,hashlib
import numpy as np
from scipy import sparse
ROOT=Path.cwd();INPUT=ROOT/'.work/unified-cosmology/calibrated-hosts/spectra';OUT=ROOT/'.work/unified-cosmology/full-spectrum-design'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
libpath=ROOT/'.work/unified-cosmology/calibrated-host-physics/ssp-library.npz'
lib=np.load(libpath);lw=lib['wavelength_A'];lr=lib['resolution_sigma_km_s']
regions={'common_3700_4900':(3700.,4900.),'old_indices_3850_4161':(3850.,4161.),'Hgamma_G4300':(4250.,4450.),'Hbeta':(4800.,4910.),'Mgb':(5100.,5250.),'Fe5270_5335':(5250.,5400.),'Halpha':(6500.,6630.)}
rows=[];sources={str(libpath.relative_to(ROOT)):sha(libpath)}
for mp in sorted(INPUT.glob('*.json')):
 m=json.loads(mp.read_text());p=ROOT/m['array_file'];assert sha(p)==m['array_sha256'];a=np.load(p);z=m['desi_z'];parts=[]
 for cam,lo,hi in [('B',-np.inf,5780.),('R',5780.,7570.),('Z',7570.,np.inf)]:
  wave=a[cam+'_WAVELENGTH'];rest=wave/(1+z);flux=a[cam+'_FLUX'];ivar=a[cam+'_IVAR'];mask=a[cam+'_MASK'];d=a[cam+'_RESOLUTION'].astype(float)
  valid=(wave>=lo)&(wave<hi)&(mask==0)&np.isfinite(flux)&np.isfinite(ivar)&(ivar>0)
  n=len(wave);k=d.shape[0]//2;R=sparse.dia_matrix((d,np.arange(k,-k-1,-1)),shape=(n,n)).tocsr()
  sums=np.asarray(R.sum(axis=0)).ravel();log=np.log(wave)-np.median(np.log(wave));mean=np.divide(R.T@log,sums,out=np.zeros(n),where=sums>0);var=np.divide(R.T@(log*log),sums,out=np.zeros(n),where=sums>0)-mean*mean
  sig=np.where((var>=0)&(sums>0),299792.458*np.sqrt(np.maximum(var,0)),np.nan);intr=np.interp(rest,lw,lr)
  parts.append(dict(cam=cam,wave=wave,rest=rest,flux=flux,ivar=ivar,valid=valid,sigma=sig,intrinsic=intr,sums=sums))
 row={'targetid':m['targetid'],'ozdes_id':m['oz_OzDES_ID'],'z':z,'coadd_numexp':m['fibermap']['COADD_NUMEXP'],'regions':{}}
 for name,(l,h) in regions.items():
  fields={k:[] for k in ['valid','flux','ivar','sigma','intrinsic','rest']};available=0
  for part in parts:
   sel=(part['rest']>=l)&(part['rest']<h)&((part['wave']<5780) if part['cam']=='B' else ((part['wave']>=5780)&(part['wave']<7570)) if part['cam']=='R' else(part['wave']>=7570))
   available+=int(sel.sum())
   for key in fields:fields[key].extend(part[key][sel].tolist())
  fields={k:np.array(v) for k,v in fields.items()};v=fields['valid'].astype(bool);f=fields['flux'][v];iv=fields['ivar'][v];ss=fields['sigma'][v];si=fields['intrinsic'][v]
  native_step=.8/(1+z);totalwidth=native_step*available;validwidth=native_step*v.sum()
  row['regions'][name]={'native_pixels_in_region':available,'valid_pixels':int(v.sum()),'approx_native_geometric_coverage':min(1.,float(totalwidth/(h-l))),'approx_valid_coverage':min(1.,float(validwidth/(h-l))),'signed_pixel_SNR_median':None if not len(f) else float(np.median(f*np.sqrt(iv))),'signed_mean_SNR':None if not len(f) else float(f.sum()/np.sqrt((1/iv).sum())),'max_abs_pixel_SNR':None if not len(f) else float(max(abs(f*np.sqrt(iv)))),'negative_flux_pixels':int((f<0).sum()),'instrument_sigma_kms_percentiles':None if not len(ss) else np.nanpercentile(ss,[0,5,50,95,100]).tolist(),'library_sigma_kms_percentiles':None if not len(si) else np.percentile(si,[0,50,100]).tolist(),'undefined_signed_response_second_moments':int((~np.isfinite(ss)).sum()),'instrument_narrower_than_library_valid_pixels':int((ss<si).sum()),'instrument_narrower_fraction':None if not len(ss) else float(np.sum(ss<si)/np.isfinite(ss).sum())}
 sources[str(mp.relative_to(ROOT))]=sha(mp);sources[str(p.relative_to(ROOT))]=sha(p);rows.append(row)
# Additional mask diagnostics use all available FSPS nebular centres, rather than
# the old Library.lines subset restricted to five diagnostic bands.
all_lines=lib['emission_line_wavelength_A']; extra_rows=[]
for row in rows:
 a=np.load(INPUT/(row['targetid']+'.npz'));z=row['z'];before=after=high_before=high_after=0;neg_elems=all_elems=0
 for cam,lo,hi in [('B',-np.inf,5780.),('R',5780.,7570.),('Z',7570.,np.inf)]:
  w=a[cam+'_WAVELENGTH'];r=w/(1+z);f=a[cam+'_FLUX'];iv=a[cam+'_IVAR'];d=a[cam+'_RESOLUTION'].astype(float)
  good=(w>=lo)&(w<hi)&(r>=3700)&(r<4900)&(a[cam+'_MASK']==0)&np.isfinite(f)&np.isfinite(iv)&(iv>0)
  keep=good.copy()
  for line in all_lines[(all_lines>3690)&(all_lines<4910)]:keep &= np.abs(np.log(r/line))*299792.458>400
  snr=np.abs(f*np.sqrt(np.maximum(iv,0)))
  before+=int(good.sum());after+=int(keep.sum());high_before+=int(np.sum(good&(snr>=20)));high_after+=int(np.sum(keep&(snr>=20)))
  neg_elems+=int(np.sum(d[:,good]<0));all_elems+=int(d[:,good].size)
 row['common_nebular_mask400']={'valid_pixels_before':before,'retained_pixels_after':after,'abs_SNR_ge20_before':high_before,'abs_SNR_ge20_after':high_after,'resolution_negative_coefficient_fraction':neg_elems/all_elems}
summary={}
for name in regions:
 r=[x['regions'][name] for x in rows];snr=[x['signed_pixel_SNR_median'] for x in r if x['signed_pixel_SNR_median'] is not None]
 summary[name]={'hosts_with_geometric_coverage95':sum(x['approx_native_geometric_coverage']>=.95 for x in r),'hosts_with_valid_coverage95':sum(x['approx_valid_coverage']>=.95 for x in r),'hosts_with_valid_coverage95_and_signed_mean_SNR5':sum(x['approx_valid_coverage']>=.95 and x['signed_mean_SNR']>=5 for x in r),'valid_pixel_count_min_median_max':np.percentile([x['valid_pixels'] for x in r],[0,50,100]).tolist(),'median_signed_pixel_SNR_min_median_max':np.percentile(snr,[0,50,100]).tolist(),'hosts_with_any_instrument_narrower_than_library':sum(x['instrument_narrower_than_library_valid_pixels']>0 for x in r),'narrower_fraction_all_valid_pixels':sum(x['instrument_narrower_than_library_valid_pixels'] for x in r)/sum(x['valid_pixels']-x['undefined_signed_response_second_moments'] for x in r),'undefined_signed_response_second_moments':sum(x['undefined_signed_response_second_moments'] for x in r),'max_abs_pixel_SNR':max(x['max_abs_pixel_SNR'] for x in r if x['max_abs_pixel_SNR'] is not None)}
result={'status':'input_availability_and_response_moment_inventory_only_no_fits','hosts':len(rows),'multi_exposure':sum(x['coadd_numexp']>1 for x in rows),'redshift_range':[min(x['z'] for x in rows),max(x['z'] for x in rows)],'library_shape':list(lib['spectra_Lsun_per_A_per_formed_Msun'].shape),'library_wavelength_min_max':[float(min(lw)),float(max(lw))],'library_sigma_optical':np.unique(lr[(lw>3700)&(lw<6800)]).tolist(),'regions':summary,'all_FSPS_line_centres_common_region':all_lines[(all_lines>3690)&(all_lines<4910)].tolist(),'nebular_mask400':{'retained_pixels_min_median_max':np.percentile([x['common_nebular_mask400']['retained_pixels_after'] for x in rows],[0,50,100]).tolist(),'hosts_with_abs_SNR_ge20_before':sum(x['common_nebular_mask400']['abs_SNR_ge20_before']>0 for x in rows),'hosts_with_abs_SNR_ge20_after':sum(x['common_nebular_mask400']['abs_SNR_ge20_after']>0 for x in rows),'pixels_abs_SNR_ge20_before':sum(x['common_nebular_mask400']['abs_SNR_ge20_before'] for x in rows),'pixels_abs_SNR_ge20_after':sum(x['common_nebular_mask400']['abs_SNR_ge20_after'] for x in rows)},'rows':rows,'input_sha256':sources,'source_sha256':{str(Path(__file__).relative_to(ROOT)):sha(__file__)},'limits':['Coverage uses native0.8A pixels and fixed existing camera boundaries; no imputation.','SNR is a signed formal-IVAR measurement; not a host selection or age detection.','Instrument sigma is a signed-column second moment of native R; negative response wings are preserved, not a fitted Gaussian LSF or full matching operator.','No emission masking beyond release mask in this availability inventory; feature presence does not imply stellar absorption is identified.']}
(OUT/'input-inventory.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['rows','input_sha256']},indent=2))
