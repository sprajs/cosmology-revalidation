from pathlib import Path
import json,hashlib,re,csv,os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import pandas as pd
import numpy as np
ROOT=Path.cwd();OUT=ROOT/'.work/unified-cosmology/distance-ladder-overlap-screen'
a=ROOT/'.work/unified-cosmology/survey-selection/normalized/dovekie-ledger.csv';b=ROOT/'.work/unified-cosmology/inference/pantheon/Pantheon+SH0ES.dat'
d=pd.read_csv(a,dtype={'CID':str,'IAU_alias':str,'transient_alias':str}).fillna('');p=pd.read_csv(b,sep=r'\s+',dtype={'CID':str})
def norm(x):
 s=str(x).strip().lower()
 if s in {'','nan','unknown','null','-9'}:return ''
 if re.match(r'^sn[12][0-9]{3}',s):s=s[2:]
 return s
rows=[];skyonly=[]
lookup={}
for j,key in enumerate(p.CID.map(norm)):
 lookup.setdefault(key,[]).append(j)
pr=np.radians(p.RA.to_numpy());pd=np.radians(p.DEC.to_numpy())
for _,dr in d.iterrows():
 ra,dec=np.radians([float(dr.RA),float(dr.DEC)])
 angular=2*np.arcsin(np.sqrt(np.clip(np.sin((pd-dec)/2)**2+np.cos(pd)*np.cos(dec)*np.sin((pr-ra)/2)**2,0,1)))*180/np.pi*3600
 valid=(p.RA>=0)&(p.RA<360)&(p.DEC>=-90)&(p.DEC<=90)&(0<=dr.RA<360)&(-90<=dr.DEC<=90)
 aliases={norm(dr[k]):k for k in ('CID','IAU_alias','transient_alias') if norm(dr[k])}
 candidates={j for key in aliases for j in lookup.get(key,[])}
 candidates.update(np.flatnonzero(np.asarray(valid)&(angular<=1)&(np.abs(p.zHEL.to_numpy()-float(dr.zHEL))<=.001)).tolist())
 for j in sorted(candidates):
  prr=p.iloc[j]
  key=norm(prr.CID);column=aliases.get(key)
  numeric=key.isdigit();qualified=not numeric or int(prr.IDSURVEY)==int(dr.IDSURVEY)
  alias=column is not None and qualified
  sky=bool(valid.iloc[j] and angular[j]<=1)
  dz=abs(float(prr.zHEL)-float(dr.zHEL));zg=dz<=.001
  if not alias and not(sky and zg):continue
  item={'dovekie_row':int(dr.row),'dovekie_physical_ID':dr.physical_ID,'dovekie_CID':dr.CID,'dovekie_IDSURVEY':int(dr.IDSURVEY),'pantheon_row':int(j),'pantheon_CID':prr.CID,'pantheon_IDSURVEY':int(prr.IDSURVEY),'alias_column':column or '', 'numeric_CID_survey_qualified':bool(numeric and alias),'angular_separation_arcsec':float(angular[j]),'absolute_delta_zHEL':dz,'sky_gate':sky,'redshift_gate':zg,'IS_CALIBRATOR':int(prr.IS_CALIBRATOR),'USED_IN_SH0ES_HF':int(prr.USED_IN_SH0ES_HF),'pantheon_PKMJD':float(prr.PKMJD),'pantheon_zHD_gt_0_01':bool(prr.zHD>.01)}
  if alias:item['status']='exact_alias_sky_z' if sky and zg else 'exact_alias_failed_corroboration';rows.append(item)
  else:item['status']='sky_z_only_epoch_unverified';skyonly.append(item)
for name,x in [('alias-candidates.csv',rows),('sky-only-unverified.csv',skyonly)]:
 with (OUT/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(x[0]) if x else ['status']);w.writeheader();w.writerows(x)
accepted=[r for r in rows if r['status']=='exact_alias_sky_z']
def counts(x):return {'lightcurve_rows':len(x),'dovekie_rows':len({r['dovekie_row']for r in x}),'dovekie_events':len({r['dovekie_physical_ID']for r in x}),'pantheon_CID_names':len({r['pantheon_CID']for r in x})}
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
result={'status':'bounded_candidate_inventory_not_crosscovariance','gates':{'sky_arcsec':1.,'delta_zHEL':.001,'alias':'Exact case-normalized releasednames; removeSNprefixonlybefore4digityear. NumericCIDrequires matchingIDSURVEY; never global numericmatch.'},'exact_alias_candidates':counts(rows),'accepted_exact_alias_sky_z':counts(accepted),'accepted_calibrators':counts([r for r in accepted if r['IS_CALIBRATOR']]),'accepted_SH0ES_HF':counts([r for r in accepted if r['USED_IN_SH0ES_HF']]),'accepted_Pantheon_cosmology_zcut':counts([r for r in accepted if r['pantheon_zHD_gt_0_01']]),'alias_failed_corroboration':counts([r for r in rows if r['status']!='exact_alias_sky_z']),'sky_only_epoch_unverified':counts(skyonly),'input_sha256':{str(a.relative_to(ROOT)):sha(a),str(b.relative_to(ROOT)):sha(b)},'source_sha256':sha(Path(__file__)),'outputs':{x.name:sha(x)for x in OUT.glob('*.csv')},'limits':['Every Pantheon row retained separately, including repeated measurements.','Sky-only candidates unaccepted without independentepochcheck.','A1arcsec gate may reject genuine aliases because releasedcoordinatesare rounded; allfailedpairsretained.','No likelihoods combined; absenceofeventoverlapdoesnotestablishindependenceofcalibrationorothercovariance.']}
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
