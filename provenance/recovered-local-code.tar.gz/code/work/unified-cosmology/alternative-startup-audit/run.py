from pathlib import Path
import sys,json,re,datetime,hashlib
import numpy as np
ROOT=Path.cwd();WORK=ROOT/'.work/unified-cosmology/alternative-startup-audit'
sys.path.insert(0,str(ROOT/'studies/unified_cosmology/code/inference'))
sys.path.insert(0,str(ROOT/'studies/unified_cosmology/code/external_probes'))
from spectral_surrogate import coordinates,polynomial,SPECTRA
from modern_adapter import modern_info
import camb
camb.get_results=lambda *a,**k:(_ for _ in ()).throw(RuntimeError('Native spectra prohibited'))
mod=np.load(ROOT/'.work/unified-cosmology/inference/surrogate/cubic-0509.npz');extra=modern_info()['theory']['camb']['extra_args']
result={}
for evolution in ['linear','smooth01']:
 folder=ROOT/f'.work/unified-cosmology/inference/modern-cpl-{evolution}-dovekie-official_planck-fast-metropolis-scale1p6-7316f91342ee'
 log=(ROOT/f'.work/unified-cosmology/modern-{evolution}-scale16.log').read_text();(WORK/f'{evolution}.log').write_text(log)
 progress={};initial={}
 for line in log.splitlines():
  m=re.match(r'\[(\d+) : mcmc\] Initial point: (.*)',line)
  if m:initial[int(m[1])]={k:float(v) for k,v in re.findall(r'(\w+):([+\-\d.eE]+)',m[2])}
  m=re.match(r'\[(\d+) : mcmc\] Progress @ (.*?) : (\d+) steps taken(.*)',line)
  if m:
   row={'time':m[2],'steps':int(m[3]),'tail':m[4]};progress.setdefault(int(m[1]),[]).append(row)
 pts=[];chains={}
 for rank,point in initial.items():pts.append({'kind':'logged_initial_rounded','rank':rank,'point':point})
 for path in sorted(folder.glob('chain.[0-9]*.txt')):
  text=path.read_text();lines=text.splitlines();names=lines[0].lstrip('# ').split();good=[l for l in lines[1:] if len(l.split())==len(names)]
  if not good:continue
  snap=WORK/f'{evolution}-{path.name}';snap.write_text(lines[0]+'\n'+'\n'.join(good)+'\n')
  arr=np.loadtxt(snap,ndmin=2);rank=int(path.name.split('.')[1])-1;chains[str(rank)]={'rows':len(arr),'frequency_sum':float(arr[:,0].sum())}
  indices=np.unique(np.linspace(0,len(arr)-1,min(25,len(arr))).astype(int))
  for i in indices:
   point={k:float(arr[i,names.index(k)]) for k in ['H0','ombh2','omch2','logA','ns','tau','w','wa']}
   pts.append({'kind':'stored_postburn_row','rank':rank,'row':int(i),'point':point})
 for r in pts:
  p=r['point'];phys={k:p[k] for k in ['H0','ombh2','omch2','ns','tau','w','wa']};phys['As']=1e-10*np.exp(p['logA'])
  pars=camb.set_params(**phys,**extra);bg=camb.get_background(pars);x=np.linalg.solve(mod['coordinate_cholesky'],coordinates(pars,bg)-mod['centre'])
  r['x']=x.tolist();r['max_abs_whitened']=float(max(abs(x)))
  flat=polynomial(x,mod['exponents'])@mod['coefficients']*mod['output_scale'];cl=flat.reshape(5,int(mod['length']))
  r['negative_spectra']=[key for j,key in enumerate(SPECTRA) if key in ['tt','ee','pp'] and (cl[j,2:]<=0).any()]
  r['nonfinite_spectra']=bool(not np.isfinite(cl).all())
 rates={}
 for rank,rr in progress.items():
  last=rr[-1];end=datetime.datetime.fromisoformat(last['time']);recent=[r for r in rr if (end-datetime.datetime.fromisoformat(r['time'])).total_seconds()<=150]
  first=recent[0];dt=(end-datetime.datetime.fromisoformat(first['time'])).total_seconds();steps=last['steps']-first['steps']
  rates[str(rank)]={'last':last,'last_window_seconds':dt,'last_window_steps':steps,'seconds_per_step':dt/steps if steps else None}
 result[evolution]={'progress':rates,'stored_chains':chains,'points':pts,'raw_log_sha256':hashlib.sha256(log.encode()).hexdigest(),'limits':'Current accepted burn-in states are not persisted. Logged initial coordinates are rounded; saved postburn rows are sampled evenly by row, not posterior-weighted. No direct native-call counter is exposed in these logs.'}
(WORK/'result.json').write_text(json.dumps(result,indent=2)+'\n')
for name,res in result.items():
 print(name,'rates',json.dumps(res['progress']))
 for rank in range(4):
  p=[r for r in res['points'] if r['rank']==rank];i=[r for r in p if r['kind']=='logged_initial_rounded'];s=[r for r in p if r['kind']=='stored_postburn_row']
  print(rank,'initial',i[0]['max_abs_whitened'] if i else None,'stored',len(s),'max',max((r['max_abs_whitened'] for r in s),default=None),'outside',sum(r['max_abs_whitened']>4 for r in s),'neg',sum(bool(r['negative_spectra']) for r in p),'latest',s[-1]['x'] if s else None)
