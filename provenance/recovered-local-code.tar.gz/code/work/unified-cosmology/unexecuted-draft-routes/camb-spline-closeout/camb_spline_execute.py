"""Bounded three-implementation CAMB audit; immutable attempts and no retry."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import copy
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np

import camb_spline_audit as preparation
import native_accuracy_runtime as rt
from target_identity import canonical

ROOT=rt.ROOT
HERE=Path(__file__).resolve().parent
DESIGN=HERE/'camb-spline-execution-design.json'
VALIDATION=ROOT/'studies/unified_cosmology/results/inference/camb-spline-execution-validation.json'


def sources():
    value=preparation.sources()
    for path in [Path(__file__),DESIGN,HERE/'camb_spline_execute_validate.py',Path(rt.__file__)]:
        value[rt.relative(path)]=rt.digest(path)
    return value


def verify_preparation(path,fresh=True):
    plan=rt.read(path)
    assert plan['identity']==rt.identity({k:v for k,v in plan.items() if k not in ('identity','payload_sha256')})
    assert plan['status']=='prepared_no_physical_calls' and plan['physical_calls']==0
    assert plan['source_sha256']==preparation.sources()
    rt.verify_hashes(plan['source_sha256']);rt.verify_hashes(plan['input_sha256'])
    paths=[ROOT/p for p in plan['input_sha256'] if p.endswith('/build-record.json')]
    assert len(paths)==1;preparation.verify_build(paths[0])
    with rt.guards_without_physics():
        if fresh:
            evidence,_=rt.evidence(ROOT/plan['evidence']['screen_path'],ROOT/plan['evidence']['review_path'])
            assert evidence==plan['evidence']
        one,two=rt.contracts.configuration_pair(plan['evidence']['settings'])
    assert canonical(one)==plan['configurations']['1'] and canonical(two)==plan['configurations']['2']
    expected=[]
    for arm in ['original_wheel','source_control','source_fixed']:
        for accuracy in [1,2]:
            for ordinal,audit in enumerate([0,31]):
                ref=plan['evidence']['references'][audit]
                expected.append(dict(index=len(expected),arm=arm,accuracy=accuracy,ordinal=ordinal,
                                     audit_index=audit,parent_index=ref['parent_index'],point=ref['point']))
    assert plan['requests']==expected
    return plan,{'1':one,'2':two}


def validate_guard():
    value=json.loads(VALIDATION.read_text())
    assert value['status']=='passed_synthetic_camb_spline_execution_validation' and value['physical_calls']==0
    assert value['source_sha256']==sources()
    return {rt.relative(VALIDATION):rt.digest(VALIDATION)}


def prepare(prepared,work):
    assert not work.exists(),'Fresh execution namespace required.'
    original,_=verify_preparation(prepared)
    validation=validate_guard()
    value={'schema':'camb166-spline-execution-plan-v1','design':json.loads(DESIGN.read_text()),
           'preparation_path':rt.relative(prepared),'preparation_sha256':rt.digest(prepared),
           'preparation_identity':original['identity'],'source_sha256':sources(),'validation_sha256':validation,
           'requests':original['requests'],'groups':[{'worker':i,'arm':arm,'accuracy':accuracy} for i,(arm,accuracy) in enumerate(
               ( (arm,accuracy) for arm in ['original_wheel','source_control','source_fixed'] for accuracy in [1,2]))]}
    value['identity']=rt.identity(value);work.mkdir(parents=True);rt.write_new(work/'plan.json',value)
    return value


def verify(work,fresh=True):
    plan=rt.read(Path(work)/'plan.json')
    assert plan['identity']==rt.identity({k:v for k,v in plan.items() if k not in ('identity','payload_sha256')})
    assert plan['source_sha256']==sources() and plan['design']==json.loads(DESIGN.read_text())
    assert plan['validation_sha256']==validate_guard()
    path=ROOT/plan['preparation_path'];assert rt.digest(path)==plan['preparation_sha256']
    old,info=verify_preparation(path,fresh)
    assert plan['preparation_identity']==old['identity'] and plan['requests']==old['requests']
    return plan,old,info


def import_identity(old,arm):
    import camb
    package=Path(camb.__file__).resolve().parent
    binary=package/'camblib.so'
    impl=old['arms'][arm]['implementation']
    if arm=='original_wheel':
        path=next(p for p in impl['installed_file_sha256'] if p.endswith('/camb/camblib.so'))
        expected=impl['installed_file_sha256'][path]
    else:path=impl['binary_path'];expected=impl['binary_sha256']
    assert binary==ROOT/path and rt.digest(binary)==expected,'Wrong CAMB implementation imported.'
    assert camb.__version__=='1.6.6'
    return {'arm':arm,'package_path':rt.relative(package),'binary_path':path,'binary_sha256':expected,
            'python_executable':sys.executable,'python_realpath':str(Path(sys.executable).resolve()),
            'camb_version':camb.__version__,'versions':{k:importlib.metadata.version(k) for k in old['evidence']['versions']}}


def record_paths(work,index):
    base=Path(work)/f'{index:02d}'
    return {kind:base.with_suffix(suffix) for kind,suffix in [('record','.json'),('ticket','.ticket.json'),('claim','.claim.json'),('spectrum','.npz')]}


def binding(plan,request):return {'execution_identity':plan['identity'],'request':request}


def difference(value,raw,reference,reference_raw=None):
    assert set(value['loglikes'])==set(reference['loglikes']) and set(value['derived'])==set(reference['derived'])
    out={'component_loglike_difference':{k:value['loglikes'][k]-v for k,v in reference['loglikes'].items()},
         'logposterior_difference':value['logpost']-reference['logpost'],
         'prior_sum_difference':sum(value['logpriors'])-sum(reference['logpriors']),
         'derived_difference':{k:value['derived'][k]-v for k,v in reference['derived'].items()}}
    out['density_accounting_closure']=out['logposterior_difference']-sum(out['component_loglike_difference'].values())-out['prior_sum_difference']
    assert abs(out['density_accounting_closure'])<1e-8
    assert abs(out['prior_sum_difference'])<1e-8,'Fixed point/prior changed.'
    if reference_raw is not None:
        assert canonical(value['metadata'])==canonical(reference['metadata'])
        assert np.array_equal(raw['ell'],reference_raw['ell'])
        mask=raw['ell']>=2;metric={}
        for key in rt.contracts.SPECTRA:
            delta=raw[key]-reference_raw[key]
            metric[key]={'peak_normalized_max_absolute':float(np.max(abs(delta[mask]))/max(np.max(abs(reference_raw[key][mask])),1e-300))}
            if key=='te':
                denom=np.sqrt(np.maximum(reference_raw['tt']*reference_raw['ee'],0));eligible=mask&(denom>0)
            else:denom=reference_raw[key];eligible=mask&(denom>0)
            metric[key]['positive_reference_support_count']=int(np.sum(eligible))
            metric[key]['pointwise_max_absolute']=float(np.max(abs(delta[eligible]/denom[eligible]))) if np.any(eligible) else None
        out['spectra']=metric
        out['background_H_relative_max']=float(np.max(abs(np.array(value['H'])/reference['H']-1)))
    return out


def original_reference(old,request):
    ref=old['evidence']['references'][request['audit_index']]
    if request['accuracy']==2:return rt.old_reference(ref)
    row=rt.original.sealed_read(ROOT/ref['native_record_path'])
    assert row['point']==request['point'] and rt.digest(ROOT/ref['native_record_path'])==ref['native_record_sha256']
    value={'logpost':row['exact_logpost'],'loglikes':row['exact_loglikes'],'derived':row['derived'],
           'logpriors':[row['exact_logpost']-sum(row['exact_loglikes'].values())]}
    return value,None


def worker(work,worker_index):
    work=Path(work);plan,old,infos=verify(work);rt.verify_environment()
    group=plan['groups'][worker_index];assert group['worker']==worker_index
    requests=[r for r in plan['requests'] if (r['arm'],r['accuracy'])==(group['arm'],group['accuracy'])]
    assert [r['ordinal'] for r in requests]==[0,1]
    imported=import_identity(old,group['arm'])
    assert imported['versions']==old['evidence']['versions']
    rt.write_new(work/f'worker-{worker_index}-imports.json',{'execution_identity':plan['identity'],'pid':os.getpid(),'import':imported})
    started=time.monotonic();model=None;completed=[];failed=None
    try:
        model=rt.construct_model(infos[str(group['accuracy'])]);construction=time.monotonic()-started
        for request in requests:
            paths=record_paths(work,request['index']);key=binding(plan,request)
            assert rt.read(paths['ticket'])['binding']==key
            assert not any(paths[k].exists() for k in ['claim','record','spectrum'])
            rt.write_new(paths['claim'],{'binding':key,'pid':os.getpid(),'worker':worker_index})
            row={'binding':key,'point':request['point'],'import':imported,'pid':os.getpid(),
                 'model_construction_seconds':construction,'ticket_sha256':rt.digest(paths['ticket']),
                 'claim_sha256':rt.digest(paths['claim']),'native_logposterior_invocations':0}
            timer=time.monotonic()
            try:
                row['native_logposterior_invocations']=1
                value,raw=rt.native_value(model,request['point'])
                assert all(value['metadata']['finalized_theory_extra_args'][k]==request['accuracy'] for k in ['AccuracyBoost','lSampleBoost','lAccuracyBoost'])
                row.update(value=value,status='finite_implementation_comparison')
                if request['arm']=='original_wheel':
                    reference,reference_raw=original_reference(old,request)
                    row['original_record_replay']=difference(value,raw,reference,reference_raw)
                rt.save_spectrum(paths['spectrum'],raw)
                row.update(spectrum_path=rt.relative(paths['spectrum']),spectrum_sha256=rt.digest(paths['spectrum']))
            except Exception as error:
                row.update(status='failed_implementation_evaluation',error_type=type(error).__name__,error=str(error))
            row['seconds']=time.monotonic()-timer;rt.write_new(paths['record'],row);completed.append(request['index'])
            if row['status']!='finite_implementation_comparison':failed=request['index'];break
    except Exception as error:
        failed={'error_type':type(error).__name__,'error':str(error)}
    finally:
        if model is not None:model.close()
        try:verify(work,fresh=False);assert import_identity(old,group['arm'])==imported
        except Exception as error:failed={'end_identity_failure':str(error),'previous_failure':failed}
        rt.write_new(work/f'worker-{worker_index}.json',{'execution_identity':plan['identity'],'pid':os.getpid(),
            'group':group,'completed_requests':completed,'failure':failed,'seconds':time.monotonic()-started})
    return failed is None


def collect(work):
    work=Path(work);plan,old,_=verify(work)
    manifest=work/'output-hashes.json'
    if manifest.exists():rt.verify_hashes(rt.read(manifest)['files'])
    rows=[];lookup={};files={}
    for request in plan['requests']:
        paths=record_paths(work,request['index'])
        if paths['record'].exists():
            row=rt.read(paths['record']);assert row['binding']==binding(plan,request) and row['point']==request['point']
            for kind in ['ticket','claim']:
                assert rt.read(paths[kind])['binding']==binding(plan,request) and row[kind+'_sha256']==rt.digest(paths[kind])
            if row['status']=='finite_implementation_comparison':
                assert row['native_logposterior_invocations']==1
                assert row['spectrum_path']==rt.relative(paths['spectrum']) and row['spectrum_sha256']==rt.digest(paths['spectrum'])
                raw=rt.load_spectrum(paths['spectrum']);lookup[(request['arm'],request['accuracy'],request['audit_index'])]=(row['value'],raw)
        else:
            claimed=paths['claim'].exists()
            row={'binding':binding(plan,request),'status':'incomplete_attempt_no_retry',
                 'native_logposterior_invocations':0,'unknown_invocation_count':claimed,'known_unstarted':not claimed}
        rows.append(row)
        files.update({rt.relative(p):rt.digest(p) for p in paths.values() if p.exists()})
    process_ok=True
    for group in plan['groups']:
        n=group['worker'];receipt=work/f'worker-{n}.json';process=work/f'worker-{n}-process.json';imports=work/f'worker-{n}-imports.json'
        if not all(p.exists() for p in [receipt,process,imports]):process_ok=False;continue
        r=rt.read(receipt);p=rt.read(process);i=rt.read(imports)
        assert all(x['execution_identity']==plan['identity'] for x in [r,p,i])
        assert r['pid']==p['pid']==i['pid'] and r['group']==group
        assert p['log_sha256']==rt.digest(ROOT/p['log_path'])
        expected=[x['index'] for x in plan['requests'] if (x['arm'],x['accuracy'])==(group['arm'],group['accuracy'])]
        process_ok &= p['returncode']==0 and r['failure'] is None and r['completed_requests']==expected
        files.update({rt.relative(x):rt.digest(x) for x in [receipt,process,imports,ROOT/p['log_path']]})
    comparisons=[]
    for index in [0,31]:
        for accuracy in [1,2]:
            for high,low in [('source_control','original_wheel'),('source_fixed','source_control')]:
                a=(high,accuracy,index);b=(low,accuracy,index)
                if a in lookup and b in lookup:comparisons.append({'contrast':high+' minus '+low,'accuracy':accuracy,'audit_index':index,
                    'difference':difference(*lookup[a],*lookup[b])})
        for arm in ['original_wheel','source_control','source_fixed']:
            a=(arm,2,index);b=(arm,1,index)
            if a in lookup and b in lookup:
                # Accuracy metadata intentionally differ here; match all other finalized settings.
                va,ra=copy.deepcopy(lookup[a]);vb,rb=lookup[b]
                for key in ['AccuracyBoost','lSampleBoost','lAccuracyBoost']:va['metadata']['finalized_theory_extra_args'][key]=1
                comparisons.append({'contrast':'accuracy2 minus accuracy1','arm':arm,'audit_index':index,
                                    'difference':difference(va,ra,vb,rb)})
    good=process_ok and len(lookup)==12
    result={'schema':'camb166-spline-comparison-result-v1','status':'completed_bounded_implementation_comparison' if good else 'incomplete_or_failed_implementation_comparison',
            'execution_identity':plan['identity'],'preparation_identity':plan['preparation_identity'],
            'source_sha256':plan['source_sha256'],'validation_sha256':plan['validation_sha256'],
            'requests':rows,'comparisons':comparisons,'finite_requests':len(lookup),
            'known_full_density_invocations':sum(x['native_logposterior_invocations'] for x in rows),
            'unknown_invocation_requests':sum(bool(x.get('unknown_invocation_count')) for x in rows),
            'known_unstarted':sum(bool(x.get('known_unstarted')) for x in rows),
            'posterior_qualified':False,'interpretation':'Two fixed-point implementation diagnostics only; no convergence or posterior qualification.',
            'input_sha256':rt.merge(old['input_sha256'],{rt.relative(work/'plan.json'):rt.digest(work/'plan.json'),**files})}
    return result,files


def execute(work,workers):
    work=Path(work);plan,old,_=verify(work);rt.verify_environment()
    assert 1<=workers<=2
    assert set(p.name for p in work.iterdir())=={'plan.json'},'Existing attempt cannot be retried.'
    rt.write_new(work/'execution.json',{'execution_identity':plan['identity'],'coordinator_pid':os.getpid(),'workers':workers,'no_retry':True})
    for request in plan['requests']:rt.write_new(record_paths(work,request['index'])['ticket'],{'binding':binding(plan,request)})
    def run(group):
        n=group['worker'];log=work/f'worker-{n}.log'
        command=[str(ROOT/old['arms'][group['arm']]['python']),str(Path(__file__).resolve()),'worker','--work',str(work),'--worker',str(n)]
        with log.open('x') as stream:
            process=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT,env=os.environ.copy())
            code=process.wait()
        rt.write_new(work/f'worker-{n}-process.json',{'execution_identity':plan['identity'],'pid':process.pid,'returncode':code,
            'command':command,'log_path':rt.relative(log),'log_sha256':rt.digest(log)})
    with ThreadPoolExecutor(max_workers=workers) as pool:list(pool.map(run,plan['groups']))
    return report(work)


def report(work,output=None):
    work=Path(work);value,files=collect(work)
    path=work/'output-hashes.json'
    if not path.exists():rt.write_new(path,{'execution_identity':value['execution_identity'],'files':files})
    else:assert rt.read(path)['files']==files
    rt.verify_hashes(value['source_sha256']);rt.verify_hashes(value['validation_sha256']);rt.verify_hashes(value['input_sha256'])
    if output is not None:
        output=Path(output)
        if output.exists():assert json.loads(output.read_text())==value,'Immutable result differs.'
        else:output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    return value


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['prepare','execute','worker','report'])
    parser.add_argument('--prepared',type=Path);parser.add_argument('--work',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=1);parser.add_argument('--worker',type=int);parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.action=='prepare':value=prepare(args.prepared.resolve(),args.work.resolve());print(json.dumps({'identity':value['identity'],'physical_calls':0}))
    elif args.action=='worker':sys.exit(0 if worker(args.work,args.worker) else 1)
    else:
        value=execute(args.work,args.workers) if args.action=='execute' else report(args.work,args.output)
        if args.action=='execute' and args.output:value=report(args.work,args.output)
        print(json.dumps({'status':value['status'],'finite_requests':value['finite_requests'],'known_full_density_invocations':value['known_full_density_invocations']}))
