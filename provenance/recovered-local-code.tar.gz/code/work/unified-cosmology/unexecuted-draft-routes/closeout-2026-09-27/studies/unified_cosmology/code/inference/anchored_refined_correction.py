"""Explicit refined-anchored native2 correction; no old-schema routing."""
from __future__ import annotations
import argparse
import copy
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import time
import zipfile

import numpy as np

import anchored_refined_sampling as s
import anchored_correction as old
import native_accuracy_runtime as rt
from diagnostics import check_mpi
from exact_correction import summarize
from target_identity import canonical

HERE=s.HERE;ROOT=s.ROOT
DESIGN=HERE/'anchored-refined-correction-design.json'
VALIDATION=ROOT/'studies/unified_cosmology/results/inference/anchored-refined-correction-validation.json'
PLAN_SCHEMA='anchored-refined-native2-plan-v1'
RECORD_SCHEMA='anchored-refined-native2-point-v1'
SUMMARY_SCHEMA='anchored-refined-native2-summary-v1'


def dependencies():
    value=rt.merge(s.dependencies(),rt.sources())
    for path in [Path(__file__),DESIGN,HERE/'anchored_refined_measurement.py',
                 HERE/'anchored_refined_correction_validate.py',HERE/'anchored_correction.py',
                 HERE/'anchored-sampling-design.json',HERE/'diagnostics.py',HERE/'measurement_summary.py']:
        value[s.relative(path)]=s.digest(path)
    return value


def validation_guard():
    value=json.loads(VALIDATION.read_text())
    assert value['status']=='passed_synthetic_refined_anchored_native2_validation'
    assert value['source_sha256']==dependencies() and value['physical_calls']==0
    return {s.relative(VALIDATION):s.digest(VALIDATION)}


def camb_implementation():
    spec=json.loads(DESIGN.read_text())['CAMB_runtime']
    assert importlib.metadata.version('camb')==spec['version']
    module=Path(importlib.util.find_spec('camb').origin).resolve()
    return verify_camb_payload(ROOT/spec['reference_environment'],ROOT/spec['wheel_path'],spec['wheel_sha256'],module)


def verify_camb_payload(reference,wheel,expected,module):
    """Exact original wheel payload, including binary and runtime data."""
    sites=list((Path(reference)/'lib').glob('python*/site-packages'));assert len(sites)==1
    site=sites[0].resolve()
    assert Path(module).resolve()==site/'camb/__init__.py','Wrong CAMB import path; same version is insufficient.'
    assert s.digest(wheel)==expected
    bound={str(Path(wheel).resolve()):expected}
    with zipfile.ZipFile(wheel) as archive:
        names=[n for n in archive.namelist() if not n.endswith('/') and not n.endswith('/RECORD')]
        assert len(names)==len(set(names))==41
        assert 'camb/camblib.so' in names
        for name in names:
            assert not Path(name).is_absolute() and '..' not in Path(name).parts
            path=site/name
            assert path.is_file() and path.read_bytes()==archive.read(name),'Changed CAMB wheel payload: '+name
            bound[str(path)]=s.digest(path)
    return bound


def qualified_chains(folder,diagnostics_path):
    folder=Path(folder).resolve();diagnostics_path=Path(diagnostics_path).resolve()
    manifests=[json.loads((folder/f'run-{i}.json').read_text()) for i in range(4)];first=manifests[0]
    for i,m in enumerate(manifests):
        assert m['schema']==s.SCHEMA and m['rank']==i and m['MPI_size']==4
        for key in ('arguments','target_identity','sampler_identity','sampler_source_sha256','proposal','pilot_evidence','validation','producer_validation'):
            assert m[key]==first[key]
    inputs=s.verify_manifest(first)
    assert first['arguments']['native_accuracy']==first['target_identity']['native_accuracy']==2
    completed=old.completion_evidence(folder,first)
    check=json.loads(diagnostics_path.read_text())
    assert check['status']=='passed' and not check['failed_gates']
    assert check['discard_fraction_after_sampler_burnin']==.3 and check['independent_chains']==4
    assert check['code_sha256']==s.digest(HERE/'diagnostics.py')
    s.verify_hashes(check['input_sha256']);assert check_mpi(folder,.3)==check
    paths=sorted(folder.glob('chain.[0-9]*.txt'));assert len(paths)==4
    assert set(check['input_sha256'])=={s.relative(p) for p in paths}
    info=s.configuration(first['arguments']);native=s.configuration(first['arguments'],native=True)
    assert canonical(native)==first['target_identity']['native_configuration']
    assert all(native['theory']['camb']['extra_args'][k]==2 for k in ('AccuracyBoost','lAccuracyBoost','lSampleBoost'))
    names=[k for k,v in info['params'].items() if isinstance(v,dict) and 'prior' in v]
    selected=old.select_points(paths,names,check,json.loads(DESIGN.read_text())['points'])
    assert selected['groups']==np.repeat(np.arange(4),500).tolist()
    # Same-chain repeated integer slots are valid; their exact values stay.
    for group in range(4):
        ids=np.flatnonzero(np.asarray(selected['groups'])==group)
        for left,right in zip(ids,ids[1:]):
            a,b=selected['locations'][left],selected['locations'][right]
            assert a['expanded_index']<=b['expanded_index'] and a['row']<=b['row']
            if a['expanded_index']==b['expanded_index']:
                assert selected['points'][left]==selected['points'][right]
                assert selected['stored_logposts'][left]==selected['stored_logposts'][right]
    inputs=rt.merge(inputs,check['input_sha256'],completed['input_sha256'],
        {s.relative(p):s.digest(p) for p in [diagnostics_path,*[folder/f'run-{i}.json' for i in range(4)]]},
        first['pilot_evidence']['input_sha256'])
    # Explicit transition-proposal files were freshly loaded by verify_manifest.
    proposal=first['proposal']
    for pathkey,hashkey in [('proposal_file','proposal_sha256'),('proposal_record_path','proposal_record_sha256')]:
        path=Path(proposal[pathkey]);path=path if path.is_absolute() else ROOT/path
        assert s.digest(path)==proposal[hashkey];inputs=rt.merge(inputs,{s.relative(path):proposal[hashkey]})
    return first,check,completed,selected,inputs,native


def make_plan(folder,diagnostics,workers):
    assert isinstance(workers,int) and 1<=workers<=json.loads(DESIGN.read_text())['workers_maximum']
    manifest,check,completed,selected,inputs,native=qualified_chains(folder,diagnostics)
    bound=dependencies();validation=validation_guard();implementation=camb_implementation()
    requests=[];ordinals=[0]*workers
    for i,point in enumerate(selected['points']):
        worker=i%workers;ordinal=ordinals[worker];ordinals[worker]+=1
        requests.append({'index':i,'point':point,'group':selected['groups'][i],
             'location':selected['locations'][i],'stored_logpost':selected['stored_logposts'][i],
             'origin':'persistent_native','worker':worker,'ordinal':ordinal})
    target={'schema':'anchored-refined-native2-density-v1','native_configuration':canonical(native),
            'parent_proposal_target_identity':manifest['target_identity']['identity'],
            'CAMB_implementation_sha256':implementation,'source_sha256':bound,
            'scientific_priors_unchanged':True}
    numerical_id=s.identity(target)
    value={'schema':PLAN_SCHEMA,'kind':'anchored_refined_native2_correction','design':json.loads(DESIGN.read_text()),
        'chain_folder':s.relative(folder),'diagnostics_path':s.relative(diagnostics),'manifest':manifest,
        'sampler_completion':completed,'diagnostics':check,'selected':selected,'requests':requests,'workers':workers,
        'input_sha256':inputs,'source_sha256':bound,'validation_sha256':validation,
        'numerical_target':target,'numerical_target_identity':numerical_id,
        'pilot_tolerances':json.loads(DESIGN.read_text())['repeated_point_tolerances']}
    value['identity']=rt.identity(value)
    return value,native


def prepare(folder,diagnostics,work,workers=4):
    with rt.guards_without_physics():value,_=make_plan(Path(folder).resolve(),Path(diagnostics).resolve(),workers)
    work=Path(work).resolve();assert work.is_relative_to(ROOT/'.work') and not work.exists()
    work.mkdir(parents=True);rt.write_new(work/'plan.json',value)
    return value


def verify_plan(path):
    plan=rt.read(path);assert plan['schema']==PLAN_SCHEMA
    with rt.guards_without_physics():
        rebuilt,native=make_plan(ROOT/plan['chain_folder'],ROOT/plan['diagnostics_path'],plan['workers'])
    assert rt.plain(plan)==rebuilt,'Parent, target, chain or implementation identity changed.'
    return plan,native


def density(native,proposal,stored,design):
    assert set(native['loglikes'])==set(proposal['loglikes'])
    values=[native['logpost'],proposal['logpost'],*native['loglikes'].values(),*proposal['loglikes'].values(),
            *native['logpriors'],*proposal['logpriors'],*native['derived'].values()]
    assert np.isfinite(values).all()
    tolerance=design['density_absolute_tolerance']
    np0=sum(native['logpriors']);pp0=sum(proposal['logpriors'])
    checks={'native_accounting':float(native['logpost']-sum(native['loglikes'].values())-np0),
            'proposal_accounting':float(proposal['logpost']-sum(proposal['loglikes'].values())-pp0),
            'prior_difference':float(np0-pp0),
            'stored_proposal_difference':float(proposal['logpost']-stored)}
    failed=[key for key,value in checks.items() if abs(value)>(design['stored_proposal_absolute_tolerance'] if key=='stored_proposal_difference' else tolerance)]
    return {'exact_logpost':native['logpost'],'exact_loglikes':native['loglikes'],
            'exact_logpriors':native['logpriors'],'derived':native['derived'],
            'proposal_logpost':proposal['logpost'],'proposal_loglikes':proposal['loglikes'],
            'proposal_logpriors':proposal['logpriors'],'stored_chain_logpost':stored,
            'log_weight':float(native['logpost']-proposal['logpost']),
            'density_checks':checks,'failed_checks':failed}


def native_metadata(value,configuration):
    actual=value['metadata'];extra=actual['finalized_theory_extra_args']
    declared=configuration['theory']['camb']['extra_args']
    assert actual['units']=='FIRASmuK2' and actual['ell_factor'] is False
    assert actual['pp']=='dimensionless C_phi_phi' and actual['CAMB_Params_max_l']>0
    assert set(declared)-set(extra)<={'halofit_version'}
    for key,wanted in declared.items():
        if key=='halofit_version' and key not in extra:continue
        if key=='lmax':assert extra[key]>=wanted
        else:assert canonical(extra[key])==canonical(wanted)
    assert all(extra[k]==2 for k in ('AccuracyBoost','lAccuracyBoost','lSampleBoost'))
    assert set(value['loglikes'])==set(configuration['likelihood'])


def worker(work,worker_id):
    work=Path(work).resolve();plan,native=verify_plan(work/'plan.json');s.runtime();rt.verify_environment()
    requests=[r for r in plan['requests'] if r['worker']==worker_id]
    assert requests and [r['ordinal'] for r in requests]==list(range(len(requests)))
    assert not (work/f'worker-{worker_id}.json').exists()
    info=s.configuration(plan['manifest']['arguments'])
    from independence_runtime import native_initialize
    initialization_claim=work/f'worker-{worker_id}-initialization.claim.json'
    rt.write_new(initialization_claim,{'plan_identity':plan['identity'],'pid':os.getpid(),'worker':worker_id})
    started=time.monotonic();initial=native_initialize(info)
    initialpath=work/f'worker-{worker_id}-initialization.json'
    rt.write_new(initialpath,{'plan_identity':plan['identity'],'explicit_native_initialization_calls':1,
        'initialization':initial,'claim_sha256':s.digest(initialization_claim)})
    exact=rt.construct_model(native)
    from cobaya.model import get_model
    proposal=get_model(info);seen={};completed=[];failed=None
    try:
        for request in requests:
            paths=rt.request_paths(work,request['index']);binding=rt.request_identity(plan,request)
            assert rt.read(paths['ticket'])['binding']==binding
            assert not any(paths[k].exists() for k in ('claim','record','spectrum'))
            rt.write_new(paths['claim'],{'binding':binding,'worker':worker_id,'pid':os.getpid(),'ordinal':request['ordinal']})
            row={'schema':RECORD_SCHEMA,'binding':binding,'index':request['index'],'point':request['point'],
                'group':request['group'],'location':request['location'],'origin':'persistent_native',
                'worker':worker_id,'pid':os.getpid(),'ordinal':request['ordinal'],
                'numerical_target_identity':plan['numerical_target_identity'],
                'ticket_sha256':s.digest(paths['ticket']),'claim_sha256':s.digest(paths['claim']),
                'initialization_sha256':{s.relative(initialpath):s.digest(initialpath)}}
            ni=qi=0;tick=time.monotonic()
            try:
                s.verify_hashes(plan['source_sha256'])
                ni=1;value,raw=rt.native_value(exact,request['point'])
                native_metadata(value,native)
                before=int(proposal.theory['spectral_surrogate'].exact_calls)
                failure_path=s.proposal.failure_log_path(plan['manifest']['arguments'])
                before_log=failure_path.read_bytes() if failure_path.exists() else b''
                qi=1;q=proposal.logposterior(request['point'],cached=False)
                after_log=failure_path.read_bytes() if failure_path.exists() else b''
                assert after_log==before_log,'Proposal CAMB fallback recorded a failure.'
                qvalue={'logpost':float(q.logpost),'loglikes':dict(zip(proposal.likelihood,map(float,q.loglikes))),
                        'logpriors':list(map(float,q.logpriors))}
                row.update(density(value,qvalue,request['stored_logpost'],plan['design']))
                row['proposal_successful_native_fallbacks']=int(proposal.theory['spectral_surrogate'].exact_calls)-before
                key=rt.identity(request['point'])
                repeated=rt.compare(value,raw,*seen[key],plan['pilot_tolerances']) if key in seen else None
                row['repeated_native_replay']=repeated
                if repeated:row['failed_checks']+=['repeat:'+x for x in repeated['failed_checks']]
                seen[key]=(copy.deepcopy(value),{k:v.copy() for k,v in raw.items()})
                rt.save_spectrum(paths['spectrum'],raw)
                row.update(value=value,spectrum_path=s.relative(paths['spectrum']),spectrum_sha256=s.digest(paths['spectrum']))
                row['status']='failed_native2_checks' if row['failed_checks'] else 'finite_native2'
            except Exception as exc:
                row.update(status='failed_native2_evaluation',failed_checks=['evaluation_exception'],error=repr(exc))
            row.update(native_logposterior_invocations=ni,proposal_logposterior_invocations=qi,seconds=time.monotonic()-tick)
            rt.write_new(paths['record'],row);completed.append(request['index'])
            if row['status']!='finite_native2':failed=request['index'];break
    finally:
        exact.close();proposal.close()
        verify_plan(work/'plan.json')
        rt.write_new(work/f'worker-{worker_id}.json',{'plan_identity':plan['identity'],'worker':worker_id,'pid':os.getpid(),
            'completed_indices':completed,'failed_index':failed,'native_model_constructions':1,'proposal_model_constructions':1,
            'explicit_native_initialization_calls':1,'initialization_path':s.relative(initialpath),
            'initialization_sha256':s.digest(initialpath),'seconds':time.monotonic()-started})


def collect(work,plan):
    work=Path(work);rows=[];files={};failures=[];pids=[];initializations=0
    if (work/'record-hashes.json').exists():
        previous=rt.read(work/'record-hashes.json');assert previous['plan_identity']==plan['identity'];s.verify_hashes(previous['files'])
    for request in plan['requests']:
        paths=rt.request_paths(work,request['index']);binding=rt.request_identity(plan,request)
        if paths['record'].exists():
            row=rt.read(paths['record']);assert row['schema']==RECORD_SCHEMA and row['binding']==binding
            for k in ('ticket','claim'):
                assert rt.read(paths[k])['binding']==binding and row[k+'_sha256']==s.digest(paths[k])
            assert row['index']==request['index'] and row['point']==request['point']
            assert row['group']==request['group'] and row['location']==request['location']
            assert row['worker']==request['worker'] and row['ordinal']==request['ordinal']
            assert row['numerical_target_identity']==plan['numerical_target_identity']
            assert row['native_logposterior_invocations'] in (0,1) and row['proposal_logposterior_invocations'] in (0,1)
            s.verify_hashes(row['initialization_sha256'])
            if row['status']=='finite_native2':
                assert row['native_logposterior_invocations']==row['proposal_logposterior_invocations']==1
                assert not row['failed_checks']
                native_metadata(row['value'],plan['numerical_target']['native_configuration'])
                recomputed=density(row['value'],{'logpost':row['proposal_logpost'],'loglikes':row['proposal_loglikes'],
                    'logpriors':row['proposal_logpriors']},request['stored_logpost'],plan['design'])
                assert all(row[k]==v for k,v in recomputed.items())
                assert row['spectrum_path']==s.relative(paths['spectrum']) and s.digest(paths['spectrum'])==row['spectrum_sha256']
                rt.load_spectrum(paths['spectrum'])
            row.update(record_path=s.relative(paths['record']),record_sha256=s.digest(paths['record']))
        else:
            row={'status':'incomplete_attempt_no_retry','index':request['index'],'point':request['point'],
                 'unknown_invocation_count':paths['claim'].exists(),'native_logposterior_invocations':0,
                 'proposal_logposterior_invocations':0,'known_unstarted':not paths['claim'].exists()}
        rows.append(row)
        files.update({s.relative(p):s.digest(p) for p in paths.values() if p.exists()})
    for i in range(plan['workers']):
        receipt=work/f'worker-{i}.json';process=work/f'worker-{i}-process.json'
        ip=work/f'worker-{i}-initialization.json';ic=work/f'worker-{i}-initialization.claim.json'
        if ip.exists():
            initial=rt.read(ip);claim=rt.read(ic)
            assert initial['claim_sha256']==s.digest(ic) and claim['worker']==i
            assert initial['plan_identity']==claim['plan_identity']==plan['identity']
            assert initial['explicit_native_initialization_calls']==1
            initializations+=1
        if not receipt.exists() or not process.exists():failures.append(f'worker:{i}:incomplete');continue
        r,p=rt.read(receipt),rt.read(process)
        expected=[x['index'] for x in plan['requests'] if x['worker']==i]
        assert r['plan_identity']==p['plan_identity']==plan['identity'] and r['worker']==p['worker']==i
        assert r['pid']==p['pid']
        assert p['log_path']==s.relative(work/f'worker-{i}.log') and s.digest(ROOT/p['log_path'])==p['log_sha256']
        assert r['native_model_constructions']==r['proposal_model_constructions']==r['explicit_native_initialization_calls']==1
        assert r['initialization_path']==s.relative(ip) and r['initialization_sha256']==s.digest(ip)
        assert claim['pid']==r['pid'];pids.append(r['pid'])
        if r['completed_indices']!=expected or r['failed_index'] is not None or p['returncode']!=0:failures.append(f'worker:{i}:failed_or_incomplete')
        for index in r['completed_indices']:
            assert rows[index]['pid']==r['pid'] and rt.read(rt.request_paths(work,index)['claim'])['pid']==r['pid']
    assert len(pids)==len(set(pids))
    for p in work.glob('worker-*'):
        if p.is_file():files[s.relative(p)]=s.digest(p)
    if (work/'execution.json').exists():files[s.relative(work/'execution.json')]=s.digest(work/'execution.json')
    unknown_initial=sum((work/f'worker-{i}-initialization.claim.json').exists() and not (work/f'worker-{i}-initialization.json').exists() for i in range(plan['workers']))
    return rows,files,failures,initializations,unknown_initial


def replay(work):
    plan,_=verify_plan(Path(work)/'plan.json');rows,files,failures,initials,unknown_initial=collect(work,plan)
    views=[dict(r,status='finite' if r['status']=='finite_native2' else r['status']) for r in rows]
    result=summarize(views,np.asarray(plan['selected']['groups']))
    unknown=sum(bool(r.get('unknown_invocation_count')) for r in rows)
    qualified=(result['status']=='passed_importance_weight_gates' and not failures and not unknown and not unknown_initial and initials==plan['workers'])
    posterior=result.get('posterior') if qualified else None
    result.update(schema=SUMMARY_SCHEMA,importance_status=result['status'],
        status='qualified_anchored_refined_native2_posterior' if qualified else 'failed_anchored_refined_native2_qualification',
        posterior=posterior,qualified_under_declared_numerical_gates=qualified,
        numerical_accuracy=2,numerical_target_identity=plan['numerical_target_identity'],
        parent_proposal_target_identity=plan['manifest']['target_identity']['identity'],plan_identity=plan['identity'],
        process_failures=failures,slots=len(rows),unknown_count_attempts=unknown,
        known_native_logposterior_invocations=sum(r['native_logposterior_invocations'] for r in rows),
        known_proposal_logposterior_invocations=sum(r['proposal_logposterior_invocations'] for r in rows),
        explicit_native_initialization_calls=initials,unknown_initialization_attempts=unknown_initial,
        known_proposal_successful_native_fallbacks=sum(r.get('proposal_successful_native_fallbacks',0) for r in rows),
        count_semantics='Density requests and explicit initialization calls, not an instrumented solver-call count. Interrupted claimed requests have unknown counts.',
        plan_path=s.relative(Path(work)/'plan.json'),plan_sha256=s.digest(Path(work)/'plan.json'),
        source_sha256=plan['source_sha256'],input_sha256=rt.merge(plan['input_sha256'],plan['validation_sha256'],plan['numerical_target']['CAMB_implementation_sha256']),
        limitations=plan['design']['limits'])
    return result,files,rows


def execute(work,output):
    assert not Path(output).exists() and not (Path(work)/'summary.json').exists(),'Use a new correction result.'
    verify_plan(Path(work)/'plan.json')
    rt.execute_workers(work,Path(__file__).name)
    result,files,_=replay(work)
    return rt.seal_summary(work,rt.read(Path(work)/'plan.json'),result,files,output)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['prepare','execute','worker','report'])
    p.add_argument('--folder',type=Path);p.add_argument('--diagnostics',type=Path);p.add_argument('--work',type=Path,required=True)
    p.add_argument('--output',type=Path);p.add_argument('--workers',type=int,default=4);p.add_argument('--worker',type=int)
    a=p.parse_args()
    if a.action=='prepare':assert a.folder and a.diagnostics;r=prepare(a.folder,a.diagnostics,a.work,a.workers)
    elif a.action=='worker':assert a.worker is not None;worker(a.work,a.worker);return
    elif a.action=='execute':assert a.output;r=execute(a.work,a.output)
    else:
        r,files,_=replay(a.work);rt.verify_saved_summary(a.work,r,files,a.output)
    print(json.dumps({'status':r.get('status','prepared_no_physical_calls'),'numerical_accuracy':2}))


if __name__=='__main__':main()
