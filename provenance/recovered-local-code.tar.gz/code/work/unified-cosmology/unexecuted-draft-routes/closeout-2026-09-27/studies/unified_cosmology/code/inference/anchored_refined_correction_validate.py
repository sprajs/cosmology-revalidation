"""Synthetic refined-anchored chain/worker/measurement contracts; zero physics."""
import argparse
from contextlib import ExitStack
import copy
import json
from pathlib import Path
import tempfile
import zipfile
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
from scipy.special import logsumexp

import anchored_refined_correction as c
import anchored_refined_measurement as m


def reject(call):
    try:call()
    except (AssertionError, ValueError, KeyError, FileNotFoundError, RuntimeError):return True
    raise AssertionError('Invalid fixture accepted')


def put(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n')


def native_config():
    return {'theory':{'camb':{'extra_args':dict(AccuracyBoost=2,lAccuracyBoost=2,lSampleBoost=2,
                lens_potential_accuracy=4,lmax=3101)}},
            'likelihood':{'released_calibration':{},'other':{}},
            'params':{'H0':{'prior':{'min':50.,'max':90.}},'x':{'prior':{'min':-10.,'max':10.}}}}


def analytic(point):
    x=point['x'];priors=[-.7];q=-.5*x*x-.7
    qlikes={'released_calibration':-.2*x*x,'other':-.3*x*x}
    likes=dict(qlikes);likes['released_calibration']+=.02*x
    derived={k:float(s*x+b) for k,s,b in [('q0',.1,-.5),('q05',.1,-.1),('q1',.1,.2),('j0',.2,1.),('omegam',.01,.3)]}
    derived['sn_chi2']=float(.4*x*x-.04*x)
    value={'logpost':q+.02*x,'loglikes':likes,'logpriors':priors,'derived':derived,'H':[70.,90.,120.,200.,1e6],
           'metadata':{'finalized_theory_extra_args':native_config()['theory']['camb']['extra_args'],
                       'CAMB_Params_max_l':3200,'provider_length':16,'units':'FIRASmuK2','ell_factor':False,'pp':'dimensionless C_phi_phi'}}
    raw={'ell':np.arange(16),**{k:np.ones(16)*(1.+x*.001) for k in ('tt','ee','te','bb','pp')}}
    return value,raw,{'logpost':q,'loglikes':qlikes,'logpriors':priors}


def chain_fixture(folder):
    folder.mkdir();rng=np.random.default_rng(274044);paths=[]
    for group in range(4):
        x=rng.normal(size=1500);weights=np.full(1500,3);q=.5*x*x+.7
        path=folder/f'chain.{group+1}.txt'
        np.savetxt(path,np.column_stack([weights,q,68+x,x]),header='weight minuslogpost H0 x',fmt='%.17g');paths.append(path)
    proposal=folder/'proposal.npz';proposal.write_bytes(b'only a hash-bound synthetic placeholder')
    proposal_record=folder/'proposal.json';put(proposal_record,{'synthetic_only':True})
    info=native_config();manifest={'schema':c.s.SCHEMA,'rank':0,'MPI_size':4,
        'arguments':{'model':'lcdm','evolution':'none','sample':'synthetic','calibration':'synthetic','native_accuracy':2,
                     'surrogate':str(folder/'synthetic-surrogate.npz')},
        'target_identity':{'identity':'a'*64,'native_accuracy':2,'native_configuration':info,'versions':{}},
        'sampler_identity':'b'*64,'sampler_source_sha256':{},
        'proposal':{'proposal_file':str(proposal),'proposal_sha256':c.s.digest(proposal),
                    'proposal_record_path':c.s.relative(proposal_record),'proposal_record_sha256':c.s.digest(proposal_record)},
        'pilot_evidence':{'input_sha256':{}},'validation':{},'producer_validation':{}}
    for i in range(4):put(folder/f'run-{i}.json',dict(manifest,rank=i))
    (folder/'chain.checkpoint').write_text('sampler:\n  independence_sampler.IndependenceMCMC:\n    converged: true\n    mpi_size: 4\n    burn_in: 0\n    Rminus1_last: 0.003\n')
    convergence={'converged':True,'original_convergence_passed':True,'proposal_sha256':manifest['proposal']['proposal_sha256'],
        'original_multivariate_previous':.004,'original_multivariate_current':.003,'original_bound_statistic':.02,
        'rank_gate':{'passed':True,'failed':[],'discard_fraction_after_sampler_burnin':.3}}
    put(folder/'chain_independence-convergence.jsonl',convergence)
    # completion_evidence reads JSONL, so this record must occupy one line.
    (folder/'chain_independence-convergence.jsonl').write_text(json.dumps(convergence)+'\n')
    for i in range(4):
        ledger=folder/f'chain_independence-candidates-{i}.jsonl';ledger.write_text('{"synthetic":true}\n')
        put(folder/f'chain_independence-terminal-{i}.json',{'converged':True,'terminal_weight':1,
            'terminal_state_in_collection':False,'ledger_sha256':c.s.digest(ledger)})
    check={'status':'passed','failed_gates':[],'discard_fraction_after_sampler_burnin':.3,'independent_chains':4,
        'code_sha256':c.s.digest(c.HERE/'diagnostics.py'),'input_sha256':{c.s.relative(p):c.s.digest(p) for p in paths},
        'equal_chain_length_for_diagnostics':3150}
    diagnostic=folder/'diagnostics.json';put(diagnostic,check)
    return manifest,check,diagnostic


def chain_controls(folder):
    manifest,check,diagnostic=chain_fixture(folder);tests=[]
    with (patch.object(c.s,'verify_manifest',return_value={}),patch.object(c,'check_mpi',return_value=check),
          patch.object(c.s,'configuration',return_value=native_config())):
        actual=c.qualified_chains(folder,diagnostic)
        selected=actual[3];assert len(selected['points'])==2000
        # Independent cumulative-RLE search, avoiding producer np.repeat.
        rng=np.random.default_rng(272639);max_error=0.
        for group,path in enumerate(sorted(folder.glob('chain.[0-9]*.txt'))):
            raw=np.loadtxt(path);cumulative=np.cumsum(raw[:,0].astype(int));discarded=int(cumulative[-1])-3150
            indices=np.floor((np.arange(500)+rng.random(500))*3150/500).astype(int)+discarded
            rows=np.searchsorted(cumulative,indices,side='right')
            for j,(index,row) in enumerate(zip(indices,rows)):
                k=group*500+j
                assert selected['locations'][k]=={'chain':path.name,'row':int(row),'expanded_index':int(index)}
                assert selected['points'][k]=={'H0':float(raw[row,2]),'x':float(raw[row,3])}
                max_error=max(max_error,abs(selected['stored_logposts'][k]+raw[row,1]))
        assert max_error==0.;tests.append('all2000_independent_cumulative_RLE_slots')
        changes=[('wrong_schema','run-0.json',lambda x:x.update(schema='dedicated-anchored-chain-v1')),
            ('rank_target','run-2.json',lambda x:x['target_identity'].update(identity='z'*64)),
            ('native1','run-0.json',lambda x:x['arguments'].update(native_accuracy=1)),
            ('terminal_failed','chain_independence-terminal-0.json',lambda x:x.update(converged=False)),
            ('terminal_ledger','chain_independence-terminal-1.json',lambda x:x.update(ledger_sha256='0'*64)),
            ('diagnostic_failed','diagnostics.json',lambda x:x.update(status='failed'))]
        for name,filename,mutation in changes:
            path=folder/filename;saved=path.read_bytes();value=json.loads(saved);mutation(value);put(path,value)
            assert reject(lambda:c.qualified_chains(folder,diagnostic));path.write_bytes(saved);tests.append(name)
        convergence=folder/'chain_independence-convergence.jsonl';saved=convergence.read_bytes()
        for key in ('original_multivariate_previous','original_multivariate_current','original_bound_statistic'):
            value=json.loads(saved);value[key]=.05 if 'bound' in key else .005
            convergence.write_text(json.dumps(value)+'\n');assert reject(lambda:c.qualified_chains(folder,diagnostic));tests.append(key+'_boundary')
        convergence.write_bytes(saved)
        with patch.object(c,'check_mpi',return_value=dict(check,status='changed')):
            assert reject(lambda:c.qualified_chains(folder,diagnostic));tests.append('fresh_diagnostics_disagree')
    return actual,tests


def pure_checks():
    design=json.loads(c.DESIGN.read_text());errors=[];rng=np.random.default_rng(274045)
    for x in rng.normal(size=100):
        point={'x':float(x),'H0':float(68+x)};native,_,q=analytic(point)
        value=c.density(native,q,q['logpost'],design)
        errors.append(abs(value['log_weight']-.02*x));assert not value['failed_checks']
        wrong=copy.deepcopy(native);wrong['logpriors'][0]+=.1
        assert set(c.density(wrong,q,q['logpost'],design)['failed_checks'])=={'native_accounting','prior_difference'}
        assert 'stored_proposal_difference' in c.density(native,q,q['logpost']+.02,design)['failed_checks']
    assert max(errors)<1e-14
    return max(errors)


def implementation_controls(folder):
    reference=folder/'reference';site=reference/'lib/python3.12/site-packages'
    names=['camb/__init__.py','camb/camblib.so','camb/HighLExtrapTemplate_lenspotentialCls.dat']+[f'camb/fixture{i}.py' for i in range(38)]
    wheel=folder/'fixture.whl'
    with zipfile.ZipFile(wheel,'w') as stream:
        for name in names:
            data=('synthetic payload '+name).encode();stream.writestr(name,data)
            path=site/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
        stream.writestr('camb-1.6.6.dist-info/RECORD','omitted installed record')
    expected=c.s.digest(wheel);module=site/'camb/__init__.py'
    result=c.verify_camb_payload(reference,wheel,expected,module)
    assert len(result)==42
    tests=['exact41_runtime_binary_Python_and_data_payload']
    for name in names[:3]:
        path=site/name;saved=path.read_bytes();path.write_bytes(saved+b'changed')
        assert reject(lambda:c.verify_camb_payload(reference,wheel,expected,module));path.write_bytes(saved)
        tests.append('changed_'+Path(name).name+'_rejected')
    with patch.object(c.zipfile,'ZipFile',side_effect=AssertionError('Must reject before archive processing')):
        assert reject(lambda:c.verify_camb_payload(reference,wheel,expected,folder/'fixed/camb/__init__.py'))
    tests.append('same_version_wrong_import_path_rejected_first')
    assert reject(lambda:c.verify_camb_payload(reference,wheel,'0'*64,module));tests.append('wrong_wheel_digest_rejected')
    actual=c.camb_implementation();assert len(actual)==42
    return tests,actual


def full_fixture(folder,qualified):
    manifest,check,complete,selected,inputs,native=qualified
    validation=folder/'fake-validation.json';put(validation,{'synthetic_only':True})
    class Native:
        def close(self):pass
    class Proposal:
        likelihood={'released_calibration':None,'other':None}
        theory={'spectral_surrogate':SimpleNamespace(exact_calls=0)}
        def logposterior(self,point,cached=False):
            value=analytic(point)[2]
            return SimpleNamespace(logpost=value['logpost'],loglikes=list(value['loglikes'].values()),logpriors=value['logpriors'])
        def close(self):pass
    from cobaya import model as model_module
    import independence_runtime
    tests=[];work=folder/'work';summary=folder/'public-summary.json'
    bound={c.s.relative(validation):c.s.digest(validation)}
    with ExitStack() as stack:
        stack.enter_context(patch.object(c,'qualified_chains',return_value=qualified))
        stack.enter_context(patch.object(c,'validation_guard',return_value=bound))
        # Only the parent/physics boundaries are synthetic; producer plan,
        # worker control, seals, collection, gates and qualifier are real.
        plan=c.prepare(folder/'chain',folder/'chain/diagnostics.json',work,workers=4)
        assert plan['schema']==c.PLAN_SCHEMA
        stack.enter_context(patch.object(c.s,'runtime',return_value={}))
        stack.enter_context(patch.object(c.rt,'verify_environment',return_value=None))
        stack.enter_context(patch.object(c.s,'configuration',return_value=native_config()))
        stack.enter_context(patch.object(independence_runtime,'native_initialize',return_value={'synthetic_only':True}))
        stack.enter_context(patch.object(c.rt,'construct_model',return_value=Native()))
        stack.enter_context(patch.object(model_module,'get_model',side_effect=lambda *a,**k:Proposal()))
        stack.enter_context(patch.object(c.rt,'native_value',side_effect=lambda model,point:analytic(point)[:2]))
        c.rt.write_new(work/'execution.json',{'plan_identity':plan['identity'],'workers':4,'retry_permitted':False})
        for request in plan['requests']:
            c.rt.write_new(c.rt.request_paths(work,request['index'])['ticket'],{'binding':c.rt.request_identity(plan,request)})
        for worker in range(4):
            pid=987650+worker
            with patch.object(c.os,'getpid',return_value=pid):c.worker(work,worker)
            log=work/f'worker-{worker}.log';log.write_text('Synthetic process receipt; no subprocess or physical evaluation.\n')
            c.rt.write_new(work/f'worker-{worker}-process.json',{'plan_identity':plan['identity'],'worker':worker,'pid':pid,
                'returncode':0,'log_path':c.s.relative(log),'log_sha256':c.s.digest(log)})
        result,files,rows=c.replay(work)
        assert result['status']=='qualified_anchored_refined_native2_posterior',result.get('failed_gates')
        assert result['known_native_logposterior_invocations']==result['known_proposal_logposterior_invocations']==2000
        assert result['explicit_native_initialization_calls']==4 and not result['process_failures']
        assert result['unknown_count_attempts']==result['unknown_initialization_attempts']==0
        c.rt.seal_summary(work,plan,result,files,summary)
        target=m.qualify_run(work,summary);reported=m.aggregate(target)
        assert type(target) is m.QualifiedAnchoredRefinedNative2 and reported['qualified_under_declared_numerical_gates']
        independent_lw=.02*np.array([p['x'] for p in selected['points']]);expected=np.exp(independent_lw-logsumexp(independent_lw))
        assert np.max(abs(expected-target.normalized_weights))<1e-15
        names=reported['weighted_covariance']['parameter_order']
        matrix=np.array([[dict(r['point'],**r['derived'])[k] for k in names] for r in rows])
        mean=expected@matrix;cov=sum(w*np.outer(v-mean,v-mean) for w,v in zip(expected,matrix))
        assert np.max(abs(cov-np.asarray(reported['weighted_covariance']['matrix'])))<1e-12
        tests+=['four_persistent_synthetic_workers_2000_slots','typed_qualification_and_unchanged_gates','independent_Gaussian_weights_covariance']
        # Unstarted/claimed/failure evidence never triggers a replacement.
        with patch('subprocess.Popen',side_effect=AssertionError('No subprocess permitted')):
            assert reject(lambda:c.rt.execute_workers(work,Path(c.__file__).name));tests.append('completed_execution_cannot_retry')
        path=work/'00000.json';saved=path.read_bytes();path.write_bytes(saved+b' ')
        assert reject(lambda:m.qualify_run(work,summary));path.write_bytes(saved);tests.append('changed_record_bytes_rejected')
        path=work/'00000.raw-cl.npz';saved=path.read_bytes();path.write_bytes(saved+b' ')
        assert reject(lambda:m.qualify_run(work,summary));path.write_bytes(saved);tests.append('changed_spectrum_bytes_rejected')
        # Failure report arithmetic is tested on collected immutable rows,
        # independent of the parent fixture and without editing saved results.
        failed=copy.deepcopy(rows);failed[0]['status']='failed_native2_evaluation'
        with patch.object(c,'collect',return_value=(failed,files,[],4,0)):
            value,_,_=c.replay(work)
            assert value['posterior'] is None and not value['qualified_under_declared_numerical_gates']
            tests.append('failed_native_evaluation_withheld')
        failed=copy.deepcopy(rows)
        for i,row in enumerate(failed):row['log_weight']+=100 if i==0 else 0
        with patch.object(c,'collect',return_value=(failed,files,[],4,0)):
            value,_,_=c.replay(work)
            assert value['posterior'] is None and value['failed_gates'];tests.append('failed_raw_weight_gates_withheld')
        for label,pfailure,initial,unknown in [('process_failed',['worker:0:failed'],4,0),('initialization_unknown',[],3,1)]:
            with patch.object(c,'collect',return_value=(rows,files,pfailure,initial,unknown)):
                value,_,_=c.replay(work);assert value['posterior'] is None;tests.append(label+'_withheld')
        # Actual collector distinguishes incomplete claims from unstarted slots.
        incomplete=folder/'incomplete';incomplete.mkdir()
        c.rt.write_new(incomplete/'plan.json',c.rt.plain(c.rt.read(work/'plan.json')))
        request=plan['requests'][0];claim=c.rt.request_paths(incomplete,0)['claim']
        c.rt.write_new(claim,{'binding':c.rt.request_identity(plan,request)})
        incomplete_rows,_,failures,initial,unknown=c.collect(incomplete,plan)
        assert incomplete_rows[0]['unknown_invocation_count'] and incomplete_rows[1]['known_unstarted']
        assert len(failures)==4 and initial==unknown==0;tests.append('claimed_unknown_vs_unstarted_zero')
        c.rt.write_new(incomplete/'worker-0-initialization.claim.json',{'plan_identity':plan['identity'],'worker':0,'pid':987650})
        assert c.collect(incomplete,plan)[4]==1;tests.append('interrupted_initialization_count_unknown')
        assert reject(lambda:m.aggregate(object()));tests.append('untyped_measurement_rejected')
    return tests


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=c.VALIDATION);args=parser.parse_args()
    # Global physical forbidders stay active; only explicit fake worker APIs
    # override specific boundaries inside the synthetic integration fixture.
    with c.rt.guards_without_physics():
        error=pure_checks()
        with tempfile.TemporaryDirectory(dir=c.ROOT/'.work',prefix='anchored-refined-validation-') as tmp:
            folder=Path(tmp);implementation,files=implementation_controls(folder)
            qualified,chains=chain_controls(folder/'chain');workers=full_fixture(folder,qualified)
    result={'status':'passed_synthetic_refined_anchored_native2_validation','physical_calls':0,
        'chain_controls':chains,'worker_measurement_controls':workers,'independent_density_cases':100,
        'CAMB_implementation_controls':implementation,'current_runtime_sha256':files,
        'maximum_logweight_absolute_error':error,'source_sha256':c.dependencies(),
        'scope':'Explicit synthetic parent/physical-model fixtures only. Real selection/completion, worker lifecycle, seals, accounting, unchanged weight gates and fresh typed consumer tested. No actual chain, model, background or spectrum calculation.'}
    args.output.parent.mkdir(parents=True,exist_ok=True);put(args.output,result)
    print(json.dumps({'status':result['status'],'chain_controls':len(chains),'worker_controls':len(workers),'sha256':c.s.digest(args.output)}))


if __name__=='__main__':main()
