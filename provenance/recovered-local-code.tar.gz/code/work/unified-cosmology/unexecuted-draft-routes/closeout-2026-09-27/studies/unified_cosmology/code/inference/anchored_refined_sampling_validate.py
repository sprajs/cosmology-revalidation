"""Validate refined-proposal production routing without model construction."""
import argparse
from contextlib import ExitStack
import copy
import importlib
import json
from pathlib import Path
import tempfile
from unittest.mock import patch

import numpy as np
from scipy.stats import multivariate_normal

import anchored_refined_sampling as sampling
from independence_proposal import FrozenMixture


def validate():
    import camb,cobaya.model
    run_module=importlib.import_module('cobaya.run')
    def forbidden(*args,**kwargs):raise RuntimeError('This validator cannot perform physical computation or sampling.')
    models=[];rejections=[]
    with ExitStack()as stack:
        for owner,name in [(camb,'get_background'),(camb,'get_results'),(camb,'get_transfer_functions'),
                           (cobaya.model,'get_model'),(run_module,'run')]:
            stack.enter_context(patch.object(owner,name,forbidden))
        path=sampling.ROOT/json.loads(sampling.proposal.DESIGN.read_text())['surrogate']['path']
        for model in ['lcdm','cpl']:
            for accuracy in [1,2]:
                args=sampling.settings(model,path,accuracy)
                assert sampling.configuration(args)==sampling.base.configuration(args)
                assert sampling.configuration(args,native=True)==sampling.base.configuration(args,native=True)
                target=sampling.identify(args)
                assert target==sampling.base.identify(args)
                assert target['sample_semantics']['extra_H0_or_Cepheid_factor']is False
                assert target['sample_semantics']['absolute_calibration_included']is True
                models.append({'model':model,'native_accuracy':accuracy,'identity':target['identity']})
        assert len({m['identity']for m in models})==4
        assert sampling.base.sampler_options is __import__('independence_gpu_run').sampler_options
        mixture=FrozenMixture(np.array([68.,0.]),np.array([[.2,.04],[.04,.3]]),['H0','x'])
        design=json.loads(sampling.pilot.DESIGN.read_text());request=sampling.pilot.requests(mixture,'cpl',design)
        fake_info={'params':{'H0':{'prior':{}},'x':{'prior':{}}},'likelihood':{'synthetic':{}}}
        target={'identity':'explicitly-synthetic-only','configuration':fake_info}
        frozen={'proposal_kind':sampling.proposal.KIND,'proposal_sha256':'synthetic-only'}
        root=sampling.ROOT/'.work/unified-cosmology/anchored-refined-validation';root.mkdir(exist_ok=True,parents=True)
        with tempfile.TemporaryDirectory(dir=root,prefix='driver-')as folder:
            folder=Path(folder);rows=[];current=None;logp=None;logq=None
            for i,x in enumerate(request['points']):
                trial=float(multivariate_normal.logpdf(x,mean=[68.15,.1],cov=[[.3,-.01],[-.01,.2]]))
                accepted,alpha=sampling.pilot.transition(trial,logp,logq,float(request['logq'][i]),float(request['logu'][i]))
                if accepted:current=i;logp=trial;logq=float(request['logq'][i])
                rows.append({'index':i,'point':dict(zip(mixture.names,map(float,x))),
                    'logq':float(request['logq'][i]),'log_uniform':float(request['logu'][i]),
                    'target_logpost':trial,'finite_target':True,'logprior':0.,'loglikes':{'synthetic':trial},
                    'accepted':accepted,'log_acceptance':alpha,'occupied_candidate':current})
            np.savez_compressed(folder/'requests.npz',**request)
            (folder/'records.jsonl').write_text(''.join(json.dumps(row)+'\n'for row in rows))
            (folder/'native-initialization.json').write_text('{"synthetic_only":true}\n')
            manifest={'schema':'anchored-refined-proposal-pilot-v1','target_identity':target,'proposal':frozen,
                'dependency_sha256':sampling.pilot.dependencies(),'validation':sampling.pilot.validation_guard(),
                'requests_sha256':sampling.digest(folder/'requests.npz')}
            (folder/'manifest.json').write_text(json.dumps(manifest))
            result=sampling.pilot.metrics(rows,request)
            result.update(status='completed_declared_request_budget',target_identity=target['identity'],
                          dependency_sha256=sampling.pilot.dependencies(),
                          input_sha256={sampling.relative(p):sampling.digest(p)for p in folder.iterdir()})
            result_path=folder/'result.json';result_path.write_text(json.dumps(result))
            checked=sampling.verify_pilot(result_path,target,mixture,frozen)
            assert checked['status']=='completed_source_bound_400_point_pilot_replayed'
            for kind in ['stopped','target','proposal','raw_records']:
                changed=copy.deepcopy(result);new_target=copy.deepcopy(target);new_frozen=copy.deepcopy(frozen)
                original_records=(folder/'records.jsonl').read_bytes()
                if kind=='stopped':changed['status']='stopped_native_fallback_budget'
                elif kind=='target':new_target['identity']='changed'
                elif kind=='proposal':new_frozen['proposal_sha256']='changed'
                else:(folder/'records.jsonl').write_bytes(original_records+b'{}\n')
                result_path.write_text(json.dumps(changed));refused=False
                try:sampling.verify_pilot(result_path,new_target,mixture,new_frozen)
                except AssertionError:refused=True
                assert refused;rejections.append(kind)
                (folder/'records.jsonl').write_bytes(original_records);result_path.write_text(json.dumps(result))
        for old_schema in ['dedicated-anchored-chain-v1','modern-chain-v1']:
            try:sampling.verify_manifest({'schema':old_schema})
            except AssertionError:rejections.append(old_schema)
            else:raise AssertionError('Old chain schema accepted.')
        try:sampling.base.verify_manifest({'schema':sampling.SCHEMA})
        except AssertionError:rejections.append('old_consumer_rejects_new_schema')
        else:raise AssertionError('Original consumer accepted new route.')
    return {'status':'passed_refined_anchored_sampling_contract_no_inference',
        'physical_calls':0,'four_actual_unchanged_science_identities':models,
        'inherited_sampler_options_identity':True,'complete_pilot_rows_replayed':400,'refusal_controls':rejections,
        'dependency_sha256':sampling.dependencies(),
        'source_sha256':{sampling.relative(p):sampling.digest(p)for p in [Path(__file__),Path(sampling.__file__),sampling.DESIGN]},
        'scope':'Production driver/configuration and saved-pilot contract only. No chain, native correction or posterior exists. Original sampler math/gates reused unchanged; separate refined-schema native consumer remains required.'}


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    result=validate();a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':result['status'],'physical_calls':0}))


if __name__=='__main__':main()
