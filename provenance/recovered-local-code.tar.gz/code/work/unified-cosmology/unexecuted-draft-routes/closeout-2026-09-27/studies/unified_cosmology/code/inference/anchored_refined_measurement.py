"""Typed qualification for the genuine refined-anchored native2 route."""
from dataclasses import dataclass
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.special import logsumexp

import anchored_refined_correction as correction
import native_accuracy_runtime as rt
from measurement_summary import PARAMETERS,weighted_fraction
from exact_correction import weighted_summary


@dataclass(frozen=True)
class QualifiedAnchoredRefinedNative2:
    numerical_accuracy:int
    numerical_target_identity:str
    native_configuration:dict
    parent_settings:dict
    records:tuple
    points:tuple
    groups:np.ndarray
    locations:tuple
    logweights:np.ndarray
    normalized_weights:np.ndarray
    posterior_summary:dict
    input_sha256:dict
    plan:dict
    plan_path:Path
    summary_path:Path


def qualify_run(work,summary_path):
    work=Path(work).resolve();summary_path=Path(summary_path).resolve()
    with rt.guards_without_physics():
        result,files,rows=correction.replay(work)
        rt.verify_saved_summary(work,result,files,summary_path)
        assert result['schema']==correction.SUMMARY_SCHEMA
        assert result['status']=='qualified_anchored_refined_native2_posterior'
        assert result['qualified_under_declared_numerical_gates'] is True
        assert result['importance_status']=='passed_importance_weight_gates'
        assert not result['failed_gates'] and result['posterior'] is not None
        assert not result['process_failures'] and result['unknown_count_attempts']==result['unknown_initialization_attempts']==0
        assert result['slots']==result['known_native_logposterior_invocations']==result['known_proposal_logposterior_invocations']==2000
        plan=rt.read(work/'plan.json')
        assert result['explicit_native_initialization_calls']==plan['workers']
        assert all(r['status']=='finite_native2' for r in rows)
        inputs=rt.merge(result['input_sha256'],result['source_sha256'],files,
            {rt.relative(p):rt.digest(p) for p in [work/'plan.json',work/'summary.json',work/'record-hashes.json',summary_path]})
        rt.verify_hashes(inputs)
        groups=np.asarray(plan['selected']['groups']);assert np.array_equal(groups,np.repeat(np.arange(4),500))
        lw=np.array([r['log_weight'] for r in rows]);weights=np.exp(lw-logsumexp(lw))
        return QualifiedAnchoredRefinedNative2(2,plan['numerical_target_identity'],plan['numerical_target']['native_configuration'],
            plan['manifest']['arguments'],tuple(rows),tuple(plan['selected']['points']),groups,
            tuple(plan['selected']['locations']),lw,weights,result,inputs,plan,work/'plan.json',summary_path)


def aggregate(target):
    assert type(target) is QualifiedAnchoredRefinedNative2 and target.numerical_accuracy==2
    posterior=target.posterior_summary['posterior'];weights=target.normalized_weights;groups=target.groups
    names=[k for k in PARAMETERS if k in posterior]
    values={k:np.array([dict(r['point'],**r['derived'])[k] for r in target.records]) for k in posterior}
    assert all(np.isfinite(v).all() for v in values.values())
    for k in names:
        direct=weighted_summary(values[k],weights)
        for field in ('mean','sd','quantiles_025_16_50_84_975'):
            assert np.max(abs(np.asarray(direct[field])-np.asarray(posterior[k][field])))<1e-12
    matrix=np.column_stack([values[k] for k in names]);centered=matrix-weights@matrix
    signs={k+'_below_zero':weighted_fraction(values[k]<0,weights,groups) for k in ('q0','q05','q1','j0')}
    signs['accelerating_with_decreasing_scale_factor_acceleration_today']=weighted_fraction((values['q0']<0)&(values['j0']<0),weights,groups)
    boundaries={}
    for k,v in target.native_configuration['params'].items():
        prior=v.get('prior',{}) if isinstance(v,dict) else {}
        if k not in values or not isinstance(prior,dict) or not {'min','max'}<=set(prior):continue
        lo,hi=prior['min'],prior['max'];margin=.01*(hi-lo)
        boundaries[k]={'prior':[lo,hi],'fraction_within_one_percent_of_lower_bound':float(weights@(values[k]<lo+margin)),
                       'fraction_within_one_percent_of_upper_bound':float(weights@(values[k]>hi-margin))}
    support=None
    if 'w' in values and 'wa' in values:
        early=values['w']+values['wa'];assert np.max(early)<=1e-10
        support={'constraint':'w0+wa<=0','diagnostic_boundary_width':.05,
                 'fraction_within_005_of_boundary':float(weights@(early>-.05)),
                 'interpretation':'Diagnostic only for imposed support; not excluded-region coverage.'}
    return {'schema':'qualified-anchored-refined-native2-measurement-v1',
        'status':'qualified_conditional_anchored_refined_native2_measurement',
        'numerical_accuracy':2,'numerical_target_identity':target.numerical_target_identity,
        'parent_proposal_target_identity':target.plan['manifest']['target_identity']['identity'],
        'settings':{k:target.parent_settings[k] for k in ('model','evolution','sample','calibration','native_accuracy')},
        'qualified_under_declared_numerical_gates':True,'posterior':{k:posterior[k] for k in names},
        'conditional_sign_fractions':signs,'scalar_box_prior_boundary_fractions':boundaries,'coupled_CAMB_support_boundary':support,
        'weighted_covariance':{'parameter_order':names,'matrix':((centered*weights[:,None]).T@centered).tolist(),
                               'normalization':'Raw normalized posterior weights; no Bessel correction.'},
        'input_sha256':target.input_sha256,'native_correction':{k:target.posterior_summary[k] for k in ('exact_points','raw_weight_ess','pareto_k','largest_normalized_weight','log_weight_quantiles')},
        'normalization':'Complete released anchored Gaussian with integrated flat-M determinant; no normalized evidence under the improper flat dM measure.',
        'limitations':target.plan['design']['limits'],'new_physical_calls':0}


def summarize_run(work,summary_path):
    target=qualify_run(work,summary_path);result=aggregate(target)
    rt.verify_hashes(target.input_sha256)
    assert correction.dependencies()==target.plan['source_sha256']
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--work',type=Path,required=True)
    p.add_argument('--summary',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();result=summarize_run(a.work,a.summary);rt.write_new(a.output,result)
    print(json.dumps({'status':result['status'],'numerical_accuracy':2}))


if __name__=='__main__':main()
