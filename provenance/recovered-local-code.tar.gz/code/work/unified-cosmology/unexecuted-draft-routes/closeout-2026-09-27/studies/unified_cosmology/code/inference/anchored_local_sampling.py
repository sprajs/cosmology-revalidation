"""Fresh direct-proposal driver using unchanged anchored science and MCMC kernels."""
import argparse
from datetime import datetime,timezone
import importlib.metadata
import json
from pathlib import Path
import numpy as np

import anchored_sampling as base
import anchored_local_proposal as proposal
import anchored_local_pilot as pilot

ROOT=base.ROOT;HERE=base.HERE
DESIGN=HERE/'anchored-local-sampling-design.json'
VALIDATION=ROOT/'studies/unified_cosmology/results/inference/anchored-local-sampling-validation.json'
SCHEMA='anchored-direct-proposal-chain-v1'
configuration=base.configuration
settings=base.settings
identify=base.identify
runtime=base.runtime
identity=base.identity
digest=base.digest
relative=base.relative
dump_new=base.dump_new
verify_hashes=base.verify_hashes


def dependencies():
    bound=proposal.dependencies()
    for path in [Path(__file__),DESIGN,HERE/'anchored_local_pilot.py',HERE/'anchored-local-pilot-design.json']:
        bound[relative(path)]=digest(path)
    return bound


def load_proposal(folder,info):
    mixture,record=proposal.load(folder,info)
    assert record['proposal_kind']==proposal.KIND
    return mixture,record


def validation_guard():
    record=json.loads(VALIDATION.read_text())
    assert record['status']=='passed_direct_anchored_sampling_contract_no_inference'
    assert record['dependency_sha256']==dependencies()
    verify_hashes(record['source_sha256'])
    assert record['physical_calls']==0
    return {relative(VALIDATION):digest(VALIDATION)}


def sampler_identity(target,bindings,frozen):
    return identity({'schema':SCHEMA,'target_identity':target['identity'],
                     'sampler_source_sha256':bindings,'normalized_proposal':frozen})


def verify_pilot(path,target,mixture,frozen):
    path=Path(path).resolve();value=json.loads(path.read_text())
    assert value['status']=='completed_declared_request_budget'and value['target_calls_recorded']==400
    assert value['qualified_scientific_measurement']is False
    assert value['target_identity']==target['identity']
    assert value['dependency_sha256']==pilot.dependencies()
    verify_hashes(value['dependency_sha256']);verify_hashes(value['input_sha256'])
    folder=path.parent
    for name in ['manifest.json','requests.npz','native-initialization.json','records.jsonl']:
        assert value['input_sha256'][relative(folder/name)]==digest(folder/name)
    manifest=json.loads((folder/'manifest.json').read_text())
    assert manifest['schema']=='anchored-direct-proposal-pilot-v1'
    assert manifest['target_identity']==target and manifest['proposal']==frozen
    assert manifest['dependency_sha256']==pilot.dependencies()
    assert manifest['validation']==pilot.validation_guard()
    assert manifest['requests_sha256']==digest(folder/'requests.npz')
    rows=[json.loads(line)for line in(folder/'records.jsonl').read_text().splitlines()]
    assert len(rows)==400 and not any(r.get('status')=='failed_evaluation'for r in rows)
    with np.load(folder/'requests.npz',allow_pickle=False)as saved:
        request={name:saved[name]for name in saved.files}
    assert request['names'].tolist()==mixture.names
    assert np.max(abs(mixture.logpdf(request['points'])-request['logq']))<1e-10
    current=None;logp=None;logq=None
    for index,row in enumerate(rows):
        assert row['index']==index and row['point']==dict(zip(mixture.names,map(float,request['points'][index])))
        assert row['logq']==request['logq'][index]and row['log_uniform']==request['logu'][index]
        trial=row['target_logpost']if row['finite_target']else -np.inf
        if row['finite_target']:
            assert abs(trial-row['logprior']-sum(row['loglikes'].values()))<1e-9
        accepted,alpha=pilot.transition(trial,logp,logq,float(request['logq'][index]),float(request['logu'][index]))
        assert row['accepted']==accepted and row['log_acceptance']==alpha
        if accepted:current=index;logp=trial;logq=float(request['logq'][index])
        assert row['occupied_candidate']==current
    for key,expected in pilot.metrics(rows,request).items():assert value[key]==expected
    inputs=dict(value['input_sha256']);inputs[relative(path)]=digest(path)
    return {'status':'completed_source_bound_400_point_pilot_replayed','path':relative(path),
            'sha256':digest(path),'input_sha256':inputs,
            'scope':'Efficiency evidence only; no posterior or convergence qualification.'}


def verify_manifest(manifest):
    assert manifest['schema']==SCHEMA and manifest['MPI_size']==4
    assert manifest['validation']==validation_guard()
    assert manifest['producer_validation']==proposal.validation_guard()
    assert manifest['sampler_source_sha256']==dependencies()
    verify_hashes(manifest['sampler_source_sha256'])
    arguments=manifest['arguments'];target=manifest['target_identity']
    assert arguments['sampler']=='frozen_independence'and arguments['resume']is False
    verify_hashes(target['source_sha256'])
    for name,value in target['versions'].items():assert importlib.metadata.version(name)==value
    assert identify(arguments)==target
    mixture,frozen=load_proposal(Path(arguments['proposal_folder']),configuration(arguments))
    assert frozen==manifest['proposal']
    assert manifest['sampler_identity']==sampler_identity(target,manifest['sampler_source_sha256'],frozen)
    assert manifest['pilot_evidence']==verify_pilot(ROOT/manifest['pilot_evidence']['path'],target,mixture,frozen)
    inputs=dict(target['source_sha256']);inputs.update(target['anchored_calibration']['input_and_audit_sha256'])
    inputs.update(manifest['sampler_source_sha256'])
    inputs[relative(Path(arguments['surrogate']))]=target['surrogate_sha256']
    for filename in ['asset-file-inventory.json','modern-file-inventory.json']:
        path=ROOT/'.work/unified-cosmology/external-probes'/filename;inputs[relative(path)]=digest(path)
    return inputs


def sample(proposal_folder,output,arguments,pilot_result,seed=None,initialization_seed=None,max_samples=None):
    from mpi4py import MPI
    rank,size=MPI.COMM_WORLD.rank,MPI.COMM_WORLD.size
    assert size==4
    environment=runtime();base.validation_guard();checked=validation_guard();producer_checked=proposal.validation_guard()
    bound=dependencies();info=configuration(arguments)
    target=identify(arguments)if rank==0 else None;target=MPI.COMM_WORLD.bcast(target,root=0)
    mixture,frozen=load_proposal(proposal_folder,info)
    pilot_evidence=verify_pilot(pilot_result,target,mixture,frozen)
    defaults=json.loads(DESIGN.read_text())['default_seeds'][arguments['model']]
    seed=defaults['sampling']if seed is None else seed
    initialization_seed=defaults['initialization']if initialization_seed is None else initialization_seed
    assert seed!=initialization_seed
    initial=base.prior_start(mixture,info['params'],initialization_seed,rank)
    output=Path(output).resolve();assert output.is_relative_to(ROOT/'.work')
    if rank==0:
        assert not output.exists(),'Fresh output only; no overwrite or resume.'
        output.mkdir(parents=True)
    MPI.COMM_WORLD.Barrier()
    from independence_runtime import native_initialize
    warmup=native_initialize(info)
    arguments=dict(arguments,seed=seed,initialization_seed=initialization_seed,
                   sampler='frozen_independence',resume=False,proposal_folder=str(Path(proposal_folder).resolve()))
    manifest={'schema':SCHEMA,'created_utc':datetime.now(timezone.utc).isoformat(),'rank':rank,'MPI_size':size,
        'arguments':arguments,'target_identity':target,'sampler_identity':sampler_identity(target,bound,frozen),
        'runtime':environment,'sampler_source_sha256':bound,'proposal':frozen,'initialization':initial,
        'pilot_evidence':pilot_evidence,
        'native_numerical_initialization':warmup,'validation':checked,'producer_validation':producer_checked,
        'seed_sequence':{'root_entropy':seed,'spawn_key':[rank]},
        'qualification':'Proposal sampling only; separate direct-schema chain/native consumers must qualify.'}
    from mpi_metadata import install
    manifest['metadata_policy']=install(output/'chain');dump_new(output/f'run-{rank}.json',manifest)
    for name,value in initial['point'].items():info['params'][name]['ref']=value
    info['sampler']={'independence_sampler.IndependenceMCMC':base.sampler_options(
        mixture,frozen['proposal_file'],frozen['proposal_sha256'],seed,max_samples)}
    info['output']=str(output/'chain');info['timing']=True
    from cobaya.run import run
    run(info)
    assert dependencies()==bound;verify_manifest(manifest)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--model',choices=['lcdm','cpl'],required=True);p.add_argument('--surrogate',type=Path,required=True)
    p.add_argument('--native-accuracy',type=int,choices=[1,2],default=2)
    p.add_argument('--proposal-folder',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--pilot-result',type=Path,required=True)
    p.add_argument('--seed',type=int);p.add_argument('--initialization-seed',type=int);p.add_argument('--max-samples',type=int)
    a=p.parse_args();sample(a.proposal_folder,a.output,settings(a.model,a.surrogate,a.native_accuracy),a.pilot_result,a.seed,a.initialization_seed,a.max_samples)


if __name__=='__main__':main()
