import sys,json,numpy as np
from pathlib import Path
sys.path.insert(0,str(Path('studies/unified_cosmology/code/inference').resolve()))
import camb
from cobaya.model import get_model
from modern_fast import configuration
p=Path('.work/unified-cosmology/inference/spectral-capture-validation-v2/00002.json');r=json.loads(p.read_text());point=r['point'];info=configuration('lcdm','none','dovekie','official_planck')
result={}
with get_model(info) as model:
 ans=model.logposterior(point);native=dict(zip(model.parameterization.derived_params(),map(float,ans.derived)))
 pars,full=model.theory['camb']._camb_transfers.get_CAMB_transfers()
 result['native']=native;result['stored']=r['derived'];result['logpost_difference']=float(ans.logpost-r['exact_logpost']);result['extra_args']=model.theory['camb'].extra_args;result['extra_attrs']=model.theory['camb'].extra_attrs
 result['background_from_exact_input_params']=camb.get_background(pars).get_derived_params()
 result['background_from_exact_output_params']=camb.get_background(full.Params).get_derived_params()
 extra=dict(info['theory']['camb']['extra_args']);extra['lmax']=9001
 cosmo={k:point[k] for k in ['H0','ombh2','omch2','ns','tau']};cosmo.update(As=1e-10*np.exp(point['logA']),w=-1.,wa=0.)
 direct=camb.set_params(**cosmo,**extra)
 result['background_from_direct_params']=camb.get_background(direct).get_derived_params()
 for tag,obj in [('native_input',pars),('native_output',full.Params),('direct',direct)]:Path('.work/unified-cosmology/'+tag+'-params.txt').write_text(str(obj))
Path('.work/unified-cosmology/native-background-params-check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2),flush=True)
