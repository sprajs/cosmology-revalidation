import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['CLIPY_NOJAX']='1'
import sys,json,hashlib,traceback
from pathlib import Path
import numpy as np
R=Path.cwd();sys.path.insert(0,str(R/'studies/unified_cosmology/code/external_probes'));sys.path.insert(0,str(R/'studies/unified_cosmology/code/inference'))
from modern_adapter import modern_info
from adapter import reference_point
from spectral_surrogate import replace_theory
from cobaya.model import get_model
source=R/'studies/unified_cosmology/code/inference/spectral_surrogate.py'
record={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
try:
 p=R/'.work/unified-cosmology/external-probes/spectral-training/train/0000.npz';f=np.load(p)
 meta=json.loads(p.with_suffix('.json').read_text());design=json.loads((R/'studies/unified_cosmology/code/external_probes/spectral-training-design.json').read_text())
 placeholder=R/'.work/unified-cosmology/host-likelihood/surrogate-independent-placeholder.npz'
 np.savez_compressed(placeholder,centre=design['centre'],coordinate_cholesky=design['coordinate_cholesky'],exponents=np.zeros((1,8),int),coefficients=f['spectra'].reshape(1,-1),output_scale=np.ones(f['spectra'].size),length=len(f['ell']))
 with get_model(replace_theory(modern_info(),placeholder,exact=True)) as model:
  theory=model.theory['spectral_surrogate'];record['required_cls']=theory.required_cls;record['extra_args']=theory.extra_args
  print('CONTRACT',json.dumps(record),flush=True)
  point=reference_point(model);point.update(meta['physical_point']);res=model.logposterior(point)
  record['loglike_differences']={name:float(actual-expected) for name,actual,expected in zip(meta['likelihood_names'],res.loglikes,meta['loglikes'])}
  cls=model.provider.get_Cl(ell_factor=True);record['spectra_relative_max']={name:float(np.max(abs(cls[name]-f['spectra'][i]))/np.max(abs(f['spectra'][i]))) for i,name in enumerate(['tt','ee','bb','te','pp'])}
  record['rdrag_difference']=float(model.provider.get_param('rdrag')-f['derived_rdrag'])
  bao=model.likelihood['bao.desi_dr2'];record['bao_data']=bao.data.to_dict(orient='records');record['bao_rs']=float(bao.rs());record['bao_pred']=[float(np.asarray(bao.theory_fun(z,obs)).item())for z,obs in zip(bao.data['z'],bao.data['observable'])];record['bao_distance_at_z']=[float(np.asarray(theory.get_angular_diameter_distance(z)).item())for z in bao.data['z']];record['bao_hubble_at_z']=[float(np.asarray(theory.get_Hubble(z,units='km/s/Mpc')).item())for z in bao.data['z']]
  record['Hubble_z01']=list(map(float,theory.get_Hubble(np.array([0.,1.]),units='km/s/Mpc')))
  record['distance_z1']=float(np.asarray(theory.get_comoving_radial_distance(1.)).item())
  raw=theory.get_Cl(ell_factor=False,units='1');ll=cls['ell']*(cls['ell']+1)
  record['raw_pp_conversion_error']=float(np.max(abs(raw['pp'][2:]*ll[2:]**2/(2*np.pi)-cls['pp'][2:])))
  record['raw_TT_conversion_error']=float(np.max(abs(raw['tt'][2:]*(2.7255e6)**2*ll[2:]/(2*np.pi)-cls['tt'][2:])))
  record['status']='evaluated'
except Exception as exc:record.update(status='failed',exception=type(exc).__name__,message=str(exc));traceback.print_exc()
out=R/'.work/unified-cosmology/host-likelihood/surrogate-independent-review.json';out.write_text(json.dumps(record,indent=2)+'\n');print('REVIEW',json.dumps(record),flush=True)
