import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,hashlib
from pathlib import Path
import numpy as np
from scipy.signal import lfilter
sys.path.insert(0,'studies/unified_cosmology/code/inference')
from exact_correction import summarize
rng=np.random.default_rng(927087);rows=[]
source=Path('studies/unified_cosmology/code/inference/exact_correction.py');sourcehash=hashlib.sha256(source.read_bytes()).hexdigest()
for rho in [0.,.5,.9]:
 means=[];ses=[]
 for rep in range(64):
  noise=rng.normal(size=(4,2500))*np.sqrt(1-rho*rho)
  draws=lfilter([1.],[1.,-rho],noise,axis=1)[:,2000:].ravel()
  records=[{'status':'finite','point':{'x':float(x)},'derived':{},'log_weight':float(.2*x-.02)}for x in draws]
  out=summarize(records,np.repeat(np.arange(4),500));means.append(out['posterior']['x']['mean']);ses.append(out['posterior']['x']['weighted_batch_mean_mcse'])
 rows.append({'rho':rho,'replicates':64,'selected_points':2000,'empirical_mean_scatter':float(np.std(means,ddof=1)),'rms_reported_mcse':float(np.sqrt(np.mean(np.array(ses)**2))),'empirical_95percent_coverage':float(np.mean(abs(np.array(means)-.2)<1.96*np.array(ses)))})
result={'source_sha256':sourcehash,'simulation_only':'KnownGaussian conditional density-ratio uncertainty stresscheck; not cosmological data or validation ofselectedchainmixing. Highrho=.9 illustrateswhy parent/weightedconvergencegates remainnecessary.','results':rows}
Path('.work/unified-cosmology/host-likelihood/correction-mcse-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
