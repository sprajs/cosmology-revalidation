import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,hashlib
from pathlib import Path
import numpy as np
from scipy.optimize import minimize
sys.path.insert(0,'studies/unified_cosmology/code/inference')
from late_geometry import Geometry
path=Path(__file__); design={'reason':'Post-initial-nested-disagreement diagnostic; profile ridge is not posterior volume or new physics prior.','omega_m_grid':[.010001,.02,.05,.1,.15,.2,.25,.28,.30,.31416,.33,.35,.4,.5,.7,.9],'starts':[[-.85,-.5],[-.9,1.],[-1.5,2.]],'bounds':[[-3.,1.],[-5.,3.]],'code_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
path.with_suffix('.design.json').write_text(json.dumps(design,indent=2)+'\n')
g=Geometry(); const=g.bmean@g.bprecision@g.bmean

def objective(wpars,om,detail=False):
 w,wa=wpars; ova=np.array([om]);wva=np.array([w]);ava=np.array([wa])
 ratio=g.integrals(g.nodes,ova,wva,ava); curve=5*np.log10(ratio[0]);sn=float(curve@g.Q@curve-2*curve@g.b+g.dd)
 ii=g.bz*g.integrals(g.bz,ova,wva,ava)[0];ee=g.expansion(g.bz[None,:,None],ova,wva,ava)[0,:,0]
 dh=299792.458/ee;dm=299792.458*ii;dv=np.cbrt(g.bz*dh*dm*dm)
 v=np.where(g.btype=='DH_over_rs',dh,np.where(g.btype=='DM_over_rs',dm,dv));aa=v@g.bprecision@v;bb=v@g.bprecision@g.bmean
 scale=np.clip(aa/bb,5000.,15000.);bao=aa/scale**2-2*bb/scale+const
 if detail:return np.array([om,scale,w,wa]),sn+bao
 return sn+bao
rows=[]
for om in design['omega_m_grid']:
 opts=[minimize(objective,x,args=(om,),method='Nelder-Mead',bounds=design['bounds'],options={'maxiter':10000,'xatol':1e-9,'fatol':1e-9})for x in design['starts']]
 best=min(opts,key=lambda o:o.fun);theta,chisq=objective(best.x,om,True); direct=sum(float(a[0])for a in g.components(theta));assert abs(chisq-direct)<1e-7
 rows.append({'omega_m':om,'theta':theta.tolist(),'chi2':float(chisq),'all_optimizer_success':[bool(o.success)for o in opts],'all_start_chi2':[float(o.fun)for o in opts],'scale_quadratic_closure':float(chisq-direct)})
result={'design':design,'rows':rows,'geometry_sha256':hashlib.sha256(Path('studies/unified_cosmology/code/inference/late_geometry.py').read_bytes()).hexdigest()};path.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
