import time,json,hashlib,os
from pathlib import Path
import numpy as np
import cupy as cp
p=Path('.work/unified-cosmology/inference/quartic-spectral/surrogate-quartic-v1.npz');m=np.load(p);a=m['coefficients'];exponents=m['exponents'];scale=m['output_scale'];rng=np.random.default_rng(272899)
x=rng.normal(size=(100,8));x=np.prod(x[:,None,:]**exponents[None,:,:],axis=-1)
g=cp.asarray(a);cp.cuda.Stream.null.synchronize()
def gpu(row):return cp.asnumpy(cp.asarray(row)@g)
y=gpu(x[0]);errors=[]
t=time.perf_counter();cpu=np.array([row@a for row in x]);cpu_seconds=time.perf_counter()-t
t=time.perf_counter();cuda=np.array([gpu(row) for row in x]);gpu_seconds=time.perf_counter()-t
error=float(np.max(abs(cpu-cuda)));scaled=float(np.max(abs(cpu-cuda)/(1+abs(cpu))))
assert scaled<1e-11
r={'status':'passed_component_check_only','cpu_seconds':cpu_seconds,'gpu_seconds':gpu_seconds,'speedup':cpu_seconds/gpu_seconds,'max_absolute_scaled_spectrum_difference':error,'max_relative_to_one_plus_abs_difference':scaled,'cases':100,'dtype':'float64','matrix_shape':list(a.shape),'model_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cupy':cp.__version__,'numpy':np.__version__,'gpu_name':cp.cuda.runtime.getDeviceProperties(0)['name'].decode(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Single-process component, includes feature transfer and output retrieval; native background/likelihood and multi-process contention not measured.'}
Path('.work/unified-cosmology/gpu-benchmark.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
