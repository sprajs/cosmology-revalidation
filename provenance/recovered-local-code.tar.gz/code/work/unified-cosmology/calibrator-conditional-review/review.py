"""Independent synthetic block-conditioning audit; no observed data/model reads."""
from pathlib import Path
import hashlib
import json
import numpy as np
from scipy.integrate import quad
from scipy.linalg import solve
from scipy.special import logsumexp
from scipy.stats import norm


def flat_logl(r, cov):
    one = np.ones(len(r))
    x = solve(cov, np.column_stack((r, one)), assume_a='gen')
    a = one @ x[:, 1]
    chi = r @ x[:, 0] - (one @ x[:, 0])**2/a
    sign, ld = np.linalg.slogdet(cov)
    assert sign == 1
    return -.5*(chi + ld + np.log(a) + (len(r)-1)*np.log(2*np.pi))


def proper_logl(r, cov):
    sign, ld = np.linalg.slogdet(cov)
    assert sign == 1
    return -.5*(r @ solve(cov, r, assume_a='gen') + ld + len(r)*np.log(2*np.pi))


def main():
    rng = np.random.default_rng(273761)
    errors = {k: 0. for k in ('log_density', 'determinant_identity', 'contrast_mean',
                              'contrast_variance', 'offset_invariance', 'direct_M_quadrature')}
    rows = []
    for i in range(64):
        nn, nc = int(rng.integers(3, 18)), int(rng.integers(1, 9))
        n = nn+nc
        mat = rng.normal(size=(n,n))
        cov = mat@mat.T/n + np.diag(rng.uniform(.2, 1., n))
        r = rng.normal(size=n)
        cnn, ccn, ccc = cov[:nn,:nn], cov[nn:,:nn], cov[nn:,nn:]
        A = solve(cnn, ccn.T, assume_a='gen').T
        oneN, oneC = np.ones(nn), np.ones(nc)
        b = oneC-A@oneN
        V0 = ccc-A@ccn.T
        p1 = solve(cnn, oneN, assume_a='gen')
        aN = oneN@p1
        mN = p1@r[:nn]/aN
        t = r[nn:]-A@r[:nn]-b*mN
        V = V0+np.outer(b,b)/aN
        full = flat_logl(r,cov)
        noncal = flat_logl(r[:nn],cnn)
        conditional = proper_logl(t,V)
        errors['log_density'] = max(errors['log_density'], abs(full-noncal-conditional))
        afull = np.ones(n)@solve(cov,np.ones(n),assume_a='gen')
        det_error = abs(np.linalg.slogdet(cov)[1]+np.log(afull)
                        -np.linalg.slogdet(cnn)[1]-np.log(aN)-np.linalg.slogdet(V)[1])
        errors['determinant_identity'] = max(errors['determinant_identity'],det_error)
        q = solve(V,b,assume_a='gen')
        v = q/(b@q)
        sigma = 1/np.sqrt(b@q)
        errors['contrast_mean'] = max(errors['contrast_mean'],abs(v@b-1))
        errors['contrast_variance'] = max(errors['contrast_variance'],abs(v@V@v-sigma**2))
        shift = 53.27
        shifted_mN = p1@(r[:nn]+shift)/aN
        shifted_t = r[nn:]+shift-A@(r[:nn]+shift)-b*shifted_mN
        errors['offset_invariance'] = max(errors['offset_invariance'],float(np.max(abs(shifted_t-t))))
        # Independent scalar posterior-M integral before completing its square.
        # Standard-normal x parametrizes M=mN+x/sqrt(aN).
        if i < 8:
            center = conditional
            def f(x):
                res = r[nn:]-A@r[:nn]-b*(mN+x/np.sqrt(aN))
                return np.exp(norm.logpdf(x)+proper_logl(res,V0)-center)
            integral, err = quad(f,-12,12,epsabs=1e-12,epsrel=1e-12)
            errors['direct_M_quadrature'] = max(errors['direct_M_quadrature'],abs(np.log(integral)))
        rows.append({'N':nn,'C':nc,'log_density_error':float(full-noncal-conditional),
                     'amplitude':float(v@t),'sigma':float(sigma)})
    # Known mixture demonstrates why tail probabilities must be averaged first.
    # Same observed scalar 0; predicted component means -3,+3, common sigma=1.
    weights = np.array([.5,.5]); residual = np.array([3.,-3.])
    cdf = float(weights@norm.cdf(residual))
    tail = 2*min(cdf,1-cdf)
    wrong = float(weights@(2*np.minimum(norm.cdf(residual),norm.sf(residual))))
    independent_cdf = quad(lambda y: .5*norm.pdf(y,-3,1)+.5*norm.pdf(y,3,1),
                           -np.inf,0,epsabs=1e-12,epsrel=1e-12)[0]
    assert max(errors.values()) < 1e-10
    assert abs(cdf-independent_cdf) < 1e-12 and tail == 1 and wrong < .003
    output = {
        'status':'passed_independent_synthetic_conditional_calibration_review',
        'seed':273761,'systems':64,'observational_reads':0,'background_calls':0,
        'max_errors':errors,'cases':rows,
        'mixture_control':{'predictive_CDF':cdf,'direct_integral_CDF':independent_cdf,
                           'correct_equal_tail_fraction':tail,
                           'incorrect_average_component_equal_tails':wrong},
        'interpretation':[
            'Proper C|N,theta factor exactly multiplies the same improper-flat-M noncalibrator likelihood.',
            'v is fixed when covariance and row selection are fixed; v^T b=1 and Var(v^T t)=sigma^2.',
            'Tail uses the CMB+BAO+N posterior, never a posterior conditioned on C.',
            'Equal-tail predictive diagnostic is not a frequentist p value or a density-ranked tail.',
            'Nonzero b is required; b=0 means this calibration-shift contrast is unidentified.',
            'This tests the released conditional Gaussian construction, not physical independence of its covariance inputs.'
        ],
        'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    }
    Path(__file__).with_name('review.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':output['status'],'max_errors':errors,'mixture_control':output['mixture_control']}))


if __name__=='__main__':main()
