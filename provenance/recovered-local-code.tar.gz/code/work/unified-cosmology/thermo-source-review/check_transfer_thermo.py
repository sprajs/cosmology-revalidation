"""Frozen four-control test of full CAMB's temporary WantTransfer switch; no spectra."""
import json,hashlib,time
from pathlib import Path
import numpy as np
import camb
ROOT=Path.cwd();WORK=ROOT/'.work/unified-cosmology/thermo-source-review'
extra=json.loads((ROOT/'.work/unified-cosmology/native-background-params-check.json').read_text())['extra_args']
inputs=[ROOT/f'.work/unified-cosmology/inference/spectral-capture-validation-v2/{i:05d}.json'for i in range(4)]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
design={'before_outcomes':'Four existing fixed controls. Compare ordinary and WantTransfer=True get_background, no native initialization, no spectra. Source-based temporary-flag hypothesis; no inference/no changed target.','input_sha256':{str(p.relative_to(ROOT)):digest(p)for p in inputs},'source_sha256':digest(Path(__file__)),'extra_args':extra}
(WORK/'transfer-thermo-design.json').write_text(json.dumps(design,indent=2)+'\n')
def forbidden(*args,**kwargs):raise RuntimeError('No full native spectra authorized')
camb.get_results=forbidden
rows=[]
for i,p in enumerate(inputs):
 row=json.loads(p.read_text());point=row['point'];cosmo={k:point[k]for k in['H0','ombh2','omch2','ns','tau']};cosmo.update(As=1e-10*np.exp(point['logA']),w=point.get('w',-1.),wa=point.get('wa',0.))
 for transfer in[False,True]:
  pars=camb.set_params(**cosmo,**extra);pars.WantTransfer=transfer
  started=time.monotonic();back=camb.get_background(pars);derived=back.get_derived_params()
  rows.append({'index':i,'WantTransfer':transfer,'rdrag':float(derived['rdrag']),'stored_native_rdrag':row['derived']['rdrag'],'relative_difference':float(derived['rdrag']/row['derived']['rdrag']-1),'zdrag':float(derived['zdrag']),'zstar':float(derived['zstar']),'Max_eta_k':back.Params.max_eta_k,'Transfer_kmax':back.Params.Transfer.kmax,'tau0':back.tau0,'seconds':time.monotonic()-started})
  print(json.dumps(rows[-1]),flush=True)
result={'rows':rows,'background_calls':len(rows),'native_spectrum_calls':0,'max_transfer_true_relative_difference':max(abs(r['relative_difference'])for r in rows if r['WantTransfer']),'design_sha256':digest(WORK/'transfer-thermo-design.json'),'source_sha256':digest(Path(__file__)),'primary_source_sha256':{p.name:digest(p)for p in WORK.glob('*.f90')}}
(WORK/'transfer-thermo-result.json').write_text(json.dumps(result,indent=2)+'\n')
