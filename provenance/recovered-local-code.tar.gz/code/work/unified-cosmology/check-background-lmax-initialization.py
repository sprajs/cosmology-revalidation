import sys,json,hashlib,os
from pathlib import Path
sys.path.insert(0,str(Path('studies/unified_cosmology/code/inference').resolve()))
from expansion_history import evaluate_background,DESIGN
from modern_fast import configuration
from independence_runtime import native_initialize
folder=Path('.work/unified-cosmology/inference/spectral-capture-validation-v2')
records=[json.loads((folder/f'{i:05d}.json').read_text()) for i in range(4)]
info=configuration('lcdm','none','dovekie','official_planck',Path('.work/unified-cosmology/inference/surrogate/cubic-0509.npz'))
extra=dict(info['theory']['spectral_surrogate']['extra_args'],lmax=9001);design=json.loads(DESIGN.read_text())
result={'scope':'Fixed previous numerical-control points; no qualified posterior used.','cold':[],'initialized':[]}
for i,r in enumerate(records):
 v=evaluate_background(r['point'],extra,design,r['derived']);result['cold'].append({'index':i,'checks':v['numerical_checks'],'failed':v['failed_numerical_gates']});print('cold',i,result['cold'][-1],flush=True)
result['initialization']=native_initialize(info)
for i,r in enumerate(records):
 v=evaluate_background(r['point'],extra,design,r['derived']);result['initialized'].append({'index':i,'checks':v['numerical_checks'],'failed':v['failed_numerical_gates']});print('initialized',i,result['initialized'][-1],flush=True)
result['input_sha256']={str(folder/f'{i:05d}.json'):hashlib.sha256((folder/f'{i:05d}.json').read_bytes()).hexdigest() for i in range(4)}
Path('.work/unified-cosmology/background-lmax-initialization-check.json').write_text(json.dumps(result,indent=2)+'\n')
