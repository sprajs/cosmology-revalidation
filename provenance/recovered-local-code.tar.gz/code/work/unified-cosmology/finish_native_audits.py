"""Finite dependency continuation for one already running inference cohort."""
import argparse,json,os,subprocess,time
from pathlib import Path
ROOT=Path.cwd();CODE=ROOT/'studies/unified_cosmology/code/inference';OUT=ROOT/'studies/unified_cosmology/results/inference'
PYTHON=ROOT/'.work/unified-cosmology/external-probes/.modern-venv/bin/python'
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('label');p.add_argument('--pid',type=int,required=True);a=p.parse_args()
folder=a.folder.resolve();proc=Path(f'/proc/{a.pid}/stat')
start=proc.read_text().split()[21] if proc.exists() else None
assert start is not None,'Named existing native continuation must be running.'
status=folder/'native-audits-status.json'
def report(stage,**kw):
 record=dict(stage=stage,time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**kw)
 status.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
report('waiting_for_this_existing_native_continuation',pid=a.pid,process_start_tick=start)
deadline=time.monotonic()+24*3600
while proc.exists() and proc.read_text().split()[21]==start:
 if time.monotonic()>deadline:raise TimeoutError('Finite current computation exceeded24hours; no retry.')
 time.sleep(30)
assert json.loads((folder/'native-continuation-status.json').read_text())['stage']=='native_continuation_finished','Parent continuation did not qualify.'
summary=OUT/(a.label+'-exact-correction.json')
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CLIPY_NOJAX='1')
def run(name,*args):
 report(name)
 subprocess.run([str(PYTHON),str(CODE/name),*map(str,args)],env=env,check=True)
run('sn_predictive_check.py','--chain-folder',folder,'--correction-summary',summary,'--cache',folder/'sn-predictive','--output',OUT/('sn-predictive-'+a.label+'.json'))
run('native_posterior_precision.py','--chain-folder',folder,'--correction-summary',summary,'--cache',folder/'native-posterior-precision','--workers',4,'--output',OUT/('native-posterior-precision-'+a.label+'.json'))
report('finite_native_audits_finished',note='Inspect all result statuses; execution completion alone is not scientific qualification.')
