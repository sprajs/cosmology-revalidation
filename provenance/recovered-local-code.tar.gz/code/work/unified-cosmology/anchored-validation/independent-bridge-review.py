import sys,json,hashlib
from pathlib import Path
from unittest.mock import patch
import numpy as np
from scipy.special import logsumexp
ROOT=Path.cwd();SRC=ROOT/'studies/unified_cosmology/code/inference'
sys.path.insert(0,str(SRC))
import anchored_bridge as b
import camb
rng=np.random.default_rng(8273907)
design=json.loads(b.DESIGN.read_text())
errors=[];null=[];constant=[];failures=[]
def forbidden(*a,**k):raise AssertionError('No native/background calls in independent review')
with patch.object(camb,'get_background',forbidden),patch.object(camb,'get_results',forbidden),patch.object(camb,'get_transfer_functions',forbidden):
 for i in range(128):
  exact=dict(zip(['released_sn','cmb','bao'],rng.normal(-300,100,3).tolist()))
  proposal=dict(zip(exact,rng.normal(-300,100,3).tolist()))
  prior=float(rng.normal(-10,3));target=float(rng.normal(-450,100))
  ep=prior+sum(exact.values());pp=prior+sum(proposal.values())
  record={'status':'finite','exact_loglikes':exact,'proposal_loglikes':proposal,'exact_logpost':ep,'proposal_logpost':pp,'log_weight':ep-pp}
  bg={'old_SN_reconstructed_loglike':exact['released_sn'],'anchored_SN':{'loglike':target,'chi2':float(rng.uniform(0,2000))}}
  out=b.replace_SN(record,bg,list(exact),design)
  direct=prior+exact['cmb']+exact['bao']+target-pp
  errors.append(abs(out['target_logweight']-direct))
  assert out['target_loglikes']['cmb']==exact['cmb'] and out['target_loglikes']['bao']==exact['bao']
  assert out['target_sn_chi2']==bg['anchored_SN']['chi2']
  bg['anchored_SN']['loglike']=exact['released_sn']
  null.append(abs(b.replace_SN(record,bg,list(exact),design)['target_logweight']-record['log_weight']))
  bg['anchored_SN']['loglike']=target+700
  constant.append(b.replace_SN(record,bg,list(exact),design)['target_logweight']-out['target_logweight'])
  bg['old_SN_reconstructed_loglike']+=1e-3
  mismatch=b.replace_SN(record,bg,list(exact),design)
  assert mismatch['status']=='source_SN_density_mismatch'
  failures.append(mismatch['status'])
assert max(errors)<1e-9 and max(null)==0 and max(abs(np.array(constant)-700))<1e-9
# A normalized replacement can carry an arbitrarily large constant from the
# changed data dimension. Its point-normalized weights must not change.
x=rng.normal(size=1000);a=x-logsumexp(x);c=x+700-logsumexp(x+700)
weight_error=float(np.max(abs(np.exp(a)-np.exp(c))));assert weight_error<1e-12
paths=[SRC/'anchored_bridge.py',SRC/'anchored-bridge-design.json',SRC/'anchored_adapter.py',Path(__file__)]
result={'status':'passed_independent_synthetic_accounting_review','cases':128,'max_direct_density_error':max(errors),'null_substitution_error':max(null),'constant_shift_weight_error':weight_error,'source_mismatch_rejections':len(failures),'native_or_background_calls':0,'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'limits':'No actual anchored posterior, overlap claim, or CAMB evaluation. Configuration/identity review separately preserved.'}
out=Path(__file__).with_suffix('.json');out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
