import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',CLIPY_NOJAX='1')
import sys,json,hashlib
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
r=Path.cwd();src=r/'studies/unified_cosmology/code/inference';sys.path.insert(0,str(src))
import anchored_adapter as a
import measurement_summary as ms
import modern_fast
import camb,cobaya.model
record=json.loads((r/'studies/unified_cosmology/results/inference/anchored-validation.json').read_text())
for name,value in record['source_sha256'].items():assert a.digest(r/name)==value
surrogate=r/next(iter(record['input_sha256']))
blocked=[];rows=[]
def forbidden(*args,**kwargs):raise RuntimeError('Forbidden native/model evaluation')
with patch.object(camb,'get_results',forbidden),patch.object(camb,'get_background',forbidden),patch.object(cobaya.model,'get_model',forbidden),patch.object(cobaya.model.Model,'__init__',forbidden):
 for model in ['lcdm','cpl']:
  for s in [None,surrogate]:
   new=a.configuration(model=model,surrogate=s);old=modern_fast.configuration(model=model,surrogate=s)
   nn=deepcopy(new);oo=deepcopy(old);nn['likelihood'].pop('released_sn');oo['likelihood'].pop('released_sn')
   assert a.canonical(nn)==a.canonical(oo)
   ident=a.identify(new,a.DATA,s)
   for path,digest in ident['anchored_calibration']['input_and_audit_sha256'].items():assert a.digest(r/path)==digest
   settings=dict(model=model,evolution='none',sample=a.SAMPLE,calibration='official_planck',fast_lensing=True,gpu=False,surrogate=str(s) if s else None)
   try:ms.verify_current_target(dict(arguments=settings,target_identity=ident))
   except AssertionError:blocked.append([model,s is not None,'generic_measurement_consumer'])
   else:raise AssertionError('Original consumer silently accepted anchored identity')
   try:modern_fast.configuration(model=model,sample=a.SAMPLE,surrogate=s)
   except ValueError:blocked.append([model,s is not None,'generic_correction_factory'])
   else:raise AssertionError('Original factory silently accepted anchored sample')
   rows.append(dict(model=model,surrogate=s is not None,identity=ident['identity'],non_SN_config_and_priors_identical=True))
result=dict(status='passed_independent_read_and_configuration_checks',configurations=rows,explicit_rejections=blocked,reviewed_source_sha256=record['source_sha256'],calibration_validation_sha256=a.digest(a.CALIBRATION_RECORD),native_or_background_or_Cobaya_model_calls=0,
 checks=['Full selected symmetric-average covariance retained with77calibrator+1580noncalibrator rows. Raw antisymmetric rounding preserved/audited separately.','One common flat-M integral includes covariance determinant and intercept precision. No extra H0/Cepheidfactor.','Only unique noncalibrator zHD sentto DAprovider, inverse indices reconstruct all1580rows with zHEL conversion.','Each calibration source/audit dependency andactualcurrentCMBassets is included in anchoredidentity; current numerical/scientific package versions bound.','Original generic correction factory and measurement qualifier refuse the anchoredtarget.'])
p=r/'.work/unified-cosmology/anchored-validation/independent-interface-review.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
