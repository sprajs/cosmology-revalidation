"""Finite continuation of a currently running cohort; no scheduled rerun."""
import argparse,json,os,subprocess,time
from pathlib import Path
ROOT=Path.cwd();CODE=ROOT/'studies/unified_cosmology/code/inference'
PYTHON=ROOT/'.work/unified-cosmology/external-probes/.modern-venv/bin/python'
p=argparse.ArgumentParser();p.add_argument('folder',type=Path);p.add_argument('label');p.add_argument('--pid',type=int,required=True);a=p.parse_args()
folder=a.folder.resolve();proc=Path(f'/proc/{a.pid}/stat')
start=proc.read_text().split()[21] if proc.exists() else None
assert start is not None,'Sampler must still be running when this finite continuation starts.'
status=folder/'native-continuation-status.json'
def report(stage,**kw):
 r=dict(stage=stage,time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**kw)
 status.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
report('waiting_for_this_sampler_process',pid=a.pid,process_start_tick=start)
deadline=time.monotonic()+24*3600
while proc.exists() and proc.read_text().split()[21]==start:
 if time.monotonic()>deadline:raise TimeoutError('Finite continuation exceeded24hours; no new task or retry scheduled.')
 time.sleep(30)
assert 'converged: true' in (folder/'chain.checkpoint').read_text(),'Sampler stopped without its declared convergence criterion.'
env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',CLIPY_NOJAX='1')
def run(name,*args):
 report(name)
 subprocess.run([str(PYTHON),str(CODE/name),*map(str,args)],env=env,check=True)
check=folder/'diagnostics.json'
run('diagnostics.py',folder,'--output',check)
assert json.loads(check.read_text())['status']=='passed','Final independent-chain diagnostic failed.'
out=ROOT/f'studies/unified_cosmology/results/inference/{a.label}-exact-correction.json'
run('spectral_correction.py',folder,'--diagnostics',check,'--points',2000,'--workers',4,'--output',out)
assert json.loads(out.read_text())['status']=='passed_importance_weight_gates','Native overlap/chain stability failed; retained for investigation.'
run('measurement_summary.py','--run',folder,out,'--output',out.with_name(a.label+'-measurement.json'))
run('quantile_precision.py','--chain-folder',folder,'--correction-summary',out,'--output',out.with_name(a.label+'-quantile-precision.json'))
run('expansion_history.py','--chain-folder',folder,'--correction-summary',out,'--cache',folder/'expansion-history','--output',out.with_name(a.label+'-expansion-history.json'))
run('luminosity_history.py','--chain-folder',folder,'--correction-summary',out,'--output',out.with_name(a.label+'-luminosity-history.json'))
report('native_continuation_finished',correction=str(out.relative_to(ROOT)))
