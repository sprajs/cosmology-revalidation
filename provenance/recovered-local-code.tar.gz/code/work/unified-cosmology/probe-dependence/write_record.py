from pathlib import Path
import json,hashlib,datetime
r=Path.cwd();w=r/'.work/unified-cosmology/probe-dependence'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
sources=[
 ('act_primary','https://arxiv.org/html/2503.14452v2#S6.S3','actprimary.html','VI.3; residual TT overlap and example Neff uncertainty'),
 ('spt_primary','https://arxiv.org/html/2506.20707v2#S7.SS1','sptprimary.html','VII.1 and VII.2.2; independence assumptions and MUSE-specific simulation check'),
 ('spt_pan_lensing','https://arxiv.org/pdf/2308.11608','spt2018.pdf','VI.A.1-2, printed pages17-18; primary/lensing factorization and Planck comparison'),
 ('primary_lensing_forecast','https://arxiv.org/pdf/2308.11588','trendafilova.pdf','III-IV and Fig3; idealized model-dependent uncertainty effects'),
 ('new_joint_lensing','https://arxiv.org/html/2504.20038v2#S8','jointlensing.html','VIII; MUSE/M2PM polarization lensing, not Pan2018 temperature'),
 ('prior_bug_notice','https://lambda.gsfc.nasa.gov/product/spt/spt3g_d1_bandp_liklyhood_info.html','sptnotice.html','Update04/01/26; cropped Planck repeated priors'),
 ('desi_dr2','https://arxiv.org/html/2503.14738v2#S4.SS3','desi.html','IV.3 and appendixB; distinct SN compilations and internal BAO systematics'),
 ('des_sn_bao','https://arxiv.org/html/2503.06712v2#S3.SS2','des-sn-bao.html','III.2; independent likelihood assumption'),
 ('des_multiprobe','https://arxiv.org/html/2605.27221v1#S2.SS2','des-multiprobe.html','II.2; separate future-expansion guardrail')]
pins=['studies/unified_cosmology/code/external_probes/modern_adapter.py','studies/unified_cosmology/code/external_probes/adapter.py','studies/unified_cosmology/results/external_probes/modern-acquisition.json','.work/unified-cosmology/external-probes/DR6-ACT-lite/act_dr6_cmbonly/PlanckActCut.py','.work/unified-cosmology/external-probes/act_dr6_lenslike/act_dr6_lenslike/act_dr6_lenslike.py','.work/unified-cosmology/external-probes/candl/candl/interface.py','.work/unified-cosmology/external-probes/.modern-venv/lib/python3.12/site-packages/spt_candl_data/SPT3G_D1_TnE_v0/lite/SPT3G_D1_TnE_lite.yaml','.work/unified-cosmology/external-probes/.modern-venv/lib/python3.12/site-packages/candl_data/SPT3G_2018_Lens_v0/SPT3G_2018_PP_lens_and_CMB.yaml']
for p in pins:assert(r/p).is_file(),p
out={
 'schema':'cosmology-probe-dependence-review-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'review_completed_conditional_factorization_not_full_cross_covariance_validated',
 'reviewed_configuration':{'adapter':'studies/unified_cosmology/code/external_probes/modern_adapter.py','model':'cpl','calibration':'official_planck','act_lmax':6500,'bao':True,'scope':'Snapshot review; runtime initialization and covariance/prior checks, no posterior fit or estimation of missing covariance.'},
 'runtime_checks':json.loads((w/'runtime-check.json').read_text()),
 'runtime_check_reproduction':{'command':'OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .work/unified-cosmology/external-probes/.modern-venv/bin/python .work/unified-cosmology/probe-dependence/runtime_check.py','python_source':(w/'runtime_check.py').read_text(),'prerequisite':'Acquire/install the pinned modern external-probe packages; restore embedded Python source at the command path from repository root. No theory evaluation required.','source_sha256':sha(w/'runtime_check.py'),'output_sha256':sha(w/'runtime-check.json')},
 'dependence_ledger':[
 {'pair':'ACT_lensing__Planck_lensing','status':'included_joint_covariance','dimensions':[10,9],'max_abs_cross_correlation':.20628399192095687,'standalone_Planck_lensing_duplicate':False},
 {'pair':'ACT_primary__Planck_primary','status':'omitted_after_scale_cuts','remaining_TT_overlap_ell':[600,1000],'source':'act_primary','quantitative_CPL_error_bound':None},
 {'pair':'SPT_D1_primary__ACT_or_Planck_primary','status':'omitted_published_approximation','SPT_ACT_overlap_fraction_of_ACT_mask_approx':.10,'source':'spt_primary','quantitative_CPL_error_bound':None},
 {'pair':'primary_CMB__Pan2018_SPT_lensing','status':'omitted_published_approximation','source':'spt_pan_lensing','response_correction_is_cross_covariance':False,'MUSE_tests_validate_exact_Pan_block':False},
 {'pair':'Pan2018_SPT_lensing__ACT_Planck_lensing','status':'omitted','sources':['spt_pan_lensing','new_joint_lensing'],'new_MUSE_cross_covariance_directly_transferable':False,'quantitative_CPL_error_bound':None},
 {'pair':'Dovekie_SN__DESI_DR2_BAO','status':'omitted_no_matching_quantitative_bound_located','sources':['desi_dr2','des_sn_bao'],'proven_large':False},
 {'pair':'CMB_lensing__DESI_DR2_BAO','status':'omitted_no_matching_quantitative_bound_located','sources':['desi_dr2'],'proven_large':False}
 ],
 'interpretation':{'full_cross_covariance_validated':False,'posterior_conditional_on_factorization':True,'universal_error_inflation_supported':False,'missing_correlations_shown_to_reverse_dark_energy_preference':False,'separate_SPT_prior_multiplication_issue_reproduced_in_current_scalar_factors':False,'historical_Dovekie_chain_prior_bug_established_by_this_review':False},
 'scope_guards':[
 'Shared cosmological theory does not supply measurement cross-covariance.',
 'SPT3G_2018_Lens_and_CMB contains twelve lensing data bins plus primary-spectrum response terms, not a second primary CMB data vector.',
 'The forecast ~5% free-w0 uncertainty effect at noise10uKarcmin and lensingLmin50 is idealized; it is neither a correction nor a bound for this CPL+SN+BAO fit.',
 'The new MUSE/M2PM SPT polarization-lensing cross-covariance tests are not Pan2018 temperature-lensing tests.',
 'DESI internal BAO systematic-bin correlation sensitivity is not a test of SN-BAO independence.',
 'Current code uses one SN compilation at a time and DESI BAO only; no DESY6BAO or 3x2pt likelihood is added.',
 'Scalar prior runtime checks do not validate every historical chain or all information embedded in released likelihoods.'
 ],
 'required_for_exact_assessment':'Matched cross-covariance or common-sky simulations for these exact estimators/masks/noise, propagated through the same CPL fit. Block removal can assess sensitivity, not directly estimate missing covariance.',
 'sources':[{'id':i,'url':u,'locator':l,'cached_path':str((w/f).relative_to(r)),'sha256':sha(w/f)}for i,u,f,l in sources],
 'reviewed_snapshot_sha256':{p:sha(r/p) for p in pins},
 'note_sha256':sha(r/'studies/unified_cosmology/notes/probe-dependence.md')}
p=r/'studies/unified_cosmology/results/inference/probe-dependence.json';p.write_text(json.dumps(out,indent=2)+'\n')
assert abs(out['runtime_checks']['joint_ACT_Planck']['max_abs_cross_correlation']-.20628399192095687)<1e-15
assert all(abs(x+.5)<1e-10 for x in out['runtime_checks']['global_parameter_prior_single_sigma_delta_logp'].values())
assert all(x['priors_remaining']==0 for x in out['runtime_checks']['candl'].values())
print(json.dumps({'result':str(p.relative_to(r)),'sha256':sha(p),'note_sha256':out['note_sha256'],'source_count':len(sources),'status':out['status']},indent=2))
