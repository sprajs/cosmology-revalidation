import sys,json,copy,hashlib
from pathlib import Path
from unittest.mock import patch
from contextlib import ExitStack
import numpy as np
repo=Path.cwd();sys.path.insert(0,str(repo/'studies/unified_cosmology/code/inference'))
import native_posterior_precision as original
import native_precision_thermal_review as thermal
from native_precision_thermal_review_validate import fixture
import camb,cobaya.model

def forbidden(*args,**kwargs):raise AssertionError('No cosmological calls in this review')
with ExitStack() as guard:
 for owner,name in [(camb,'get_results'),(camb,'get_background'),(camb,'get_transfer_functions'),(cobaya.model,'get_model'),(cobaya.model.Model,'__init__')]:guard.enter_context(patch.object(owner,name,forbidden))
 design=json.loads(original.DESIGN.read_text());review_design=json.loads(thermal.DESIGN.read_text())
 cases={}
 for mode in ['common_offset','component_cancellation','between_chain_variation']:
  rows=[]
  for i in range(32):
   row,stored,values=fixture(design,i)
   delta=1000. if mode=='common_offset' else (-1 if i%2 else 1)*.3 if mode=='component_cancellation' else [-.12,-.04,.04,.12][i//8]
   row['audit_index']=i;row['chain']=i//8
   row['point']=dict(stored['point'],H0=60+i);stored['point']=row['point']
   row['high_loglikes']['cmb']+=delta
   if mode=='component_cancellation':row['high_loglikes']['bao']-=delta
   row['high_logpost']=sum(row['high_loglikes'].values())+sum(row['high_logpriors'])
   row['comparison']=original.density_comparison(stored,row['high_loglikes'],row['high_logpriors'],row['high_logpost'],design['diagnostic_thresholds'])
   adjusted,replay=thermal.reviewed_row(row,stored,values,design,review_design)
   assert adjusted['status']=='finite_native_precision'
   assert adjusted['comparison']==row['comparison']
   rows.append(adjusted)
  summary=original.summarize(rows,design);cases[mode]=summary
 assert cases['common_offset']['status']=='no_large_variation_detected_on_fixed32'
 assert {'component_variation:cmb','component_variation:bao'}<=set(cases['component_cancellation']['diagnostic_flags'])
 assert {'total_centered_RMS','total_centered_max_absolute'}<=set(cases['between_chain_variation']['diagnostic_flags'])
 paths=[original.__file__,original.DESIGN,thermal.__file__,thermal.DESIGN,str(repo/'studies/unified_cosmology/code/inference/native_precision_review_consumer.py')]
 result={'status':'passed_independent_density_integrity_controls','cases':cases,'physical_calls':0,'source_sha256':{str(Path(p).relative_to(repo)):hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in paths}}
 Path('.work/unified-cosmology/probe-dependence/precision-density-integrity-review.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:{'status':v['status'],'flags':v.get('diagnostic_flags')} for k,v in cases.items()}))
