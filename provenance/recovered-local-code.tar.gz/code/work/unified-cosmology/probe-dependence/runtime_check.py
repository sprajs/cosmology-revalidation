from pathlib import Path
import sys,json,hashlib
import numpy as np
b=Path.cwd();ext=b/'studies/unified_cosmology/code/external_probes';sys.path.insert(0,str(ext))
from modern_adapter import modern_info
from cobaya.model import get_model
info=modern_info();info['debug']=False
m=get_model(info)
point=m.prior.reference(random_state=np.random.default_rng(92743));names=list(m.parameterization.sampled_params())
for k in ['A_planck','P_act','Tcal','Ecal']:point[names.index(k)]=1.
p0=float(m.prior.logp(point));checks={}
for k,s in [('A_planck',.0025),('P_act',.003),('Tcal',.0036),('Ecal',.0095)]:
 x=point.copy();x[names.index(k)]+=s;d=float(m.prior.logp(x)-p0);checks[k]=d;assert abs(d+.5)<1e-10
pl=m.likelihood['act_dr6_cmbonly.PlanckActCut'];act=m.likelihood['act_dr6_cmbonly.ACTDR6CMBonly'];joint=m.likelihood['act_dr6_lenslike.ACTDR6LensLike']
n=len(joint.data['bcents_act']);c=joint.data['cov'];r=c/np.sqrt(np.outer(c.diagonal(),c.diagonal()))
assert r.shape==(19,19)
candl={}
for k in ['SPT2025_TnE','SPT2023_lensing']:
 o=m.likelihood[k].candl_like
 candl[k]={'priors_remaining':len(o.priors),'covariance_shape':list(o.covariance.shape),'covariance_sha256':hashlib.sha256(np.asarray(o.covariance).astype('<f8').tobytes()).hexdigest(),'data_set_file':m.likelihood[k].data_set_file}
 assert not o.priors
out={'likelihood_blocks':list(m.likelihood),'global_parameter_prior_single_sigma_delta_logp':checks,'candl':candl,'joint_ACT_Planck':{'covariance_shape':list(c.shape),'max_abs_cross_correlation':float(np.max(abs(r[:n,n:]))),'covariance_sha256':hashlib.sha256(np.asarray(c).astype('<f8').tobytes()).hexdigest()},'Planck_cut':{'active_bins':int((pl.cov.diagonal()<1e9).sum()),'inactive_bins':int((pl.cov.diagonal()>=1e9).sum())},'ACT_ell_cuts':act.ell_cuts,'shared_ACT_Planck_amplitude':info['params']['A_act']['value'],'scope':'Checks configured block structure and scalar prior multiplicity only; does not measure omitted cross-covariance.'}
(b/'.work/unified-cosmology/probe-dependence/runtime-check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
