"""Independent constrained47-coordinate prior+likelihood check; no SED calls."""
import os
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',JAX_PLATFORM_NAME='cpu',JAX_ENABLE_X64='true',XLA_FLAGS='--xla_cpu_multi_thread_eigen=false --xla_force_host_platform_device_count=1')
os.sched_setaffinity(0,[min(os.sched_getaffinity(0))])
from pathlib import Path
import sys,json,hashlib
R=Path('/home/szymon/Documents/ChatGPT/supernova');sys.path.insert(0,str(R/'studies/infrared/code/bayesn_heldout'))
import model
import numpy as np
import jax.numpy as jnp
from scipy.stats import norm,expon,uniform
from scipy.integrate import quad
from numpyro.infer.util import log_density
rng=np.random.default_rng(273811)
A=rng.normal(size=(3,47))*.02
class Fake:
 def forward(self,p):return jnp.asarray(A)@p
fake=Fake();metadata=dict(mu_LCDM=35.,sigma_external=.1)
data=dict(metadata=metadata,errors=[.4,.6,.8],flux=[1.,-.2,.3]);records=[]
for arm in ['LCDM','broad']:
 for i,D in enumerate(([34.6,34.9,35,35.1,35.4,35.7] if arm=='LCDM' else [19.8,20.05,34.8,35.,49.95,50.2])):
  p=np.r_[D,.05+.12*i,1.3+.7*i,-.5+.2*i,rng.normal(size=42),-8+5*i]
  sites=dict(D=p[0],AV=p[1],RV=p[2],theta=p[3],epsilon_white=jnp.array(p[4:46]),tau=p[46])
  actual=float(log_density(model.numpyro_model(fake,data,arm),(),{},sites)[0])
  if arm=='LCDM':priorD=norm.logpdf(D,35.,np.hypot(.1,.088))
  else:
   val=quad(lambda mu:norm.pdf(D,mu,.088)/30,20,50,points=[np.clip(D,20,50)],epsabs=1e-14,epsrel=1e-12)[0]
   priorD=np.log(val)
  expected=priorD+expon.logpdf(p[1],scale=.329)+uniform.logpdf(p[2],loc=1.2,scale=4.8)+norm.logpdf(p[3])+norm.logpdf(p[4:46]).sum()+uniform.logpdf(p[46],loc=-10,scale=30)+norm.logpdf(data['flux'],A@p,data['errors']).sum()
  assert abs(actual-expected)<1e-10
  records.append(dict(arm=arm,D=D,absolute_log_density_error=abs(actual-expected)))
result=dict(status='passed_independent47coordinate_density_check',cases=records,max_error=max(x['absolute_log_density_error'] for x in records),native_SED_calls=0,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),reviewed_model_sha256=hashlib.sha256(Path(model.__file__).read_bytes()).hexdigest(),scope='Synthetic fake linear forward kernel; exact proper priors, latent-coordinate layout and signedGaussian observed likelihood. Does not validate high-dimensional mixing or observed data.')
out=R/'.work/unified-cosmology/probe-dependence/bayesn-synthetic-density-independent.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
