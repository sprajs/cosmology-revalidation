"""Independent array/ledger checks; no physical calculations or fixture writes."""
import hashlib,json,os,sys
from pathlib import Path
from unittest.mock import patch
import numpy as np
ROOT=Path.cwd();HERE=ROOT/'studies/unified_cosmology/code/inference';sys.path.insert(0,str(HERE))
import native_accuracy_runtime as rt
P=ROOT/'studies/unified_cosmology/results/inference/native-accuracy-execution-validation.json'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def seal(v):return hashlib.sha256(json.dumps({k:x for k,x in v.items()if k!='payload_sha256'},sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
proof=read(P);assert proof['status']=='passed_synthetic_native_accuracy_execution_validation'
for p,h in proof['source_sha256'].items():assert digest(ROOT/p)==h
root=ROOT/proof['synthetic_work'];work=root/'full';plan=read(work/'plan.json');ledger=read(work/'record-hashes.json');summary=read(work/'summary.json')
for v in [plan,ledger,summary]:assert seal(v)==v['payload_sha256']
for p,h in ledger['files'].items():assert digest(ROOT/p)==h
req=plan['requests'];assert len(req)==2000
selection=read(ROOT/plan['selection']['selection_path']);assert len(selection['points'])==2000
rows=[];max_prior=0;max_derived=0;max_density=0;max_spectrum=0;native_calls=0;reused=0
for i,r in enumerate(req):
 assert r['index']==i and r['point']==selection['points'][i] and r['location']==selection['locations'][i] and r['group']==selection['groups'][i]
 row=read(work/f'{i:05d}.json');assert seal(row)==row['payload_sha256']
 assert row['binding']['request']==r and row['point']==r['point'] and row['status']=='finite_native_accuracy2'
 parent=read(ROOT/r['parent_native_path']);x=r['point']['x']
 assert row['proposal_logpost']==parent['proposal_logpost']
 assert abs(parent['proposal_logpost']+x*x/2)<1e-14
 max_density=max(max_density,abs(row['log_weight']+.02*x),abs(row['native2_logpost']-(-x*x/2-.02*x)))
 max_derived=max(max_derived,abs(row['native2_derived']['test_derived']-(2*x+3)))
 max_prior=max(max_prior,abs(sum(row['native2_logpriors'])))
 native_calls+=row['native_logposterior_invocations'];rows.append(row)
 if r['origin']=='reused_fixed32':
  reused+=1;ref=plan['evidence']['references'][r['audit_index']]
  assert ref['parent_index']==i and ref['point']==r['point']
  old=read(ROOT/ref['record_path']);assert row['native2_loglikes']==old['high_loglikes'] and row['native2_derived']==old['high_derived']
  with np.load(ROOT/ref['spectrum_path'])as dl,np.load(ROOT/row['spectrum_path'])as cl:
   assert np.array_equal(dl['ell'],cl['ell']);ell=dl['ell'];ll=ell[1:]*(ell[1:]+1)
   for key in ['tt','ee','bb','te','pp']:
    independent=dl[key].copy();independent[1:]=independent[1:]*(2*np.pi)/(ll**(2 if key=='pp'else 1))
    max_spectrum=max(max_spectrum,float(np.max(abs(independent-cl[key]))))
assert native_calls==1968 and reused==32 and max_density<1e-14 and max_derived<1e-14 and max_prior==0 and max_spectrum<1e-14
x=np.array([r['point']['x']for r in rows]);raw=np.exp(-.02*x);w=raw/raw.sum();mean=float(w@x)
assert abs(mean-summary['posterior']['x']['mean'])<1e-14
repeats=0
for g in range(4):
 loc=[r['location']['expanded_index']for r in req if r['group']==g];assert len(loc)==500 and np.all(np.diff(loc)>=0);repeats+=int(sum(np.diff(loc)==0))
assert repeats==2
pids=[]
for j in range(4):
 receipt=read(work/f'worker-{j}.json');process=read(work/f'worker-{j}-process.json');assert receipt['pid']==process['pid'] and process['returncode']==0
 assert receipt['model_constructions']==1 and receipt['failed_index'] is None
 assert receipt['completed_indices']==[r['index']for r in req if r['worker']==j]
 pids.append(receipt['pid'])
assert len(set(pids))==4
# Test retry refusal with subprocess construction explicitly forbidden.
controls=[]
for case in ['pilot','full','interrupted','failure']:
 with patch.dict(os.environ,plan['design']['environment']),patch('subprocess.Popen',side_effect=RuntimeError('A retry must not launch a process.'))as forbidden:
  try:rt.execute_workers(root/case,'native_accuracy_pilot.py')
  except AssertionError:pass
  else:raise AssertionError('Retry accepted: '+case)
  assert forbidden.call_count==0
 controls.append(case)
failed=read(root/'failure'/'summary.json');assert failed['status']=='failed_or_incomplete_persistent_accuracy2_pilot'
assert failed['known_native_logposterior_invocations']==4 and failed['unknown_count_attempts']==0
assert sum(r.get('known_unstarted',False)for r in failed['requests'])==4
interrupted=read(root/'interrupted'/'plan.json');inc=rt.incomplete(root/'interrupted',interrupted,interrupted['requests'][0]);assert inc['unknown_native_invocation_count'] and not inc['known_unstarted']
out={'status':'passed_independent_synthetic_native_accuracy_execution_review','physical_calls':0,'slots':2000,'reused_records':reused,'new_logposterior_requests':native_calls,'preserved_repeated_slots':repeats,'max_logweight_or_density_error':max_density,'max_derived_error':max_derived,'max_independent_Dl_to_Cl_difference':max_spectrum,'mean':mean,'retry_refusals_before_subprocess':controls,'failed_known_requests':4,'failed_unstarted_requests':4,'interrupted_claim_unknown_preserved':True,'scope':'Independent saved synthetic file/array/attempt review; actual process-cache replay still requires the declared physical pilot. Counts are logposterior requests, not instrumented internal CAMB calls.','producer_source_sha256':proof['source_sha256'],'input_sha256':{str(p.relative_to(ROOT)):digest(p)for p in [P,work/'plan.json',work/'summary.json',work/'record-hashes.json']},'source_sha256':{str(Path(__file__).relative_to(ROOT)):digest(__file__)}}
path=ROOT/'.work/unified-cosmology/probe-dependence/native-accuracy-execution-independent.json';assert not path.exists();path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
