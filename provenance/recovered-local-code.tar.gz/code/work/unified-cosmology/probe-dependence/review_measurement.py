"""Synthetic-only integration test of the qualified measurement consumer."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
ROOT=Path.cwd()
CODE=ROOT/'studies/unified_cosmology/code/inference'
sys.path.insert(0,str(CODE))
from exact_correction import summarize,correction_dependencies,record_digest
from measurement_summary import summarize_run
WORK=ROOT/'.work/unified-cosmology/probe-dependence/measurement-synthetic'
WORK.mkdir(exist_ok=True)
DEST=WORK/'exact-correction';DEST.mkdir(exist_ok=True)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
target={'identity':hashlib.sha256(b'SYNTHETIC_TEST_NOT_COSMOLOGY').hexdigest(),'configuration':{'params':{'H0':{'prior':{'min':40,'max':100}},'w':{'prior':{'min':-3,'max':1}},'wa':{'prior':{'min':-5,'max':3}}}}}
for rank in range(4):
    write(WORK/f'run-{rank}.json',{'target_identity':target})
    (WORK/f'chain.{rank}.txt').write_text('SYNTHETIC TEST; NOT MEASUREMENT\n')
chains={str((WORK/f'chain.{i}.txt').relative_to(ROOT)):sha(WORK/f'chain.{i}.txt')for i in range(4)}
diagnostics=WORK/'diagnostics.json'
write(diagnostics,{'status':'passed','failed_gates':[],'input_sha256':chains,'code_sha256':sha(CODE/'diagnostics.py'),'discard_fraction_after_sampler_burnin':.3})
deps=correction_dependencies()
identity=hashlib.sha256(json.dumps({'target_identity':target['identity'],'correction_dependencies':deps},sort_keys=True,separators=(',',':')).encode()).hexdigest()
groups=np.repeat(np.arange(4),500)
x=np.tile([-1.,1.],1000);y=np.tile([-1.,-1.,1.,1.],500)
records=[]
for index,(u,v)in enumerate(zip(x,y)):
    r={'index':index,'point':{'H0':68+u,'w':-.9+.02*u,'wa':-.4+.1*v},'derived':{'omegam':.3+.01*v,'q0':-.4+.1*u,'q05':.1*v,'q1':.5+.1*u,'j0':.2+.4*v,'j05':.3+.1*v,'j1':.5+.1*v},'status':'finite','log_weight':0.,'exact_logpost':0.,'proposal_logpost':0.,'proposal_chain_logpost_difference':0.,'target_identity':identity}
    r['payload_sha256']=record_digest(r)
    write(DEST/f'{index:05d}.json',r);records.append(r)
selection={'points':[r['point']for r in records],'groups':groups.tolist(),'settings':{'model':'cpl','evolution':'none','sample':'SYNTHETIC_NOT_DATA','calibration':'SYNTHETIC'},'chain_sha256':chains,'diagnostics_path':str(diagnostics.relative_to(ROOT)),'diagnostics_sha256':sha(diagnostics),'correction_identity':identity,'correction_dependency_sha256':deps,'proposal_target_identity':target['identity']}
selection['locations']=[{'chain':f'chain.{i//500}.txt','expanded_index':i%500,'row':i%500}for i in range(2000)]
sp=DEST/'selection.json';write(sp,selection)
summary=summarize(records,groups)
summary.update(selection_sha256=sha(sp),selection_path=str(sp.relative_to(ROOT)),code_sha256=sha(CODE/'exact_correction.py'),correction_dependency_sha256=deps,correction_identity=identity,proposal_target_identity=target['identity'],diagnostics_path=str(diagnostics.relative_to(ROOT)),diagnostics_sha256=sha(diagnostics))
summary['native_record_sha256']={str((DEST/f'{i:05d}.json').relative_to(ROOT)):sha(DEST/f'{i:05d}.json')for i in range(2000)}
assert summary['status']=='passed_importance_weight_gates',summary['failed_gates']
rp=WORK/'summary.json';write(rp,summary)
report=summarize_run(WORK,rp)
assert abs(report['posterior']['H0']['mean']-68)<1e-12
order=report['weighted_covariance']['parameter_order'];cov=np.array(report['weighted_covariance']['matrix'])
i,j,k=map(order.index,['H0','w','wa'])
assert abs(cov[i,i]-1)<1e-12
assert abs(cov[i,j]-.02)<1e-12
assert abs(cov[j,j]-.0004)<1e-12
assert abs(cov[k,k]-.01)<1e-12
assert abs(cov[i,k])<1e-12
assert abs(report['conditional_sign_fractions']['q0_below_zero']['fraction']-1)<1e-12
assert not report['conditional_sign_fractions']['q0_below_zero']['both_events_observed']
assert abs(report['conditional_sign_fractions']['j0_below_zero']['fraction']-.5)<1e-12
assert report['coupled_CAMB_support_boundary']['fraction_within_005_of_boundary']==0
rejections=[]
path=DEST/'00000.json';original=path.read_bytes()
bad=json.loads(original);bad['derived']['j0']+=.123;write(path,bad)
try:summarize_run(WORK,rp)
except AssertionError:rejections.append('changed_derived_value')
else:raise AssertionError('Changed native derived value was accepted')
path.write_bytes(original)
chain=WORK/'chain.0.txt';original=chain.read_bytes();chain.write_bytes(original+b'CHANGED\n')
try:summarize_run(WORK,rp)
except AssertionError:rejections.append('changed_chain_bytes')
else:raise AssertionError('Changed parent chain was accepted')
chain.write_bytes(original)
original=rp.read_bytes();bad=json.loads(original);bad['status']='insufficient_importance_overlap';write(rp,bad)
try:summarize_run(WORK,rp)
except AssertionError:rejections.append('failed_parent_weight_gate')
else:raise AssertionError('Failed parent gate was accepted')
rp.write_bytes(original)
out={'status':'passed_synthetic_only','scientific_measurement':False,'cases':2000,'analytic_checks':['mean','full_posterior_covariance_and_crosscovariance','zero_tail_flag','balanced_jerk_fraction','coupled_support_fraction'],'rejected_mutations':rejections,'source_sha256':{str(p.relative_to(ROOT)):sha(p)for p in [Path(__file__),CODE/'measurement_summary.py',CODE/'exact_correction.py',CODE/'luminosity_sensitivity.py',CODE/'luminosity-sensitivity-design.json']}}
write(WORK.parent/'measurement-independent.json',out)
print(json.dumps(out,indent=2))
