"""Independent audit of saved synthetic MH ledger only; no model or sampler calls."""
import json,hashlib
from pathlib import Path
import numpy as np
from scipy.stats import multivariate_normal,multivariate_t
R=Path('/home/szymon/Documents/ChatGPT/supernova')
folder=R/'.work/unified-cosmology/inference/independence-validation/gaussian-final'
q=np.load(folder/'proposal.npz');mu,C=q['mean'],q['cov']
def logq(x):return np.logaddexp(np.log(.9)+multivariate_normal.logpdf(x,mu,C*1.05**2),np.log(.1)+multivariate_t.logpdf(x,mu,C*2.4,df=5))
checks=[]
for rank in range(4):
 p=folder/f'chain_independence-candidates-{rank}.jsonl';rows=[json.loads(s) for s in p.read_text().splitlines()]
 trial=np.array([r['trial'] for r in rows]);previous=np.array([r['previous'] for r in rows]);inside=(abs(trial[:,0])<=2)&(abs(trial[:,1])<=3)
 density=-.5*((trial[:,0]-.1)/.4)**2-.5*((trial[:,1]+.1)/.6)**2-np.log(24)
 old=-.5*((previous[:,0]-.1)/.4)**2-.5*((previous[:,1]+.1)/.6)**2-np.log(24)
 ratio=np.minimum(0,density-old+logq(previous)-logq(trial));accepted=inside&(np.array([r['log_uniform'] for r in rows])<ratio)
 assert np.array_equal(accepted,[r['accepted'] for r in rows])
 qerror=max(np.max(abs(logq(trial)-[r['trial_logq'] for r in rows])),np.max(abs(logq(previous)-[r['previous_logq'] for r in rows])))
 holds=[];expected_frequency=0
 for i,row in enumerate(rows):
  if i:
   prev=rows[i-1]
   assert row['previous']==(prev['trial'] if prev['accepted'] else prev['previous'])
   assert row['previous_weight']==(1 if prev['accepted'] else prev['previous_weight']+1)
  if row['accepted'] and row['burn_before']<=0:
   holds.append([row['previous_weight'],*row['previous']]);expected_frequency+=row['previous_weight']
 f=folder/f'chain.{rank+1}.txt';head=f.open().readline().lstrip('#').split();a=np.loadtxt(f);actual=a[:,[head.index(x) for x in ['weight','x','y']]]
 assert np.array_equal(actual[:,0],np.asarray(holds)[:,0]);assert np.allclose(actual[:,1:],np.asarray(holds)[:,1:],atol=6e-8,rtol=6e-8)
 checks.append(dict(rank=rank,trials=len(rows),q_max_absolute_error=float(qerror),all_MH_decisions_identical=True,all_completed_holds_identical=True,frequency_total=expected_frequency))
result=dict(status='passed_independent_saved_synthetic_ledger_review',chains=checks,native_calls=0,source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),limitation='Structural and saved-synthetic audit only; production still requires warm-runtime closure and unchanged convergence/native-correction gates.')
out=R/'.work/unified-cosmology/probe-dependence/independence-sampler-independent.json';out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
