"""Independent quadrature/augmented-covariance check; no scientific edits."""
import sys,json,hashlib
from pathlib import Path
import numpy as np
from scipy.integrate import quad
ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/'studies/unified_cosmology/code/inference'))
from luminosity_sensitivity import IntegratedLuminosity
rng=np.random.default_rng(9472)
maxlin=maxgauss=maxoffset=0.
for _ in range(12):
    z=np.linspace(.02,1.25,9)
    a=rng.normal(size=(9,9))
    C=.001*(a@a.T+np.eye(9))
    obs=rng.normal(size=9)
    pred=obs+rng.normal(scale=.15,size=9)
    f=IntegratedLuminosity(z,z,obs,C)
    r=f.from_prediction(pred)
    base=r['baseline_SN_loglike']
    grid=np.log1p(z)/np.log(2)
    v=quad(lambda e:np.exp(f.from_prediction(pred+e*grid)['baseline_SN_loglike']-base),-.5,.5,epsabs=1e-12)[0]
    maxlin=max(maxlin,abs(np.log(v)-r['log_likelihood_ratios']['linear']))
    for name,sigma in [('smooth01',.1),('smooth03',.3)]:
        new=IntegratedLuminosity(z,z,obs,C+sigma**2*f.basis@f.basis.T)
        diff=new.from_prediction(pred)['baseline_SN_loglike']-base
        maxgauss=max(maxgauss,abs(diff-r['log_likelihood_ratios'][name]))
    shifted=f.from_prediction(pred+53.)
    maxoffset=max(maxoffset,max(abs(shifted['log_likelihood_ratios'][k]-r['log_likelihood_ratios'][k])for k in r['log_likelihood_ratios']))
assert max(maxlin,maxgauss,maxoffset)<1e-9
files=[Path(__file__),ROOT/'studies/unified_cosmology/code/inference/luminosity_sensitivity.py']
out={'status':'passed','independent_cases':12,'seed':9472,'linear_quadrature_max_log_error':float(maxlin),'augmented_covariance_max_log_error':float(maxgauss),'global_offset_ratio_max_error':float(maxoffset),'source_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in files}}
Path(__file__).with_name('luminosity-independent.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
