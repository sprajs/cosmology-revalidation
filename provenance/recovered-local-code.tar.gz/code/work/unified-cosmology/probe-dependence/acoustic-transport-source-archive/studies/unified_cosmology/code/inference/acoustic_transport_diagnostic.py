"""Read-only 200-background curvature screen; no spectra or sampler changes."""
import os
os.environ['OMP_NUM_THREADS'] = '1'
os.environ['OPENBLAS_NUM_THREADS'] = '1'
os.environ['MKL_NUM_THREADS'] = '1'
import datetime
import hashlib
import io
import json
from pathlib import Path
import time
from unittest.mock import patch
import numpy as np
import camb

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT/'.work/unified-cosmology/inference'
WORK = BASE/'acoustic-transport-gpu-snapshot'
INPUTS = ['ombh2', 'omch2', 'w', 'wa']
COSMOLOGY = ['H0', 'ombh2', 'omch2', 'logA', 'ns', 'tau', 'w', 'wa']
REFERENCE_THETA100 = 1.041


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def capture():
    WORK.mkdir(parents=True, exist_ok=True)
    manifest = WORK/'snapshot.json'
    if manifest.exists():
        result = json.loads(manifest.read_text())
        assert all(sha(ROOT/p) == h for p, h in result['input_sha256'].items())
        return result
    result = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'selection': '25 chronological midpoint strata per chain after discarding30% of expanded rejection-weight time; no likelihood selection.',
              'reference_theta100': REFERENCE_THETA100, 'input_sha256': {}, 'targets': {}}
    for target, seed in [('linear', 272812), ('smooth01', 272813)]:
        folder = BASE/f'modern-cpl-{target}-dovekie-official_planck-fast-gpu-blocked-f1-scale1p6-seed{seed}-dfff858fc0d4'
        meta = json.loads((folder/'run-0.json').read_text())
        native = meta['target_identity']['configuration']['theory']['spectral_surrogate']['extra_args']
        points = []; ranks = []; locations = []; chains = []
        for rank in range(4):
            source = folder/f'chain.{rank+1}.txt'
            read = source.read_bytes()
            complete = read[:read.rfind(b'\n')+1]
            snap = WORK/f'{target}-{rank}.txt'
            snap.write_bytes(complete)
            result['input_sha256'][str(snap.relative_to(ROOT))] = sha(snap)
            names = complete.splitlines()[0].decode().lstrip('#').split()
            table = np.loadtxt(io.BytesIO(complete))
            weights = table[:, names.index('weight')]
            assert np.all(weights == np.floor(weights)) and np.all(weights >= 1)
            cumulative = np.cumsum(weights).astype(int); total = int(cumulative[-1]); discard = int(.3*total)
            positions = discard+np.floor((np.arange(25)+.5)*(total-discard)/25).astype(int)
            rows = np.searchsorted(cumulative, positions, side='right')
            for index, position in zip(rows, positions):
                points.append({k: float(table[index, names.index(k)]) for k in COSMOLOGY})
                ranks.append(rank)
                locations.append({'rank': rank, 'accepted_row': int(index), 'expanded_index': int(position),
                                  'row_rejection_weight': int(weights[index])})
            chains.append({'rank': rank, 'accepted_rows': len(table), 'expanded_rows': total,
                           'snapshot_prefix_sha256': sha(snap), 'original_path': str(source.relative_to(ROOT)),
                           'read_bytes': len(read), 'complete_bytes': len(complete)})
        result['targets'][target] = {'settings': native, 'target_identity': meta['target_identity']['identity'],
                                     'points': points, 'ranks': ranks, 'locations': locations, 'chains': chains}
    manifest.write_text(json.dumps(result, indent=2)+'\n')
    return result


def design_matrix(x, quadratic):
    return np.column_stack([np.ones(len(x)), x] + ([x[:, i]*x[:, j] for i in range(x.shape[1]) for j in range(i, x.shape[1])] if quadratic else []))


def compare(points, angles, groups):
    h0 = np.array([p['H0'] for p in points]); base = np.array([[p[k] for k in INPUTS] for p in points])
    x = np.column_stack([base, angles]); xf = x.copy(); xf[:, -1] = REFERENCE_THETA100
    records = {}; predictions = {}
    for name, quadratic, ridge in [('linear', False, 0.), ('quadratic', True, 0.), ('quadratic_ridge001', True, .01)]:
        pred = np.zeros(len(x)); fixed = np.zeros(len(x)); folds = []
        for rank in sorted(set(groups)):
            train = groups != rank; test = ~train
            mean = x[train].mean(0); sd = x[train].std(0)
            assert np.all(sd > 0)
            X = design_matrix((x[train]-mean)/sd, quadratic)
            if ridge:
                penalty = np.eye(X.shape[1])*ridge; penalty[0, 0] = 0
                coeff = np.linalg.solve(X.T@X+penalty, X.T@h0[train])
            else:
                coeff = np.linalg.lstsq(X, h0[train], rcond=None)[0]
            pred[test] = design_matrix((x[test]-mean)/sd, quadratic)@coeff
            fixed[test] = design_matrix((xf[test]-mean)/sd, quadratic)@coeff
            folds.append({'held_out_chain': int(rank), 'rmse': float(np.sqrt(np.mean((pred[test]-h0[test])**2))),
                          'design_rank': int(np.linalg.matrix_rank(X)), 'columns': X.shape[1],
                          'design_condition_number': float(np.linalg.cond(X))})
        eta = h0-fixed
        error = pred-h0
        records[name] = {'leave_one_chain_out_H0_RMSE': float(np.sqrt(np.mean(error**2))),
                         'maximum_absolute_H0_error': float(abs(error).max()),
                         'RMSE_over_snapshot_H0_SD': float(np.sqrt(np.mean(error**2))/h0.std()),
                         'fixed_reference_eta_SD': float(eta.std()),
                         'eta_SD_over_H0_SD': float(eta.std()/h0.std()), 'folds': folds}
        predictions[name] = (pred, fixed, eta)
    delta = predictions['quadratic'][1]-predictions['linear'][1]; delta -= delta.mean()
    ratio = records['quadratic']['leave_one_chain_out_H0_RMSE']/records['linear']['leave_one_chain_out_H0_RMSE']
    angle_to_h0 = predictions['quadratic'][0]-predictions['quadratic'][1]
    return {'sample_points': len(points), 'H0_range': [float(h0.min()), float(h0.max())], 'H0_SD': float(h0.std()),
            'theta100_range': [float(angles.min()), float(angles.max())], 'theta100_SD': float(angles.std()),
            'reference_theta100': REFERENCE_THETA100, 'models': records,
            'quadratic_to_linear_cross_validated_RMSE_ratio': float(ratio),
            'nonlinear_fixed_reference_H0_component_RMS': float(np.sqrt(np.mean(delta**2))),
            'nonlinear_component_over_linear_eta_SD': float(np.sqrt(np.mean(delta**2))/predictions['linear'][2].std()),
            'nonlinear_component_over_quadratic_eta_SD': float(np.sqrt(np.mean(delta**2))/predictions['quadratic'][2].std()),
            'angle_variation_equivalent_H0_SD': float(angle_to_h0.std()),
            'predictor_variables': INPUTS+['100thetaMC'],
            'interpretation': 'Unweighted diagnostic cohort, not a cosmological posterior. Leave-one-chain-out uses train-only scaling. Fixed-reference predictor f(others) does not depend on proposed H0; H0=eta+f has unit triangular Jacobian, with original physical H0 prior/support still enforced.'}


def main():
    snapshot = capture()
    saved = WORK/'backgrounds.json'
    if saved.exists():
        background = json.loads(saved.read_text())
        assert background['snapshot_sha256'] == sha(WORK/'snapshot.json')
    else:
        start = time.monotonic(); rows = []; native_calls = 0
        # Spectrum calls are forbidden, including accidental validation work.
        forbidden = lambda *a, **k: (_ for _ in ()).throw(RuntimeError('Spectra forbidden'))
        with patch.object(camb, 'get_results', side_effect=forbidden), patch.object(camb, 'get_transfer_functions', side_effect=forbidden):
            for target, data in snapshot['targets'].items():
                for i, point in enumerate(data['points']):
                    if time.monotonic()-start > 175 or native_calls >= 200:
                        raise RuntimeError('Prespecified background time/call cap reached')
                    pars = camb.set_params(**{k: point[k] for k in ['H0', 'ombh2', 'omch2', 'ns', 'tau', 'w', 'wa']},
                                           As=1e-10*np.exp(point['logA']), **data['settings'])
                    native_calls += 1
                    result = camb.get_background(pars)
                    theta = float(100*result.cosmomc_theta())
                    assert np.isfinite(theta)
                    rows.append({'target': target, 'index': i, 'theta100': theta})
                    (WORK/'background-progress.json').write_text(json.dumps({'native_background_calls': native_calls, 'rows': rows})+'\n')
        background = {'snapshot_sha256': sha(WORK/'snapshot.json'), 'native_background_calls': native_calls,
                      'native_spectrum_calls': 0, 'seconds': time.monotonic()-start, 'rows': rows,
                      'OMP_NUM_THREADS': os.environ['OMP_NUM_THREADS'], 'camb_version': camb.__version__}
        saved.write_text(json.dumps(background, indent=2)+'\n')
    output = {'status': 'diagnostic_only_no_sampler_or_target_change', 'background_execution': {k: v for k, v in background.items() if k != 'rows'},
              'code_sha256': sha(__file__), 'snapshot_path': str((WORK/'snapshot.json').relative_to(ROOT)),
              'snapshot_sha256': sha(WORK/'snapshot.json'), 'background_path': str(saved.relative_to(ROOT)), 'background_sha256': sha(saved),
              'targets': {}, 'limitations': ['These snapshots are not converged or exact-corrected posteriors.',
                   'Predictability or residual-width reduction is not an ESS/CPU or acceptance measurement.',
                   'No current chain should be restarted on this evidence alone.',
                   'A fixed triangular transport must retain the original H0 prior and mapped support, and freeze f before a separate proposal pilot.']}
    for target, data in snapshot['targets'].items():
        theta = np.array([r['theta100'] for r in background['rows'] if r['target'] == target])
        output['targets'][target] = compare(data['points'], theta, np.array(data['ranks']))
    # Reuse the previous baseline's exact background values; no new calls.
    file = BASE/'mixing-review-1328/acoustic-400.npz'
    with np.load(file) as old:
        names = list(old['names']); x = old['points']; theta = old['theta']
        picks = np.floor((np.arange(25)+.5)*x.shape[1]/25).astype(int)
        points = [dict(zip(names, row)) for row in x[:, picks].reshape(-1, x.shape[-1])]
        output['historical_baseline_100'] = compare(points, theta[:, picks].ravel(), np.repeat(np.arange(4), 25))
    output['historical_baseline_source'] = {'path': str(file.relative_to(ROOT)), 'sha256': sha(file),
                                         'scope': 'Different earlier baseline target/snapshot; same predictive diagnostic, not a controlled sampler performance comparison.'}
    destination = ROOT/'studies/unified_cosmology/results/inference/acoustic-transport-diagnostic.json'
    destination.write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'execution': output['background_execution'], 'targets': output['targets'], 'historical': output['historical_baseline_100']}, indent=2))


if __name__ == '__main__': main()
