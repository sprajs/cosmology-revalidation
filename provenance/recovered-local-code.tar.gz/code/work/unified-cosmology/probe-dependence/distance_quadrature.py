"""Scratch-only flat distance benchmark. No CMB spectra; no active-source edits."""
import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import sys,time,json,hashlib
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from numpy.polynomial.legendre import leggauss
ROOT=Path.cwd();HERE=ROOT/'studies/unified_cosmology/code/inference';EXTERNAL=HERE.parent/'external_probes'
sys.path[:0]=[str(HERE),str(EXTERNAL)]
import camb
from modern_adapter import modern_info
from likelihood import ReleasedDistances
from cobaya.likelihoods.bao.desi_dr2 import desi_dr2
WORK=ROOT/'.work/unified-cosmology/probe-dependence'
C=299792.458
sources=[EXTERNAL/'modern_adapter.py',EXTERNAL/'adapter.py',HERE/'likelihood.py',HERE/'spectral_surrogate.py',Path(__file__)]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native_attempts=[]
def forbidden(*args,**kwargs):
 native_attempts.append(True);raise RuntimeError('No native spectra permitted')
camb.get_results=forbidden;camb.get_transfer_functions=forbidden
class CumulativeDistance:
 """Per-background cache, no interpolation between redshift tabulation nodes."""
 def __init__(self,background,z,nodes=16):
  if background.Params.omk != 0:raise ValueError('Only exactly flat spatial geometry supported')
  self.background=background # strong ownership: never reused with another state
  self.nodes,self.weights=leggauss(nodes);self.hubble_evaluations=0
  self.prepare(z)
 def prepare(self,z):
  z=np.atleast_1d(np.asarray(z,dtype=float))
  if z.ndim!=1 or not np.isfinite(z).all() or np.any(z<0):raise ValueError('Finite nonnegative scalar/1D redshifts required')
  self.grid=np.unique(np.r_[0.,z]);lo=self.grid[:-1];hi=self.grid[1:]
  half=(hi-lo)/2;mid=(hi+lo)/2
  abscissa=mid[:,None]+half[:,None]*self.nodes
  H=self.background.hubble_parameter(abscissa.reshape(-1)).reshape(abscissa.shape)
  self.hubble_evaluations+=abscissa.size
  if not np.isfinite(H).all() or np.any(H<=0):raise ValueError('Non-expanding/nonfinite background')
  segments=C*half*np.sum(self.weights/H,axis=1)
  self.chi=np.r_[0.,np.cumsum(segments)]
 def comoving(self,z):
  z=np.atleast_1d(np.asarray(z,dtype=float))
  if z.ndim!=1 or not np.isfinite(z).all() or np.any(z<0):raise ValueError('Finite nonnegative scalar/1D redshifts required')
  ii=np.searchsorted(self.grid,z)
  if np.any(ii>=len(self.grid)) or not np.array_equal(self.grid[np.minimum(ii,len(self.grid)-1)],z):
   self.prepare(np.r_[self.grid,z]);ii=np.searchsorted(self.grid,z)
  return self.chi[ii]
 def angular(self,z):
  z=np.atleast_1d(np.asarray(z,dtype=float));return self.comoving(z)/(1+z)
class Provider:
 def __init__(self,background,z,nodes=None):
  self.background=background;self.cache=None if nodes is None else CumulativeDistance(background,z,nodes)
  self.rd=background.get_derived_params()['rdrag']
 def get_angular_diameter_distance(self,z):
  return np.atleast_1d(self.background.angular_diameter_distance(z)) if self.cache is None else self.cache.angular(z)
 def get_Hubble(self,z,units='km/s/Mpc'):
  h=np.atleast_1d(self.background.hubble_parameter(z));return h/C if units=='1/Mpc' else h
 def get_param(self,k):
  assert k=='rdrag';return self.rd
 def get_comoving_radial_distance(self,z):
  return np.atleast_1d(self.background.comoving_radial_distance(z)) if self.cache is None else self.cache.comoving(z)
def evaluate(sn,bao,provider,epsilon=0):
 sn.provider=provider;bao.provider=provider;derived={}
 return {'SN':float(sn.logp(epsilon=epsilon,_derived=derived)),'BAO':float(bao.logp()),'sn_chi2':derived['sn_chi2']}
def main():
 started=time.monotonic();extra=modern_info()['theory']['camb']['extra_args'];extra['lmax']=9001
 paths=[ROOT/f'.work/unified-cosmology/external-probes/spectral-training/holdout/{i:04d}.json' for i in [9,10]]+[ROOT/f'.work/unified-cosmology/inference/broad-spectral/holdout/{i:04d}.json' for i in [34,116]]
 design={'fixed_points':[str(p.relative_to(ROOT)) for p in paths],'purpose':'Two original local design points plus two broad design stress points, not posterior-selected points. Same CAMB H(z), cumulative interval quadrature; no interpolation.','nodes':[4,8,16], 'independent_adaptive_quad':'epsabs=epsrel=2e-12; z=.01,.3,.5,1,1.5,2.33','maximum_background_calls':4,'spectral_calls_allowed':0,'timing_repeats':8,'flat_only':True,'active_target_changes':False}
 design_path=WORK/'distance-quadrature-design.json';assert not design_path.exists();design_path.write_text(json.dumps(design,indent=2)+'\n')
 sn=ReleasedDistances({});smooth=ReleasedDistances({'smooth_sigma':.1});bao=desi_dr2({},packages_path=str(EXTERNAL.parents[3]/'.work/unified-cosmology/external-probes/packages'))
 z=np.unique(np.r_[0.,sn.background_z,bao.data['z'].to_numpy()]);qz=np.array([.01,.3,.5,1.,1.5,2.33]);rows=[];background_calls=0
 data=Path(sn.data_file);sources.extend([data,Path(camb.__file__),Path(sys.modules[desi_dr2.__module__].__file__)])
 for source in paths:
  point=json.loads(source.read_text())['physical_point'];pars=camb.set_params(**{k:v for k,v in point.items() if k!='logA'},As=np.exp(point['logA'])*1e-10,**extra)
  t=time.monotonic();bg=camb.get_background(pars);background_seconds=time.monotonic()-t;background_calls+=1
  native=Provider(bg,z);natives=evaluate(sn,bao,native);smooth_native=evaluate(smooth,bao,native);linear_native=evaluate(sn,bao,native,.12)
  native_da=native.get_angular_diameter_distance(z);native_chi=native.get_comoving_radial_distance(z)
  modes={};approximations={}
  for order in [4,8,16]:
   t=time.monotonic();provider=Provider(bg,z,order);construct=time.monotonic()-t;approximations[order]=provider
   da=provider.get_angular_diameter_distance(z);chi=provider.get_comoving_radial_distance(z)
   likes=evaluate(sn,bao,provider);slikes=evaluate(smooth,bao,provider);llikes=evaluate(sn,bao,provider,.12)
   modes[str(order)]={'prepare_seconds':construct,'max_abs_DA_Mpc':float(max(abs(da-native_da))),'max_relative_DA_nonzero':float(max(abs((da[1:]-native_da[1:])/native_da[1:]))),'max_abs_comoving_Mpc':float(max(abs(chi-native_chi))),'loglike':likes,'loglike_delta_native':{k:likes[k]-natives[k] for k in likes},'smooth01_loglike_delta_native':{k:slikes[k]-smooth_native[k] for k in slikes},'linear_epsilon012_loglike_delta_native':{k:llikes[k]-linear_native[k] for k in llikes}}
  convergence=float(max(abs(approximations[8].get_angular_diameter_distance(z)-approximations[16].get_angular_diameter_distance(z))))
  # Independent adaptive integration never changes background parameters.
  independently=np.array([C*quad(lambda zz:1/float(bg.hubble_parameter(zz)),0,float(zz),epsabs=2e-12,epsrel=2e-12)[0]/(1+zz) for zz in qz])
  independent_errors={str(order):float(max(abs(Provider(bg,np.r_[z,qz],order).get_angular_diameter_distance(qz)-independently))) for order in [8,16]}
  # Native convention: zHD geometry and distinct observed zHEL time-dilation.
  for provider in [native,approximations[8],approximations[16]]:
   da=provider.get_angular_diameter_distance(sn.background_z)[sn.inverse_z]
   dl=da*(1+sn.z)*(1+sn.zhel)
   assert np.array_equal(dl,da*(1+sn.z)*(1+sn.zhel))
  zero=approximations[16].get_angular_diameter_distance(0.); assert zero.shape==(1,) and zero[0]==0.
  order_z=np.array([2.33,0.,.5,.5,.01,1.]);forward=approximations[16].get_angular_diameter_distance(order_z)
  assert forward[2]==forward[3] and forward[1]==0 and forward.shape==order_z.shape
  assert np.max(abs(forward-np.array([approximations[16].get_angular_diameter_distance(zi)[0] for zi in order_z])))==0
  assert approximations[16].get_angular_diameter_distance(np.array([])).shape==(0,)
  # Alternate timing order; include per-state GL construction in joint likelihood.
  timings={key:[] for key in ['native_distance','GL8_distance_including_prepare','GL16_distance_including_prepare','native_SN_BAO','GL8_SN_BAO_including_prepare','GL16_SN_BAO_including_prepare']}
  for repeat in range(8):
   for order in ([None,8,16] if repeat%2==0 else [16,8,None]):
    label='native' if order is None else f'GL{order}'
    t=time.monotonic();provider=Provider(bg,z,order);provider.get_angular_diameter_distance(z)
    timings[label+'_distance'+('' if order is None else '_including_prepare')].append(time.monotonic()-t)
    t=time.monotonic();provider=Provider(bg,z,order);evaluate(sn,bao,provider)
    timings[label+'_SN_BAO'+('' if order is None else '_including_prepare')].append(time.monotonic()-t)
  rows.append({'source':str(source.relative_to(ROOT)),'input_sha256':sha(source),'point':point,'background_seconds':background_seconds,'native_loglike':natives,'orders':modes,'GL8_GL16_max_abs_DA_Mpc':convergence,'adaptive_quad_max_abs_DA_Mpc':independent_errors,'timing_seconds':timings,'median_timing_seconds':{k:float(np.median(v)) for k,v in timings.items()},'edge_cases_passed':True})
  print(json.dumps({'point':str(source.relative_to(ROOT)),'median':rows[-1]['median_timing_seconds'],'GL8_delta_SN_BAO':modes['8']['loglike_delta_native']}),flush=True)
 # Explicit restriction and invalid-input checks use existing background, no extra call.
 from types import SimpleNamespace
 for invalid in [-1.,float('nan'),float('inf'),[[.1,.2]]]:
  try:CumulativeDistance(bg,invalid,16);raise AssertionError('invalid redshift accepted')
  except ValueError:pass
 try:CumulativeDistance(SimpleNamespace(Params=SimpleNamespace(omk=.001)),[.1],16);raise AssertionError('curved geometry accepted')
 except ValueError:pass
 assert background_calls==4 and not native_attempts
 result={'status':'scratch_numerical_benchmark_only','design_sha256':sha(design_path),'source_sha256':{str(p.relative_to(ROOT)) if p.is_relative_to(ROOT) else str(p):sha(p) for p in sources},'background_calls':background_calls,'native_spectrum_calls':len(native_attempts),'SN_rows':len(sn.z),'SN_unique_redshifts':len(sn.background_z),'SN_BAO_unique_grid_including_zero':len(z),'extra_args':extra,'cases':rows,'elapsed_seconds':time.monotonic()-started,'limitations':['Four fixed observed-design/stress points only, not posterior precision qualification.','Same CAMB flat Friedmann background with a different explicit numerical distance quadrature.','SN/BAO timing is not complete CMB likelihood timing or ESS/walltime.','Per-background object cache; no values shared across cosmologies.','zHEL retained separately in released SN prediction; no zHEL-to-zHD replacement.']}
 (WORK/'distance-quadrature.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({'elapsed_seconds':result['elapsed_seconds'],'background_calls':background_calls,'native_spectrum_calls':len(native_attempts)}))
if __name__=='__main__':main()
