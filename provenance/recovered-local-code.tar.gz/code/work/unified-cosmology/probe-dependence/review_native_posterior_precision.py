"""Independent synthetic review; forbids native model construction."""
import sys,json,hashlib,tempfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
ROOT=Path.cwd(); HERE=ROOT/'studies/unified_cosmology/code/inference'
sys.path.insert(0,str(HERE))
import native_posterior_precision as p
from target_identity import canonical
D=json.loads(p.DESIGN.read_text());rng=np.random.default_rng(927981)
source_before=p.digest(HERE/'native_posterior_precision.py')
selection_checks=0
for case in range(100):
    n=int(rng.integers(8,100));groups=np.repeat(np.arange(4),n)
    order=rng.permutation(4*n);groups=groups[order]
    locations=[{'expanded_index':int(11*(int(i)%n)+3)} for i in order]
    picked=p.select_indices(groups,locations)
    assert len(picked)==32 and len({r['parent_index'] for r in picked})==32
    for chain in range(4):
        expected=[11*int(np.floor((j+.5)*n/8))+3 for j in range(8)]
        assert [x['expanded_index'] for x in picked if x['chain']==chain]==expected
    selection_checks+=1
configs=0
for backend in [{},{'fast_lensing':True},{'gpu':True,'fast_lensing':True}]:
    for model in ['lcdm','cpl']:
        for evolution in ['none','linear','smooth01','smooth03']:
            for calibration in ['official_planck','paper_literal']:
                settings=dict(backend,model=model,evolution=evolution,calibration=calibration,sample='dovekie')
                nominal,high=p.native_configurations(settings,D)
                n,h=canonical(nominal),canonical(high)
                assert set(n['theory'])=={'camb'}
                for key in D['numerical_controls']:
                    assert h['theory']['camb']['extra_args'][key]==2
                    h['theory']['camb']['extra_args'][key]=1
                assert h==n
                configs+=1
density_errors=[]
for case in range(100):
    low={str(j):float(v) for j,v in enumerate(rng.normal(-100,20,9))}
    delta=rng.normal(0,.1,9);priors=rng.normal(-2,1,4).tolist()
    stored={'exact_loglikes':low,'exact_logpost':sum(low.values())+sum(priors)}
    high={k:low[k]+delta[int(k)] for k in low}
    highlog=sum(high.values())+sum(priors)
    row=p.density_comparison(stored,high,priors,highlog,D['diagnostic_thresholds'])
    assert not row['failed_density_checks']
    density_errors.append(abs(row['high_minus_declared_total_loglike']-sum(delta)))
    shifted=p.density_comparison(stored,high,[priors[0]+.1]+priors[1:],highlog+.1,D['diagnostic_thresholds'])
    assert 'prior_sum_changed' in shifted['failed_density_checks']
    corrupt=p.density_comparison(stored,high,priors,highlog+.2,D['diagnostic_thresholds'])
    assert 'logdensity_accounting' in corrupt['failed_density_checks']
rows=[{'status':'finite_native_precision','audit_index':i,'chain':i//8,'point':{'x':float(i)},'comparison':{'high_minus_declared_total_loglike':7.,'high_minus_declared_component_loglikes':{'CMB':6.,'SN':1.}}} for i in range(32)]
a=p.summarize(rows,D);assert a['status']=='no_large_variation_detected_on_fixed32' and not a['posterior_qualification']
rows2=json.loads(json.dumps(rows))
for i,r in enumerate(rows2):
    sign=1 if i%2 else -1
    r['comparison']['high_minus_declared_component_loglikes']={'CMB':6.+sign*.3,'SN':1.-sign*.3}
b=p.summarize(rows2,D);assert b['status']=='numerical_sensitivity_requires_followup'
assert all('component_variation:'+k in b['diagnostic_flags'] for k in ['CMB','SN'])
with tempfile.TemporaryDirectory(dir=ROOT/'.work/unified-cosmology/probe-dependence') as tmp:
    tmp=Path(tmp);f=tmp/'fixture.json';p.sealed_write(f,{'x':[1.,2.]});assert p.sealed_read(f)['x']==[1.,2.]
    corrupt=json.loads(f.read_text());corrupt['x'][0]=4.;f.write_text(json.dumps(corrupt))
    try:p.sealed_read(f)
    except AssertionError:pass
    else:raise AssertionError('Tamper accepted')
    cache=tmp/'cache'
    with patch('measurement_summary.summarize_run',side_effect=RuntimeError('unqualified_sentinel')),patch.object(p,'factory',side_effect=AssertionError('model factory reached')):
        try:p.prepare(tmp,tmp/'missing.json',cache)
        except RuntimeError as e:assert str(e)=='unqualified_sentinel'
        else:raise AssertionError('Qualification gate bypassed')
    assert not cache.exists()
assert p.digest(HERE/'native_posterior_precision.py')==source_before
result={'status':'passed_independent_synthetic_review','source_sha256':source_before,'design_sha256':p.digest(p.DESIGN),'selection_cases':selection_checks,'configuration_pairs':configs,'density_accounting_cases':100,'max_density_sum_error':max(density_errors),'constant_offset_and_component_cancellation_checks':'passed','cached_payload_tamper_rejected':True,'unqualified_parent_rejected_before_cache_or_factory':True,'native_spectrum_calls':0,'GPU_calls':0}
result['review_source_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(ROOT/'.work/unified-cosmology/probe-dependence/native-posterior-precision-independent.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
