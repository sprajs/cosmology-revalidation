import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,hashlib
from pathlib import Path
import numpy as np
from scipy.special import logsumexp
ROOT=Path.cwd(); CODE=ROOT/'studies/unified_cosmology/code/inference';sys.path.insert(0,str(CODE))
import camb
calls=[]
def forbidden(*a,**k):
 calls.append('native');raise AssertionError('No native calculation authorized')
camb.get_results=forbidden;camb.get_background=forbidden;camb.get_transfer_functions=forbidden
import joint_lensing_bridge as b
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rows=[];sources={str(CODE/'joint_lensing_bridge.py'):sha(CODE/'joint_lensing_bridge.py')}
for variant in ['actplanckspt3g_baseline','actplanckspt3g_extended']:
 response=b.JointResponse(variant)
 for index in [0,2]:
  path=ROOT/f'.work/unified-cosmology/inference/native-precision/{index:02d}-spectra.npz';sources[str(path.relative_to(ROOT))]=sha(path)
  with np.load(path) as f:
   ell=f['ell'];dl=np.array([f[k] for k in ['tt','ee','bb','te','pp']])
  out={'ell':ell}
  fac=np.divide(2*np.pi,ell*(ell+1),out=np.zeros(len(ell),dtype=float),where=ell>0)
  for key,arr in zip(['tt','ee','bb','te'],dl[:4]):out[key]=arr*fac
  out['pp']=np.divide(2*np.pi*dl[4],(ell*(ell+1))**2,out=np.zeros(len(ell),dtype=float),where=ell>0)
  got=response.evaluate(out,native_check=True)
  P=response.data['cinv'];r=response.data['data_binned_clkk']-np.asarray(got['bandpowers'])
  effective_cov=np.linalg.solve(P,np.eye(len(P)))
  direct=-.5*r@np.linalg.solve(effective_cov,r)
  const=-.5*(np.linalg.slogdet(effective_cov)[1]+len(P)*np.log(2*np.pi))
  row={'variant':variant,'spectrum':index,'native_vs_compressed_loglike':got['native_loglike_absolute_difference'],'native_vs_compressed_bandpower':got['native_bandpower_max_absolute_difference'],'direct_covariance_kernel_error':abs(direct-got['kernel_loglike']),'normalization_error':abs(const-got['normalized_gaussian_constant'])}
  assert max(row[k] for k in row if k not in ['variant','spectrum'])<1e-10
  rows.append(row)
 del response
# Independent auxiliary-prior cancellation: old x,a jointly dependent; replacement
# x likelihood independent of a. Integrate exactly the same finite quadrature.
x=np.linspace(-5,5,801);a=np.linspace(0,2,201);X=x[:,None];A=a[None,:]
logpriorx=-X**2/8; logpriora=-np.log(2)
old_ap=-.5*((X-.3)/.9)**2
old_pan=-.5*((X+1.1*(A-1))/.7)**2
new=-.5*((X+.2)/1.3)**2
logsource=logpriorx+logpriora+old_ap+old_pan
logbridge=logsource+new-old_ap-old_pan
expected=np.broadcast_to(logpriorx+logpriora+new,logsource.shape)
maxratio=float(np.max(abs(logbridge-expected)))
weights_a=np.ones(len(a));weights_a[[0,-1]]=.5
marginal=logsumexp(logbridge+np.log(weights_a),axis=1)
direct=logsumexp(expected+np.log(weights_a),axis=1)
marginal-=logsumexp(marginal);direct-=logsumexp(direct)
error=float(np.max(abs(marginal-direct)))
assert error<1e-13 and maxratio<1e-13 and not calls
result={'status':'independent_review_checks_passed_no_new_physics_calls','source_sha256':sources,'actual_stored_spectrum_checks':rows,'auxiliary_prior_cancellation_max_logdensity_error':maxratio,'auxiliary_marginal_normalized_logdensity_error':error,'forbidden_physics_calls':len(calls),'scope':'Read-only method checks, no cosmological posterior or overlap qualification.'}
result['review_source_sha256']=sha(__file__)
(ROOT/'.work/unified-cosmology/probe-dependence/joint-bridge-independent.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
