"""Bounded full-target CPU/GPU cubic comparison; native spectra forbidden."""
import os
os.environ['OMP_NUM_THREADS']='1';os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['MKL_NUM_THREADS']='1'
import sys,time,json,hashlib,subprocess
from pathlib import Path
import numpy as np
ROOT=Path.cwd();HERE=ROOT/'studies/unified_cosmology/code/inference';sys.path.insert(0,str(HERE))
import camb
from cobaya.model import get_model
from modern_fast import configuration as cpu_factory
from modern_gpu import configuration as gpu_factory
from spectral_surrogate import polynomial,coordinates
from target_identity import canonical
OUT=ROOT/'.work/unified-cosmology/probe-dependence/cubic-gpu-benchmark.json'
MODEL=ROOT/'.work/unified-cosmology/inference/surrogate/cubic-0509.npz'
HOLD=ROOT/'.work/unified-cosmology/external-probes/spectral-training/holdout'
START=time.monotonic();calls={'forbidden_native_spectrum_attempts':0}
def forbidden(*a,**kw):
 calls['forbidden_native_spectrum_attempts']+=1;raise AssertionError('Native spectrum calculation forbidden')
camb.get_results=forbidden;camb.get_transfer_functions=forbidden
h=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
def memory():
 return {'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,memory.total,memory.used,memory.free','--format=csv,noheader'],text=True).strip(),'processes':subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,used_memory','--format=csv,noheader'],text=True).strip()}
report={'status':'in_progress','model_sha256':h(MODEL),'source_sha256':{str(p.relative_to(ROOT)):h(p) for p in [Path(__file__),HERE/'modern_fast.py',HERE/'modern_gpu.py',HERE/'spectral_surrogate.py']},'before_memory':memory(),'cases':[],'point_rule':'First4 originalholdouts inlexicalorder with maxabswhitened<2.5 andpositiveTT/EE/PP. LCDM fixesw=-1wa=0 retainingearlyparams/theta via background-onlyH0 inversion. No posterior interpretation.'}
with np.load(MODEL) as f: model={k:f[k] for k in f.files}
for family in ['cpl','lcdm']:
 ci=cpu_factory(family,'none','dovekie','official_planck',MODEL);gi=gpu_factory(family,'none','dovekie','official_planck',MODEL)
 original=gi['theory']['spectral_surrogate']['external'];gi['theory']['spectral_surrogate']['external']=ci['theory']['spectral_surrogate']['external'];assert canonical(ci)==canonical(gi);gi['theory']['spectral_surrogate']['external']=original
 chosen=[]
 for path in sorted(HOLD.glob('*.json')):
  r=json.loads(path.read_text())
  if r['status']!='finite_exact':continue
  point=dict(r['physical_point']);extra=dict(ci['theory']['spectral_surrogate']['extra_args']);phys={k:point[k] for k in ['ombh2','omch2','ns','tau']};phys['As']=np.exp(point['logA'])*1e-10
  if family=='cpl':pars=camb.set_params(**phys,H0=point['H0'],w=point['w'],wa=point['wa'],**extra)
  else:
   pars=camb.set_params(**phys,cosmomc_theta=r['actual_coordinates'][0]/100,w=-1.,wa=0.,**extra);point.update(H0=pars.H0,w=-1.,wa=0.)
  bg=camb.get_background(pars);x=np.linalg.solve(model['coordinate_cholesky'],coordinates(pars,bg)-model['centre'])
  if max(abs(x))>=2.5:continue
  cls=((polynomial(x,model['exponents'])@model['coefficients'])*model['output_scale']).reshape(5,-1)
  if not np.isfinite(cls).all() or any(np.any(cls[k,2:]<=0) for k in [0,1,4]):continue
  chosen.append({'path':str(path.relative_to(ROOT)),'sha256':h(path),'point':point,'maxabswhitened':float(max(abs(x)))})
  if len(chosen)==4:break
 assert len(chosen)==4,(family,len(chosen))
 row={'model':family,'points':chosen,'timed_evaluations':[]}
 t=time.monotonic();cpu=get_model(ci);gpu=get_model(gi);row['construction_seconds']=time.monotonic()-t
 names=set(cpu.parameterization.sampled_params());ref={n:float(v['ref']['loc'] if isinstance(v.get('ref'),dict) else v['ref']) for n,v in ci['params'].items() if n in names}
 points=[dict(ref,**{k:v for k,v in p['point'].items() if k in names}) for p in chosen]
 for name,obj in [('cpu',cpu),('gpu',gpu)]:
  t=time.monotonic();initial=obj.logposterior(points[0],cached=False);row[name+'_warm_seconds']=time.monotonic()-t;assert np.isfinite(initial.logpost)
 row['active_memory_with_one_benchmark_GPU_context']=memory()
 for repeat in range(2):
  for i,point in enumerate(points):
   outputs={};timings={}
   for name,obj in ([('cpu',cpu),('gpu',gpu)] if (i+repeat)%2==0 else [('gpu',gpu),('cpu',cpu)]):
    t=time.monotonic();outputs[name]=obj.logposterior(point,cached=False);timings[name]=time.monotonic()-t
   left,right=outputs['cpu'],outputs['gpu'];assert np.isfinite(left.logpost) and np.isfinite(right.logpost)
   err={'logpost':abs(left.logpost-right.logpost),'component_loglikes':float(np.max(abs(np.array(left.loglikes)-right.loglikes))),'logpriors':float(np.max(abs(np.array(left.logpriors)-right.logpriors))),'derived':float(np.max(abs(np.array(left.derived)-right.derived)))}
   assert max(err.values())<1e-6,err
   row['timed_evaluations'].append({'repeat':repeat,'point':i,'seconds':timings,'maximum_errors':err})
   assert time.monotonic()-START<115,'Bounded benchmark time budget reached'
 assert cpu.theory['spectral_surrogate'].exact_calls==gpu.theory['spectral_surrogate'].exact_calls==0
 for name in ['cpu','gpu']:row[name+'_median_full_logposterior_seconds']=float(np.median([x['seconds'][name] for x in row['timed_evaluations']]))
 row['median_speedup']=row['cpu_median_full_logposterior_seconds']/row['gpu_median_full_logposterior_seconds'];row['maximum_component_closure']=max(x['maximum_errors']['component_loglikes'] for x in row['timed_evaluations'])
 cpu.close();gpu.close();del cpu,gpu
 report['cases'].append(row);report['elapsed_seconds']=time.monotonic()-START;OUT.write_text(json.dumps(report,indent=2)+'\n')
report.update(status='completed_fixed_point_comparison',**calls,after_memory=memory(),elapsed_seconds=time.monotonic()-START,scope='Fixedinterior full likelihood timings under live host contention. No newnative spectra, chain qualification, MCMC ESS/walltime prediction or changed target. Freshcohort wouldremainseparateandneedfullgates.')
assert calls['forbidden_native_spectrum_attempts']==0
OUT.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','elapsed_seconds','forbidden_native_spectrum_attempts']}));print(json.dumps([{k:r[k] for k in ['model','cpu_median_full_logposterior_seconds','gpu_median_full_logposterior_seconds','median_speedup','maximum_component_closure']} for r in report['cases']]))
