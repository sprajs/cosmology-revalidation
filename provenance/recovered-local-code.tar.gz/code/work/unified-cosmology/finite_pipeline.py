"""Attach one finite, sequential continuation to one existing sampler process.

No scheduler, automatic retry, process termination, source edits or resume.
Default invocation is read-only. Root controls production invocation.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[2]
CODE = ROOT/'studies/unified_cosmology/code/inference'
OUT = ROOT/'studies/unified_cosmology/results/inference'
PYTHON = ROOT/'.work/unified-cosmology/external-probes/.modern-venv/bin/python'


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def parse_stat(text):
    # comm may contain spaces and parentheses. Fields after its final ')' start
    # at field3 (state); starttime is field22, hence remainder index19.
    fields = text[text.rindex(')')+2:].split()
    return {'state': fields[0], 'start_tick': fields[19]}


def process(pid):
    try:
        return parse_stat(Path(f'/proc/{pid}/stat').read_text())
    except (FileNotFoundError, ProcessLookupError):
        return None


def lifetime(current, initial):
    if current is None:
        return 'process_gone'
    if current['start_tick'] != initial['start_tick']:
        return 'pid_reused_original_lifetime_ended'
    if current['state'] in {'Z', 'X', 'x'}:
        return 'process_exited_not_yet_reaped'
    return 'running'


def wait_existing(pid, initial, seconds=24*3600, poll=10):
    deadline = time.monotonic()+seconds
    while True:
        reason = lifetime(process(pid), initial)
        if reason != 'running':
            return reason
        if time.monotonic() >= deadline:
            raise TimeoutError('Finite sampler wait expired; no retry scheduled.')
        time.sleep(min(poll, max(0, deadline-time.monotonic())))


def atomic_json(path, value):
    temporary = path.with_name(path.name+'.part')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    temporary.replace(path)


def competing_continuations(folder):
    names = {'finish_native.py', 'finish_native_audits.py', 'finish_sensitivities.py', 'finite_pipeline.py'}
    matches = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            args = [x.decode(errors='replace') for x in (entry/'cmdline').read_bytes().split(b'\0') if x]
            state = process(int(entry.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        if state is None or state['state'] in {'Z', 'X', 'x'}:
            continue
        if not any(Path(x).name in names for x in args):
            continue
        # Script argv contain the folder as an individual argument, not a shell
        # command substring. Relative arguments are resolved against process cwd.
        try:
            cwd = (entry/'cwd').resolve(strict=True)
            present = any((cwd/x).resolve() == folder for x in args if not x.startswith('-'))
        except (FileNotFoundError, ProcessLookupError, PermissionError, OSError):
            continue
        if present:
            matches.append(int(entry.name))
    return matches


def stages(folder, label):
    correction = OUT/(label+'-exact-correction.json')
    diagnostic = folder/'diagnostics.json'
    rows = []
    def add(script, output, args, required=None, condition=None):
        rows.append({'script': script, 'source_sha256': digest(CODE/script),
                     'output': str(output), 'argv': [str(PYTHON), str(CODE/script), *map(str,args)],
                     'required_status': required, 'condition': condition})
    add('diagnostics.py', diagnostic, [folder, '--output', diagnostic], 'passed')
    add('spectral_correction.py', correction,
        [folder, '--diagnostics', diagnostic, '--points', 2000, '--workers', 4, '--output', correction],
        'passed_importance_weight_gates')
    output = OUT/(label+'-measurement.json')
    add('measurement_summary.py', output, ['--run', folder, correction, '--output', output],
        'qualified_conditional_measurements')
    common = ['--chain-folder', folder, '--correction-summary', correction]
    for script, suffix, cache in [
        ('quantile_precision.py', '-quantile-precision', None),
        ('expansion_history.py', '-expansion-history', 'expansion-history'),
        ('luminosity_history.py', '-luminosity-history', None),
        ('sn_predictive_check.py', '-sn-predictive', 'sn-predictive'),
        ('native_posterior_precision.py', '-native-posterior-precision', 'native-posterior-precision')]:
        filename = (suffix.lstrip('-')+'-'+label if script in
                    {'sn_predictive_check.py', 'native_posterior_precision.py'} else label+suffix)
        output = OUT/(filename+'.json')
        args = common+(['--cache', folder/cache] if cache else [])
        if script == 'native_posterior_precision.py':
            args += ['--workers', 4]
        add(script, output, args+['--output', output])
    for omission in ['sn', 'bao', 'lensing']:
        output = OUT/(label+'-omit-'+omission+'.json')
        add('probe_omission.py', output,
            common+['--omit', omission, '--cache', folder/('omit-'+omission), '--output', output])
    settings = json.loads((folder/'run-0.json').read_text())['arguments']
    if settings['evolution'] == 'smooth01':
        output = OUT/(label+'-to-smooth03.json')
        add('luminosity_bridge.py', output,
            common+['--target', 'smooth03', '--cache', folder/'smooth03-bridge', '--output', output])
    output = OUT/(label+'-joint-lensing.json')
    add('joint_lensing_bridge.py', output,
        common+['--cache', folder/'joint-lensing-bridge', '--execute-native', '--workers', 4, '--output', output],
        condition='native_precision_screen_passed')
    return rows


def selftest():
    text = '123 (a tricky ) process) S '+ ' '.join(map(str,range(4,53)))
    assert parse_stat(text) == {'state': 'S', 'start_tick': '22'}
    assert lifetime(None, {'start_tick':'1'}) == 'process_gone'
    assert lifetime({'start_tick':'2','state':'S'}, {'start_tick':'1'}).startswith('pid_reused')
    child = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(.15)'])
    initial = process(child.pid); assert initial is not None
    # Do not poll/wait with Popen until the tested function has detected the
    # unreaped zombie itself. Only this selftest child is reaped afterwards.
    try:
        result = wait_existing(child.pid, initial, seconds=5, poll=.01)
        assert result == 'process_exited_not_yet_reaped', result
    finally:
        assert child.wait(timeout=5) == 0
    assert process(child.pid) is None
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp)/'state.json'; atomic_json(path, {'ok': True})
        assert json.loads(path.read_text()) == {'ok':True}
        assert not path.with_name(path.name+'.part').exists()
    print(json.dumps({'status':'passed', 'native_or_scientific_calls':0,
                      'checks':['spaced_parenthesized_comm','exit_race_missing_process','PID_reuse',
                                'real_unreaped_zombie','atomic_status_write']}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder', nargs='?', type=Path); parser.add_argument('label', nargs='?')
    parser.add_argument('--pid', type=int); parser.add_argument('--execute', action='store_true')
    parser.add_argument('--selftest', action='store_true')
    args = parser.parse_args()
    if args.selftest:
        selftest(); return
    assert args.folder and args.label and args.pid
    assert re.fullmatch(r'[a-z0-9-]+', args.label), 'A unique safe output label is required.'
    folder = args.folder.resolve(); assert folder.is_relative_to(ROOT/'.work')
    initial = process(args.pid); assert initial is not None, 'Attach to an existing sampler lifetime.'
    command = [x.decode() for x in Path(f'/proc/{args.pid}/cmdline').read_bytes().split(b'\0') if x]
    cwd = Path(f'/proc/{args.pid}/cwd').resolve(strict=True)
    assert any(Path(x).name in {'independence_run.py', 'independence_gpu_run.py'} for x in command), \
        'This attachment is for the explicitly named global sampler process.'
    assert any((cwd/x).resolve() == folder for x in command), 'Sampler command names a different cohort.'
    commands = stages(folder, args.label)
    plan = {'schema':'finite-pipeline-v1', 'folder':str(folder), 'label':args.label,
            'pid':args.pid, 'process':initial, 'process_command':command,
            'launcher_sha256':digest(__file__), 'stages':commands,
            'note':'Completion is not scientific qualification; inspect every result and variant status.'}
    if not args.execute:
        print(json.dumps(plan, indent=2)); return
    competitors = competing_continuations(folder)
    assert not competitors, f'Existing continuation(s) already own this cohort: {competitors}'
    assert all(not Path(row['output']).exists() for row in commands), 'Preserve all earlier outputs; use a fresh label/cohort.'
    # O_EXCL makes this a one-shot attachment, including after an error. No stale
    # lock is cleared automatically and no stage or native attempt is retried.
    lock = folder/'finite-pipeline-plan.json'
    with lock.open('x') as stream:
        json.dump(plan, stream, indent=2); stream.write('\n')
    status_path = folder/'finite-pipeline-status.json'
    completed = []
    def report(stage, **extra):
        record = {'stage':stage, 'time_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
                  'launcher_pid':os.getpid(), 'parent_pid':args.pid,
                  'plan_sha256':digest(lock), 'completed_results':completed, **extra}
        atomic_json(status_path, record); print(json.dumps(record), flush=True)
    try:
        report('waiting_for_one_sampler_lifetime')
        reason = wait_existing(args.pid, initial)
        import yaml
        checkpoint = yaml.safe_load((folder/'chain.checkpoint').read_text())
        samplers = list(checkpoint['sampler'].values())
        assert len(samplers) == 1 and samplers[0]['converged'] is True, 'Sampler stopped without declared convergence.'
        report('sampler_lifetime_ended_and_checkpoint_converged', lifetime_end=reason)
        env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1', CLIPY_NOJAX='1')
        precision_status = None
        for row in commands:
            assert digest(__file__) == plan['launcher_sha256'], 'Launcher source changed.'
            assert digest(CODE/row['script']) == row['source_sha256'], 'Stage source changed after attachment.'
            if row['condition'] and precision_status != 'no_large_variation_detected_on_fixed32':
                completed.append({'script':row['script'], 'status':'not_run_native_precision_support_gate',
                                  'precision_status':precision_status})
                continue
            output = Path(row['output'])
            assert not output.exists(), 'Another writer created the planned output.'
            report('executing_stage', script=row['script'])
            subprocess.run(row['argv'], cwd=ROOT, env=env, check=True)
            value = json.loads(output.read_text())
            record = {'script':row['script'], 'path':str(output.relative_to(ROOT)),
                      'sha256':digest(output), 'status':value['status']}
            if 'variants' in value:
                record['variant_status'] = {k:v['status'] for k,v in value['variants'].items()}
            completed.append(record)
            if row['required_status']:
                assert value['status'] == row['required_status'], 'Required parent scientific qualification failed.'
            if row['script'] == 'native_posterior_precision.py':
                precision_status = value['status']
        report('finite_execution_completed_result_review_required',
               qualified_measurement_is_conditional=True,
               no_model_comparison_or_probe_covariance_claim=True)
    except BaseException as error:
        report('stopped_no_retry', error=repr(error)); raise


if __name__ == '__main__':
    main()
