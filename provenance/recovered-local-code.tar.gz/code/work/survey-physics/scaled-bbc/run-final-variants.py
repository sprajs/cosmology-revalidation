import subprocess,os
from concurrent.futures import ThreadPoolExecutor
prefix=['.venv/bin/python','studies/host_ages/code/survey_physics/scaled_bbc.py','bbc','--shards','16']
def one(flags):
 name='primary' if not flags else '-'.join(x.lstrip('-') for x in flags)
 with open('.work/survey-physics/scaled-bbc/final-'+name+'.log','w') as log:
  subprocess.run(prefix+flags,check=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT)
  subprocess.run(['.venv/bin/python','studies/host_ages/code/survey_physics/scaled_response.py','--shards','16']+flags,check=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT)
 print(name,'complete',flush=True)
with ThreadPoolExecutor(max_workers=4) as p:list(p.map(one,[[],['--common'],['--common','--fixed'],['--highmass-gauge']]))
