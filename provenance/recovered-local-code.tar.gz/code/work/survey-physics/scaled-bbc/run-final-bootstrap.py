import subprocess,os
from concurrent.futures import ThreadPoolExecutor
base=['.venv/bin/python','studies/host_ages/code/survey_physics/scaled_bootstrap.py','--shards','16']
env={**os.environ,'OPENBLAS_NUM_THREADS':'1'}
for flags in [[],['--common']]:
 for mode,n in [('joint',200),('training_only',100)]:
  subprocess.run(base+flags+['--mode',mode,'--replicates',str(n)],env=env,check=True)
def one(spec):
 flags,mode,n=spec
 name='-'.join(x.lstrip('-') for x in flags)+'-'+mode
 with open('.work/survey-physics/scaled-bbc/bootstrap-final-'+name+'.log','w') as log:
  subprocess.run(base+flags+['--mode',mode,'--replicates',str(n),'--workers','2'],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print(name,'complete',flush=True)
with ThreadPoolExecutor(max_workers=4) as p:
 list(p.map(one,[(flags,mode,n) for flags in [['--common','--fixed'],['--highmass-gauge']] for mode,n in [('joint',200),('training_only',100)]]))
