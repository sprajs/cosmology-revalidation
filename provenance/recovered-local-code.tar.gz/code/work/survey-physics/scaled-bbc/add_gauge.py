from pathlib import Path
p=Path('studies/host_ages/code/survey_physics/scaled_bbc.py');s=p.read_text()
def rep(a,b):
 global s
 assert a in s,a
 s=s.replace(a,b,1)
rep('def source_config(data, train, fixed=False):','def source_config(data, train, fixed=False, gauge=False):')
rep('    return text, source, changes','    elif gauge:\n        for key,value in {"u5":"0","p5":"0"}.items():\n            text=re.sub(r"(?m)^"+key+r"=.*$",key+"="+value,text)\n            changes[key]=value\n    return text, source, changes')
rep('def execute_bbc(data, train, folder, fixed=False):','def execute_bbc(data, train, folder, fixed=False, gauge=False):')
rep('source_config(data, train, fixed)','source_config(data, train, fixed, gauge)')
rep('"nuisance_mode": (','"nuisance_mode": "fixed_gamma_highmass_width_colour_refit" if gauge else (')
rep('        for key in ["M0avg", "sigint"]:', '''        if gauge:
            r['parameters']['gamma0']={'value':0.,'conditional_error':0.,'fixed':True}
            deviation=float(np.max(abs(.5-expit((f.HOST_LOGMASS-10)/.001)+.5)))
            assert f.HOST_LOGMASS.ge(10.04).all() and deviation<1e-15
            r['gamma_gauge_max_host_factor_deviation']=deviation
        for key in ["M0avg", "sigint"]:''')
rep('            design = design[:, 3:]','            design = design[:, 3:]\n        elif gauge:\n            design=np.column_stack([design[:,:2],design[:,3:]])')
rep('        centered_shape = (\n            design[:, :3] @ null[:, :3].T','        nfree=2 if gauge else 3\n        centered_shape = (\n            design[:, :nfree] @ null[:, :nfree].T')
rep('            fixed\n            or (','            fixed or gauge\n            or (')
rep('            not fixed and abs(r["parameters"]["gamma0"]["value"])','            not fixed and not gauge and abs(r["parameters"]["gamma0"]["value"])')
rep('                    not fixed\n                    and (','                    not fixed and not (gauge and k=="gamma0")\n                    and (')
rep('def run_stage(shards, common=False, fixed=False):','def run_stage(shards, common=False, fixed=False, gauge=False):')
rep('    suffix = ("-common" if common else "") + ("-fixed" if fixed else "")','    if gauge:\n        assert not fixed\n        common=True\n    suffix = ("-common" if common else "") + ("-fixed" if fixed else "")+("-highmass-gauge" if gauge else "")')
rep('        ids = n.index.intersection(a.index)','        ids = n.index.intersection(a.index)\n        original_common=len(ids)\n        if gauge:\n            ids=ids[n.loc[ids,"HOST_LOGMASS"].ge(10.04)&a.loc[ids,"HOST_LOGMASS"].ge(10.04)]')
rep('f"eval-{arm}-common.FITRES"','f"eval-{arm}{suffix}.FITRES"')
rep('execute_bbc(t[e]["path"], t[tr]["path"], folder, fixed)','execute_bbc(t[e]["path"], t[tr]["path"], folder, fixed, gauge)')
rep('    (RESULTS / (f"scaled-bbc-k{shards:03d}" + suffix + ".json")).write_text(','    if gauge:\n        out["highmass_stratum"]={"min_logmass":10.04,"pre_stratum_common_candidates":original_common,"retained_common_candidates":len(ids),"candidate_loss":original_common-len(ids)}\n    (RESULTS / (f"scaled-bbc-k{shards:03d}" + suffix + ".json")).write_text(')
rep('    p.add_argument("--fixed", action="store_true")','    p.add_argument("--fixed", action="store_true")\n    p.add_argument("--highmass-gauge",action="store_true")')
rep('run_stage(a.shards, a.common, a.fixed)','run_stage(a.shards, a.common, a.fixed, a.highmass_gauge)')
p.write_text(s)
p=Path('studies/host_ages/code/survey_physics/scaled_response.py');s=p.read_text()
rep('    p.add_argument("--fixed", action="store_true")','    p.add_argument("--fixed", action="store_true")\n    p.add_argument("--highmass-gauge",action="store_true")')
rep('suffix = ("-common" if a.common else "") + ("-fixed" if a.fixed else "")','suffix = ("-common" if a.common or a.highmass_gauge else "") + ("-fixed" if a.fixed else "")+("-highmass-gauge" if a.highmass_gauge else "")')
p.write_text(s)
