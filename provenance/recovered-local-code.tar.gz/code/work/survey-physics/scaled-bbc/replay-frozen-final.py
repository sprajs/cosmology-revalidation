import subprocess,json
from pathlib import Path
result=Path('studies/host_ages/results/survey_physics')
prior={p.name:json.loads(p.read_text()) for p in result.glob('scaled-bbc-k016*.json')}
oldtables=json.loads((result/'scaled-inputs-k016.json').read_text())['tables']
subprocess.run(['.venv/bin/python','studies/host_ages/code/survey_physics/scaled_bbc.py','merge','--shards','16'],check=True,stdout=subprocess.DEVNULL)
newtables=json.loads((result/'scaled-inputs-k016.json').read_text())['tables']
assert oldtables==newtables
subprocess.run(['.venv/bin/python','.work/survey-physics/scaled-bbc/run-final-variants.py'],check=True)
for name,p in prior.items():
 n=json.loads((result/name).read_text())
 for k in p['cases']:
  assert p['cases'][k]['outputs']==n['cases'][k]['outputs'],(name,k)
print('All scientific final outputs byte-identical on current-source replay.',flush=True)
