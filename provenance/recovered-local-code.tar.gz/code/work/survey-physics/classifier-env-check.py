import torch
from pathlib import Path
p=Path('/home/szymon/Documents/ChatGPT/supernova/.work/survey-physics/SNDATA_ROOT/models/classifiers/DES-SN5YR/SNNTRAINV19_z_TRAINDES_V19')
print(list(p.iterdir()))
