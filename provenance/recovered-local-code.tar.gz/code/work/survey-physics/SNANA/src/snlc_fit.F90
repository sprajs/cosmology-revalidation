! F77 -> F90 translation created 2025-11-29 with command:
!   ../util/convert_snana_f77_to_f90.py snlc_fit.car
!
! Include base snana code to read/write data and apply cuts
#include "snana.F90" 


! May 6 2026: define MARK_USED macro to suppress "unused argument" with -Wall compile flag
#define MARK_USED(FOO) IF(.FALSE.)THEN;DO;IF(SIZE(SHAPE(FOO))==-1) EXIT;ENDDO;ENDIF

! *********************************************************
! Created June 2006   by R.Kessler
! 
! Generic SNIa lightcurve fitter.
! "Generic" means that any SNIa model can be fit to the data.
! This code applies a known model, but does NOT train SN models.
! 
! -------------------------------------------------------
! This file patches in public analysis utilities
! (HBOOK, READING DATA, etc ...)
! 
! Contents:
!   FITPAR_INI   : one-time init
!   FITPAR_INI2  : one-time init after 1st event is read
!   FITPAR_PREP  : prepare each SN prior to fit (was FITPAR_INI)
!   FITPAR_ANA   : analyze fit results after each lightcurve fit
!   FITPAR_END   : called once after all fits
! 
!   FCNSNLC      : function to minimize for MINUIT
! 
! 
!        HISTORY 
!  ~~~~~~~~~~~~~~~~~~~~~~~~~~
! 
! Dec 2025: translate to fotran 90 [.F90]

! --------------------------------------------------------



! =======================================



! =====================================================================
  MODULE SNFITPAR
    USE SNPAR
    IMPLICIT NONE

#ifdef OBSOLETE
    INTEGER  & 
         IPAR_ITER  & 
        ,IPAR_ISN  & 
        ,IPAR_PEAKMJD  & 
        ,IPAR_SHAPE  & 
        ,IPAR_SHAPE2  & 
        ,IPAR_AV  & 
        ,IPAR_RV, sIPAR_AVRV  & 
        ,IPAR_DLMAG, IPAR_ZPHOT  & 
        ,IPAR_X0, IPAR_COLOR   &  ! for SALT2
        ,IPAR_MB               &  ! for SALT2
        ,IPAR_MAX  & 
        ,IPAR_SPARE  & 
        ,ERRFLAG_FITPREP_NOFILTERS  & 
        ,ERRFLAG_FITPREP_QUANTILES  & 
        ,ERRFLAG_FITPREP_NOEPOCHS  & 
        ,ERRFLAG_FITPREP_NEPOCH  & 
        ,ERRFLAG_FITPREP_ADJUST  & 
        ,ERRFLAG_FIT_BADCOV  & 
        ,ERRFLAG_FIT_CRAZYERR  & 
        ,ERRFLAG_FIT_MARGINALIZE  & 
        ,ERRFLAG_FIT_CUTS  & 
        ,ERRFLAG_FIT_FITPROB_ITER1  & 
        ,ERRFLAG_FIT_SHAPE_ITER1  & 
        ,ERRFLAG_FIT_COLOR_ITER1  & 
        ,ERRFLAG_ZFIT_DROPFILTCUTS  & 
        ,ERRFLAG_ZFIT_RANGE  & 
        ,ERRFLAG_REPEAT_ITER  & 
        ,ERRFLAG_REPEAT_MINOS  & 
! 
        ,OPT_FITANA_STORE_VAL  & 
        ,OPT_FITANA_STORE_ERR
#endif

    INTEGER, PARAMETER ::            &
         IPAR_ITER            =  1   &  ! iteration: 1,2 ... NFIT_ITERATION
        ,IPAR_ISN             =  2   & 
        ,IPAR_PEAKMJD         =  3   &  ! MJD at peak
        ,IPAR_SHAPE           =  4   &  ! stretch or delta, or dm15 ...
        ,IPAR_SHAPE2          =  5   &  ! 2nd shape-param
        ,IPAR_AV              =  6   & 
        ,IPAR_COLOR           =  IPAR_AV      &  ! for SALT2
        ,IPAR_RV              =  7            &  ! MLCS-RV
        ,IPAR_MB              =  IPAR_RV      &  ! for SALT2
        ,IPAR_AVRV            =  IPAR_RV      &  ! AV/RV
        ,IPAR_DLMAG           =  8            &  ! distance modulus
        ,IPAR_X0              =  IPAR_DLMAG   &  ! for SALT2
        ,IPAR_ZPHOT           =  9            &  ! photoZ
        ,IPAR_MAX             =  9             &  ! max number of fit params
        ,IPAR_SPARE           =  IPAR_MAX + 1  & 
!  Define Error flags
!  _FIT -> fixed redshift; _ZFIT -> photoz fit
        ,ERRFLAG_FITPREP_NOFILTERS  =  1   &  ! no valid filters
        ,ERRFLAG_FITPREP_NOEPOCHS   =  2   &  ! no epochs in FITINI_COV
        ,ERRFLAG_FITPREP_NEPOCH     =  3   &  ! too few epochs
        ,ERRFLAG_FITPREP_QUANTILES  =  4   &  ! quantiles either negative or not increasing
        ,ERRFLAG_FITPREP_ADJUST     =  5   &  ! bad chi2 on initial params (July 2024)
        ,ERRFLAG_FIT_BADCOV         =  9   &  ! MNSTAT returns ISTAT<3
        ,ERRFLAG_FIT_CRAZYERR       = 10   &  ! insane error detected
        ,ERRFLAG_FIT_MARGINALIZE    = 11   &  ! could not marginalize
        ,ERRFLAG_FIT_CUTS           = 12   &  ! failed 1 or more cuts
        ,ERRFLAG_ZFIT_DROPFILTCUTS  = 13   &  ! fail Zphot-cuts after drop filter
        ,ERRFLAG_ZFIT_RANGE         = 14   &  ! Zphot outside valid range
        ,ERRFLAG_FIT_FITPROB_ITER1  = 15   &  ! 1st iteration FITPROB cut (4/2024)
        ,ERRFLAG_FIT_SHAPE_ITER1    = 16   &  ! 1st iteration SHAPE cut (7/2024)
        ,ERRFLAG_FIT_COLOR_ITER1    = 17   &  ! 1st iteration COLOR cut
        ,ERRFLAG_REPEAT_ITER        = -1   &  ! repeat fit iteration
        ,ERRFLAG_REPEAT_MINOS       = -2   &  ! repeat entire it with MINOS
        ,OPT_FITANA_STORE_VAL = 1          & 
        ,OPT_FITANA_STORE_ERR = 2 
         
!  OPT_PHOTOZ mask options for redshift prior (Jun 3 2022)

    INTEGER, PARAMETER ::                  & 
         BIT_PHOTOZ_GAUSS            = 0   &  ! OPT_PHOTOZ += 1
        ,BIT_BESTZ_GAUSS             = 1   &  ! OPT_PHOTOZ += 2
        ,BIT_PHOTOZ_QUANTILES        = 2   &  ! OPT_PHOTOZ += 4
        ,BIT_PHOTOZ_QUANTILES_STEFFEN = 3   &  ! OPT_PHOTOZ += 8 ! note: set OPT_PHOTOZ = 12 for this option
        ,BIT_PHOTOZ_QUANTILES_LINEAR = 4   &  ! OPT_PHOTOZ += 16
        ,BIT_PHOTOZ_AUTO_INISTP      = 5   &  ! OPT_PHOTOZ += 32
        ,BIT_PHOTOZ_CHEAT            = 6      ! OPT_PHOTOZ += 64
         

! Declare masks for how to treat log sigma term in fit April 26 2024 W.D. Kenworthy
    INTEGER, PARAMETER ::             & 
        MASK_CHI2_SIGMA_ERRTOT  = 1   &  ! sigma = sigma_data + sigma_model
       ,MASK_CHI2_SIGMA_ERRDATA = 2   &  ! sigma_data only
       ,MASK_CHI2_SIGMA_LOGDET  = 4   &  ! Eventually should become default
       ,MASK_CHI2_SIGMA_IGNORE  = 128    ! Compute quantity for output, but do not use in fit

  END MODULE SNFITPAR


! =====================================================================
  MODULE SNFITVAR
    USE SNPAR
    USE SNFITPAR
    IMPLICIT NONE

    INTEGER, PARAMETER :: MXFIT_DATA = 2000   ! -> 2000 on Mar 13 2024 (was 1500)

! variables used in fit.

    LOGICAL  & 
         LBKSNINFO  & 
        ,USESIM_FITPAR(IPAR_MAX)  & 
        ,LOBS_FITMODEL, LREST_FITMODEL  & 
        ,LSED_FITMODEL  & 
        ,DOFIT_PHOTOZ_MCMC_ADJUST   ! True if using MCMC init for photo-z

    INTEGER  & 
         FITMODEL_INDEX               &  ! integer index for model to fit
        ,NSHAPEPAR                     &  ! 1 or 2
        ,NFITDOF(0:MXFILT_OBS)        &  ! # deg of freedom per filter (0=all)
        ,NFILT_FIT                    &  ! number of filters fitted
        ,ISTORE_ZPULL                 &  ! storage index for Photoz Pull
        ,NFILT_MODEL                  &  ! # rest-filters in SN model
        ,IFILTMAP_MODEL(MXFILT_ALL)   &  ! spare map: ifilt_rest = (ifilt)
        ,IFILTINVMAP_MODEL(MXFILT_ALL) ! inverse map

! ------------
! NEW Jan 25 2014
! Define two sets of arrays:
!  1: _ALL stores all epochs using the fixed 'ep' index
!  2: _FIT stores only the epochs used in the fit; so each index
!     can change its location on the next iteration. This sparse
!     array is needed for SNLCPAK.
! 
! Note that EPLIST_FIT is used in FCN to loop over only
! the epochs to be fit.
! 
! Oct 15 2021: add IEP_CCDNUN, IEP_IMGNUM

    INTEGER, PARAMETER :: MXVAR_R4=60, MXVAR_I4=12

    REAL*4  & 
         R4EP_ALL(MXFIT_DATA,MXVAR_R4)   &  !vs. absolute epoch; fixed each iter
        ,R4EP_FIT(MXFIT_DATA,MXVAR_R4)   &  !sparse subset in fit; changes each iter
        ,R4EP_LAST(MXFIT_DATA,MXVAR_R4) ! store R4EP_ALL for previous fit-iter

    INTEGER  & 
         I4EP_ALL(MXFIT_DATA,MXVAR_I4)  & 
        ,I4EP_FIT(MXFIT_DATA,MXVAR_I4)  & 
        ,EPLIST_FIT(MXFIT_DATA)          ! ep-list for _FIT arrays

    CHARACTER  & 
         BANDEP_ALL(MXFIT_DATA)*4   &  ! added July 2017
        ,BANDEP_FIT(MXFIT_DATA)*4


! define index for each variable.

! variable indices for integer I4EP_ and R4EP_

    INTEGER, PARAMETER ::           & 
! for I4EP_XXX
         IEP_IMJD            = 1   &  ! for absolute IMJD index
        ,IEP_EPOCH           = 2   &  ! for absolute ep index
        ,IEP_IFILT           = 4   &  ! sparse survey filter index
        ,IEP_IFILT_OBS       = 5   &  ! absolute filter index
        ,IEP_IFILT_REST1     = 6   &  ! absolute filter index, nearest rest-filter
        ,IEP_IFILT_REST2     = 7   &  ! idem, 2nd nearest rest-frame filter
        ,IEP_REJECT          = 8   &  ! flag to reject epoch from fit
        ,IEP_REJECT2         = 9   &  ! rejected inside Trest window (Mar 2020)
        ,IEP_DETNUM          = 10  &  ! Detector/CCD number
        ,IEP_IMGNUM          = 11  &  ! image number (e..g, EXPNUM, VISIT_ID)
! 
! for R4EP_XXX
        ,JEP_MJD              = 1  & 
        ,JEP_TOBS             = 2  & 
        ,JEP_TREST            = 3  & 
        ,JEP_DATAFLUX         = 4  & 
        ,JEP_DATAFLUX_ERR     = 5  & 
        ,JEP_DATAMAG          = 6  & 
        ,JEP_DATAMAG_ERR      = 7  & 
        ,JEP_MODELFLUX        = 8  & 
        ,JEP_MODELFLUX_ERR    = 9  & 
        ,JEP_MODELMAG         = 10  & 
        ,JEP_MODELMAG_ERR     = 11  & 
        ,JEP_FLUX_ERRTOT      = 12  & 
        ,JEP_RATIO            = 13  & 
        ,JEP_RATIO_ERR        = 14  & 
        ,JEP_LAMREST          = 15  & 
        ,JEP_AVWARP           = 16  & 
        ,JEP_KCOR             = 17  & 
        ,JEP_KCOR_ERR         = 18  & 
        ,JEP_DATAFLUX_REST    = 19  & 
        ,JEP_MODELMAG_REST    = 20  & 
        ,JEP_FUDGEFLUX_ERR    = 21  & 
        ,JEP_RESID            = 22  & 
        ,JEP_RESID_ERR        = 23  & 
        ,JEP_MAGDIF           = 24   &  ! mag(data) - mag(fitModel)
        ,JEP_DELCHI2          = 25  & 
        ,JEP_XTHOST           = 26  & 
        ,JEP_MWXT             = 27  & 
        ,JEP_MWXT_MAGERR      = 28  & 
        ,JEP_MWXT_FLUXERR     = 29  & 
        ,JEP_FPKRAT           = 30  & 
        ,JEP_FPKRATERR        = 31  & 
        ,JEP_PSF           = 32  & 
        ,JEP_NEA           = 33  & 
        ,JEP_SKYSIG        = 34  & 
        ,JEP_SKYSIG_T      = 35  & 
        ,JEP_ZP            = 36  & 
        ,JEP_ZPERR         = 37  & 
        ,JEP_GAIN          = 38  & 
        ,JEP_XPIX          = 39  & 
        ,JEP_YPIX          = 40  & 
        ,JEP_AREAFRAC      = 41  & 
        ,JEP_SKYFLUXCAL    = 42  & 
        ,JEP_SBFLUXCAL     = 43  & 
        ,JEP_ERRTEST       = 44   &  ! ERRCALC/FLUXCAL_ERR
        ,JEP_ERRCALC       = 45   &  ! calculated error
        ,JEP_PHOTPROB      = 46   & 
        ,JEP_SIM_MAGREST   = 47   & 
        ,JEP_SIM_FLUXREST  = 48   & 
        ,JEP_SIM_FLUXCAL   = 49   &  ! for LSIM_MAGOBS = T
        ,JEP_SIM_DELCHI2   = 50   &  ! chi2 from data-sim flux diff
        ,JEP_FUDGE_MAXFRAC = 51   & 
        ,JEP_WAVECOR       = 52

! EP_XXX refers to "IMJD" variables stored at end of fit.
! These arrays are defined to be passed for plotting.

    REAL  & 
         FCN_FITCHI2(0:MXFILT_OBS)          &  ! FCN fit chi2 per filter (0=>sum)
        ,XNFITDOF(0:MXFILT_OBS)  & 
        ,PEAKMAG_OBS_MODEL(MXFILT_ALL)          &  ! model peak mag (observer)
        ,PEAKMAG_OBS_MODEL_ERR(MXFILT_ALL)      &  ! error on above
        ,PEAKFLUX_OBS_MODEL(MXFILT_ALL)         &  ! model peak flux (observer)
        ,PEAKFLUX_OBS_MODEL_ERR(MXFILT_ALL)     &  ! model peak flux (observer)
        ,PEAKFLUX_OBS_MODEL_COR(MXFILT_ALL)     &  ! data/model correction
        ,PEAKMAG_REST_MODEL(MXFILT_ALL)         &  ! model peak mag (rest-frame)
        ,PEAKMAG_REST_MODEL_ERR(MXFILT_ALL)     &  ! error on above
        ,PEAK_KCOR_MODEL(MXFILT_ALL)            &  ! model Kcor at peak
! 
        ,REDSHIFT_FIT    &  ! z used in fit: SNLC_REDSHIFT or SIM_REDSHIFT
        ,CUTWIN_FITPAR(2,IPAR_MAX)              &  ! used in fitter cuts
        ,CUTWIN_FITCOV(2,IPAR_MAX,IPAR_MAX)     &  ! idem, 9/2016
        ,CUTWIN_FITERRz1(2,IPAR_MAX)            &  ! cuts on sigma(fitPar)/(1+z)
! 
        ,LC_FITCHI2(0:MXFILT_OBS)    &  ! min chi2 from fit
        ,LC_FITPROB(0:MXFILT_OBS)    &  ! prob from above
        ,LC_MARGCHI2(0:MXFILT_OBS)   &  ! chi2 from marginalized params
        ,LC_MARGPROB(0:MXFILT_OBS)   &  ! prob from above
! 
        ,RESTLAMBDA_MODEL(2)    &  ! central filter range defined by SN model
        ,RESTLAMBDA_USEFIT(2)  ! range actually used in fit (Nov 2012)

    LOGICAL  & 
         USE_FITCOV   &  ! T=> use full covariance matrix in fit
        ,USE_FILT(0:MXFILT_ALL)   &  ! user-filter and it exists
        ,USE_LANDOLT_REST  & 
        ,USE_LANDOLT_OBS

    INTEGER  & 
         NFITDATA              &  ! number of fitted data points
        ,NFITDATA_REJECT       &  !  number rejected
        ,NFITDATA_TOTAL                  &  ! sum of above
        ,IFITDATA_USRFUN  & 
        ,I4BAND_EP_NEARPEAK(MXFIT_DATA) ! ep index nearest peak

! R4BNAND_  for filter-dependent quantities
! R4SN_     for SN-dependent quantities (scalars)

    REAL*8  R8EP_MJD(MXFIT_DATA)

    REAL*4  & 
          R4BAND_TREST_NEARPEAK(MXFILT_ALL)  & 
         ,R4BAND_XTMW_NEARPEAK(MXFILT_ALL)  & 
         ,R4BAND_SNRMAX_FIT(MXFILT_ALL)  & 
         ,R4BAND_SNRMAX_RAW(MXFILT_ALL)  & 
! 
         ,R4SN_TEARLY, R4SN_TLATE  & 
         ,R4SN_MJDmin, R4SN_MJDmax  & 
         ,R4SN_FFSUM_DATA      &  !  sum F_data**2/sigma^2
         ,R4SN_FFSUM_MODEL     &  !  sum F_model**2/sigma^2
         ,R4SN_FFSUM_CROSS     &  !  sum F_data*F_model/sigma^2
         ,R4SN_FFSUM_WGT  & 
         ,R4SN_FFSUM_RATIO  & 
         ,RADIUS_POP   ! e.g., sqrt [  (x1/3)^2 + (c/0.3)^2 ]

! define covariance matrices for SN model correlations (NOT for fit)

    REAL*8  & 
         COVMAT1(MXFIT_DATA*MXFIT_DATA)   &  ! 1-dim matrix from get_covar
        ,COVMAT2(MXFIT_DATA,MXFIT_DATA)   &  ! 2-dim matrix to invert
        ,COVMAT_MIN     &  ! min value among all elements
        ,COVMAT_MAX    ! max value ...

    CHARACTER  & 
         FITMODEL_PATH*(MXCHAR_PATH)           &  ! path for model params
        ,FITMODEL_LIST(MXMODEL_INDEX)*40          &  ! generic name(s) for each model
        ,FITMODEL_VERSION*(MXCHAR_MODELNAME)   &  ! = FITMODEL_NAME
        ,FILTLIST_MODEL*(MXFILT_REST*2)  ! filter string for rest-frame model

! common block




! define photoZ variables for photoZ fit.

    REAL  & 
         PHOTOZ_ERR_SNFIT     &  ! photoZ error from SN photoz fit
        ,PHOTOZ_ERR_SNHOST    &  ! photoZ error from host gal
        ,PHOTOZ_ERR_SNMAG     &  ! photoZ error from intrinsic SN mag error
        ,PHOTOZ_ERR_ZPULL     &  ! photoZdif(SN-host) / error
        ,PRIOR_PHOTOZ, PRIOR_PHOTOZ_ERR  &  ! actual z prior used in fit
! 
        ,PHOTOZ_DROPFILTER_MIN(MXFILT_ALL)   &  ! min valid Z
        ,PHOTOZ_DROPFILTER_MAX(MXFILT_ALL)   &  ! max valid Z
        ,PHOTODZ_MIN(MXITER)     &  ! min | PHOTOZ-Zvalid(model) |
        ,PHOTODZ1Z_MIN(MXITER)   &  ! idem ind dZ/(1+z) space
! 
        ,PHOTOZ_RANGE_KCOR(2)  & 
        ,PHOTODZ_REJECT_ORIG  ! in case PHOTODZ_REJECT is altered for zSpec
! 
! ? DOFIT_PHOTOZ_HOST=> DOFIT_PHOTOZ_GAUSS

    LOGICAL  & 
         DOFIT_PHOTOZ_HOST       &  ! T=> include host-photoz
        ,DOFIT_PHOTOZ_noHOST     &  ! T=> no host-photoz
        ,DOFIT_PHOTOZ_CHEAT      &  ! T=> cheater option
        ,PHOTOZ_DROPFILTER(MXFILT_ALL)   &  ! T=> filter was dropped
        ,PHOTOZ_ADDFILTER(MXFILT_ALL)   ! T=> filter added

    INTEGER MASK_PHOTOZ_SOURCE  ! set used OPT_PHOTOZ bits

    INTEGER IFILT_NEARDROP  ! used filt-index nearest to gettinng dropped

    CHARACTER PRIOR_COMMENT*20  ! text for stdout print


! define variables for prior on each fit variable.
! CHI2GRID_PRIOR is a grid storing chi2-values to add.

    INTEGER, PARAMETER :: NBIN_PRIOR = 5000   ! Feb 2026: 1000 -> 5000

    REAL*8  & 
         PRIOR_CHI2GRID(NBIN_PRIOR,IPAR_MAX)  & 
        ,PRIOR_PROBGRID(NBIN_PRIOR,IPAR_MAX)  & 
        ,PRIOR_VALGRID(NBIN_PRIOR,IPAR_MAX)  & 
        ,PRIOR_RANGE(2,IPAR_MAX)  & 
        ,PRIOR_BINSIZE(IPAR_MAX)  & 
        ,FLATPRIOR_RANGE(2,IPAR_MAX)  ! used to interp near discontinuity

! define prior info from external SNCID_LIST_FILE
    REAL*4    PRIOR_FITPAR_SNCID_FILE(2,IPAR_MAX) ! Gauss mean/sigma per fit par
    CHARACTER PRIOR_BANDLIST_SNCID_FILE*40        ! bands used in fit
    LOGICAL   PRIOR_USE_FILT_SNCID_FILE(MXFILT_ALL)

    LOGICAL USE_PRIOR(IPAR_MAX), USE_PRIOR_AV

    INTEGER FLATPRIOR_BINRANGE(2,IPAR_MAX)



  END MODULE SNFITVAR

! =====================================================================
  MODULE FITINP_NML
    USE SNPAR
    IMPLICIT NONE

! namelist input variables.

    CHARACTER  & 
          FITMODEL_NAME*(MXCHAR_FILENAME)     &  ! I: path/model
         ,FITCOVAR_FILE*(MXCHAR_FILENAME)     &  ! I: '' => default, 'SIM' => from sim (for MLCS2k2)
         ,STRETCH_TEMPLATE_FILE*(MXCHAR_FILENAME)   &  ! template for stretch model
         ,SALT2_DICTFILE*(MXCHAR_FILENAME)     &  ! output for SALT2's HUBBLEFIT
         ,FILTLIST_FIT*(MXFILT_ALL)     &  ! I: char list of filters to fit:
!                                      ! I: examples: 'gri' or 'g r i', etc ...
         ,FILTLIST_DMPFCN*20       &  ! I: idem for CHI2FUN [FCN] dump
         ,FILTLIST_DMPFUN*20       &  ! I: idem for USRFUN [flux-fun] dump
         ,NEARFILT_IGNORE_REST*20  &  ! I: ignore these nearest rest-filters
         ,FILTER_FITMAGDIF*4       &  ! I: fit magObs in this filter 2 ways for test
         ,CCID_DUMP_CHI2_MATRIX*20  ! I: CID to print each chi2 term in matrix

    CHARACTER  & 
         FILTLIST_FITRESTMAG*12     ! I: fit for these restMag filters
    REAL  & 
         LUMIFIX_FITRESTMAG        &  ! I: fix shape par to this value (legacy name)
        ,SHAPEFIX_FITRESTMAG       &  ! I: same as above
        ,COLORFIX_FITRESTMAG       &  ! I: fix color par to this value
        ,LAMEXTRAP_FITRESTMAG      &  ! I: allow this much rest-frame extrapolation
        ,DLAMTOL_FITRESTMAG       ! I: allow this lam-tolerance for closest bands

    LOGICAL  & 
          DOFIT_FILT(0:MXFILT_ALL)  & 
         ,LDMPFCN(0:MXFILT_ALL)  & 
         ,LDMPFUN(MXFILT_ALL)  & 
         ,LFIXPAR_ALL        &  ! I: T=> fix all paramters; FITVAL = INIVAL
         ,LFIXPAR_ADJUST     &  ! I: T=> leave params based on FITINI_ADJUST
         ,LKCOR_STRETCH      &  ! I: T=> get Kcor from stretched template
         ,LKCOR_AVWARP       &  ! I: T=> get Kcor from color-warped template
         ,USE_MODEL_MAGERR   &  ! I: T=> use mag error from model
         ,ENABLE_MAGSHIFT_SALT2   &  ! I: T=> enable syst mag shifts from training (not MAGCOR)
         ,ENABLE_WAVESHIFT_SALT2  &  ! I: T=> enable syst wave shifts from training (not WAVECOR)
         ,ALLOW_NEGFLUX_SALT2     &  ! I: T=> alow Flam < 0; otherwise force Flam=0
         ,ADD_SALT2ERR_FROMz      &  ! I: T=> add SALT2 param errors from zerr
         ,USESIM_COLOR       &  ! I: T=> use simulated color (AV,c ...)
         ,USESIM_AV          &  ! I: T => use sim. AV in fit (only if LSIM=T)
         ,USESIM_RV          &  ! I: T => idem for RV
         ,USESIM_LUMIPAR     &  ! I: T => use sim lumipar in fit (legacy name)
         ,USESIM_SHAPE       &  ! I: T => use sim shape value in fit
         ,USESIM_PEAKMJD     &  ! I: T => use sim peakMJD
         ,USESIM_DLMAG       &  ! I: T => use sim DLMAG
         ,USESIM_INIVAL      &  ! I: T => use sim params as initial values
         ,MINOS_ERR_DLMAG    &  ! I: T=> require valid MINOS error for DLMAG
         ,MINOS_ERR_REQALL0  &  ! I: T=> require all MINOS errors to be valid
         ,MINOS_ERR_REQALL1  &  ! I: T=> require all but 1 MINOS errors to be valid
         ,MINOS_ERRMAX_BAD   &  ! I: T=> flag too-small errors (def=T)
         ,UCOR_BXB           &  ! I: T=> correct U-band with BX-B
         ,LTRACE             &  ! I: T=> debug tool to identify crashes
         ,DOCHI2_SIGMA       &  ! I: T=> add chi2 from model-error
         ,CHECK_CRAZYFITERR ! I: T=> check for crazy fit errors (default)

! option to compute Zmax/Vmax for 1/Vmax method (Jun 2013)
    CHARACTER MAGLIM_VMAX*60   ! I: e.g., 'r 21.5  i 22.0'
    INTEGER   OPT_VMAX         ! I: integer mask of options

! Note that _REJECT refer to epochs after 1st fit iteration ;
! these epochs are rejected before 2nd fit.
! FITWIN_XXX refer to cuts on final fit parameters, and are apply to SN.
! Jun 2015: FITWIN_AV -> FITWIN_COLOR

    REAL  & 
         RESTLAMBDA_FITRANGE(2)   &  ! I: rest-frame central lambda range (A)
        ,UVLAM_EXTRAPFLUX       &  ! I: extrapolate SED model back to this lambda
        ,DELCHI2_REJECT         &  ! I: reject epoch at 2nd iter if chi2 >
        ,SIGNOISE_REJECT        &  ! I: reject epoch below this signal/noise
        ,TREST_REJECT(2)        &  ! I: reject epoch at 2nd iter if fails Trest
        ,MJD_REJECT(2)          &  ! I: reject epoch at 2nd iter that fail MJD cut
        ,PEAKMJD_SANITY(2)      &  ! I: sanity check window on fit PEAKMJD
        ,FITWIN_ZPULL(2)        &  ! I: cut-window for ZPULL
        ,FITWIN_ZPHOT(2)        &  ! I: cut-windo on photoz (Dec 2014)
        ,FITWIN_COLOR(2)        &  ! I: cut-window for COLOR/AV
        ,FITWIN_SHAPE(2)        &  ! I: "         for SHAPE
        ,FITWIN_PROB(2)         &  ! I: cut-window on chi2 prob
        ,FITWIN_PROB_ITER1(2)   &  ! I: cut-window on 1st-iter FITPROB (fast cut)
        ,FITWIN_SHAPE_ITER1(2)  &  ! I: cut-window on 1st-iter shape (fast cut)
        ,FITWIN_COLOR_ITER1(2)   &  ! I: cut-window on 1st-iter color (fast cut)
        ,FITWIN_CHI2RED_INI(2)   &  ! I: cut-window on chi2 using initial guess params
        ,FITWIN_CHI2RED_INI2(2)  &  ! I: cut-window on chi2 using init-adjusted params
        ,FITWIN_NOMARG_PROB(2)   &  ! I: cut-window before marginalization
        ,FITWIN_CHI2SIGMA(2)    &  ! I: cut on chi2-contribution from sigma-term
        ,FITWIN_TREST(2)        &  ! I: cut on T - T0 (to replace TREST_REJECT)
        ,FITWIN_MJD(2)          &  ! I: cut on absolute MJD range.
        ,FITWIN_PEAKMJD(2)      &  ! I: cut on final fitted peakmjd
! 
        ,FITWIN_COV_OFFDIAG(2)  &  ! I: global cut on offDiag fitted cov (9/2016)
        ,FITWIN_PEAKMJD_ERR(2)  &  ! I: cut on PEAKMJDerr (9/2016)
        ,FITWIN_MB_ERR(2)       &  ! I: cut on mBerr  (9/2016)
        ,FITWIN_SHAPE_ERR(2)    &  ! I: cut on x1err or delta_err (9/2016)
        ,FITWIN_COLOR_ERR(2)    &  ! I: cut on cerr or AVerr (9/2016)
! 
        ,FITWIN_PEAKMJD_ERRz1(2)   &  ! I: cut on PEAKMJDerr/(1+z), added Mar 2017
        ,FITWIN_MB_ERRz1(2)        &  ! I: cut on NBerr/(1+z)
        ,FITWIN_SHAPE_ERRz1(2)     &  ! I: cut on x1err/(1+z)
        ,FITWIN_COLOR_ERRz1(2)    ! I: cut on cerr/(1+z)

    REAL  & 
         INISTP_PEAKMJD        &  ! I: initial step size for MJD  (days)
        ,INISTP_AV             &  ! I: initial step size for AV
        ,INISTP_RV  & 
        ,INISTP_AVRV           &  ! I: non-zero => fit for AV/RV instead of RV
        ,INISTP_COLOR          &  ! I: initiaql step for color param
        ,INISTP_DLMAG          &  ! I: initial step for lumi-distance mu
        ,INISTP_X0             &  ! I: initial step for SALT2 x0
        ,INISTP_PHOTOZ         &  ! I: initial step for photo-redshift
        ,INISTP_SHAPE          &  ! I: initial step for shape-par
        ,INISTP_SHAPE2         &  ! I: initial step for 2nd shape-par
! 
        ,INIVAL_PEAKMJD        &  ! I: initial value for MJD  (days)
        ,INIVAL_RV             &  ! I: initial value for RV
        ,INIVAL_AV             &  ! I: initial value for AV
        ,INIVAL_AVRV           &  ! I:
        ,INIVAL_COLOR          &  ! I: initial value for color
        ,INIVAL_DLMAG          &  ! I: initial value lumi-distance m
        ,INIVAL_X0             &  ! I: initial value for x0
        ,INIVAL_PHOTOZ         &  ! I: initial value photo-redshift
        ,INIVAL_SHAPE          &  ! I: initial value shape-par
        ,INIVAL_SHAPE2         &  ! I: idem for 2nd shape-par
        ,INIVAL_SHIFT_ERRFRAC  &  ! I: after 1st iter, INIVAL += FITERR*ERRFRAC
        ,FRACERRDIF_REPEATFIT  &  ! I: repeat fit with MINOS if FRACERRDIF > thius
! 
        ,INIVAL_GRIDSEARCH_DPEAKMJD(3)   &  ! I: min,max w.r.t. t0_approx, binsize
        ,INIVAL_GRIDSEARCH_COLOR(3)      &  ! I: min,max,binsize
! 
        ,PRIOR_AVEXP(2)    &  ! I: 2 exp slopes for AV prior
        ,PRIOR_AVWGT(2)    &  ! I: 2 exp wgts for AV prior
        ,PRIOR_AVRES       &  ! I: gaussian smearing on exponential prior
        ,PRIOR_MJDSIG      &  ! I: add chi2 = [(MJD - MJDINI)/MJDSIG]^2
        ,PRIOR_SHAPE_RANGE(2)   &  ! I: min,max for FLAT SHAPE prior
        ,PRIOR_SHAPE_SIGMA      &  ! I: sigma for guassian roll-off on FLAT prior
        ,PRIOR_SHAPE2_RANGE(2)  &  ! I: min,max for FLAT SHAPE2 prior
        ,PRIOR_SHAPE2_SIGMA     &  ! I: sigma for guassian roll-off on FLAT prior
        ,PRIOR_COLOR_RANGE(2)   &  ! I: min,max for FLAT SHAPE prior
        ,PRIOR_COLOR_SIGMA      &  ! I: sigma for guassian roll-off on FLAT prior
        ,PRIOR_LUMIPAR_RANGE(2)   &  ! I: legacy input for PRIOR_SHAPE_RANGE
        ,PRIOR_LUMIPAR_SIGMA      &  ! I: legacy_input for PRIOR_SHAPE_SIGMA
        ,PRIOR_DMU_RANGE(2)       &  ! I: min/max for prior on mu-mu_theory
        ,PRIOR_DMU_SIGMA          &  ! I: Gauss roll-offf
        ,PRIOR_DELTA_PROFILE(4)   &  ! I: DELTA-prior pars: sig(low,up)   min (for MLCS2k2)
! 
        ,FUDGE_COVAR       &  ! I: fudge normalized covariances (0=> no fudge)
        ,SCALE_COVAR       &  ! I: scale entire covariance matrix by this factor
        ,LANDOLT_COLOR_SHIFT(10)   &  ! shifts in color terms (if OPT_LANDOLT>0)
        ,TREST_PEAKRENORM(2)    &  ! I: Trest-range to renorm peakFlux for FPKRAT
        ,TREST_DMPFUN(2)        &  ! I: Trest-range for FILTLIST_DMPFUN
        ,SCALE_PLOTCHI2         &  ! I: for HFUNMIN
        ,SALT2alpha             &  ! I: needed for constrained photoZ fit
        ,SALT2beta              &  ! I: idem
        ,LAMREST_MODEL_SMOOTH  ! I: smooth rest-model at filter-jump

    INTEGER  & 
         OPT_NEARFILT       &  ! I: 4=> 2nd closest filter from MLCS2k2
        ,OPT_COVAR          &  ! I: legacy name for OPT_COVAR_FLUX
        ,OPT_COVAR_FLUX     &  ! I: options for using flux-covariance matrix
        ,OPT_COVAR_MWXTERR  &  ! I: 1 => use MW error in cov matrix
        ,OPT_XTMW_ERR       &  ! I: legacy variable: set to OPT_COVAR_MWXTERR
        ,OPT_COVAR_LCFIT    &  ! I: option to fix non-invertible COV(mB,x1,c)
        ,OPT_SNXT           &  ! I: SN extinction options (depends on model)
        ,OPT_KCORERR        &  ! I: Kcor error option (2=>SJ)
        ,OPT_LANDOLT        &  ! I: bit1 => convert Bessell -> Landolt
        ,OPT_PRIOR          &  ! I: 1=use prior; 0=turn off all priors
        ,OPT_PRIOR_AV       &  ! I: 1=> nominal (default), 0=> flat
        ,OPT_MNSTAT_COV     &  ! I: 1-> repeat on bad value
        ,SIMFIT_IDEAL_PRESCALE   &  ! I: pre-scale sample for including IDEAL fit
        ,NGRID_PDF      &  ! I: number of grid-bins for each dimens of pdf
        ,NSIGMA_PDF     &  ! I: compute PDF for +- NSIGMA_PDF
        ,MAX_INTEGPDF   &  ! I: max # times to integrate PDFs
        ,CONTOUR_LIST(4,20)   &  ! I: define contour plots: CID,IPAR1,IPAR2,NPT
        ,OPT_SALT2FIT   &  ! I: fit 0=> fit x0;  1=> fit log10(x0); 2=> fit delta-mu
        ,NFIT_VERBOSE   &  ! I: number of verbose printouts (avoid huge logs)
        ,OPT_CHI2_SIGMA  ! I: 1= SIGMA_LAST= Total Error, 2= SIGMA_LAST= Data Error, 128= Compute but don't use

! ----------------------
! define all of the PHOTOZ options here in one place
! (except for INISTP_PHOTOZ ande INIVAL_PHOTOZ)

    LOGICAL  & 
         DOFIT_PHOTOZ        &  ! I: T=> fit SN photo-redshift
        ,SKIP_PHOTOZ_INIT    &  ! I: T=> skip initial parameter estimate
        ,LDMP_PHOTOZ_DROPFILTER  ! I: T=> dump reason for dropped filter

    INTEGER  & 
         OPT_PHOTOZ   ! I: bit 0 (1 ) => use host-galaxy ZPRIOR;
                      ! I: bit 1 (2 ) => use spectro Z-prior
                      ! I: bit 2 (4 ) => use zPhot quantiles, cubic spline
                      ! I: bit 3 (8 ) => use zPhot quantiles, Steffan spline
                      ! I: bit 4 (16) => cheat: start with Zspec and correct filters

    INTEGER  &                      ! I: COURSE_PHOTOZ params below have default values
          NBINc_COURSE_PHOTOZ   &   ! I: number of color bins for course PHOTOZ search
         ,NBINs_COURSE_PHOTOZ   &   ! I: number of stretch bins for course PHOTOZ search
         ,NBINt_COURSE_PHOTOZ   &   ! I: number of PEAKMJD bins for course PHOTOZ search
         ,NBINz_COURSE_PHOTOZ   &   ! I: number of 1/(1+zphot) for course PHOTOZ 
         ,SCALE_NBIN_COURSE_PHOTOZ  ! I: scale all NBIN values

    REAL  &
          RANGEc_COURSE_PHOTOZ(2)     &  ! I: color range for course PHOTOZ search
         ,RANGEs_COURSE_PHOTOZ(2)     &  ! I: stretch range for course PHOTOZ search
         ,RANGEt_COURSE_PHOTOZ(2)     &  ! I: delta-PEAKMJD range for course PHOTOZ search
         ,RANGEz_COURSE_PHOTOZ(2)        ! I: photoz range for course PHOTOZ search

    INTEGER  &
          NEVAL_MCMC_PHOTOZ               ! I: MCMC option for approx global search (not ready?)

    REAL  & 
         PHOTOZ_ITER1_LAMRANGE(2)   &  ! I: cut on obs-filter, ITER=1 only
        ,PHOTOZ_BOUND(2)        &  ! I: MINUIT bound for photoz fit
        ,PHOTODZ_REJECT         &  ! I: reject filters in photoZ fit (see code)
        ,PHOTODZ1Z_REJECT       &  ! I: idem for dz/(1+z)
        ,PRIOR_ZERRSCALE        &  ! I: scale hostZ-error for z-prior in photoZ fits
        ,PRIOR_MUERRSCALE       &  ! I: scale MU-error for x0-prior in photoZ fits
        ,SNMAGRMS_for_PHOTOZ    &  ! I: compute PHOTOZ error from SNMAGRMS
        ,PARLIST_MCMC_PHOTOZ(5) ! params for MCMC burn-in

! define varibales to fudge the data errors for particular
! TREST-range and passbands. Note that FUDGE_MAGERR_MODEL
! globally replaces the model error, while FUDGE_FITERR_MAXFRAC
! is added to chi2-error in the specified passbands and Trest range.

    INTEGER  & 
         FUDGE_FITERR_MAXITER     ! I: see manual

    REAL  & 
         FUDGE_FITERR_MAXFRAC       &  ! I: add fit-error = this fraction of maxflux
        ,FUDGE_FITERR_TREST(4)      &  ! I: apply err-fudge to two TREST-ranges
        ,FUDGE_FITERR_RESTLAM(4)    &  ! I: "      "        to RESTLAM range
        ,FUDGE_MAGERR_MODEL         &  ! I: fix model mag-error
        ,FUDGEALL_MAXFRAC           &  ! I: MAXFRAC fudge for all epochs
        ,FUDGEALL_ITER1_MAXFRAC     &  ! I: idem, but 1st iteration only
        ,FUDGE_DATAERR_SCALE        &  ! I: re-scale all data  errors.
        ,FUDGE_MODELERR_SCALE      ! I: re-scale all model errors.

    CHARACTER  & 
         FUDGE_FITERR_PASSBANDS*(MXFILT_ALL) ! I: apply err-fudge to these bands

    CHARACTER VARLIST_PDF*60  ! I: list of variables to marginalize PSF (default='ALL')

! allow TREST-cut to depend on filter (to override global FITWIN_TREST cut)
    CHARACTER  & 
        FITWIN_TREST_FILTER*120    ! I: e.g., 'gr -10.0 50.0  iz 0 50'
    REAL  & 
        FITWIN_TREST_FILT(2,MXFILT_ALL)  ! Trest window for each filter

    LOGICAL  & 
         DOFUDGE_FITERR(MXFILT_ALL)  &  ! internal logical computed from above
        ,USE_FUDGE_FITERR            &  ! internal logical
        ,DOPRIOR_DLMAG              ! internal logical



! ------

    NAMELIST / FITINP /  & 
          FITMODEL_NAME, RESTLAMBDA_FITRANGE, UVLAM_EXTRAPFLUX  & 
         ,FILTLIST_FIT  & 
         ,FILTLIST_DMPFCN, FILTER_FITMAGDIF  & 
         ,FILTLIST_FITRESTMAG, LUMIFIX_FITRESTMAG, SHAPEFIX_FITRESTMAG  & 
         ,COLORFIX_FITRESTMAG, LAMEXTRAP_FITRESTMAG, DLAMTOL_FITRESTMAG  & 
         ,FILTLIST_DMPFUN, TREST_DMPFUN, SCALE_PLOTCHI2  & 
         ,NEARFILT_IGNORE_REST     & 
         ,DOFIT_PHOTOZ, SKIP_PHOTOZ_INIT  & 
         ,LDMP_PHOTOZ_DROPFILTER  & 
         ,LFIXPAR_ALL, LFIXPAR_ADJUST, LKCOR_AVWARP, LKCOR_STRETCH  & 
         ,USE_MODEL_MAGERR, DOCHI2_SIGMA, OPT_CHI2_SIGMA  & 
         , LAMREST_MODEL_SMOOTH  & 
         ,CHECK_CRAZYFITERR, ADD_SALT2ERR_FROMz  & 
         ,ENABLE_MAGSHIFT_SALT2, ENABLE_WAVESHIFT_SALT2  & 
         ,ALLOW_NEGFLUX_SALT2  & 
         ,STRETCH_TEMPLATE_FILE, SALT2_DICTFILE  & 
         ,DELCHI2_REJECT, SIGNOISE_REJECT, PEAKMJD_SANITY  & 
         ,FITWIN_ZPULL, FITWIN_ZPHOT  & 
         ,FITWIN_COLOR, FITWIN_SHAPE, FITWIN_MJD, FITWIN_PEAKMJD  & 
         ,FITWIN_PROB, FITWIN_PROB_ITER1  & 
         ,FITWIN_SHAPE_ITER1, FITWIN_COLOR_ITER1  & 
         ,FITWIN_CHI2RED_INI, FITWIN_CHI2RED_INI2  & 
         ,FITWIN_NOMARG_PROB, FITWIN_CHI2SIGMA  & 
         ,FITWIN_TREST, FITWIN_TREST_FILTER, FITWIN_TREST_FILT  & 
         ,FITWIN_COV_OFFDIAG, FITWIN_PEAKMJD_ERR  & 
         ,FITWIN_MB_ERR, FITWIN_SHAPE_ERR, FITWIN_COLOR_ERR  & 
         ,FITWIN_PEAKMJD_ERRz1  & 
         ,FITWIN_MB_ERRz1, FITWIN_SHAPE_ERRz1, FITWIN_COLOR_ERRz1  & 
         ,SNMAGRMS_for_PHOTOZ  & 
         ,TREST_REJECT, MJD_REJECT  & 
         ,USESIM_AV, USESIM_RV, USESIM_COLOR  & 
         ,USESIM_LUMIPAR, USESIM_SHAPE  & 
         ,USESIM_PEAKMJD, USESIM_DLMAG, USESIM_INIVAL  & 
         ,INISTP_PEAKMJD, INISTP_AV, INISTP_RV, INISTP_AVRV  & 
         ,INISTP_DLMAG, INISTP_X0, INISTP_PHOTOZ, INISTP_COLOR  & 
         ,INISTP_SHAPE, INISTP_SHAPE2  & 
         ,INIVAL_PEAKMJD  & 
         ,INIVAL_AV, INIVAL_RV, INIVAL_AVRV  & 
         ,INIVAL_DLMAG, INIVAL_PHOTOZ, INIVAL_COLOR, INIVAL_X0  & 
         ,INIVAL_SHAPE, INIVAL_SHAPE2, INIVAL_SHIFT_ERRFRAC  & 
         ,INIVAL_GRIDSEARCH_DPEAKMJD, INIVAL_GRIDSEARCH_COLOR  & 
         ,FRACERRDIF_REPEATFIT  & 
         ,OPT_COVAR, OPT_COVAR_FLUX, OPT_COVAR_MWXTERR, OPT_XTMW_ERR  & 
         ,OPT_COVAR_LCFIT, OPT_SNXT, OPT_KCORERR, OPT_NEARFILT  & 
         ,OPT_LANDOLT, UCOR_BXB  & 
         ,OPT_PHOTOZ, SCALE_NBIN_COURSE_PHOTOZ &
         ,NBINc_COURSE_PHOTOZ,  NBINs_COURSE_PHOTOZ &
         ,NBINt_COURSE_PHOTOZ,  NBINz_COURSE_PHOTOZ &
         ,RANGEc_COURSE_PHOTOZ, RANGEs_COURSE_PHOTOZ &
         ,RANGEt_COURSE_PHOTOZ, RANGEz_COURSE_PHOTOZ &
         ,NEVAL_MCMC_PHOTOZ, PARLIST_MCMC_PHOTOZ  & 
         ,FUDGE_COVAR, SCALE_COVAR, LANDOLT_COLOR_SHIFT  & 
         ,NGRID_PDF, NSIGMA_PDF, MAX_INTEGPDF, VARLIST_PDF  & 
         ,PRIOR_AVEXP, PRIOR_AVWGT, PRIOR_AVRES, PRIOR_MJDSIG  & 
         ,PRIOR_ZERRSCALE, PRIOR_MUERRSCALE, DOPRIOR_DLMAG  & 
         ,PRIOR_COLOR_RANGE, PRIOR_COLOR_SIGMA  & 
         ,PRIOR_SHAPE_RANGE, PRIOR_SHAPE_SIGMA  & 
         ,PRIOR_SHAPE2_RANGE, PRIOR_SHAPE2_SIGMA  & 
         ,PRIOR_LUMIPAR_RANGE, PRIOR_LUMIPAR_SIGMA   &  ! legacy
         ,PRIOR_DMU_RANGE, PRIOR_DMU_SIGMA           &
         ,PRIOR_DELTA_PROFILE  & 
         ,OPT_PRIOR, OPT_PRIOR_AV  & 
         ,OPT_MNSTAT_COV, SIMFIT_IDEAL_PRESCALE  & 
         ,MINOS_ERR_DLMAG, MINOS_ERR_REQALL0, MINOS_ERR_REQALL1  & 
         ,MINOS_ERRMAX_BAD  & 
         ,CONTOUR_LIST, LTRACE, NFIT_VERBOSE  & 
         ,FUDGE_FITERR_MAXFRAC, FUDGE_FITERR_TREST  & 
         ,FUDGE_FITERR_PASSBANDS  & 
         ,FUDGE_FITERR_RESTLAM, FUDGE_MAGERR_MODEL,FUDGE_FITERR_MAXITER  & 
         ,FUDGEALL_MAXFRAC, FUDGEALL_ITER1_MAXFRAC  & 
         ,FUDGE_DATAERR_SCALE, FUDGE_MODELERR_SCALE  & 
         ,FITCOVAR_FILE  & 
         ,TREST_PEAKRENORM  & 
         ,SALT2alpha, SALT2beta , OPT_SALT2FIT  & 
         ,PHOTODZ_REJECT, PHOTODZ1Z_REJECT  & 
         ,PHOTOZ_ITER1_LAMRANGE, PHOTOZ_BOUND  & 
         ,MAGLIM_VMAX, OPT_VMAX, CCID_DUMP_CHI2_MATRIX

    EQUIVALENCE ( FITWIN_MJD(1),   MJD_REJECT(1)   )
    EQUIVALENCE ( FITWIN_TREST(1), TREST_REJECT(1) )


  END MODULE FITINP_NML

! =====================================================================
  MODULE TABLEVARCOM
    USE SNPAR
    IMPLICIT NONE

! Created May 2014
! Misc arrays used to initialize and fill FITRES table(s).
! These arrays either don't exist elsewhere (e..g, REDUCED
! covariance), or they replace existing arrays with BIDON
! elements removed; e.g., SNRMAX-list with unused filters
! excluded.

    INTEGER, PARAMETER :: MXCOV_TBL = 50

    REAL  & 
         TBL_REDCOV(MXCOV_TBL)          &  ! only fited params
        ,TBL_COV(MXCOV_TBL)             &  ! idem
        ,TBL_XTMW(MXFILT_ALL)           &  ! only fitted filters
        ,TBL_SNRMAX(MXFILT_ALL)        ! idem

    INTEGER  & 
         NCOV_TBL          &  ! size of REDCOV,COV arrays
        ,NCOV_TBL_PKMJD    &  ! first NCOV_PKMD elements have PKMJD element
        ,IPAR_TBL_COV(2,MXCOV_TBL)   ! list if IPARs for COV

! variables to define subset of fitted bands;

    INTEGER  & 
         NFILTOBS_TABLE                   &  ! for ntuple
        ,IFILTOBS_MAP_TABLE(MXFILT_OBS)   &  ! ifilt_obs vs. sparse index
        ,IFILT_MAP_TABLE(MXFILT_OBS)     ! ifilt vs. sparse index

    CHARACTER SURVEY_FILTERS_TABLE*100  ! list of surveys filters to plot

! variables for SPECTRA table (Nov 2016)
    INTEGER, PARAMETER :: MXLAM_TBLSPEC = 1000
    INTEGER    NBLAM_TBLSPEC, TBLSPEC_IFILTOBS
    INTEGER    TBLSPEC_DETNUM, TBLSPEC_IMGNUM  ! Oct 2021
    CHARACTER  TBLSPEC_CFILT*4, TBLSPEC_FIELD*(MXCHAR_FIELDNAME)
    REAL  & 
         TBLSPEC_MJD, TBLSPEC_TREST, TBLSPEC_TOBS, TBLSPEC_WAVECOR, TBLSPEC_LAMREST  & 
        ,TBLSPEC_FLUXCAL_DATA,  TBLSPEC_FLUXCAL_DATA_ERR  & 
        ,TBLSPEC_FLUXCAL_MODEL, TBLSPEC_FLUXCAL_MODEL_ERR  & 
        ,TBLSPEC_MAG_MODEL(MXFILT_OBS)  & 
        ,TBLSPEC_MAG_MODEL_ERR(MXFILT_OBS)  & 
        ,TBLSPEC_LAMLIST(MXLAM_TBLSPEC)  & 
        ,TBLSPEC_FLUXLIST(MXLAM_TBLSPEC)
    REAL*8 TBLSPEC8_MJD

! - - - - - -




! define table var for DMPFCN
    INTEGER  & 
         TBLDMPFCN_ISN, TBLDMPFCN_IFLAG, TBLDMPFCN_ITER, TBLDMPFCN_NCALL
    REAL  & 
         TBLDMPFCN_ZSN  & 
        ,TBLDMPFCN_PEAKMJD, TBLDMPFCN_DISTANCE  & 
        ,TBLDMPFCN_SHAPEPAR, TBLDMPFCN_COLORPAR  & 
        ,TBLDMPFCN_CHI2PRIOR(0:20), TBLDMPFCN_CHI2TOT


  END MODULE TABLEVARCOM

! =====================================================================
  MODULE ALLFILTCOM
    USE SNPAR
    IMPLICIT NONE
! 
! Mar 2013: generic variables to store ALL-FILTER results
!           before doing more specialize fits such as rest-frame mags.

    INTEGER  & 
         NFIT_ITERATION_ALLFILT  & 
        ,NOBS_ALLFILT           ! store NFILT_OBS using all filters

    CHARACTER  & 
         ALLFILTLIST_FIT*(MXFILT_ALL)    ! original filter list
    LOGICAL  & 
         USE_ALLFILT(MXFILT_ALL)

    REAL  & 
         FITVAL_ALLFILT(20)   &  ! MXFITPAR = 12, so 20 gives extra room
        ,FITERR_ALLFILT(20)


  END MODULE ALLFILTCOM

! =====================================================================
  MODULE MAGDIFCOM
    USE SNPAR
    USE ALLFILTCOM
    IMPLICIT NONE

! Mar 2013: for FILTER_FITMAGDIF option

    INTEGER  & 
         IFILTOBS_FITMAGDIF      &  ! absolute index
        ,IFILT_FITMAGDIF            ! sparse survey-filter index

    INTEGER,  PARAMETER ::             & 
         NFIT_ITER_FITMAGDIF     = 1  &  ! Number of fit-iters per test
        ,IFLAG_FITMAGDIF_NOMINAL = 0  & 
        ,IFLAG_FITMAGDIF_1FILT   = 1  & 
        ,IFLAG_FITMAGDIF_XFILT   = 2 


    INTEGER  & 
         IFLAG_FITMAGDIF(MXITER)   &  ! 1-> one filter fit, 2-> complement
        ,NFILT_FITMAGDIF(MXITER)  ! NFILT to fit per iteration

    CHARACTER  & 
         FILTLIST_FITMAGDIF(MXITER)*(MXFILT_ALL) ! filter-list per iteration

    REAL  & 
         FITMAG_1FILT, FITMAGERR_1FILT  & 
        ,FITMAG_XFILT, FITMAGERR_XFILT  & 
        ,FITMAGDIF, FITERRDIF  & 
        ,FITPROB_1FILT, FITPROB_XFILT



  END MODULE MAGDIFCOM

! =====================================================================
  MODULE FITRESTCOM
    USE SNPAR
    USE ALLFILTCOM
    IMPLICIT NONE


! for option to fit peakMag in rest-frame filter
    INTEGER, PARAMETER ::           & 
         MXFILT_FITRESTMAG    = 10  & 
        ,NFIT_ITER_FITRESTMAG =  1    ! Number of fit-iters per rest-filter

    INTEGER  & 
         NFILTDEF_FITRESTMAG  & 
        ,IFILTDEF_FITRESTMAG(MXFILT_FITRESTMAG)  & 
        ,IFILTDEF_ITER_FITRESTMAG(MXITER)     &  ! IFILTDEF vs. ITER
        ,IFILTSP_ITER_FITRESTMAG(MXITER)      &  ! sparse IFILT vs. ITER
        ,ITERLAST_FITRESTMAG(MXFILT_FITRESTMAG)  &  ! last iteration vs. IFILTSP
        ,NFILTDEF_SURVEY_ORIG  & 
        ,NLCPLOT_FITRESTMAG  & 
        ,IFILTOBS_BRACKET(MXFILT_FITRESTMAG)  & 
        ,IPAROFF_FITRESTMAG  ! IPAR offset for LCVAL_STORE

    REAL  & 
         FITRESTMAG(MXFILT_FITRESTMAG)          &  ! calculated restmag value
        ,FITRESTMAG_ERR(MXFILT_FITRESTMAG)     ! error on above


  END MODULE FITRESTCOM

! =====================================================================
  MODULE FITIDEALCOM
    USE SNPAR
    IMPLICIT NONE

    INTEGER, PARAMETER :: SIMFIT_IDEAL_DEBUG=777    ! do nominal fit twice

    LOGICAL DOFIT_IDEAL_EVENT ! refers to both ideal and nominal fit for this event
    LOGICAL DOFIT_IDEAL       ! =T for ideal fit, =F for nominal fit that follows
    INTEGER NFIT_ITERATION_ORIG, NFIT_ITERATION_IDEAL
    REAL*4  & 
          SAVE_FLUXCAL(MXEPOCH), SAVE_MWEBV, SAVE_MWEBV_ERR  & 
         ,FITPAR_IDEAL(20)

  END MODULE FITIDEALCOM

! =====================================================================
  MODULE VMAXCOM
    USE SNPAR
    IMPLICIT NONE

! Created Jun 2013 by R.K.

! Examples for OPT_VMAX
!  OPT_VMAX = 2 -> use obs for mag, peak for Zmax
!  OPT_VMAX = 3 -> use peak for both mag and Zmax

    REAL*8, PARAMETER ::  MAGDIF_CONVERGE = 0.001    ! stop when |mag(zmax)-MAGLIM| < CONVERGE    

    INTEGER, PARAMETER ::     & 
         MXFILT_VMAX   = 5   & 
        ,OPTBIT_MAG    = 0   &  ! bit0 off/on -> mag at best-fit obs/peak
        ,OPTBIT_ZMAX   = 1   &  ! bit1 off/on -> zmax from best-fot obs/peak
        ,OPTBIT_VERBOSE = 7     ! bit7(128) -> verbose printout

    INTEGER  & 
         NFILT_VMAX    &  !Number of obs filters to compute Zmax/Vmax
        ,IFILTOBS_LIST_VMAX(MXFILT_VMAX) ! sparse list

    REAL  & 
         MAGLIM_LIST_VMAX(MXFILT_VMAX)  & 
        ,TREST_LIST_VMAX(MXFILT_VMAX)  & 
        ,MAG_LIST_VMAX(MXFILT_VMAX)  & 
        ,Z_LIST_VMAX(MXFILT_VMAX)  & 
        ,VOL_LIST_VMAX(MXFILT_VMAX)

    INTEGER NEP_LIST_VMAX(MXFILT_VMAX)

    CHARACTER FILTLIST_VMAX*20




  END MODULE VMAXCOM

! =====================================================================
  MODULE SNFITCOM

    USE SNFITPAR
    USE SNFITVAR
    USE FITINP_NML


  END MODULE SNFITCOM


! ===================================

! ===========================================
! =====================================================================
! =====================================================================
! =====================================================================
    SUBROUTINE FITPAR_INI(IERR)
! 
! One-time user init: (read input, open files, etc ...)
! Flow chart:
!  -> RDFITNML
!  -> FITRESTMAG_INI
!  -> FITMAGDIF_INI
!  -> SIMFIT_IDEAL_INI
!  -> FITMODEL_INI
!  -> SEDMODEL_INI
!  -> SETCUTS_FITWIN_TREST
!  -> PHOTOZ_ANA(0,0,ISTAT) 
!  -> INIT_FUDGE_FITERR
!  -> FITINI_PRIORS
!      -> FITINI_PKMJDPRIOR
!      -> FITINI_ZPRIOR  [METHOD_SPLINE_QUANTILES set here]
!      -> FITINI_MUPRIOR
!      -> FITINI_AVPRIOR
!      -> FITINI_FLATPRIOR
!      -> MAKE_TABLE_PRIORS

!  -> FITINI_TABLEVAR
!  -> DMP_SNMJD_INTERP
!  -> FITINI_EPVAR   
! 
! Jul 19 2019: overhaul arguments to INIT_GENMAG_SNOOPY
! 
! Aug 2 2019: pass full model name (including path) to INIT_GENMAG_SNOOPY,
!             instead of passing only the model name without path
! 
! Jun 17 2020: if OPT_PHOTOZ==2, set ERRMAX_BAD(zPHOT) = 1.0E-8
! 
! -------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML
    USE INTERPCM

    IMPLICIT NONE

    INTEGER  & 
         IERR    ! (O) 0 => OK

! local var

    INTEGER  ipar, ipar2, istat, len1, len2, len3, LL, LEN_VERS, LEN_NAME
    INTEGER ifiltdef, ifiltr, NF_UNDEF, NF_DEF, NSURFACE, i, OPTMASK
    REAL    ERRMAX
    REAL*8  LAMRANGE8(2)

    CHARACTER  & 
         cfilt*2  & 
        ,cfilt_rest*(MXFILT_REST)  & 
        ,cfilt_defined*(MXFILT_ALL)  & 
        ,cfilt_undefined*(MXFILT_ALL)  & 
        ,covFile*(MXCHAR_FILENAME)  & 
        ,tmpName*(MXCHAR_FILENAME) 

! define functions

    INTEGER  & 
         INIT_GENMAG_STRETCH2   &  ! 1 or 2-par stretch
        ,INIT_GENMAG_MLCS2k2  & 
        ,INIT_GENMAG_SNOOPY  & 
        ,get_NSURFACE_SEDMODEL

    EXTERNAL  & 
         INIT_GENMAG_STRETCH2  & 
        ,INIT_GENMAG_MLCS2k2  & 
        ,INIT_GENMAG_SNOOPY  & 
        ,INIT_GENMAG_EXTINCTION

    INTEGER FILTINDX

! ------------------- BEGIN FITPAR_INI ---------------------

    IERR = 0

    CALL RDFITNML(IERR)
    if ( IERR .NE. 0 ) RETURN


! set FITANA_CUTWIN_XXX for cuts that might change for photoZ fits.
! This allows using the same FITANA_CUTWIN_XXX array in FITANA

    DO i = 1, 2
     FITANA_CUTWIN_TREST(i)    = CUTWIN_TREST(i)
     FITANA_CUTWIN_TREST2(i)   = CUTWIN_TREST2(i)
     FITANA_CUTWIN_TRESTMIN(i) = CUTWIN_TRESTMIN(i)
     FITANA_CUTWIN_TRESTMAX(i) = CUTWIN_TRESTMAX(i)
     FITANA_CUTWIN_TGAPMAX(i)  = CUTWIN_TGAPMAX(i)
     FITANA_CUTWIN_T0GAPMAX(i) = CUTWIN_T0GAPMAX(i)
     FITANA_CUTWIN_SNRSUM(i)   = CUTWIN_SNRSUM(i)
    ENDDO
! -------
! Default is rest-frame model; override below for obs-frame
    LOBS_FITMODEL  = .FALSE.
    LREST_FITMODEL = .TRUE.
    LSED_FITMODEL  = .FALSE.

! ---------------------------------
! set fitpar names.

    DO ipar = 1, MXFITSTORE
       write(PARNAME_STORE(ipar),20) ipar
20     format('BIDON', I3.3)
    ENDDO

    PARNAME_STORE(IPAR_ITER)   = 'ITER'
    PARNAME_STORE(IPAR_ISN)    = 'ISN'

! init to model that fits for extinction and MU;
! might be changed below, for example, for SALT2 model

    PARNAME_STORE(IPAR_AV)      = 'AV'
    ERRMAX_BAD(IPAR_AV)         = 0.005  ! 0.01->0.005  6/17/2020

    PARNAME_STORE(IPAR_DLMAG)   = 'DLMAG'
    ERRMAX_BAD(IPAR_DLMAG)      = 0.0

! check for floating RV in fit
    if ( INISTP_AVRV .GT. 0.0 ) then
      PARNAME_STORE(IPAR_AVRV)    = 'AVRV'
    else
      PARNAME_STORE(IPAR_RV)      = 'RV'
    endif

    PARNAME_STORE(IPAR_PEAKMJD) = 'PKMJD'

    IF ( INISTP_PHOTOZ .GT. 0.0 ) THEN
      IF ( INISTP_PHOTOZ == 1 ) THEN
         CALL ABORT_ON_CUTWIN_TREST()  ! Feb 2014
      ENDIF
      PARNAME_STORE(IPAR_ZPHOT)  = 'zPHOT'
    ELSE
      PARNAME_STORE(IPAR_ZPHOT)  = 'REDSHIFT'
    ENDIF

    IF ( OPT_PHOTOZ == 2 ) THEN
        ERRMAX_BAD(IPAR_ZPHOT)   =  1.0E-8 ! likely has specz prior, 6/2020
        PHOTOZ_ITER1_LAMRANGE(1) =  2000.  ! Dec 2023: include UV region
    ELSE
        ERRMAX_BAD(IPAR_ZPHOT) =  0.0005
    ENDIF
    ABORT_ON_BADZ           = .FALSE.

    IF ( LSIM_SNANA ) THEN
      do ipar = 1, IPAR_MAX
        USESIM_FITPAR(ipar) = .FALSE.
      enddo
      USESIM_FITPAR(IPAR_AV)      = USESIM_AV .or. USESIM_COLOR
      USESIM_FITPAR(IPAR_RV)      = USESIM_RV
      USESIM_FITPAR(IPAR_PEAKMJD) = USESIM_PEAKMJD
      USESIM_FITPAR(IPAR_SHAPE)   = USESIM_SHAPE.or.USESIM_LUMIPAR
      USESIM_FITPAR(IPAR_DLMAG)   = USESIM_DLMAG
      USESIM_FITPAR(IPAR_ZPHOT)   = USESIM_REDSHIFT

    ENDIF

! set default cut-windows to be wide open

    DO ipar = 1, IPAR_MAX
      CUTWIN_FITPAR(1,ipar) = -1.0E8
      CUTWIN_FITPAR(2,ipar) =  1.0E8

      CUTWIN_FITERRz1(1,ipar) = -0.001
      CUTWIN_FITERRz1(2,ipar) = +1.0E8

      DO ipar2 = 1, IPAR_MAX
         if ( ipar .eq. ipar2 ) then
           CUTWIN_FITCOV(1,ipar,ipar2) = -1.0E8
           CUTWIN_FITCOV(2,ipar,ipar2) = +1.0E8
         else
           CUTWIN_FITCOV(1,ipar,ipar2) = FITWIN_COV_OFFDIAG(1)
           CUTWIN_FITCOV(2,ipar,ipar2) = FITWIN_COV_OFFDIAG(2)
         endif
      ENDDO  ! end ipar2 loop

    ENDDO  ! end ipar loop
! ------------

    CALL LANDOLT_PREP()

! ---------------------
! print WARNING if fitting subset of filters.
    Len1 = INDEX(SURVEY_FILTERS,' ') - 1
    Len2 = INDEX(FILTLIST_FIT,  ' ') - 1

    if ( len2 == 0 ) then
       c1err = '&FITINP input FILTLIST_FIT is blank'
       c2err = 'Must specify list of filters to fit; e.g., griz'
       CALL MADABORT("FITPAR_INI", c1err, c2err )
    endif
    IF ( Len2 .LT. Len1 ) THEN
       print*,'  WARNING: fitting filter subset  ',  & 
            FILTLIST_FIT(1:Len2),'  from  ', SURVEY_FILTERS(1:Len1)
    ENDIF

! -------------------------------------------------------
! Covariance matrix:
! construct name of covar_File for this version;
! if it does not exist, then set covFile = '' so that
! the default is used.

    if ( fitcovar_file .EQ. 'SIM' .or. fitcovar_file .EQ. 'sim' ) then
       len1    = INDEX(SNDATA_PREFIX, ' ' ) - 1
       fitcovar_file = SNDATA_PREFIX(1:len1) // '_COVAR.DAT'
    endif

! check option to fit restmags.
    CALL FITRESTMAG_INI()

! check option to fit obsMag 2 different ways
    CALL FITMAGDIF_INI()

! check option to include IDEAL fit with FLUX=TRUEFLUX (no Poisson fluctuations)
    CALL SIMFIT_IDEAL_INI()

! ------------------------------------------------------
! set FITMODEL_INDEX, FITMODEL_PATH and FITMODEL_VERSION

    CALL FITMODEL_INI()

    LEN_VERS = INDEX(FITMODEL_VERSION, ' ' ) - 1
    LEN_NAME = INDEX(FITMODEL_NAME,' ') - 1

    tmpName  = FITMODEL_NAME(1:LEN_NAME) // char(0)

! set rest-frame filter ranges.
    FILTLIST_MODEL = ''
    NFILT_MODEL    = 0

    NSHAPEPAR = 1  ! default is 1 shape-par unless changed below

    LL = INDEX(SNDATA_ROOT,' ') - 1

    IF (   FITMODEL_INDEX .EQ. MODEL_STRETCH  & 
        .or. FITMODEL_INDEX .EQ. MODEL_STRETCH2 ) THEN


       RESTLAMBDA_MODEL(1) = 3000.0
       RESTLAMBDA_MODEL(2) = 9500.0

       ISTAT = INIT_GENMAG_STRETCH2(tmpName,CFILT_REST,LEN_NAME,LEN2)

       if ( FITMODEL_INDEX .EQ. MODEL_STRETCH ) then
         PARNAME_STORE(IPAR_SHAPE) = 'STRETCH'
       else
         PARNAME_STORE(IPAR_SHAPE)  = 'SRISE'
         PARNAME_STORE(IPAR_SHAPE2) = 'SFALL'
         NSHAPEPAR = 2
       endif

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN

       LOBS_FITMODEL  = .TRUE.
       LREST_FITMODEL = .FALSE.
       LSED_FITMODEL  = .TRUE.

       PARNAME_STORE(IPAR_COLOR)  = 'c'
       ERRMAX_BAD(IPAR_COLOR)     = 0.001

       PARNAME_STORE(IPAR_SHAPE)  = 'x1'
       ERRMAX_BAD(IPAR_SHAPE)     =  0.001

       PARNAME_STORE(IPAR_SHAPE2)  = 'x2'    ! Dec 2023
       ERRMAX_BAD(IPAR_SHAPE2)     =  0.0001

       if ( OPT_SALT2FIT .EQ. 0 .or. OPT_SALT2FIT .EQ. 4) then   !default
         PARNAME_STORE(IPAR_X0)         = 'x0'
       else if ( OPT_SALT2FIT .EQ. 1 ) then
         PARNAME_STORE(IPAR_X0)         = 'logx0'
       else if ( OPT_SALT2FIT .EQ. 2 ) then
         PARNAME_STORE(IPAR_X0)         = 'MUDIF'
       else
         write(c1err,669) OPT_SALT2FIT
669        format('Invalid OPT_SALT2FIT = ',I5 )
         c2err = 'Check &FITINP namelist'
         CALL MADABORT("FITPAR_INI", c1err, c2err )
       endif
       ERRMAX_BAD(IPAR_X0)        = 0.0

! note that mB is computed from fitpars, and does not float in fit
       PARNAME_STORE(IPAR_MB)         = 'mB'

       CALL SEDMODEL_INI(0,IERR)

       NSURFACE = get_NSURFACE_SEDMODEL()
       if ( NSURFACE == 3 ) THEN
           NSHAPEPAR = 2
           INISTP_SHAPE2 = 0.1
           INIVAL_SHAPE2 = 0.01
       endif

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_BAYESN ) THEN

       LOBS_FITMODEL  = .TRUE.
       LREST_FITMODEL = .FALSE.
       LSED_FITMODEL  = .TRUE.

       PARNAME_STORE(IPAR_COLOR)  = 'AV'
       ERRMAX_BAD(IPAR_COLOR)     = 0.001

       PARNAME_STORE(IPAR_SHAPE)  = 'THETA'
       ERRMAX_BAD(IPAR_SHAPE)     =  0.001

       PARNAME_STORE(IPAR_DLMAG)  = 'DLMAG'
       ERRMAX_BAD(IPAR_DLMAG)     = 0.0

       CALL SEDMODEL_INI(0,IERR)

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SIMSED ) THEN

       LOBS_FITMODEL  = .TRUE.
       LREST_FITMODEL = .FALSE.
       LSED_FITMODEL  = .TRUE.

       PARNAME_STORE(IPAR_X0)     = 'MUDIF'
       ERRMAX_BAD(IPAR_X0)        = 0.0

       CALL  SEDMODEL_INI(0,IERR)

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_MLCS2k2 ) THEN

       PARNAME_STORE(IPAR_SHAPE)  = 'DELTA'
       ERRMAX_BAD(IPAR_SHAPE) = 0.02

       len2 = INDEX(fitcovar_file, ' ' ) - 1
       len3 = 0

       COVFILE = FITCOVAR_FILE(1:len2) // CHAR(0)

       ISTAT = INIT_GENMAG_MLCS2k2(  & 
                     tmpName, covFile, scale_covar,  & 
                     FILTLIST_MODEL, LEN_VERS,len2,len3  & 
                            )

! fetch valid lambda-range from mlcs-function; note that the range
! depends on which IR filters are used.

       CALL GET_LAMRANGE_MLCS2k2(LAMRANGE8(1),LAMRANGE8(2))
       RESTLAMBDA_MODEL(1) = SNGL( LAMRANGE8(1) )
       RESTLAMBDA_MODEL(2) = SNGL( LAMRANGE8(2) )

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SNOOPY ) THEN


       CALL GET_LAMRANGE_snoopy(LAMRANGE8(1),LAMRANGE8(2))
       RESTLAMBDA_MODEL(1) = SNGL( LAMRANGE8(1) )
       RESTLAMBDA_MODEL(2) = SNGL( LAMRANGE8(2) )
       PARNAME_STORE(IPAR_SHAPE) = 'STRETCH'
       OPTMASK = 0
       ISTAT = INIT_GENMAG_SNOOPY(tmpName, OPTMASK,  & 
             FILTLIST_MODEL, LEN_NAME, len2 )  ! return args

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_FIXMAG ) THEN

       PARNAME_STORE(IPAR_SHAPE) = 'NULL'
       FILTLIST_MODEL = "UBVRI"

       print*,' '
       print*,' Invalid FIXMAG model.'
       print*,' Program Stopping Gracefully. '
       print*,' '
       STOP

    ELSE
       c1err = 'Invalid FITMODEL_NAME: ' // FITMODEL_NAME(1:40)
       c2err = 'Check &FITINP namelist'
       CALL MADABORT("FITPAR_INI", c1err, c2err )
    ENDIF

! ============================================
! load IFILTMAP_MODEL array and its inverse
! Mar 2013: abort if model filter is not defined in kcor table.

    DO i       = 1, MXFILT_ALL
      IFILTMAP_MODEL(i)    = -9
      IFILTINVMAP_MODEL(i) = -9
    ENDDO
    NFILT_MODEL = INDEX(FILTLIST_MODEL, ' ' ) - 2 ! subtract 2 for char(0)
    CFILT = ''
    CFILT_DEFINED = ''
    CFILT_UNDEFINED = ''
    NF_UNDEF = 0  ! number of undefined filters
    NF_DEF   = 0
    DO i       = 1, NFILT_MODEL
      CFILT    = FILTLIST_MODEL(i:i)
      ifiltdef = FILTINDX(cfilt)   ! absolute index of model filter
      IFILTMAP_MODEL(i)           = ifiltdef
      IFILTINVMAP_MODEL(ifiltdef) = i

      ifiltr  = IFILTDEF_INVMAP_REST(IFILTDEF)
      IF ( ifiltr < 0 ) then
         NF_UNDEF = NF_UNDEF + 1
         CFILT_UNDEFINED = CFILT_UNDEFINED(1:NF_UNDEF-1) // CFILT(1:1)
      ELSE
         NF_DEF = NF_DEF + 1
         CFILT_DEFINED = CFILT_DEFINED(1:NF_DEF-1) // CFILT(1:1)
      ENDIF
    ENDDO


! -----------
! set optional filter-dependent cuts on TREST
    CALL SETCUTS_FITWIN_TREST

! ----------------------------------------------

    CUTWIN_FITPAR(1,IPAR_PEAKMJD) = FITWIN_PEAKMJD(1)
    CUTWIN_FITPAR(2,IPAR_PEAKMJD) = FITWIN_PEAKMJD(2)
    CUTWIN_FITPAR(1,IPAR_SHAPE)   = FITWIN_SHAPE(1)
    CUTWIN_FITPAR(2,IPAR_SHAPE)   = FITWIN_SHAPE(2)
    CUTWIN_FITPAR(1,IPAR_AV)      = FITWIN_COLOR(1)
    CUTWIN_FITPAR(2,IPAR_AV)      = FITWIN_COLOR(2)
    CUTWIN_FITPAR(1,IPAR_ZPHOT)   = FITWIN_ZPHOT(1)
    CUTWIN_FITPAR(2,IPAR_ZPHOT)   = FITWIN_ZPHOT(2)

! cuts on offDiag cov already set since it's the same cut on each element.
! Here set diagonal cuts for each fitPar.

    IPAR = IPAR_PEAKMJD ; ERRMAX = FITWIN_PEAKMJD_ERR(2)
    CUTWIN_FITCOV(2,IPAR,IPAR) = ERRMAX*ERRMAX
    CUTWIN_FITERRz1(2,IPAR)    = FITWIN_PEAKMJD_ERRz1(2)

    IPAR = IPAR_MB ; ERRMAX = FITWIN_MB_ERR(2)
    CUTWIN_FITCOV(2,IPAR,IPAR) = ERRMAX*ERRMAX
    CUTWIN_FITERRz1(2,IPAR)    = FITWIN_MB_ERRz1(2)

    IPAR = IPAR_SHAPE ; ERRMAX = FITWIN_SHAPE_ERR(2)
    CUTWIN_FITCOV(2,IPAR,IPAR) = ERRMAX*ERRMAX
    CUTWIN_FITERRz1(2,IPAR)    = FITWIN_SHAPE_ERRz1(2)

    IPAR = IPAR_COLOR ; ERRMAX = FITWIN_COLOR_ERR(2)
    CUTWIN_FITCOV(2,IPAR,IPAR) = ERRMAX*ERRMAX
    CUTWIN_FITERRz1(2,IPAR)    = FITWIN_COLOR_ERRz1(2)

! determin RESTLAMBDA_USEFIT based on user FITRANGE and that
! defined by the model
    RESTLAMBDA_USEFIT(1) = MAX(RESTLAMBDA_MODEL(1),RESTLAMBDA_FITRANGE(1))
    RESTLAMBDA_USEFIT(2) = MIN(RESTLAMBDA_MODEL(2),RESTLAMBDA_FITRANGE(2))

    print*,'  '
    write(6,350) 'SN-MODEL', RESTLAMBDA_MODEL
    write(6,350) 'USER-DEF', RESTLAMBDA_FITRANGE
    write(6,350) 'Final   ', RESTLAMBDA_USEFIT
350   format(T5, A, 2x, 'LAMBDA RANGE: ', F6.0,' - ', F6.0 )

! abort if range makes no sense
    IF( RESTLAMBDA_USEFIT(2) .LT. 1000. ) THEN
       c1err = 'Invalid LAMBDA RANGE (see above).'
       c2err = 'Something is messed up.'
       CALL MADABORT("FITPAR_INI", c1err, c2err )
    ENDIF

! print cuts to reject epochs at 2nd epoch

    print*,'  '
    print*,'  SECOND-ITERATION EPOCH-REJECTION CUTS: '
    print*,'    REJECT  delchi2      > ', DELCHI2_REJECT
    print*,'    REJECT  signal/noise < ', SIGNOISE_REJECT
    print*,'    REJECT  Trest        < ', FITWIN_TREST(1)
    print*,'    REJECT  Trest        > ', FITWIN_TREST(2)
    print*,'    REJECT  MJD          < ', FITWIN_MJD(1)
    print*,'    REJECT  MJD          > ', FITWIN_MJD(2)
    print*,'    REJECT  PEAKMJD      < ', FITWIN_PEAKMJD(1)
    print*,'    REJECT  PEAKMJD      > ', FITWIN_PEAKMJD(2)
    print*,'  '

    print*,' '
    print*,'  FINAL FIT CUTS: '
    print*,'    REQUIRE MINOS ERROR for DLAMG        : ',  & 
                       MINOS_ERR_DLMAG
    print*,'    REQUIRE MINOS ERROR for ALL   FITPAR : ',  & 
                       MINOS_ERR_REQALL0
    print*,'    REQUIRE MINOS ERROR for ALL-1 FITPAR : ',  & 
                       MINOS_ERR_REQALL1
    print*,'    FIT-SIGMACHI2     > ', FITWIN_CHI2SIGMA(1)
    print*,'    FIT-PROB(final)   > ', FITWIN_PROB(1)
    print*,'    FIT-PROB(no marg) > ', FITWIN_NOMARG_PROB(1)

    if ( NEARFILT_IGNORE_REST .NE. ' ' ) then
        print*,'    IGNORE NEAREST REST-FRAME FILTERS: ',  & 
                  NEARFILT_IGNORE_REST
    endif

    if ( DOFIT_PHOTOZ ) then
      print*,'    REQUIRE photoZ(SN-host) pull :',  & 
                       FITWIN_ZPULL(1),' to ', FITWIN_ZPULL(2)
      CALL PHOTOZ_ANA(0,0,ISTAT) ! init ZDROP for each filter

    endif

    print*,'  '

! print ERRMAX_BAD

    DO ipar = 1, IPAR_MAX

       if ( .not. MINOS_ERRMAX_BAD ) ERRMAX_BAD(ipar) = 0.0

       write(6,88) PARNAME_STORE(ipar), ERRMAX_BAD(ipar)
88       format(T5,'Valid ERROR(', A10, ') must be > ', F9.5 )
    ENDDO
    print*,'  '

! ------------------
! check FUDGE_FITERR to see if some flux-errors should be
! blown up. Set logical(s) DOFUDGE_FITERR(ifilt_obs) to use later.

    CALL INIT_FUDGE_FITERR

! -----------------------------------------------
! initialize priors

    CALL FITINI_PRIORS()

! rest-frame init
    IF ( LREST_FITMODEL ) THEN
       CALL INIT_GENMAG_EXTINCTION(OPT_SNXT)
    ENDIF

! -------------------------------------------
! Define extra "TABLEVAR" variables for output tables

    CALL FITINI_TABLEVAR

! check for file with interpolated MAGS at specified MJDs.

    IF ( N_INTERP_MJDLIST .GT. 0 ) THEN
       CALL DMP_SNMJD_INTERP(0,0)
    ENDIF

! check for option to compuare Zmax/Vmax
    CALL VMAX_INI()

! ----
    CALL FITINI_EPVAR(-1)

    RETURN
  END SUBROUTINE FITPAR_INI

! ===========================================
    SUBROUTINE FITPAR_INI2(IERR)
! 
! Created May 2012 by R.Kessler
! One-time Initialization after 1st event is read
! but before the fit is performed.
! 
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER IERR ! (O) 0=OK

    INTEGER ipar
    CHARACTER FNAM*12
! ------------- BEGIN ----------------
    IERR = 0
    FNAM = 'FITPAR_INI2'
! ------------------------------------------------
! Determine which parameters are floated in fit.
! Use namelist input since the global INISTP array has
! not yet been filled.

    do ipar = 1, IPAR_MAX
       FLOATPAR(ipar) = .TRUE.
    enddo
    FLOATPAR(IPAR_ITER) = .FALSE.
    FLOATPAR(IPAR_ISN)  = .FALSE.

    IPAR = IPAR_AV
      if (INISTP_AV     .EQ. 0.0 ) FLOATPAR(IPAR) = .FALSE.
    IPAR = IPAR_RV
      if (INISTP_RV     .EQ. 0.0 ) FLOATPAR(IPAR) = .FALSE.
    IPAR = IPAR_ZPHOT
      if (INISTP_PHOTOZ .EQ. 0.0 ) FLOATPAR(IPAR) = .FALSE.

    IPAR = IPAR_SHAPE
      if (INISTP_SHAPE  .EQ. 0.0 ) FLOATPAR(IPAR) = .FALSE.
    IPAR = IPAR_SHAPE2
      if (INISTP_SHAPE2 .EQ. 0.0 ) FLOATPAR(IPAR) = .FALSE.

    IPAR = IPAR_DLMAG
      if (INISTP_DLMAG  .EQ. 0.0 ) FLOATPAR(IPAR) = .FALSE.

    IF ( OPT_TABLE(ITABLE_FITRES) > 0 ) THEN
       CALL TABLE_SNFIT(IDTABLE_FITRES,IFLAG_INI)
    ENDIF

    if ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
       IF ( OPT_TABLE(ITABLE_MODELSPEC) > 0 ) then
          CALL TABLE_SNSPEC_SALT2(0)
       ENDIF
       IF ( LDMPFCN(0) ) then
          OPT_TABLE(ITABLE_DMPFCN) = 1 ! auto-enable this table
          CALL TABLE_DMPFCN(0)
       ENDIF
    ENDIF

    IF ( SALT2_DICTFILE .NE. ' ' ) THEN
       CALL DMP_DICTFILE(0)  ! init dictFile
    ENDIF

    RETURN
  END SUBROUTINE FITPAR_INI2

! ===========================================
    SUBROUTINE FITPAR_END(IERR)
! 
! User end-routine after all analysis/fits are done.
! [close files, summarize statistics, global analysis, etc ...]
! -------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE INTERPCM

    IMPLICIT NONE

    INTEGER IERR ! (O) 0 => OK

! local var


! ------------------- BEGIN ---------------------
    IERR = 0

    IF ( N_INTERP_MJDLIST .GT. 0 ) THEN
       CALL DMP_SNMJD_INTERP(-9,0)
    ENDIF

    IF ( OPT_COVAR_LCFIT > 0 ) THEN
      write(6,40) N_SNLC_COVFIX
 40     format(T8,'COV(mB,x1,c)-invertability fixed for ', I6,' events')
    ENDIF

    RETURN
  END SUBROUTINE FITPAR_END

! ==========================================
    SUBROUTINE FITPAR_PREP ( iter, IERR )
! 
! For each "isn" supernova, this user-routine is used to
! initialize global variables used as input to the fitter:
! 
! NFITPAR             = number of fit parameters
! PARNAME_STORE(1:NFITPAR)  = name of each parameters (<= 10 bytes)
! INIVAL(1:NFITPAR)   = initial value
! INISTP(1:NFITPAR)   = initial step size (0 => fixed parameter!)
! 
! 
! Useful notes:
! 
! 
! It is highly recommened that the first fit parameter
! is INIVAL(1) = DBLE(ISN)  with INISTP(1) = 0.0
! You will need this index in FCNSNLC to get information
! about a particular SN.
! Another useful init is to set your initial MJD_AT_PEAK equal  to
! SNLC_SEARCH_PEAKMJD(isn) from Masao's LC fitter during the survey.
! 
! 
! Fill MAG_XTMW_REF(ifilt_obs)  so that  USRFUN
! can make the same approx MilkyWay correction that was
! applied to data.
! 
! 
! Mar 19 2024: set MASK_PHOTOZ_SOURCE
! 
! ----------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FILTUPDCM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER  & 
         iter   &  ! (I) fit iteration: 1,2, ... NFIT_ITERATION
        ,IERR  ! (O) 0=> init OK; else skip fit

! local var

    INTEGER  ipar, bit, ifilt, ifilt_obs, OPT, LL, LCHAR
    REAL*8 LAMMIN,LAMMAX, LAMAVG, Z8, Z8TEST
    REAL*4 Z4, LMIN4

    CHARACTER CFILT*1, CCID*(MXCHAR_CCID), CTMP*8

    LOGICAL  & 
         USE_FILT_ITER1(MXFILT_ALL)  & 
        ,FIRST_ITER, NEXT_ITER, NOMATCH, LAMFAIL, LPRINT  & 
        ,LPZ_HOST, LPZ_BEST, LPZ_Q, LZSPEC, LDMP_MASK

! functions

    LOGICAL LFITFUN_FILT, FIRST_ITERATION, IS_ZSPEC
    INTEGER NEAREST_IFILTDEF_WRAPPER

! ---------- BEGIN FITPAR_PREP -------------

    IERR = 0  ! init to OK
    LPRINT = STDOUT_UPDATE

    FIRST_ITER = FIRST_ITERATION(ITER) .and. (.not. LREPEAT_ITER)

    NEXT_ITER  = ((.not. FIRST_ITER) .and. (ITER > 1))  & 
                  .or. LREPEAT_ITER

    if ( FIRST_ITER ) NEXT_ITER = .FALSE.

    IF ( FIRST_ITER .and. OPT_FILTER_UPDATE > 0 ) THEN

      IF ( LSED_FITMODEL ) CALL SEDMODEL_INI(1,IERR)

      IF ( LREST_FITMODEL ) THEN
        LL = INDEX(FITMODEL_VERSION,' ') - 1
        C1ERR = 'FILTER_UPDATE  option not implemented for ' //  & 
                    FITMODEL_VERSION(1:LL)
        C2ERR = '(rest-frame model) that uses K-corrections. Sorry.'
        CALL MADABORT("FITPAR_PREP", c1err, c2err)
      ENDIF

    ENDIF


! init Trest-related variables that are set after fit
    IF ( FIRST_ITER ) THEN
      TRESTMIN_FIT        = -999.
      TRESTMAX_FIT        = -999.
      TRESTRANGE_FIT      = -999.
      NFILT_TRESTMIN_FIT  = -9
      NFILT_TRESTMAX_FIT  = -9
      TGAPMAX_FIT         = -9.0
      T0GAPMAX_FIT        = -9.0

      CALL FITINI_EPVAR(-1)    ! added Jan 1, 2014
    ENDIF

    LBKSNINFO = .FALSE.

    NFITPAR_MN = IPAR_MAX  ! # MINUIT params includes NFIXPAR

    CCID  = SNLC_CCID
    LCHAR = ISNLC_LENCCID

! print global banner

    IF ( LPRINT ) THEN
      ctmp = ''
      if ( LREPEAT_ITER ) CTMP = '(again)'
      write(global_banner,400) ITER, CCID(1:LCHAR), CTMP
400   format('FITPAR_PREP: Begin FIT-ITERATION ', I2,  ' for CID ', A, 3x, A )
      CALL PRBANNER( global_banner(1:68) )
    ENDIF

! load redshift to use in spec-z fit

    IF ( SNLC_ZHELIO < 0.0  .and. OPT_PHOTOZ == 0 ) then
       write(6,26) SNLC_CCID(1:LCHAR)
26       format(T5,'Z-WARNING for CID=',A,  & 
            ' : no Z_helio => use ZCMB for lc fit' )
       call flush(6)
    ENDIF
! ------------------------------
! set global REDSHIFT_FIT to use for things like
! getting rest-frame filters and Trest values.

    CALL SET_REDSHIFT_FIT(iter)

    Z8 = DBLE(REDSHIFT_FIT)
    Z4 = REDSHIFT_FIT       ! ensure 4-byte redshift variable

! ---------------------------------
! set redshift-arg for LFITFUN_FILT (below)
! For photoz fit set Z8TEST=-9 so that z-dependent tests are
! skipped ; they are applied in PHOTOZ_ANA (after 1st fit) instead.

    Z8TEST = Z8
    IF ( DOFIT_PHOTOZ ) THEN
      Z8TEST = -9.0

! reset DROPFILTER array in first iteration only
      if ( FIRST_ITER ) then

! Mar 19 2024: set mask of which OPT_PHOTOZ option (bit) is actually used.
        MASK_PHOTOZ_SOURCE = 0

        LPZ_HOST = btest(OPT_PHOTOZ,BIT_PHOTOZ_GAUSS)
        LPZ_BEST = btest(OPT_PHOTOZ,BIT_BESTZ_GAUSS)
        LPZ_Q    = btest(OPT_PHOTOZ,BIT_PHOTOZ_QUANTILES)
        LZSPEC   = LPZ_BEST .and. IS_ZSPEC()

        if ( LPZ_Q ) then
!           use z_spec prior or quantiles; ignore zPHOT point estimate
          if ( LZSPEC ) then
              bit = BIT_BESTZ_GAUSS  ! use zspec prior if available and requested
          else
              bit = BIT_PHOTOZ_QUANTILES
          endif
          MASK_PHOTOZ_SOURCE = IBSET(MASK_PHOTOZ_SOURCE,BIT)

        else if ( LPZ_BEST ) then
           MASK_PHOTOZ_SOURCE =  & 
                IBSET(MASK_PHOTOZ_SOURCE,BIT_BESTZ_GAUSS)
        else if ( LPZ_HOST ) then
           MASK_PHOTOZ_SOURCE =  & 
                IBSET(MASK_PHOTOZ_SOURCE,BIT_PHOTOZ_GAUSS)
        endif

! - - - - - - -
        LDMP_MASK = .FALSE.
        if ( LDMP_MASK ) then
           write(6,660) LPZ_HOST, LPZ_BEST, LPZ_Q, LZSPEC,  & 
                    MASK_PHOTOZ_SOURCE
660          format(' xxx LPZ[HOST,BEST,Q]=',3L2, 3x, 'LZSPEC=',L2, 3x,  & 
                 '--> MASK_PHOTOZ_SOURCE=',I5 )
           call flush(6)
        endif

! --------------------
        DO 220 ifilt_obs = 1,  MXFILT_ALL

          PHOTOZ_ADDFILTER(ifilt_obs)  = .FALSE.
          PHOTOZ_DROPFILTER(ifilt_obs) = .FALSE.

! skip initial DROP-FILTER test if cheat-flag is set
          IF ( DOFIT_PHOTOZ_CHEAT ) GOTO 220

! check option to exclude certain lambda regions on first
! iteration (default is to ignore UV filters).
! Note that any filters dropped here can get added back before
! 2nd iteration depending on the photoZ-fit value.

          LAMAVG  = FILTOBS_LAMAVG(ifilt_obs)
          LAMFAIL = LAMAVG .LT. PHOTOZ_ITER1_LAMRANGE(1)  & 
                .or.  LAMAVG .GT. PHOTOZ_ITER1_LAMRANGE(2)

          if ( LAMFAIL ) then
            PHOTOZ_DROPFILTER(ifilt_obs) = .TRUE.
          endif

220         CONTINUE  ! end of IFILT_OBS
      endif  ! end if FIRST_ITER

    ENDIF  ! end of DOFIT_PHTOOZ

! ---------------------------------
! count how many filters to fit;
! a fit filter must:
!   -  be specified by the user (DOFIT_FILT)
!   -  exist in the lightcurve.
!   -  transform to rest-frame lambda within RESTLAMBDA_FITRANGE(2)
! 

    NFILT_FIT         = 0
    FILTLIST_FIT_USE  = ''
    NFILT_OBS_USEFIT  = 0
    LAMMIN =  99999.
    LAMMAX = -99999.
    USE_FILT(0)  = .FALSE.       ! for protection against IFILT=0

! store USE_FILT array from previous iteration in order
! flag any changes in the 2nd iteration.

    if ( NEXT_ITER ) then
       DO ifilt     = 1, NFILTDEF_SURVEY
          ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
          USE_FILT_ITER1(ifilt_obs) = USE_FILT(ifilt_obs)
       ENDDO
    endif

! Jan 2025: for photo-z fit, read BANDLIST to force fitting same bands again
    IF ( USE_PRIOR_SNCID_FILE .and. DOFIT_PHOTOZ ) THEN
       CALL FORCE_BANDLIST_SNCID_FILE()
    ENDIF

    DO ifilt     = 1, NFILTDEF_SURVEY

       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       cfilt     = filtdef_string(ifilt_obs:ifilt_obs)

! set USE_FILT based on user-request, existence,
! and valid rest-frame filter.

       USE_FILT(ifilt_obs) =  & 
            LFITFUN_FILT(ifilt_obs,Z8TEST)

       NOMATCH  =  & 
           USE_FILT_ITER1(ifilt_obs) .NEQV. USE_FILT(ifilt_obs)

! print message if observer-filter is dropped or added on 2nd iteration
       if ( NEXT_ITER .and. NOMATCH .and. STDOUT_UPDATE ) THEN

           if ( USE_FILT_ITER1(ifilt_obs) ) then
              write(6,24) CCID(1:LCHAR), 'DROPPED', cfilt
           else
              write(6,24) CCID(1:LCHAR), 'ADDED', cfilt
           endif
24           format(T10,'WARNING for SN ',A,' : ',  & 
                  A,' obs-filter=', A )
       endif

       if ( USE_FILT(ifilt_obs) ) then

          NFILT_FIT = NFILT_FIT + 1
          MAG_XTMW_REF(ifilt_obs) = SNLC_MWXT_MAG(ifilt)

          LAMAVG = FILTOBS_LAMAVG(ifilt_obs)
          IF ( LAMAVG .LT. LAMMIN ) then
             LAMMIN = LAMAVG
          ENDIF

          IF ( LAMAVG .GT. LAMMAX ) then
             LAMMAX = LAMAVG
          ENDIF

          LL = INDEX ( FILTLIST_FIT_USE, ' ' ) - 1
          FILTLIST_FIT_USE = FILTLIST_FIT_USE(1:LL) // cfilt
          NFILT_OBS_USEFIT = NFILT_OBS_USEFIT + 1

          if ( LREST_FITMODEL ) then
            OPT = OPT_FILTOBS
            IFILT_REST_MAP(ifilt) =  & 
               NEAREST_IFILTDEF_WRAPPER(OPT,ifilt_obs, 1, Z4, LMIN4)
          endif

       endif

    ENDDO

! set range of observer filters to evaluate for each obs filter.
! This is needed for the color transformation and for U -> U-BX+B

    CALL SET_IFILT_OBS(LPRINT)

    IF ( NFILT_FIT .EQ. 0 ) THEN
       print*,' '
       print*,' FITPAR_PREP WARNING for CID ', SNLC_CCID
       print*,'   Found no valid observer frame filters to fit.'
       print*,'   '
       IERR = ERRFLAG_FITPREP_NOFILTERS
       RETURN
    ENDIF

! init EP_XXX arrays ( before calling FITINI_ADJUST)
    CALL FITINI_EPVAR(iter)

! set INIVAL and INISTP arrays.
    CALL FITINI_PARVAL(iter)

! Check 1st iter override from SNCID_LIST_FILE
    IF ( FIRST_ITER ) CALL FITINI_LIST_FILE(iter)

! init linear FITCOV arrays
    OPT = 1  ! bit 1 => print info to stdout
    CALL FITINI_COV(OPT, ITER, FITVAL(1,ITER-1), IERR)
    IF ( IERR .NE. 0 ) RETURN

! -------

! check for photoZ fit (after FITINI_COV)
    IF ( DOFIT_PHOTOZ ) CALL FITINI_PHOTOZ(iter, IERR)
    IF ( IERR .NE. 0 ) RETURN

! adjust fitpar based on initial Fdata/Fmodel ratios.
    CALL FITINI_ADJUST(iter,IERR)
    IF ( IERR .NE. 0 ) RETURN


! Apr 29 2022: check 1st iter override from SNCID_LIST_FILE

    IF ( LREST_FITMODEL .and. ITER .EQ. NFIT_ITERATION ) THEN
      CALL FITINI_PRKCOR()   ! print Kcor info
    ENDIF

! check option to fix all parameters in fit

    IF ( LFIXPAR_ALL .or. LFIXPAR_ADJUST ) THEN
      DO ipar = 1, NFITPAR_MN
         INISTP(ipar)  = 0.0
      ENDDO
    ENDIF

! ---------------
    CALL FLUSH(6)

    RETURN
  END SUBROUTINE FITPAR_PREP 


! =====================================
    SUBROUTINE FITINI_EPVAR(ITER)

    USE SNPAR
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER ITER  ! (I) SN index and iteraion

    INTEGER  ifilt, ep, ivar

! ----------- BEGIN -------------

    IF ( ITER < 0 ) THEN
       DO ep = 1, MXFIT_DATA

          DO ivar = 1, MXVAR_R4
             R4EP_ALL(ep,ivar)  = NULLVAL
             R4EP_FIT(ep,ivar)  = NULLVAL
             R4EP_LAST(ep,ivar) = NULLVAL
          ENDDO
          DO ivar = 1, MXVAR_I4
             I4EP_ALL(ep,ivar) = -999
             I4EP_FIT(ep,ivar) = -999
          ENDDO
          BANDEP_ALL(ep) = ''
          BANDEP_FIT(ep) = ''
       ENDDO
    ENDIF


! init scalars
    R4SN_TEARLY       = +999
    R4SN_TLATE        = -999.
    R4SN_MJDmin       = +6E8
    R4SN_MJDmax       = -6E8
    R4SN_FFSUM_DATA   = NULLVAL
    R4SN_FFSUM_MODEL  = NULLVAL
    R4SN_FFSUM_CROSS  = NULLVAL
    R4SN_FFSUM_WGT    = NULLVAL
    R4SN_FFSUM_RATIO  = NULLVAL

! init filter-dependent variables.

    DO ifilt = 1, MXFILT_ALL
         PEAKMAG_OBS_MODEL(ifilt)           = NULLVAL
         PEAKMAG_OBS_MODEL_ERR(ifilt)       = 0.0
         PEAKMAG_REST_MODEL(ifilt)          = NULLVAL
         PEAKMAG_REST_MODEL_ERR(ifilt)      = 0.0
         PEAKFLUX_OBS_MODEL(ifilt)          = NULLVAL
         PEAKFLUX_OBS_MODEL_ERR(ifilt)      = 0.0
         PEAKFLUX_OBS_MODEL_COR(ifilt)      = 1.
         PEAK_KCOR_MODEL(ifilt)             = 0.0

         R4BAND_SNRMAX_FIT(ifilt)     = -99.
         R4BAND_SNRMAX_RAW(ifilt)     = NULLVAL
         R4BAND_TREST_NEARPEAK(ifilt) = -999.
         R4BAND_XTMW_NEARPEAK(ifilt)  = NULLVAL

         if ( ifilt .LE. MXFILT_OBS ) then
            FCN_FITCHI2(ifilt)    = 0.0
         endif
    ENDDO

    RETURN
  END SUBROUTINE FITINI_EPVAR


! ===================================================
    SUBROUTINE FITPAR_ANA ( isn, iter, ERRFLAG )
! 
! User-routine to analyze fit results after each SN.
! Includes incrementing histograms, statistics, etc ...
! 
! Fit results are in
! 
!   FITPAR(1:NFITPAR)
!   FITERR(1:NFITERR)
! 
! Recommend making (REAL*8) equivalence to local
! variables with more appropriate names.
! 
! Returns ERRFLAG as follows:
!  =  0 => OK; keep SN
!  = >0 => discard fit (call CDTOPDIR)
!  = -1 => decrement ITER and try again (e.g., for photoZ spike)
! 
! 
!       HISTORY
! 
! Feb 28 2020:
!   set ERRFLAG = -1 (repeat iter) if both ITER1_MAXFRAC and
!   DELCHI2_REJECT are set. Fixes long-standing bug.
! 
! Aug 28 2020: if ERRFLAG=0 then set CUTFLAG_SNANA += 2 so that
!              correct CUTFLAG_SNANA shows up in FITRES table.
! 
! May 18 2021: skip crazyflux check of OPT_SNCID_LIST > 0
! Jul 23 2024: apply user defined 1st-iteration cuts on FITPROB, shape, color;
!              see FITWIN_[FITPROB,SHAPE,COLOR]_ITER1
! 
! Dec 7 2024: check CRAZYFITERR even if OPT_SNCID_LIST > 0
! -------------------------------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE SNFITCOM
    USE FILTCOM
    USE INTERPCM
    USE VMAXCOM

    IMPLICIT NONE

    INTEGER  & 
         isn    &  ! (I) sparse SN index
        ,iter   &  ! (I) fit iteration: 1,2, ... NFIT_ITERATION
        ,ERRFLAG  ! (O)

! local var

    INTEGER CID, LCID, i, IERR_MARG, j, PHASE2_IDX(4)
    LOGICAL DOLC_PLOT, LFITOK,  FIRST, LAST, DO_REFIT, CRAZY
    REAL FRACERRDIF, FITPROB, SHAPE, COLOR
    character ccid*(MXCHAR_CCID)

! function
    LOGICAL CRAZYFITERR, DOPLOT_SNLC

! -------------------- BEGIN ---------------

    ERRFLAG  = 0   ! init output to "accept"
    LAST     = ITER .EQ. NFIT_ITERATION
    FIRST    = ITER .EQ. 1

    CID   = SNLC_CID
    CCID  = SNLC_CCID
    LCID  = ISNLC_LENCCID

! ------------------------------------------------------
! check cuts on 1st-iteration FITPROB and fit pars
    IF ( ITER==1 ) THEN
       FITPROB = FITPROBCHI2_STORE(1)
       SHAPE   = SNGL(FITVAL(IPAR_SHAPE,ITER))
       COLOR   = SNGL(FITVAL(IPAR_COLOR,ITER))
       IF( FITPROB < FITWIN_PROB_ITER1(1) .or.  & 
            FITPROB > FITWIN_PROB_ITER1(2) ) THEN
          ERRFLAG = ERRFLAG_FIT_FITPROB_ITER1
       ENDIF
       IF( SHAPE < FITWIN_SHAPE_ITER1(1) .or.  & 
            SHAPE > FITWIN_SHAPE_ITER1(2) ) THEN
          ERRFLAG = ERRFLAG_FIT_SHAPE_ITER1
       ENDIF
       IF( COLOR < FITWIN_COLOR_ITER1(1) .or.  & 
            COLOR > FITWIN_COLOR_ITER1(2) ) THEN
          ERRFLAG = ERRFLAG_FIT_COLOR_ITER1
       ENDIF
       if ( ERRFLAG > 0 ) RETURN
    ENDIF

! 
! transfer I4/R4EP_ALL arrays to sparse I4/R4EP_FIT arrays (Jan 25 2014)
    CALL LOAD_EPFIT()

! for photoz fit, check for repeat iteration or discard fit
    IF ( DOFIT_PHOTOZ ) THEN
       CALL PHOTOZ_ANA(1,iter,ERRFLAG)
       IF ( LAST ) THEN
          CALL SET_ZHD_PHOTOZ()
          IF ( ERRFLAG > 0 ) RETURN
       ENDIF
    ENDIF

! --------------------------------------------
! Jan 2016: fit iteration again if cov matrix has not converged

    DO_REFIT =  & 
           OPT_MNSTAT_COV > 0 .and.   &  ! user option
           LAST               .and.   &  ! last fit iteration
           MNSTAT_COV < 3     .and.   &  ! MINUIT status
           (.not. LREPEAT_ITER)      ! not already repeating

    IF ( DO_REFIT ) THEN
       if ( STDOUT_UPDATE ) then
          write(6,46) MNSTAT_COV, CCID
46        format(T5,'Bad COV matrix (MNSTAT_COV=',I2,') '  & 
               '-> repeat fit for CID=',A12 )
       endif
       ERRFLAG = ERRFLAG_REPEAT_ITER  ! -1
       RETURN
    ENDIF

! --------------------------------------------
! May 2018 check option to repeat entire fit with MINOS

    FRACERRDIF = LCFRACERRDIF_STORE(IPAR_COLOR)
    DO_REFIT =  & 
          LAST                  .and.   &  ! last fit iteration
          (.NOT. LREPEAT_MINOS) .and.  & 
          ABS(FRACERRDIF) > FRACERRDIF_REPEATFIT  ! large cERR change


    IF ( DO_REFIT ) THEN
       write(6,48) FRACERRDIF, CCID(1:12)
 48      format(T5,'Unstable c-error: cFRACERRDIF=',F6.2,  & 
                    '-> repeat fit with MINOS, CID=',A12 )
       ERRFLAG = ERRFLAG_REPEAT_MINOS  ! -2
       RETURN
    ENDIF

! set default of NFIT=1 to plot (before calling FITRESTMAG or FITMAGDIF)
! This call is not needed, but avoids confusion with NFIT=0 inside the
! sntools_output routines.
    IF ( ITER .EQ. 1 ) THEN
      CALL SNLCPAK_NFIT(1)   ! 5/01/2014
    ENDIF

! check optional rest-mag  (Feb 2012)
    CALL FITRESTMAG_CALC(ITER)

! check optional magdif test (Mar 2013)
    CALL FITMAGDIF_CALC(ITER)

! check optional IDEAL fit with FLUX=TRUEFLUX (Aug 2017)
    CALL SIMFIT_IDEAL_CALC(ITER)


! -------------------------------------------------
! check for crazy errors, unless:
!   + plotchi2-debugger is on, or

    CRAZY = CRAZYFITERR(iter)

    IF ( CRAZY ) THEN
      write(6,222) CCID(1:LCID)
222     format(T15,'CRAZY ERROR for CID=', A,' ==> SKIP ' )
      ERRFLAG = ERRFLAG_FIT_CRAZYERR
      RETURN
    ENDIF

! ---------------------------------------
    IF ( ITER < NFIT_ITERATION ) RETURN

! ----- BELOW IS LAST ITERATION -------

! check for special variable computation for SIMSED models;
    CALL SIMSED_RECON()

! ------------------------------------------------------
! compute SIMCHI2 on last iteration
!       IF ( LSIM_SNANA .and. LAST ) then
!  4.22.2019: disable because of problem with wrong host redshift
!          CALL GET_SIMCHI2_CHEAT()
!       ENDIF

! -------------------------------------------------
    DOLC_PLOT = DOPLOT_SNLC()

! ---------------------------------------
! check option to marginalize

    if ( LTRACE ) CALL DMPTRACE("CALLING FITANA_MARG")

    CALL FITANA_MARG(ISN, .FALSE., IERR_MARG)
    IF ( IERR_MARG > 0 ) THEN
       ERRFLAG = ERRFLAG_FIT_MARGINALIZE
       GOTO 333
       RETURN          ! discard fit
    ENDIF

    ! New call FITANA_LOGMASS May,2026
    CALL FITANA_LOGMASS()

! ---------------------------------------
! store fit results for plotting

    if ( LTRACE ) CALL DMPTRACE("CALLING FITANA_STORE")

    CALL FITANA_STORE()

! ---------------------------------------
! Use fitted flux to update ERROR CALC from ZPT,PSF and SKY

    if ( LTRACE ) CALL DMPTRACE("CALLING UPD_FLUXERRCALC")
    CALL UPD_FLUXERRCALC()

! -------------------------------
! Nov 2018: Check option to fix non-invertible COV(mB,x1,c)
    CALL FIX_COVAR_LCFIT()

! ----------------------
! check option to compute Zmax for 1/Vmax method
! (after FITANA_STORE ad before SNTABLE calls)
    do i = 1, NFILT_VMAX
       CALL VMAX_ANA(i)
    enddo

! ----------------------------------------
! on last iteration, check if fit is OK

    if ( LTRACE ) CALL DMPTRACE("CALLING FITANA_CUTS")
    CALL FITANA_CUTS(isn,LFITOK)    ! returns LFITOK
    IF ( .NOT. LFITOK ) THEN
       ERRFLAG = ERRFLAG_FIT_CUTS
       GOTO 333
    ENDIF

    if ( LTRACE ) CALL DMPTRACE("CALLING FITANA_SUMMARY")

    ! Local read-only diagnostic: exact Minuit Hessian covariance, avoiding
    ! the MINOS-diagonal / Hessian-off-diagonal mixture in FITRES.
    PHASE2_IDX = (/ IPAR_X0, IPAR_SHAPE, IPAR_COLOR, IPAR_PEAKMJD /)
    write(6,'(A,1X,A,1X,20(ES25.17E3,1X))') 'PHASE2_HESSIAN:', &
         TRIM(CCID), (FITVAL(PHASE2_IDX(i),ITER),i=1,3), &
         FITVAL(IPAR_PEAKMJD,ITER)+MJDOFF, &
         ((FITERRMAT(PHASE2_IDX(i),PHASE2_IDX(j)),j=1,4),i=1,4)
    CALL FITANA_SUMMARY(isn)

 333  CONTINUE

    IF ( ERRFLAG .NE. 0 ) THEN
! back to topdir
        CALL CDTOPDIR_OUTPUT(STDOUT_UPDATE)
        RETURN
    ENDIF

! - - - - - - -
! Aug 28 2020: if we get here, set CUTFLAG_SNANA bit for fit success.
    CUTFLAG_SNANA  = IBSET(CUTFLAG_SNANA,1) ! for SNANA tree

! ---------------------------------------------------------
! book plots for this SN; all plots are vs. relative epoch

    IF ( DOLC_PLOT ) THEN

       CCID = SNLC_CCID(1:LCID) // char(0)
       CALL MAKEDIR_OUTPUT(CCID,SNLC_CID,LCID)

      if ( LTRACE ) CALL DMPTRACE("inside DOLC_PLOT if-block")

      CALL SNLCPLOT()

      CALL CDTOPDIR_OUTPUT(STDOUT_UPDATE)  ! back to topdir

    ENDIF

! ---------------------------------

! check tables to fill
    IF ( OPT_TABLE(ITABLE_FITRES) > 0 ) THEN
        CALL PREP_FITRES_TABLEVAR()
        CALL TABLE_SNFIT(IDTABLE_FITRES,IFLAG_ANA)
    ENDIF

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
       if ( OPT_TABLE(ITABLE_MODELSPEC) > 0 ) then
          CALL TABLE_SNSPEC_SALT2(isn)
       endif
    ENDIF


    IF ( SALT2_DICTFILE .NE. ' ' ) THEN
       CALL DMP_DICTFILE(1)
    ENDIF

! check for single-epoch dump of FLUX & MAG at specified MJD
! See input namelist "SNMJD_LIST_FILE"

    IF ( N_INTERP_MJDLIST > 0 ) THEN
      CALL DMP_SNMJD_INTERP(1,1)  ! evaluate at MJD from LIST file
      CALL DMP_SNMJD_INTERP(1,0)  ! evaluate at PEAK
    ENDIF

    RETURN
  END SUBROUTINE FITPAR_ANA 

! ================================================
    LOGICAL FUNCTION CRAZYFITERR(iter)

! Returns TRUE if a crazy fit error is identified.
! Jan 28 2020: check for crazy-small errors too, only if floated.
! Mar 28 2025: check ZPHOT

    USE SNDATCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER  ITER ! (I) ! SN index & fit-iteration
    REAL ERR_COLOR, ERR_SHAPE, ERR_DIST, ERR_PKMJD, ERR_ZPHOT
    LOGICAL  & 
        LNAN,  & 
        FLOAT_COLOR, FLOAT_SHAPE, FLOAT_DIST, FLOAT_PKMJD, FLOAT_ZPHOT

! --------------- BEGIN ----------------

    CRAZYFITERR = .FALSE.

    ERR_COLOR =  SNGL( FITERR(IPAR_COLOR,ITER) )
    ERR_SHAPE =  SNGL( FITERR(IPAR_SHAPE,ITER) )
    ERR_DIST  =  SNGL( FITERR(IPAR_DLMAG,ITER) )
    ERR_PKMJD =  SNGL( FITERR(IPAR_PEAKMJD,ITER) )
    ERR_ZPHOT =  SNGL( FITERR(IPAR_ZPHOT,ITER) )

    FLOAT_COLOR = FLOATPAR(IPAR_COLOR)
    FLOAT_SHAPE = FLOATPAR(IPAR_SHAPE)
    FLOAT_DIST  = FLOATPAR(IPAR_DLMAG)
    FLOAT_PKMJD = FLOATPAR(IPAR_PEAKMJD)
    FLOAT_ZPHOT = FLOATPAR(IPAR_ZPHOT)

! xxxxxxxxxxxxxxxxxxx
!      print*, ' xxx '
!      print*, ' xxx -------- CRAZYFITERR iter=', iter
!      print*, ' xxx ERR(c,s,d,t0) = ',
!     &     ERR_COLOR, ERR_SHAPE, ERR_DIST, ERR_PKMJD
! xxxxxxxxxxxxxxxxxxx

! if we are fitting only 1 filter, then don't bother
! checking crazy error

    if ( .NOT. CHECK_CRAZYFITERR ) then
       RETURN
    endif

! check for NaN on every fit iteration
    LNAN = .FALSE.
    if ( ISNAN(ERR_COLOR) ) LNAN = .TRUE.
    if ( ISNAN(ERR_SHAPE) ) LNAN = .TRUE.
    if ( ISNAN(ERR_DIST)  ) LNAN = .TRUE.
    if ( ISNAN(ERR_PKMJD) ) LNAN = .TRUE.
    if ( ISNAN(ERR_ZPHOT) ) LNAN = .TRUE.  ! Mar 2025

    IF ( LNAN ) THEN
       CRAZYFITERR = .TRUE.
       RETURN
    ENDIF

! don't do any more until last iteration
    IF ( ITER < NFIT_ITERATION ) THEN
       RETURN
    ENDIF

! ------------------------
! last fit iteration

    CRAZYFITERR = .TRUE.
    IF ( FLOAT_COLOR ) THEN
      IF ( ERR_COLOR > 3.0  .or. ERR_COLOR < 1.0E-8  ) RETURN
    ENDIF

    IF ( FLOAT_SHAPE ) THEN
      IF ( ERR_SHAPE > 3.0  .or. ERR_SHAPE < 1.0E-8  ) RETURN
    ENDIF

    IF ( FLOAT_DIST ) THEN
      IF ( ERR_DIST  > 3.0  .or. ERR_DIST  < 1.0E-15 ) RETURN
    ENDIF

    IF ( FLOAT_PKMJD ) THEN
      IF ( ERR_PKMJD > 10.0 .or. ERR_PKMJD < 1.0E-8  ) RETURN
    ENDIF

    IF ( FLOAT_ZPHOT ) THEN  ! Mar 2025
!  min based on Roman sims
!  max is a guess
      IF ( ERR_ZPHOT > 2.0 .or. ERR_ZPHOT < 1.0E-4  ) RETURN
    ENDIF

    CRAZYFITERR = .FALSE.

    RETURN
  END FUNCTION CRAZYFITERR

! =====================================
    LOGICAL FUNCTION FIRST_ITERATION(ITER)

! Created Aug 2017
! Return TRUE on first iteration of fit.
! Normally this is when ITER=1, but with some exceptions
! involving mutliple/repeat fits

    USE SNDATCOM
    USE SNANAFIT
    USE FITIDEALCOM

    IMPLICIT NONE

    INTEGER ITER
! ---------------- BEGIN ---------------

    FIRST_ITERATION = (ITER .EQ. 1) ! .and. (.not. LREPEAT_ITER)

    IF ( DOFIT_IDEAL_EVENT .and. ITER.EQ.NFIT_ITERATION_IDEAL+1) then
       FIRST_ITERATION = .TRUE.
    ENDIF

    RETURN
  END FUNCTION FIRST_ITERATION


! ===============================
    SUBROUTINE SIMSED_RECON()

! Created Jun 28, 2012
! If SIMSED model has parameters S2c and S2x1,
! compute SIMMB and SIMx0.
! Beware that ALPHA and BETA are hard-wired.
! 

    USE SNDATCOM
    USE FITINP_NML

    IMPLICIT NONE

    INTEGER IPAR, IPARx1, IPARc
    REAL S2x1, S2c, S2x0, S2x0inv, arg

! --------------- BEGIN ------------

    IF ( .NOT. LSIM_SNANA   ) RETURN
    IF ( NPAR_SIMSED .LE. 0 ) RETURN

! for SIMSED model with S2x1 and S2c,
! compute SIM_SALT2mb and SIM_SALT2x0

    IPARx1 = -9
    IPARc  = -9
    DO 100 ipar = 1, NPAR_SIMSED
      if ( SIMSED_PARNAME(IPAR)(1:4) .EQ. 'S2x1' ) then
          IPARx1 = IPAR
      endif
      if ( SIMSED_PARNAME(IPAR)(1:3) .EQ. 'S2c' ) then
          IPARc = IPAR
      endif
100   CONTINUE

    IF ( IPARx1 .GT. 0 .and. IPARc .GT. 0 ) THEN
       S2c  = SIMSED_PARVAL(IPARc)
       S2x1 = SIMSED_PARVAL(IPARx1)
       arg       = ( SIM_DLMAG - SALT2alpha*S2x1 + SALT2beta*S2c ) ;
       S2x0inv   = 1.0E-12 * (10.0**(0.4*arg) )
       S2x0      = 1./S2x0inv ;
       SIM_SALT2mB = 10.635 - 2.5*log10(S2x0);
       SIM_SALT2x0 = S2x0
    ENDIF

    RETURN
  END SUBROUTINE SIMSED_RECON

! ======================================
    SUBROUTINE FIX_COVAR_LCFIT()

! Nov 2018
! Check option to fix COV(mB,x1,c) if not invertible.
! Use algorithm for Marriner 2011 (SALT2mu code),
! which is update_covMatrix() function in sntools.c
! 
! Uses &FITINP OPT_COVAR_LCFIT mask, with mask options
! defined below as parameters.
! 
! There are two options here to fix COV to ensure invertibility:
! 1. M11 (Marriner 2011):
!    Diagonal COV is ERROR^2, and off-diag is from Minuit's MNEMAT
!    Beware that MNEMAT diagonals correpond to parabolic error,
!    not MINOS error.
! 
! 2. RED: use reduced covariance from MNEMAT and MINOS errors to
!    to construct COV matrix.
! 
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER, PARAMETER ::                & 
         OPTMASK_COVAR_FIXCOV_M11 =   1  & ! fix non-invertible COV as in Marriner11
        ,OPTMASK_COVAR_FIXCOV_RED =   2  & ! fix COV using reduced FITERRMAT
        ,OPTMASK_COVAR_DUMPROW    = 128  & ! one-row dump for each fix 
        ,OPTMASK_COVAR_DUMPFULL   = 256    ! dump COV(old) -> COV(fix)  


    CHARACTER NAME*20
    LOGICAL  L_VALID, L_UPD
    INTEGER  FIXCOV_M11, FIXCOV_RED, LDMP1, LDMP2
    INTEGER  OPT, OPTMASK, IPAR, IPAR2, NPAR, IERR, LENCCID, i,j
    INTEGER  IPAR_LIST(10)
    REAL*8   COV_ORIG(3,3), COV_UPD(3,3), X0JACOB(3,3)
    REAL*8   MBERR, X0, X0ERR, COV_TMP, ERR_TMP, ERR2_TMP,SF,EIGMIN
    REAL*8   COV_MN, COR_MN
    EXTERNAL UPDATE_COVMATRIX

! -------------- BEGIN --------------

    IF ( OPT_COVAR_LCFIT == 0 ) RETURN

    OPT = OPT_COVAR_LCFIT
    FIXCOV_M11 = IAND ( OPT, OPTMASK_COVAR_FIXCOV_M11 )
    FIXCOV_RED = IAND ( OPT, OPTMASK_COVAR_FIXCOV_RED )
    LDMP1      = IAND ( OPT, OPTMASK_COVAR_DUMPROW    )
    LDMP2      = IAND ( OPT, OPTMASK_COVAR_DUMPFULL   )

    L_VALID = .FALSE.
    if ( FIXCOV_M11 > 0 ) L_VALID = .TRUE.
    if ( FIXCOV_RED > 0 ) L_VALID = .TRUE.

    if ( .NOT. L_VALID ) then
       write(C1ERR,66) OPT_COVAR_LCFIT
 66      format('Invalid &FITINP  OPT_COVAR_LCFIT = ', I8 )
       C2ERR = 'Check bit-options in subroutine FIX_COVAR_LCFIT'
       CALL MADABORT("FIX_COVAR_LCFIT", C1ERR, C2ERR)
    endif

! load list of fit-param IPAR used to construct local COV
    NPAR = 3
    IPAR_LIST(1) = IPAR_X0
    IPAR_LIST(2) = IPAR_SHAPE
    IPAR_LIST(3) = IPAR_COLOR

! define jacobian factor for x0err
    X0    = LCVAL_STORE(IPAR_X0)
    SF    = -2.5/(x0*LOGTEN)

! set diagonal COV using stored errors ; don't use diagonal FITERRMAT
! since it's not necessarily ERR^2.

    DO i = 1, NPAR
       IPAR    = IPAR_LIST(i)
       ERR_TMP = LCERR_STORE(IPAR)
       do j = 1, NPAR
          IPAR2 = IPAR_LIST(j)
          ERR2_TMP = LCERR_STORE(IPAR2)
          X0JACOB(i,j) = 1.0
          COV_MN       = FITERRMAT(IPAR,IPAR2) ! minuit COV
          COR_MN       = FITCORMAT(IPAR,IPAR2) ! minuit reduced corr
          if ( IPAR  == IPAR_X0 ) X0JACOB(i,j) = X0JACOB(i,j)*SF
          if ( IPAR2 == IPAR_X0 ) X0JACOB(i,j) = X0JACOB(i,j)*SF

          if ( i == j ) then
             COV_ORIG(i,i) = (ERR_TMP * ERR_TMP)
          else
             if ( FIXCOV_M11 > 0 ) then
                COV_ORIG(i,j) = COV_MN
             else
                COV_ORIG(i,j) = (ERR_TMP*ERR2_TMP) * COR_MN
             endif
          endif
          COV_ORIG(i,j) = COV_ORIG(i,j)*X0JACOB(i,j)
          COV_UPD(i,j)  = COV_ORIG(i,j)
       enddo
    ENDDO


! ----------------------------------
! prepare arguments for update_covmatrix

    LENCCID = INDEX(SNLC_CCID,' ') - 1
    NAME    = SNLC_CCID(1:LENCCID) // char(0)
    OPTMASK = 0
    if ( LDMP2>0 ) OPTMASK = 4   ! 1=abort on bad COV,  4=dump
    EIGMIN  = 0.0001

!       print*,' xxx LDMP(1,2) = ', LDMP1, LDMP2, OPTMASK

    call update_covmatrix(NAME, OPTMASK, NPAR, COV_UPD, EIGMIN,  & 
                 IERR, LENCCID)

    L_UPD = ( (IERR .NE. 0) .or. FIXCOV_RED>0 )
    if ( L_UPD ) then
       N_SNLC_COVFIX = N_SNLC_COVFIX + 1

       DO i = 1, 3
          IPAR = IPAR_LIST(i)

          DO j = 1, 3
             IPAR2 = IPAR_LIST(j)
             COV_TMP = COV_UPD(i,j)
             if ( i == j ) then
                LCERR_STORE(IPAR) = SNGL( sqrt(COV_TMP/X0JACOB(i,i)) )
             else
                FITERRMAT(IPAR,IPAR2) = COV_TMP/X0JACOB(i,j)
             endif
          ENDDO
       ENDDO

! update MBERR based on updated x0ERR
       X0ERR = LCERR_STORE(IPAR_X0)
       MBERR = X0ERR * abs(SF)
       LCERR_STORE(IPAR_MB) = SNGL(MBERR)
    ENDIF

! --- check dump options ----

    if ( LDMP1>0 .and. L_UPD ) then
       write(6,20) SNLC_CCID(1:12)
 20      format(T8,'Fix COV(mB,x1,c) for CID ', A)
    endif

    RETURN
  END SUBROUTINE FIX_COVAR_LCFIT

! ======================================
    SUBROUTINE UPD_FLUXERRCALC()

! Feb 24, 2012
! Loop over fitted epochs and call FLUXERRCALC
! with fitted flux rather than the FLUXCAL from
! the data file.
! 
! Nov 27, 2012: remove ISN argument from subroutine and from
!                FLUXERRCALC call.
! 
! -------------------------


    USE SNDATCOM
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER IFITDATA, iep
    REAL    FLUXCAL, FLUXCAL_ERR

! -------------- BEGIN -------------

    IF ( .NOT. DO_FLUXERRCALC ) RETURN

    DO 200 ifitdata  = 1, NFITDATA
       iep           = EPLIST_FIT(ifitdata)
       FLUXCAL       = R4EP_ALL(iep,JEP_MODELFLUX)
       FLUXCAL_ERR   = R4EP_ALL(iep,JEP_DATAFLUX_ERR)
       CALL FLUXERRCALC(iep, FLUXCAL, FLUXCAL_ERR)

200   CONTINUE
    RETURN
  END SUBROUTINE UPD_FLUXERRCALC

! ==================================
    SUBROUTINE SETCUTS_FITWIN_TREST

! Jan 2012
! By default set each FITWIN_TREST_FILT = global FITWIN_TREST
! Then check user-namelist strings FITWIN_TREST_FILTER
! for tighter TREST-windows.
! 
! Initial use is to limit the SNACC-filter Trest-range
! because the FUDGE_FITERR options allow downweighting
! but not removing epochs. The FITWIN_TREST_FILTER option
! allow removing epochs in specific filters.
! 
! May 26, 2012:
!  fix aweful bug. First do-loop to init FITWIN_TREST_FILT
!  is now up to MXFILT_ALL=80 instead of MXFILT_OBS=62.
!  Previously FITWIN_TREST_FILT with IFILT_OBS > 62 were
!  not initialized, and thus these filters were likely
!  dropped on 2nd fit iteration.
! 
! ------------

    USE SNDATCOM
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER ifilt_obs, iwd, NWD, NFILT, ifilt, LEN, MSKOPT
    REAL    TMIN, TMAX
    CHARACTER CFILT*(MXFILT_ALL), CFILT1*2, CWD*60, FNAM*24

! function
    INTEGER FILTINDX

    INTEGER  STORE_PARSE_WORDS
    EXTERNAL STORE_PARSE_WORDS

! ------------ BEGIN -----------

    FNAM = 'SETCUTS_FITWIN_TREST'

! first set each filter-Trest window to the global default.
! c   DO ifilt_obs = 1, MXFILT_OBS !!! aweful bug fixed May 2012
    DO ifilt_obs = 1, MXFILT_ALL
      FITWIN_TREST_FILT(1,ifilt_obs) = FITWIN_TREST(1)
      FITWIN_TREST_FILT(2,ifilt_obs) = FITWIN_TREST(2)
    ENDDO

! count how many FITWIN_TREST_FILTER cuts have been  specified.
    IF ( FITWIN_TREST_FILTER .EQ. ' ' ) RETURN

    MSKOPT = MSKOPT_PARSE_WORDS_STRING
    NWD = STORE_PARSE_WORDS(MSKOPT, FITWIN_TREST_FILTER//char(0),  & 
          FNAM//char(0), 80, 24)

! make sure that number of elements is a multiple of
! three (filters, TMIN, TMAX)

    IF ( mod(NWD,3) .NE. 0 ) then
      C1ERR = 'Invalid FITWIN_TREST_FILTER = '
      C2ERR = FITWIN_TREST_FILTER(1:80)
      CALL MADABORT("SETCUTS_FITWIN_TREST", C1ERR, C2ERR)
    ENDIF

    DO 100 iwd  = 1, NWD, 3

      CALL get_PARSE_WORD_fortran(iwd+0, CWD, LEN, FNAM)
      CFILT = CWD

      CALL get_PARSE_WORD_fortran(iwd+1, CWD, LEN, FNAM)
      read(CWD,*) TMIN
      CALL get_PARSE_WORD_fortran(iwd+2, CWD, LEN, FNAM)
      read(CWD,*) TMAX

      NFILT = INDEX(CFILT,' ') - 1
      do ifilt = 1, NFILT
         cfilt1 = CFILT(ifilt:ifilt)
         ifilt_obs = FILTINDX(cfilt1)
         FITWIN_TREST_FILT(1,ifilt_obs) = TMIN
         FITWIN_TREST_FILT(2,ifilt_obs) = TMAX
         write(6,20) CFILT1, TMIN, TMAX
20         format(T5,'Set special FITWIN_TREST(filt=',A1,') : ',  & 
                    F6.1,' to ', F6.1)
      enddo

100   CONTINUE

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE SETCUTS_FITWIN_TREST

! ===================================================
    SUBROUTINE SEDMODEL_INI(IFLAG,IERR)
! 
! Created Nov 09, 2010 by R.Kessler
! 
! Called from FITPAR_INI to initialize model(s) based
! on a SED spectral surface. This init includes
! primary reference, filters, and the model-dependent
! INIT_GENMAG_XXX() function.
! 
! Models supported:
!  - SALT2
!  - SIMSED
! 
! 
!  IFLAG = 0 => called before any SN have been fitted (init stage)
!  IFLAG > 0 => called just before fitting each SN
! 
!    HISTORY
! 
! Jun 24 2018: pass NONE argument to INIT_GENMAG_SALT2
! 
! Jul 09 2019: call set_UVLAM_EXTRAPFLUX_SEDMODEL
! 
! Apr 20 2020: fix dimenstion of TMP_FITMODEL to allow paths
! 
! Jul 30 2024:
!  remove "ZMAX = PHOTOZ_RANGE_KCOR(2)" because PHOTOZ_RANGE_KCOR isn't set yet.
!  This results in zmax=0 and undefined log10(zmax)  ... not clear how this worked at all.
! 
! ---------------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FILTUPDCM
    USE SNLCINP_NML

    IMPLICIT NONE

! subroutine args
    INTEGER  IFLAG   ! (I) 0-> one-time init
    INTEGER  IERR    ! (O) 0 => OK

! local var

    INTEGER  & 
         IFILT_OBS, IFILT, OPT_FRAME, i  & 
        ,LEN1, LEN2, LEN_NAME, ISTAT, NLAM, OPTMASK  & 
        ,NZBIN, OPT_FILTER_UPDATE_SAVE

    REAL*8  & 
         LAM(MXLAMBIN_PRIM)  & 
        ,VALa(MXLAMBIN_PRIM)  & 
        ,VALb(MXLAMBIN_PRIM)  & 
        ,LAMSHIFT, MAGPRIM, LAMRANGE(2)  & 
        ,ZMIN, ZMAX, LOGZDIF, RVMW, PARLIST(10)

    CHARACTER  & 
         tmpname*40  & 
        ,SURVEY_NAME_FILTER*(2*MXCHAR_SURVEY)  & 
        ,TMP_FITMODEL*(MXCHAR_FILENAME), TMP_EXTRAP*10  & 
        ,BLANK*8, CFILT1*2, cfilt*(MXFILT_ALL)

! functions

    INTEGER  & 
         RESET_SEDMODEL  & 
        ,INIT_PRIMARY_SEDMODEL  & 
        ,INIT_FILTER_SEDMODEL  & 
        ,INIT_GENMAG_SALT2  & 
        ,INIT_GENMAG_SIMSED  & 
        ,INIT_GENMAG_BAYESN

    EXTERNAL  & 
         RESET_SEDMODEL  & 
        ,INIT_PRIMARY_SEDMODEL  & 
        ,INIT_FILTER_SEDMODEL  & 
        ,INIT_GENMAG_SALT2  & 
        ,INIT_GENMAG_SIMSED  & 
        ,INIT_GENMAG_BAYESN  & 
        ,init_redshift_sedmodel  & 
        ,init_mwxt_sedmodel  & 
        ,set_UVLAM_EXTRAPFLUX_SEDMODEL  & 
        ,GET_CALIB_PRIMARY_SED    &  ! refac
        ,GET_CALIB_FILTERTRANS   ! refac

! ------------------- BEGIN SEDMODEL_INI ---------------

    IERR = 0
    LEN_NAME   = INDEX(FITMODEL_NAME,' ') - 1

! reset SEDMODEL to init and/or erase previous instance
    ISTAT = RESET_SEDMODEL()

! init primary spectrum

    CALL GET_CALIB_PRIMARY_SED(tmpname, NLAM, LAM, VALa, 20)
    ISTAT = INIT_PRIMARY_SEDMODEL(tmpname, NLAM,LAM,VALa,LEN1)

    RVMW = DBLE(RV_MWCOLORLAW)
    DO i = 1, 10
      PARLIST(i) = DBLE( PARLIST_MWCOLORLAW(i) )
    ENDDO
    CALL init_MWXT_SEDMODEL(OPT_MWCOLORLAW, PARLIST, RVMW) ;

! set entire redshift range if same filters are used for each SN;
! for SN-dependent filters, set exact z-range (and 1 Z-bin)
! to avoid lots of uncecessary CPU time.

    IF ( IFLAG .EQ. 0 .or. DOFIT_PHOTOZ ) THEN
      zmin    = CUTWIN_REDSHIFT(1)
      zmax    = CUTWIN_REDSHIFT(2)

      zmin    = max(zmin,0.005)
      zmax    = min(zmax,5.0)   ! avoid crazy Zmax = E4

      if ( DOFIT_PHOTOZ ) then
        ZMAX = min ( ZMAX, PHOTOZ_BOUND(2) )
      endif

      logzdif = log10(zmax) - log10(zmin)
      NZBIN    = int(100.* logzdif) + 1
    ELSE
      zmin = SNLC_REDSHIFT
      zmax = SNLC_REDSHIFT
      NZBIN = 1
    ENDIF

    CALL init_redshift_sedmodel(NZBIN, zmin, zmax)

! now init each filter.
    IF ( IFLAG .EQ. 0 ) THEN
       OPT_FILTER_UPDATE_SAVE = OPT_FILTER_UPDATE
       OPT_FILTER_UPDATE      = 0 ! needed to read kcor-filters
    ENDIF

    DO 44 ifilt  = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       cfilt1    = filtdef_string(ifilt_obs:ifilt_obs)
       
       LAMSHIFT = FILTER_LAMSHIFT_FILT(ifilt_obs) ! Apr 12 2025 fix

! pass ifilt_obs; everything else is returned.
! VALa = transSN, VALb = transREF8

       OPT_FRAME = OPT_FILTOBS - 1 ! fortran -> C
       CALL GET_CALIB_FILTERTRANS(OPT_FRAME, ifilt_obs,      &  ! (I)
                 SURVEY_NAME_FILTER, CFILT, MAGPRIM,             &  ! (O)
                 NLAM, LAM, VALa, VALb,                          &  ! (O)
                 40, 40 )

       LEN1  = INDEX(cfilt,char(0))
       LEN2  = INDEX(SURVEY_NAME_FILTER,char(0))
       ISTAT = INIT_FILTER_SEDMODEL(IFILT_OBS, cfilt,  & 
                    SURVEY_NAME_FILTER,  & 
                    MAGPRIM, NLAM, LAM, VALa, VALb, LAMSHIFT,  & 
                    LEN1, LEN2 )

       CALL FLUSH(6)
       
44  CONTINUE  ! end of IFILT loop

! --------------------------------------------------------
! Sep 2026: prep option to apply wavecor shift to each observation
    if ( NSTORE_WAVECOR > 0 ) then
       CALL PREP_WAVECOR_SEDMODEL(SNLC_WAVECOR_MIN,SNLC_WAVECOR_MAX)
    endif


! --------
    IF ( IFLAG .EQ. 0 ) THEN
       OPT_FILTER_UPDATE  = OPT_FILTER_UPDATE_SAVE
    ENDIF

    CALL set_UVLAM_EXTRAPFLUX_SEDMODEL(UVLAM_EXTRAPFLUX)

! ----------------------------------------
! now do general model-dependent init.
! TMP_FITMODEL has the special end-string char(0) need for C functions.

    TMP_FITMODEL = FITMODEL_NAME(1:LEN_NAME) // char(0)
    BLANK        = "" // char(0)

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN

      OPTMASK = 0
      IF ( REQUIRE_DOCANA > 0 )           OPTMASK = OPTMASK + 2
      IF ( .NOT. ENABLE_MAGSHIFT_SALT2  ) OPTMASK = OPTMASK + 4
      IF ( .NOT. ENABLE_WAVESHIFT_SALT2 ) OPTMASK = OPTMASK + 8
      IF ( .NOT. ALLOW_NEGFLUX_SALT2    ) OPTMASK = OPTMASK + 16   ! Mar 2021
      if ( NSTORE_WAVECOR > 0           ) OPTMASK = OPTMASK + 32   ! Sep 2026
      IF ( DEBUG_FLAG == 1024           ) OPTMASK = OPTMASK + 1024 ! SALT2 debug flag

      ISTAT = INIT_GENMAG_SALT2( TMP_FITMODEL, BLANK, OPTMASK,  & 
                  LEN_NAME, 40 )

! turn on covariance model by default,
! unless user specifically sets OPT_COVAR=0
      IF ( OPT_COVAR_FLUX .EQ. -9 ) OPT_COVAR_FLUX    = 1
      if ( .not. USE_MODEL_MAGERR ) OPT_COVAR_FLUX    = 0

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_BAYESN ) THEN

       !       BAYESN BLOCK created Nov 2022
       OPTMASK = 0
       if(debug_flag == 821) then
          OPTMASK = 2048  ! enable test mode (Aug. 21 2025 M. Chernyashevskyy)
       endif


       ISTAT=INIT_GENMAG_BAYESN(TMP_FITMODEL,TMP_EXTRAP,OPTMASK,BLANK,  & 
            LEN_NAME,10,8)

! turn on covariance model by default,
! unless user specifically sets OPT_COVAR=0
       IF ( OPT_COVAR_FLUX .EQ. -9 ) OPT_COVAR_FLUX    = 1
       if ( .not. USE_MODEL_MAGERR ) OPT_COVAR_FLUX    = 0

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SIMSED ) THEN

!          ISTAT = INIT_GENMAG_SIMSED( TMP_FITMODEL, LEN_NAME )

    ELSE
       LEN1 = INDEX(FITMODEL_VERSION,' ') - 1
       C1ERR = 'Invalid FITMODEL_VERSION = '  & 
                       // FITMODEL_VERSION(1:LEN1)
       C2ERR = 'Model must be based on spectral surface(s).'
       CALL MADABORT("SEDMODEL_INI", c1err, c2err)
    ENDIF

    LKCOR_AVWARP  = .FALSE.
    OPTMASK = 1
    CALL GET_LAMRANGE_SEDMODEL(OPTMASK,LAMRANGE(1),LAMRANGE(2))
    RESTLAMBDA_MODEL(1) = SNGL(LAMRANGE(1))
    RESTLAMBDA_MODEL(2) = SNGL(LAMRANGE(2))

    CALL FLUSH(6)
    RETURN
  END SUBROUTINE SEDMODEL_INI


! =====================
    SUBROUTINE GET_SIMCHI2_CHEAT()

! Created Feb 2, 2014
! 
! Call FCNSNLC with  IFLAG = FCNFLAG_USESIM to replace the
! fitted parameters with the true simulated parameters.
! Store resulting chi2 in global SIMCHI2_CHEAT.
! This works fine for 4-parameter fits, but there is a
! subtle issue for 5-par (photo-z) fits; if the true
! redshift (ZSIM) is very far away from the fitted ZPHOT
! then the wrong filters are used and the program will abort.
! For example, ZPHOT=.4 will use z-band, but if ZSIM=0.1
! then z-band goes outside the 9200 range of SALT2 and
! will abort.
! 
! If any obs-frame filter is undefined in the rest-frame
! [ based on range of LAMOBS/(1+ZSIM) ] then skip chi2
! computation and set SIMCHI2_CHEAT = -1 * NFILT_UNDEFINED
! 
! Apr 4 2018: fix bug, RESTLAMBDA_MODEL -> RESTLAMBDA_FITRANGE
! 

    USE SNDATCOM
    USE SNANAFIT
! CDE,SNLCINP.
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    LOGICAL   USED, LAM1, LAM2
    INTEGER   ifilt, IFILT_OBS, NFILT_UNDEFINED
    CHARACTER cfilt*2
    DOUBLE PRECISION GRAD(MXFITPAR), Z1SIM, LAMREST

! function(s)
    DOUBLE PRECISION  USRFUN   ! for SIMCHI2_CHEAT
    EXTERNAL          USRFUN

! ---------------- BEGIN -----------------

! first check that each filter used in the fit
! is defined by the model in the rest frame.

    NFILT_UNDEFINED = 0
    Z1SIM  = 1.0 + SIM_REDSHIFT_HELIO
    DO 100 ifilt     = 1, NFILTDEF_SURVEY

       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       cfilt     = filtdef_string(ifilt_obs:ifilt_obs)
       USED      = USE_FILT(ifilt_obs)  ! used in nominal fit
       if ( .NOT. USED ) GOTO 100

       LAMREST = FILTOBS_LAMAVG(ifilt_obs)/Z1SIM
       LAM1    = LAMREST .GE. RESTLAMBDA_FITRANGE(1)
       LAM2    = LAMREST .LE. RESTLAMBDA_FITRANGE(2)

       if ( .not. (LAM1 .and. LAM2) ) THEN
          NFILT_UNDEFINED = NFILT_UNDEFINED + 1

          write(6,30) SNLC_CCID, cfilt(1:1), SIM_REDSHIFT_HELIO
 30         format(T3,'WARNING: CID ', A18,' has ',  & 
              A,'-band undefined for SIMCHI2_CHEAT(zsim=',F5.3,')' )
          call flush(6)
       endif

 100  CONTINUE

! bail if there are any undefined filters in the rest-frame.
    if ( NFILT_UNDEFINED > 0 ) THEN
       SIMCHI2_CHEAT = -1.0 * DBLE(NFILT_UNDEFINED)
       return
    endif

! if we get here, filters are OK so compute SIMCHI2_CHEAT.

    CALL FCNSNLC(NFITPAR_MN, GRAD, SIMCHI2_CHEAT,  & 
           INIVAL, FCNFLAG_USESIM, USRFUN)

    RETURN
  END SUBROUTINE GET_SIMCHI2_CHEAT

! ===================================================
    SUBROUTINE PHOTOZ_ANA(IFLAG, iter, ERRFLAG )
! 
! Created Aug 2009 by R.Kessler
! Analyze PHOTOZ fit.
! 
! On ITER=0, init & print ZDROP for each filter.
!    Also remove SNANA-Trest cuts and store cuts in PHOTOZ-cut variables
! 
! On 1st iteration, check for filters to drop.
! On 2nd iteration, do nothing but fill global variables.
! 
! If filter(s) are dropped, set ERRFLAG = -1
! so that the 1st iteration is repeated (LREPEAT_ITER=T)
! 
! Fill global variables
!  PHOTODZ_MIN(iter)   MIN distance to model-boundary over all filters,
!  PHOTODZ1Z_MIN(iter)
!  IFILT_NEARDROP     ! filter-index closest to being dropped
! 
! 
! April 2024: check FITWIN_PROB_ITER
! Nov 2024: add more info for dump (LDMP)
! -----------------------------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE

! subroutine args

    INTEGER  & 
         IFLAG    &  ! (I) 0= one time init; 1= each SN
        ,iter     &  ! (I) fit iteration: 1,2, ... NFIT_ITERATION
        ,ERRFLAG  ! (O)

! local var

    REAL*8  & 
         PHOTOZ_VAL, PHOTOZ1_VAL, PHOTOZ_ERR, Z, ZZ, LAMOBS & 
        ,ZMIN, Z1MIN,  DZatMIN, DZ1ZatMIN  & 
        ,ZMAX, Z1MAX,  DZatMAX, DZ1ZatMAX  & 
        ,MJD, PEAKMJD, Trest, Z1  & 
        ,ZMIN_KCOR, ZMAX_KCOR, ZBIN_KCOR

    REAL CUTWIN_SNANA(2), TLIST(MXEPOCH), SNRLIST(MXEPOCH), Z4, SNR

    INTEGER  & 
         IFILT, IFILT_OBS, NFILT_CUT, NFILT  & 
        ,IFITDATA, NTLIST, iep, LCID, MSKCUT  & 
        ,FLIST(MXEPOCH)  & 
        ,NFILTDROP, IFILTDROP  & 
        ,NTCUT, LENF

    LOGICAL   LCUT, LDMP, LZTEST, LDROP, LADD
    CHARACTER cfilt1*12, cfiltdrop*20, cfiltadd*20, ccid*(MXCHAR_CCID)
    character VERB*8

! function
    REAL TRESTzCUT
    LOGICAL LFITFUN_FILT, LTEST_ZPHFILTER

    EXTERNAL GET_KCOR_ZRANGE  ! sntools_calib.c[h]

! ------------------ BEGIN --------------

! check for cheater flag.
    IF ( IFLAG .EQ. 0 .and. ITER .EQ. 0 ) THEN
      IF ( BTEST(OPT_PHOTOZ,BIT_PHOTOZ_CHEAT) ) THEN
         DOFIT_PHOTOZ_CHEAT = .TRUE.       ! set global flag
         OPT_PHOTOZ = IBSET(OPT_PHOTOZ,BIT_PHOTOZ_GAUSS)  ! set host-prior bit to be safe
      ELSE
         DOFIT_PHOTOZ_CHEAT = .FALSE.
      ENDIF

!    Nov 2024: preserve original PHOTODZ_REJECT in case it gets altered
!              for subset of zSpec
      PHOTODZ_REJECT_ORIG = PHOTODZ_REJECT

      PHOTOZ_RANGE_KCOR(1) = CUTWIN_REDSHIFT(1)
      PHOTOZ_RANGE_KCOR(2) = CUTWIN_REDSHIFT(2)
      if ( LREST_FITMODEL ) then
         CALL GET_KCOR_ZRANGE(ZMIN_KCOR, ZMAX_KCOR, ZBIN_KCOR)
         PHOTOZ_RANGE_KCOR(1) = SNGL(ZMIN_KCOR)
         PHOTOZ_RANGE_KCOR(2) = SNGL(ZMAX_KCOR + 4.0*ZBIN_KCOR)
      endif


      ! Dec 2025: set course-grid for each fitted parameter
      CALL INIT_COURSEBIN_PHOTOZ() 
        
    ENDIF  ! end IFLAG==0

! - - - - - - - -

    ERRFLAG = 0  ! default is OK
    LDROP = .FALSE.
    LADD  = .FALSE.

! bail if we just did 2-band FITRESTMAG since it makes no sense to repeat.
    if( IFILTOBS_BRACKET(1) > 0 ) RETURN

    if ( IFLAG .GT. 0 ) THEN
      CCID = SNLC_CCID
      LCID = ISNLC_LENCCID
    ENDIF

    IF ( ITER > 0 ) THEN
      PHOTODZ_MIN(iter)    = 9999.
      PHOTODZ1Z_MIN(iter)  = 9999.
      PHOTOZ_VAL           = FITVAL(IPAR_ZPHOT,iter)
      PHOTOZ_ERR           = FITERR(IPAR_ZPHOT,iter)
      PHOTOZ1_VAL          = 1. + PHOTOZ_VAL
    ENDIF

! check LREPEAT after PHOTOZ_VAL/ERR are defined
    IF ( LREPEAT_ITER ) THEN
      GOTO 800     ! never process repeated iteration
    ENDIF

    IFILT_NEARDROP       = -9
    LDMP = LDMP_PHOTOZ_DROPFILTER

    if ( ITER .EQ. 0 ) then

      print*,' '
      print*,  & 
         '  APPLY THESE TREST-RELATED CUTS BEFORE/AFTER PHOTOZ FIT: '
      call flush(6)

      Z  = PHOTOZ_BOUND(2)
      ZZ = 1. + PHOTOZ_BOUND(2)
      Z4 = SNGL(Z)

      cutwin_snana(1) = TRESTzCUT(1, Z4, CUTWIN_Trest(1) )
      cutwin_snana(2) = TRESTzCUT(2, Z4, CUTWIN_Trest(2) )
      CALL PHOTOZ_SAVECUT('TREST',  & 
           cutwin_trest, cutwin_snana, FITANA_cutwin_trest )

      cutwin_snana(1) = TRESTzCUT(1, Z4, CUTWIN_Trestmin(1) )
      cutwin_snana(2) = TRESTzCUT(2, Z4, CUTWIN_Trestmin(2) )
      CALL PHOTOZ_SAVECUT('TRESTMIN',  & 
           cutwin_trestmin, cutwin_snana, FITANA_cutwin_trestmin )

      cutwin_snana(1) = TRESTzCUT(1, Z4, CUTWIN_Trestmax(1) )
      cutwin_snana(2) = TRESTzCUT(2, Z4, CUTWIN_Trestmax(2) )
      CALL PHOTOZ_SAVECUT('TRESTMAX',  & 
           cutwin_trestmax, cutwin_snana, FITANA_cutwin_trestmax )

      cutwin_snana(1) = TRESTzCUT(1, Z4, CUTWIN_T0gapmax(1) )
      cutwin_snana(2) = TRESTzCUT(2, Z4, CUTWIN_T0gapmax(2) )
      CALL PHOTOZ_SAVECUT('T0GAPMAX',  & 
           cutwin_t0gapmax, cutwin_snana, FITANA_cutwin_t0gapmax )

      cutwin_snana(1) = TRESTzCUT(1, Z4, CUTWIN_Tgapmax(1) )
      cutwin_snana(2) = TRESTzCUT(2, Z4, CUTWIN_Tgapmax(2) )
      CALL PHOTOZ_SAVECUT('TGAPMAX',  & 
           cutwin_tgapmax, cutwin_snana, FITANA_cutwin_tgapmax )

! change SNANA-Trest cuts

      print*,' '
      print*,'  FIRST-ITERATION FILTER SELECTION: '
      call flush(6)
    endif

    IF( LDMP .and. (ITER .EQ. 1) .and. (.NOT. LREPEAT_ITER) ) then
       print*,' ----------------------------------------------- '
       print*,'  DROP-FILTER DUMP for CID = ' , CCID
    ENDIF

    NFILTDROP = 0
    cfiltdrop = ''
    cfiltadd  = ''

    DO 100 ifilt   = 1, NFILTDEF_SURVEY
        ifilt_obs  = IFILTDEF_MAP_SURVEY(ifilt)
        cfilt1     = filtdef_string(ifilt_obs:ifilt_obs)

! only check FILTLIST_FIT filters specified by user
        if ( .NOT. DOFIT_FILT(ifilt_obs) ) goto 100

        LAMOBS = FILTOBS_LAMAVG(ifilt_obs)

! get min/max redshift allowed by model
        ZMIN = LAMOBS/RESTLAMBDA_USEFIT(2) - 1.0
        ZMAX = LAMOBS/RESTLAMBDA_USEFIT(1) - 1.0

! print filter range in ITER=0 only
        if ( ITER .EQ. 0 ) then
           write(6,600) cfilt1(1:1), ZMIN, ZMAX
600          format(T6,'Keep ',A,' if ', F7.3,' < Zphot < ', F7.3 )
           call flush(6)
           goto 100
        endif

! store valid z-range in global
        PHOTOZ_DROPFILTER_MIN(ifilt_obs) = SNGL(ZMIN)
        PHOTOZ_DROPFILTER_MAX(ifilt_obs) = SNGL(ZMAX)

        Z1MIN = 1. + ZMIN
        Z1MAX = 1. + ZMAX

! note that negative DZ always means outside the ZMIN/ZMAX range
! defined by the model.

        DZatMIN   = (PHOTOZ_VAL - ZMIN) ! should be roughly positive
        DZatMAX   = (ZMAX - PHOTOZ_VAL) ! idem
        DZ1ZatMIN = (PHOTOZ_VAL - ZMIN) / Z1MIN
        DZ1ZatMAX = (ZMAX - PHOTOZ_VAL) / Z1MAX

! keep track of filter that is closest to getting dropped.
        if ( abs(DZatMIN) < abs(PHOTODZ_MIN(iter)) ) then
          PHOTODZ_MIN(iter)   = SNGL(DZatMIN)
          PHOTODZ1Z_MIN(iter) = SNGL(DZ1ZatMIN)
          IFILT_NEARDROP      = IFILT_OBS
        endif

        if ( abs(DZatMAX) < abs(PHOTODZ_MIN(iter)) ) then
          PHOTODZ_MIN(iter)   = SNGL(DZatMAX)
          PHOTODZ1Z_MIN(iter) = SNGL(DZ1ZatMAX)
          IFILT_NEARDROP      = IFILT_OBS
        endif

! apply cut to see if this filter should be tossed;

        LCUT = .FALSE.
        IF ( DZatMIN   .LT. PHOTODZ_REJECT   ) LCUT = .TRUE.
        IF ( DZatMAX   .LT. PHOTODZ_REJECT   ) LCUT = .TRUE.
        IF ( DZ1ZatMIN .LT. PHOTODZ1Z_REJECT ) LCUT = .TRUE.
        IF ( DZ1ZatMAX .LT. PHOTODZ1Z_REJECT ) LCUT = .TRUE.

! set cut logical only on first iteration
        IF ( ITER .EQ. 1 .and. .not. LREPEAT_ITER ) then
           PHOTOZ_DROPFILTER(ifilt_obs) = LCUT
           if ( LCUT  ) then
              ERRFLAG   = -1          ! set repeat flag
              NFILTDROP = NFILTDROP + 1  ! local counter
              LENF = index(cfiltdrop,' ') -1
              cfiltdrop = cfiltdrop(1:LENF) // cfilt1(1:1)
              LDROP = .TRUE.
           endif
        ENDIF

        if ( LDMP ) then
          print*,' xxx DROPFILTER(', cfilt1(1:1), ') = ', LCUT
          write(6,666) ZMIN, ZMAX, DZatmin, DZatMAX
666         format('  xxx ', T10,'ZMIN,ZMAX=',2F6.3,  & 
                 3x, 'DZatMIN/MAX=',2F7.3)
          print*,' xxx    ITER, LREPEAT_ITER=', ITER, LREPEAT_ITER
          print*,' xxx    PHOTODZ_REJECT, PHOTODZ1Z_REJECT=',  & 
                   PHOTODZ_REJECT, PHOTODZ1Z_REJECT
          CALL FLUSH(6)
        endif

! 4/24/2011: check if a filter will be added
        LZTEST =  LFITFUN_FILT(ifilt_obs,PHOTOZ_VAL)
        if ( LZTEST .and. .not. USE_FILT(ifilt_obs) ) then
           PHOTOZ_ADDFILTER(ifilt_obs) = .TRUE.
           ERRFLAG  = -1          ! set repeat flag
           LENF = index(cfiltadd,' ') -1
           cfiltadd = cfiltadd(1:LENF) // cfilt1(1:1)
           LADD = .TRUE.
        endif

!          print*,'  xxxx ITER=', ITER,
!     &          '   USE_FILT(', cfilt1(1:1), ') = ', USE_FILT(ifilt_obs),
!     &          '   LZTEST=', LZTEST,
!     &          '   DROP=', PHOTOZ_DROPFILTER(ifilt_obs)

100   CONTINUE  ! IFILT loop over all filters


    IF ( ITER .EQ. 0 ) RETURN

! On last iteration, set NEARDROP-filter index to negative
! if it was dropped. This is to identify dropped filters
! in the analysis-ntuple (ntid 7788)

    LCUT = PHOTOZ_DROPFILTER(IFILT_NEARDROP)
    IF ( ITER .EQ. NFIT_ITERATION .and. LCUT ) THEN
       IFILT_NEARDROP = -IFILT_NEARDROP
    ENDIF


! if filters are dropped, then check if Trest-related
! SNANA cuts are still satisfied. If not, set ERRFLAG
! to SKIP this turkey. Use the loose snana cuts instead of the
! tighter (final) cuts.

    IF ( ERRFLAG .EQ. -1 ) THEN

      VERB = ''
      IF( LDROP ) THEN
         VERB = 'Dropped'
         CFILT1 = cfiltdrop(1:12)
      ENDIF
      IF( LADD  ) THEN
         VERB = 'Added'
         CFILT1 = cfiltadd(1:12)
      ENDIF

      if ( STDOUT_UPDATE ) then
        LENF = index(CFILT1,' ') - 1
        write(6,190) VERB, CCID(1:LCID), cfilt1(1:LENF)
190       format(T8, A, 2x, A,'-', A,  & 
                     ' : retest Trest-related cuts: ', $ )
        call flush(6)
      endif

      PEAKMJD = FITVAL(IPAR_PEAKMJD,iter)
      Z1      = FITVAL(IPAR_ZPHOT,iter)  + 1.0
      NTLIST = 0
      DO 200 ifitdata = 1, NFITDATA

        iep       = EPLIST_FIT(ifitdata)
        ifilt_obs = I4EP_ALL(iep,IEP_IFILT_OBS)

        if ( PHOTOZ_DROPFILTER(ifilt_obs) ) GOTO 200

        MJD           = SNLC8_MJD(iep) - MJDOFF
        SNR           = SNLC_SNR(iep)
        Trest         = (MJD - PEAKMJD) / z1
        NTLIST        = NTLIST + 1
        TLIST(NTLIST) = SNGL(Trest)
        FLIST(NTLIST) = ifilt_obs
        SNRLIST(NTLIST) = SNR

200     CONTINUE

! if we don't have enough measurements after filter-drop, bail ASAP.
      if ( NTLIST .LT. CUTWIN_NEPOCH(1) ) then
        ERRFLAG = ERRFLAG_ZFIT_DROPFILTCUTS
        if ( STDOUT_UPDATE ) then
          write(6,186) NTLIST
186         format(I2,' obs -> FAIL' )
        endif
        return
      endif

! get Nfilt passing Trestmin & Trestmax cuts.

      CALL GET_TRESTVAR (  & 
              NTLIST, TLIST, FLIST, SNRLIST  &  ! (I) Trest   IFILT arrays
             ,CUTWIN_TREST                   &  ! (I) user cutwin
             ,CUTWIN_TRESTMIN                &  ! (I) idem
             ,CUTWIN_TRESTMAX                &  ! (I) idem
             ,CUTWIN_TREST2                  &  ! (I)
             ,NFILT                          &  ! (O) Nfilt within TREST-range
             ,TRESTMIN_FIT, TRESTMAX_FIT     &  ! (O) Trestmin,max after fit
             ,NFILT_TRESTMIN_FIT             &  ! (O)
             ,NFILT_TRESTMAX_FIT             &  ! (O)
             ,NFILT_TREST2_FIT               &  ! (O)
             ,TGAPMAX_FIT, T0GAPMAX_FIT      &  ! (O)
             ,SNRSUM_FIT    )               ! (O)


      TRESTRANGE_FIT = TRESTMAX_FIT - TRESTMIN_FIT  ! De 18 2017

! require at least enough filters to have a chance at NFILT_SNRMAX cut

      MSKCUT = 0

      NTCUT = int(CUTWIN_NEPOCH(1))
      if ( NTLIST < NTCUT ) then
        MSKCUT = MSKCUT + 1
        ERRFLAG = ERRFLAG_ZFIT_DROPFILTCUTS
      endif

      NFILT_CUT = int(CUTWIN_NFILT_SNRMAX(1))
      if ( NFILT < (NFILT_CUT-1) ) then
         MSKCUT = MSKCUT + 2
         ERRFLAG = ERRFLAG_ZFIT_DROPFILTCUTS
      endif

      NFILT_CUT = int(CUTWIN_NFILT_SNRMAX2(1))
      if ( NFILT < (NFILT_CUT-1) ) then
         MSKCUT = MSKCUT + 4
         ERRFLAG = ERRFLAG_ZFIT_DROPFILTCUTS
      endif

      NFILT_CUT = int(CUTWIN_NFILT_TRESTMIN(1))
      if ( NFILT_TRESTMIN_FIT < NFILT_CUT )  then
         MSKCUT = MSKCUT + 8
         ERRFLAG = ERRFLAG_ZFIT_DROPFILTCUTS
      endif

      NFILT_CUT = int(CUTWIN_NFILT_TRESTMAX(1))
      if ( NFILT_TRESTMAX_FIT < NFILT_CUT )  then
         MSKCUT = MSKCUT + 16
         ERRFLAG = ERRFLAG_ZFIT_DROPFILTCUTS
      endif

      if ( STDOUT_UPDATE ) then
        if ( ERRFLAG > 0 ) then
           write(6,196) 'FAIL', MSKCUT
        else
           write(6,191) 'PASS'
        endif
        call flush(6)
      endif

191     format(A)
196     format(A,' (MSKCUT=',I3,')' )

! ----------------------
!        print*,' xxxx TRESTMIN, TRESTMAX = ',
!     &          TRESTMIN_FIT, TRESTMAX_FIT
!        print*,' xxxx NFILT(TRESTMIN,TRESTMAX) = ',
!     &          NFILT_TRESTMIN_FIT, NFILT_TRESTMAX_FIT
! ----------------------

    ENDIF  ! end of ERRFLAG = -1

! -------------------------

800   CONTINUE

! after 1st iteration, SKIP SN if photoz no longer respects z-range for each filter.
    IF ( ITER > 1 .OR. LREPEAT_ITER ) THEN
       LZTEST = LTEST_ZPHFILTER(ITER, PHOTOZ_VAL, PHOTOZ_ERR,  & 
                   IFILTDROP)
       IF ( .NOT. LZTEST ) ERRFLAG = ERRFLAG_ZFIT_RANGE
    ENDIF

    RETURN
  END SUBROUTINE PHOTOZ_ANA 



! =================
    LOGICAL FUNCTION LTEST_ZPHFILTER(ITER,ZPH,ZPH_ERR,IFILTBAD)
! 
! Created Aug 25, 2011 by R.Kessler
! Returns TRUE if all filters respect their photoz range
! defined by PHOTOZ_DROPFILTER_MIN/MAX(ifilt_obs).
! This function is used to weed out fits in which the
! photoz changes dramatically between iterations,
! causing one or more filters to be undefined.
! 
! --------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER ITER            ! (I) fit-iter
    REAL*8  ZPH, ZPH_ERR    ! (I) ZPHOT and its error
    INTEGER IFILTBAD        ! (O) absolute filter index for bad filter

! local var

    REAL*8  ZMIN, ZMAX
    INTEGER IFILT, IFILT_OBS
    LOGICAL LZTEST
    CHARACTER CFILT1*1

! ------------- BEGIN -------------

    IFILTBAD        = -9
    LTEST_ZPHFILTER = .TRUE.

    DO 300 ifilt     = 1, NFILTDEF_SURVEY
        ifilt_obs  = IFILTDEF_MAP_SURVEY(ifilt)
        if ( .NOT. USE_FILT(ifilt_obs) ) goto 300

        cfilt1  = filtdef_string(ifilt_obs:ifilt_obs)

        ZMIN = PHOTOZ_DROPFILTER_MIN(ifilt_obs)
        ZMAX = PHOTOZ_DROPFILTER_MAX(ifilt_obs)
        LZTEST = ( ZPH - ZPH_ERR .GE. ZMIN ) .and.  ( ZPH + ZPH_ERR .LE. ZMAX )

        IF ( .NOT. LZTEST ) THEN
          LTEST_ZPHFILTER = .FALSE.

          if ( STDOUT_UPDATE ) then
             write(6,301) SNLC_CCID(1:ISNLC_LENCCID), ZPH, cfilt1, ITER
301          format(T2,'WARNING CID=',A,' : PHOTOZ=', F5.3,  ' is outside range for ',  & 
                        A,'-band (ITER=',I1, ') => SKIP ' )
          endif
          IFILTBAD = IFILT_OBS
          RETURN
        ENDIF

300   CONTINUE

    RETURN
  END FUNCTION LTEST_ZPHFILTER

! ============
    REAL FUNCTION TRESTzCUT(OPT, z, Trest)

! Created Aug 19, 2009
! Returns either (1+z)*Trest or  1/(1+z) times Trest
! 
! OPT = 1 : return TRESTzCUT that is smaller than Trest
! OPT = 2 : return TRESTzCUT that is larger than Trest
! 
    INTEGER OPT    ! (I) option
    REAL Z, TREST  ! (I) redshift, Trest

! local

    REAL Z1, Z1FAC

! ----------- BEGIN ----------

    TRESTzCUT = -999.
    Z1 = 1. + z

    IF ( OPT .EQ. 1 ) THEN
      if ( Trest .GE. 0.0 ) then
          Z1FAC = 1./Z1
      else
          Z1FAC = Z1
      endif

    ELSE IF ( OPT .EQ. 2 ) THEN

      if ( Trest .GE. 0.0 ) then
          Z1FAC = Z1
      else
          Z1FAC = 1./Z1
      endif
    ENDIF

    TRESTzCUT = Trest * Z1FAC

    RETURN
  END FUNCTION TRESTzCUT

! ============================================================
    SUBROUTINE PHOTOZ_SAVECUT(name,  & 
              cutwin_orig, cutwin_snana, cutwin_save )

! Created Aug 15, 2009 by R.Kessler
! 
! Save SNANA cut-window in CUTWIN_SAVE; then open
! cutwin_orig to be wide open so that cut is not
! applied in snana.

    CHARACTER NAME*(*)   ! (I) name of cut
    REAL  & 
         CUTWIN_ORIG(2)     &  ! (I) original SNANA cut
        ,CUTWIN_SNANA(2)    &  ! (I) loosened SNANA cut
        ,CUTWIN_SAVE(2)    ! (O) address to save orig-snana cut for later

! ------------ BEGIN ---------

    CUTWIN_SAVE(1) = CUTWIN_ORIG(1)
    CUTWIN_SAVE(2) = CUTWIN_ORIG(2)

    CUTWIN_ORIG(1) = CUTWIN_SNANA(1)
    CUTWIN_ORIG(2) = CUTWIN_SNANA(2)

    write(6,20) name, CUTWIN_SNANA
20    format(T8,'Relaxed ',A10,' cut before photoZ fit: ',  & 
          F8.3,' to ', F8.3 )

    write(6,30) name, CUTWIN_SAVE
30    format(T8,'Nominal ',A10,' cut after  photoZ fit: ',  & 
          F8.3,' to ', F8.3 )

    RETURN
  END SUBROUTINE PHOTOZ_SAVECUT

! ====================================================
    SUBROUTINE SET_ZHD_PHOTOZ()

! Created Jan 26 2018
! Set redshift globals for output tables:
!    SNLC_zHELIO[_ERR]
!    SNLC_zCMB[_ERR]
!    SNLC_zHD[_ERR]
! 
! For zHD, translate heliocentric fitted photo into cmb frame,
! and include ZPECERR in zHDERR
! 
! ASSUMPTION: HOSTGAL_ZPHOT is in heliocentric frame.
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER OPT
    CHARACTER EQ*4
    REAL*8  ZHEL, ZCMB, ZERR, ZERR1, ZERR2

! function
    REAL*8 zhelio_zcmb_translator

! -------------- BEGIN -------------
    OPT   = 1 ! --> convert ZHEL to ZCMB
    EQ    = 'eq' // char(0)
    ZHEL  = DBLE(LCVAL_STORE(IPAR_ZPHOT))
    ZCMB  =  & 
         zhelio_zcmb_translator(ZHEL,SNLC8_RA,SNLC8_DEC,EQ,OPT,4)

    ZERR1 = DBLE( LCERR_STORE(IPAR_ZPHOT) )
    ZERR2 = DBLE( SNLC_ZPEC_ERR * ( 1.0 + zCMB ) )
    ZERR  = sqrt(ZERR1*ZERR1 + ZERR2*ZERR2)

    SNLC_ZHELIO     = SNGL(ZHEL)
    SNLC_ZHELIO_ERR = SNGL(ZERR1)

    SNLC_zCMB       = SNGL(ZCMB)
    SNLC_zCMB_ERR   = SNGL(ZERR1) ! do not include vpec error here

    SNLC_zHD        = SNGL(ZCMB)
    SNLC_zHD_ERR    = SNGL(ZERR)  ! include vpec error

    RETURN
  END SUBROUTINE SET_ZHD_PHOTOZ

! ====================================================
    SUBROUTINE FITANA_MARG(isn,DOPDFPLOT,ERRFLAG)
! 
! Shell to call MARG_DRIVER
! Returns ERRFLAG=0 (OK) or ERRFLAG > 0 (discard fit)
! 
! 
! -----------


    USE SNDATCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER ISN       ! (I) SN sparse index
    LOGICAL DOPDFPLOT ! (I) T => make PDF monitor plots
    INTEGER ERRFLAG   ! (O) returns 0=> OK, >0 => discard

! local var

    INTEGER  OPT, ifilt, ifilt_obs, NDOF, LL, ITER, IFILTBAD
    REAL FITPROB, CHI2, NSIGMA
    REAL*8  CHI8, ZPH8, ZPHERR8
    LOGICAL  LFITPROB, LMARG, LZPHOT, LTMP

! functions
    REAL*8  PROB_CHI2NDOF
    LOGICAL LTEST_ZPHFILTER

! --------------- BEGIN ---------------

    MARK_USED(isn)
    MARK_USED(DOPDFPLOT)

    ERRFLAG = 0  ! init to OK

! store filter-dependent chi2 before continuing
! These are just the fit chi2 from minimization.

    DO ifilt = 0, NFILTDEF_SURVEY

       if ( ifilt .GT. 0 ) then
          ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
          LTMP      = USE_FILT(ifilt_obs)
       else
          LTMP = .FALSE.
       endif

       if ( ifilt .EQ. 0 .or. LTMP ) then
         NDOF = NEPOCH_FIT(ifilt) - NFITPAR(ifilt)
         LC_FITCHI2(ifilt)  = FCN_FITCHI2(ifilt)
         LC_MARGCHI2(ifilt) = FCN_FITCHI2(ifilt)

         CHI8 = DBLE(LC_FITCHI2(ifilt))
         LC_FITPROB(ifilt)  = SNGL( PROB_CHI2NDOF(CHI8, NDOF) )
         LC_MARGPROB(ifilt) = LC_FITPROB(ifilt)
       endif

    ENDDO  ! ifilt

    LMARG = NGRID_PDF .GT. 0

! make sure that either MARGINALIZATION or MCMC is specified.

    IF ( .not. LMARG ) RETURN

! ---------------------------------------------------------
! skip marginalization if fitted chi2-prob fails cut

    LL = ISNLC_LENCCID

    FITPROB  = LCPROBCHI2_STORE(1)  ! fitprob before marginalization
    LFITPROB = ( FITPROB .GT. FITWIN_NOMARG_PROB(1) )
    IF ( .NOT. LFITPROB ) THEN
      write(6,600) 'FITPROB', SNLC_CCID(1:LL), FITPROB
      RETURN
    ENDIF

600     format(t5,A,'(CID ',A,') = ',G12.4,  & 
             ' FAILS CUT => SKIP MARGINALIZATION' )

! skip marg if chi2(sigma) fails cut since it won't change after marg.
    CHI2 = FITCHI2_STORE(4)
    LTMP = (CHI2 .GE. FITWIN_CHI2SIGMA(1) ) .and.  & 
             (CHI2 .LE. FITWIN_CHI2SIGMA(2) )

    IF ( (OPT_CHI2_SIGMA > 0) .and. .not. LTMP ) THEN
      write(6,600) 'CHI2SIGMA', SNLC_CCID(1:LL), CHI2
      RETURN
    ENDIF

! ---------------------------------------------------------
! Check for too-tiny errors.
    CALL FITERR_ADJUST()

! marginalize !

    IF ( LMARG ) THEN

      NSIGMA = float(NSIGMA_PDF)
      OPT    = OPT_INTEGPDF_FULL  ! default is full chi2 evaluation

! now check for reasons to quit FCNSNLC early (to save CPU time)
      IF ( OPT_COVAR_FLUX .LE. 0 .or. COVMAT_MIN .GE. 0.0 ) then
        OPT = OPT_INTEGPDF_QUITCHI2
      ENDIF

      CALL MARG_DRIVER(OPT,  MAX_INTEGPDF, NGRID_PDF, NSIGMA, VARLIST_PDF)

!   for PHOTOZ fit, check if filters were added/dropped which
!   can happen if photoZ_marg - photoZ_fit is  large enough.

      IF ( DOFIT_PHOTOZ ) THEN
        ZPH8    = LCVAL_STORE(IPAR_zPHOT)
        ZPHERR8 = 0.0
        ITER    = NFIT_ITERATION+1
        LZPHOT  = LTEST_ZPHFILTER(ITER, ZPH8, ZPHERR8, IFILTBAD)
        if ( .NOT. LZPHOT ) then
           ERRFLAG = ERRFLAG_ZFIT_RANGE
           return
        endif

      ENDIF

    ENDIF

! store marginalized chi2 per filter

    DO ifilt = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)

       if ( ifilt_obs.GT.0 .and. USE_FILT(ifilt_obs) ) then

         NDOF = NEPOCH_FIT(ifilt) - NFITPAR(ifilt)
         LC_MARGCHI2(ifilt) = FCN_FITCHI2(ifilt)

         LTMP = NDOF .GT. 0 .and. LC_MARGCHI2(ifilt) .GE. 0.0
         if ( LTMP ) then
            CHI8 = DBLE( LC_MARGCHI2(ifilt) )
            LC_MARGPROB(ifilt) = SNGL( PROB_CHI2NDOF(CHI8, NDOF) )
         else
            LC_MARGPROB(ifilt) = 1.0
         endif
       endif
    ENDDO

    RETURN
  END SUBROUTINE FITANA_MARG


! ============================================
    SUBROUTINE FCNSNLC(NVAR,GRAD, CHI2TOT, XVAL,IFLAG, USRFUN )
! 
! User function to be minimized (chi2, log-likelihood, etc ...).
! "USRFUN" is an optional function, for example from MC.
! YOU are responsible to sync XVAL(1:NFITPAR) in this function with
! INIVAL(1:NFITPAR) in FITPAR_PREP and with FITPAR(1_NFITPAR)
! in FITPAR_ANA.
! 
! The prior-chi2 "CHI2INI" is used for minimization.
! However, the stored chi2 "FCN_FITCHI2(0)" does NOT include
! CHI2INI so that the probability is based on the data and
! model, and not on the prior.
! 
! 
! 
! The data to compare the function to are in KEEP,SNCUTS
! in snana.car. A few useful variables are
! 
!   SNLC_CID         ! CID vs. sparse SN index
!   SNLC_NEPOCH_STORE      ! Number of Epochs
! 
!   SNLC_RA          ! RA   vs. SN
!   SNLC_DECL        ! OBDECL vs. SN
!   SNLC_REDSHIFT    ! redshift used for analysis
! 
!   SNLC_XTINC_MW(MXFILT_ALL)  ! interstellar extinction
! 
!   SNLC_FLUXCAL(MXFILT_OBS,MXEPOCH)
!   SNLC_FLUXCAL_ERRSTAT(MXFILT_OBS,MXEPOCH)
!   SNLC_FLUXCAL_ERRSYST(MXFILT_OBS,MXEPOCH)
!   SNLC_FLUXCAL_ERRTOT(MXFILT_OBS,MXEPOCH)
! 
!   chi2 = D_i  COV_ij D_j
! 
! 
! 
!  HISTORY
! ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
! 
! Mar 1 2017: load R4EP(iep,JEP_MAGDIF)
! 
! Jun 23 2019: protect I4EP_ALL array bound
! Jul 13 2019:
!   + compute RATIO_ERR only if LFLAG_USER=T (to reduce compute time)
!   + apply SNR_RAW cut to compute R4SN_FFSUM_XXX
! 
! Feb 28 2020:
!   define DELCHI2_NOFUDGE to make test with DELCHI2_REJECT;
!   fixes long-standing bug when FUDGEALL_ITER1_MAXFRAC is set.
! 
! May 12 2026: use LFITDATA logical to protect divide-by-zero in 
!                sqsig = 1.0 / covmat2(ifitdata,ifitdata)
!               [Finally caught by debug flag]
! ---------------------------------------------------
    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE FILTCOM
    USE FITIDEALCOM
    USE TABLEVARCOM
! subroutine ars

    INTEGER  & 
          NVAR     &  ! numnber of VARIABLE params only
         ,IFLAG

    DOUBLE PRECISION  GRAD(*), XVAL(*), chi2tot, USRFUN

    EXTERNAL USRFUN

! local arguments

    INTEGER  & 
         ISN, ITER, ifilt, ipar, IFILT_obs, epoch, ifitdata  & 
        ,NFITDATA_LOC, NFITDATA_LAM_REJECT, irow, icol, IERR, ep  & 
        ,NFITDATA_FILT(0:MXFILT_OBS), NDMPFCN(0:MXFILT_OBS)

    character cfilt*1

    DOUBLE PRECISION  & 
         ZSN, ZZ, CHI2INI, SHAPEPAR(2), DISTPAR, COLORPAR  & 
        ,RVHOST, PEAKMJD, Trest, Tobs, wavecor  & 
        ,AVRV, MWAV, MWEBV, XTAV, XTMW, MJD, MJDFIT  & 
        ,flux_data, flux_data_errtot, flux_data_sqerrtot  & 
        ,signoise_data, signoise_model  & 
        ,flux_model, flux_model_err ,flux_model_sqerr  & 
        ,flux_fudge_sqerr, flux_fudge_err, flux_errtot  & 
        ,errtmp, arg, RATIO, RATIO_ERR, MAGDIF, SNR_FIT, SNR_RAW  & 
        ,AVwarp, mag_kcor(2), mag_tmp, mag_err  & 
        ,dif, sqdif, sqsig, inv_sqsig, sqsig_nofudge  & 
        ,delchi2, delchi2_diag, delchi2_sigma, delchi2_nofudge  & 
        ,chi2_offdiag  & 
        ,chi2filt_sigma(MXFILT_OBS),chi2sum_sigma,chi2filt(MXFILT_OBS)  & 
        ,errfrac, DEL_FLUX(MXFIT_DATA)  & 
        ,FF, COV_INV, x1, DT1, DT2, CHI2PRIOR(0:MXFITPAR)  & 
        ,LAMAVG, LAMREST, XVAL4COV(MXFITPAR), scale_chi2, chi2save

    LOGICAL  & 
         LFLAG_FIRST_MN   &  ! first call from MINUIT (IFLAG=2)
        ,LFLAG_LAST_MN    &  ! last call from MINUIT  (IFLAG=3)
        ,LFLAG_USER       &  ! called from user (IFLAG=30)
        ,LFLAG_USESIM     &  ! use SIM params instead of XVAL (IFLAG=99)
        ,LFLAG_FAST       &  ! speed up if possible (for pdf integration)
        ,LFLAG_FIT, LFLAG_PRIOR_ONLY, LFLAG_SIGMA_ONLY  & 
        ,LAST, LDMPFCN_LOC, LDMPFUN_LOC, LREJECT, LREJECT2, LFITDATA  & 
        ,FIRSTFILT, LASTFILT, LTMP, LMUFIX, LPOSFLUX  & 
        ,FIRST_ITER  & 
        ,REJECT_TREST, REJECT_MJD, REJECT_SIGNOISE, REJECT_DELCHI2  & 
        ,DO_LOGDET, DUMP_FCNCHI2

    CHARACTER CVAR*20, star*1
    REAL*8 logdet, LAST_FLUXERR, logdet_offset


! functions
    REAL*8  & 
         FCNCHI2_PRIOR, FCNCHI2_SIGMA & 
        ,GET_RV8, GET_DIST8, SALT2xx1, getlogdeterminant
    LOGICAL FIRST_ITERATION

! ----------- BEGIN FCNSNLC ------------

    MARK_USED(NVAR)
    MARK_USED(GRAD(1))

    CHI2TOT = 1.0E7

    LFLAG_FIRST_MN   = IFLAG .EQ.  2   ! first MINUIT call
    LFLAG_LAST_MN    = IFLAG .EQ.  3   ! last MINUIT call here => store info
    LFLAG_FIT        = IFLAG .EQ.  4   !
    LFLAG_USER       = IFLAG .EQ. FCNFLAG_USER ! user-call (NOT from MINUIT)
    LFLAG_USESIM     = IFLAG .EQ. FCNFLAG_USESIM ! use sim params
    LFLAG_FAST       = IFLAG .EQ. FCNFLAG_FAST
    LFLAG_PRIOR_ONLY = IFLAG .EQ. FCNFLAG_PRIOR_ONLY
    LFLAG_SIGMA_ONLY = IFLAG .EQ. FCNFLAG_SIGMA_ONLY
    LAST = LFLAG_LAST_MN .or. LFLAG_USER .or. LFLAG_USESIM

    NCALL_FCNFLAG(IFLAG) = NCALL_FCNFLAG(IFLAG) + 1

    R4SN_FFSUM_DATA  = 0.0
    R4SN_FFSUM_MODEL = 0.0
    R4SN_FFSUM_CROSS = 0.0
    R4SN_FFSUM_WGT   = 0.0
    R4SN_FFSUM_RATIO = 0.0

    IF ( LAST ) THEN
! include rejects on last iter
       NFITDATA_LOC = NFITDATA + NFITDATA_REJECT
    ELSE
       NFITDATA_LOC = NFITDATA
    ENDIF
    NFITDATA_LAM_REJECT = 0

! extract parameters into local variables

    ITER       = int ( XVAL(IPAR_ITER) )
    ISN        = int ( XVAL(IPAR_ISN)  )

    if ( ITER .EQ. 0 .OR. ISN .EQ. 0 ) RETURN

    FIRST_ITER = FIRST_ITERATION(ITER)

    COLORPAR    = XVAL(IPAR_AV)       !  AV or c
    AVRV        = XVAL(IPAR_AVRV)
    SHAPEPAR(1) = XVAL(IPAR_SHAPE)
    SHAPEPAR(2) = XVAL(IPAR_SHAPE2)
    PEAKMJD     = XVAL(IPAR_PEAKMJD)
    DISTPAR     = XVAL(IPAR_DLMAG)    ! MU or x0
    ZSN         = XVAL(IPAR_zPHOT)
    RVHOST      = GET_RV8(XVAL)
    MWEBV       = DBLE( SNLC_MWEBV )
    MWAV        = MWEBV/RV_MWCOLORLAW

! check for photoZ fit that constrains DLMAG to input cosmology.

    LMUFIX = (DOFIT_PHOTOZ .and. (INISTP_DLMAG .EQ. 0.0) )
    IF ( LMUFIX ) THEN
       DISTPAR = GET_DIST8(ZSN,SHAPEPAR(1),COLORPAR,ONE8)
    ENDIF

    ZZ  = 1.0 + ZSN

    IF ( LFLAG_USESIM .and. LSIM_SNANA ) THEN
       COLORPAR     = SIMVAL_STORE(IPAR_AV)
       RVHOST       = SIMVAL_STORE(IPAR_RV)
       DISTPAR      = SIMVAL_STORE(IPAR_DLMAG)
       SHAPEPAR(1)  = SIMVAL_STORE(IPAR_SHAPE)
       SHAPEPAR(2)  = SIMVAL_STORE(IPAR_SHAPE2)
       PEAKMJD      = SIMVAL_STORE(IPAR_PEAKMJD) - MJDOFF
       ZSN          = SIMVAL_STORE(IPAR_zPHOT)
    ENDIF

! ------------------------------------
! Get initial CHI2 from priors.

    IF ( LFLAG_SIGMA_ONLY ) THEN
      CHI2INI = 0.0
    ELSE
      CHI2INI = FCNCHI2_PRIOR(XVAL,CHI2PRIOR)
    ENDIF

    CHI2TOT    = CHI2INI
    chi2sum_sigma = 0.0

! bail on large CHI2INI unless we are dumping.
    if ( CHI2TOT .GT. 1.0E7  .and. .not. LDMPFCN(0) ) RETURN
    if ( LFLAG_PRIOR_ONLY ) RETURN

! -------------------------------------------

    DO ifilt = 1, MXFILT_OBS
       CHI2FILT(ifilt)       = 0.0
       CHI2FILT_SIGMA(ifilt) = 0.0
       NFITDATA_FILT(ifilt)  = 0
       NDMPFCN(ifilt)        = 0
    ENDDO
       NFITDATA_FILT(0)  = 0
       NDMPFCN(0)        = 0

    FIRSTFILT = .TRUE.

    IF ( LDMPFCN(0) ) THEN
       print*,' '
       print*,' -------------------------------------- '
       write(6,602) SNLC_CCID,  ITER, IFLAG
602      format(T5,'PREPARE FCNSNLC DUMP for CID= ', A16,  & 
                 3x,'   (ITER=',I2, 2x, 'IFLAG=',I2, ')' )

       call flush(6)
    ENDIF

! ------------------------------------

    DO 102 ifitdata   = 1, NFITDATA_LOC

      epoch           = EPLIST_FIT(ifitdata)
      ifitdata_usrfun = ifitdata  ! load common block for USRFUN

      LFITDATA = ifitdata .LE. NFITDATA

      ifilt     = I4EP_ALL(epoch,IEP_IFILT)
      ifilt_obs = I4EP_ALL(epoch,IEP_IFILT_OBS)
      cfilt     = filtdef_string(ifilt_obs:ifilt_obs) ! for debug only

!    protect model against invalid rest-frame lambda values
      LAMAVG    = DBLE( FILTOBS_LAMAVG(ifilt_obs) )
      LAMREST   = LAMAVG /ZZ

      if ( LAMREST < RESTLAMBDA_USEFIT(1) .or. LAMREST > RESTLAMBDA_USEFIT(2) ) then
         if ( LFITDATA ) NFITDATA_LAM_REJECT = NFITDATA_LAM_REJECT + 1
         goto 102
      endif

      MJD                = R8EP_MJD(ifitdata)
      MJDFIT             = MJD - MJDOFF

      flux_data        = dble ( R4EP_ALL(epoch,JEP_DATAFLUX) )
      flux_data_errtot = dble ( R4EP_ALL(epoch,JEP_DATAFLUX_ERR) )
      flux_fudge_err   = dble ( R4EP_ALL(epoch,JEP_FUDGEFLUX_ERR) )
      wavecor          = dble ( R4EP_ALL(epoch,JEP_WAVECOR) )

      flux_fudge_sqerr   = flux_fudge_err   * flux_fudge_err
      flux_data_sqerrtot = flux_data_errtot * flux_data_errtot

! compute data SNR with/without fudged error
      errtmp = dsqrt(flux_data_sqerrtot + flux_fudge_sqerr)
      SNR_FIT   = flux_data / errtmp
      SNR_RAW   = flux_data / flux_data_errtot

      Tobs      = MJDFIT - PEAKMJD    ! observation time, days
      Trest     = Tobs / ZZ

      Nfitdata_filt(ifilt) = Nfitdata_filt(ifilt) + 1
      Nfitdata_filt(0)     = Nfitdata_filt(0) + 1
      LASTFILT  = Nfitdata_filt(ifilt) .EQ. NEPOCH_FIT(ifilt)

! set local dump logicals = namelist flag .and. (debug option)

       LDMPFCN_LOC = LDMPFCN(ifilt_obs)  & 
              .and. LFITDATA  ! .and. FIRST_ITERATION(ITER)

       if(DOFIT_IDEAL_EVENT .and. DOFIT_IDEAL ) LDMPFCN_LOC = .FALSE. ! xxx DEBUG ONLY

       LDMPFUN_LOC = LDMPFUN(ifilt_obs)  & 
                 .and. Trest .GE. TREST_DMPFUN(1)  & 
                 .and. Trest .LE. TREST_DMPFUN(2)  & 
                 .and. LFITDATA

! dumpe header just once per filter.
       if(LDMPFCN_LOC .and. FIRSTFILT ) then

! print  fit-pars to see crazy values.

            write(6,603) 'ZSN', ZSN
            write(6,604) 'PEAKMJD', PEAKMJD
            write(6,603)  PARNAME_STORE(IPAR_AV)(1:6), COLORPAR
            if ( INISTP_AVRV .GT. 0.0 ) then
              write(6,603)  PARNAME_STORE(IPAR_AVRV)(1:6), AVRV
              write(6,603)  'RVHOST', RVHOST
            endif

            write(6,603) 'MWAV', MWAV
            write(6,603) 'SHAPE', SHAPEPAR(1)
            write(6,603)  PARNAME_STORE(IPAR_DLMAG)(1:6), DISTPAR

603           format(T7, A, T17,'= ', G14.6 )
604           format(T7, A, T17,'= ', F12.4 )

! print non-zero chi2prior contributions

            print*,' '
            DO ipar = 0, IPAR_MAX
              CVAR = PARNAME_STORE(ipar)
              if ( CHI2PRIOR(ipar) .GT. 0.0 ) then
                write(6,690) CVAR, CHI2PRIOR(ipar)
690               format(T8,'CHI2PRIOR(', A8, ') = ', G12.4 )
              endif
              CALL FLUSH(6)
              TBLDMPFCN_CHI2PRIOR(ipar) = sngl(CHI2PRIOR(ipar))
            ENDDO

! always print total prior-chi2
            print*,'      CHI2PRIOR(TOTAL) = ', SNGL(CHI2INI)

            CALL FLUSH(6)

           ! Jan 2025  store Table variables
            TBLDMPFCN_ISN       = ISN
            TBLDMPFCN_NCALL     = NCALL_FCNFLAG(IFLAG)
            TBLDMPFCN_IFLAG     = IFLAG
            TBLDMPFCN_ITER      = ITER
            TBLDMPFCN_ZSN       = SNGL(ZSN)
            TBLDMPFCN_PEAKMJD   = SNGL(PEAKMJD)
            TBLDMPFCN_DISTANCE  = SNGL(DISTPAR)
            TBLDMPFCN_SHAPEPAR  = SNGL(SHAPEPAR(1))
            TBLDMPFCN_COLORPAR  = SNGL(COLORPAR)
            TBLDMPFCN_CHI2PRIOR(0) = SNGL(CHI2INI)
       endif  ! end of DUMP

       IF ( FIRSTFILT ) FIRSTFILT = .FALSE.

! =====================
! get flux (observer frame) from model
! Note that info on all five filters is passed.

      flux_model =  & 
           USRFUN ( ITER, IFILT_OBS  &  ! (I) iteration and absolute filter index
           ,ZSN, Tobs                &  ! (I) redshift and MJD-PEAKMJD
           ,WAVECOR                  &  ! (I) filter wavecor (Aug 30 2026)
           ,SHAPEPAR                 &  ! (I) delta, stretch, x1 ...
           ,DISTPAR                  &  ! (I) MU or x0
           ,COLORPAR                 &  ! (I) AV or c
           ,RVHOST                   &  ! (I) color law
           ,MWEBV                    &  ! (I) MW extinct
           ,LDMPFUN_LOC              &  ! (I)
           ,AVwarp                   &  ! (O) AV warp for SEC
           ,MAG_KCOR                 &  ! (O) K-correction   error
           ,XTAV                     &  ! (O) host-gal extinct in rest-filter
           ,XTMW                     &  ! (O) MW extinct in obs-filter (mag)
           ,MAG_ERR                  &  ! (O) mag error from model
           )

! convert MAG_ERR into flux-error

      errfrac          = 1.0 - TEN8**(-0.4*MAG_ERR)
      flux_model_err   = flux_model * errfrac
      flux_model_sqerr = flux_model_err * flux_model_err

! ---------------------------------------------
! get data-model chi2 ;
! if USE_FITCOV=T, then sum diagonal elements of cov matrix.

      dif      = flux_data - flux_model
      sqdif    = dif * dif

      IF ( USE_FITCOV .and. LFITDATA ) THEN
         sqsig         = 1.0 / covmat2(ifitdata,ifitdata)
         delchi2_diag  = sqdif / sqsig
      ENDIF

! always evaluate simple chi2 ignoring covariance
      sqsig         = flux_data_sqerrtot + flux_model_sqerr  + flux_fudge_sqerr
      sqsig_nofudge = flux_data_sqerrtot + flux_model_sqerr
      inv_sqsig     = 1.0/sqsig

      flux_errtot = dsqrt(sqsig)

      delchi2         = sqdif * inv_sqsig
      delchi2_nofudge = sqdif/sqsig_nofudge

      IF ( LFLAG_SIGMA_ONLY ) THEN
        delchi2         = 0.0
        delchi2_diag    = 0.0
        delchi2_nofudge = 0.0
      ENDIF


! check for 2log(sigma) in chi2
      delchi2_sigma=0.0
      IF (IAND(OPT_CHI2_SIGMA, MASK_CHI2_SIGMA_ERRTOT) >0 ) THEN
         delchi2_sigma = FCNCHI2_SIGMA(iter,epoch,flux_errtot)

      ELSE IF (IAND(OPT_CHI2_SIGMA,MASK_CHI2_SIGMA_ERRDATA) >0 ) THEN
         delchi2_sigma = FCNCHI2_SIGMA(iter,epoch,flux_data_errtot)
      ENDIF

      IF (IAND(OPT_CHI2_SIGMA,MASK_CHI2_SIGMA_IGNORE) > 0 ) THEN
          delchi2_sigma = 0.0 ! D.Kenworthy April 26 2024
      ENDIF

      IF ( LFITDATA ) then
        DEL_FLUX(ifitdata)  = dif
        chi2filt(ifilt) = chi2filt(ifilt) + delchi2

        chi2filt_sigma(ifilt) = chi2filt_sigma(ifilt) + delchi2_sigma

! sum chi2_sigma over all epochs ... sum used only for OPT_COVAR_FLUX > 0
        chi2sum_sigma = chi2sum_sigma   + delchi2_sigma

        if ( USE_FITCOV ) then
           chi2tot  = chi2tot  + delchi2_diag   ! diag part of chi2
        else
           chi2tot  = chi2tot  + delchi2        ! add conventional chi2
        endif

! always tack on chi2 from log(sigma) term
        chi2tot  = chi2tot + delchi2_sigma

      ENDIF

! if fast-flag is set, quit when chi2 is too big;
! this corresponds to tiny pdf in integral.

      if ( LFLAG_FAST .and.  chi2tot .GT. FITCHI2_QUIT ) return

! check dump-flag again; print every epoch here

      if ( LDMPFCN_LOC ) then
          write(6,666) cfilt, Trest, delchi2  & 
                ,flux_model, flux_model_err  & 
                ,flux_data, flux_data_errtot

666         format(2x,A,  2x, 'Trest=',F6.2, 2x,'dchi2=',F9.5, 2x,  & 
              'Fmodel=',E10.4,'+-',E9.4, 2x,  & 
              'Fdata=', E10.4,'+-',E9.4  )

          NDMPFCN(0)     = NDMPFCN(0) + 1
          NDMPFCN(ifilt) = NDMPFCN(ifilt) + 1
          CALL FLUSH(6)
      endif

! always store flux for model in case we need to re-compute
! covariance matrix each time. The other EP_XXX arrays are
! computed inside LAST if-block.

      R4EP_ALL(epoch,JEP_MODELFLUX)     = SNGL(flux_model)
      R4EP_ALL(epoch,JEP_MODELFLUX_ERR) = SNGL(flux_model_err)
      R4EP_ALL(epoch,JEP_FLUX_ERRTOT)   = SNGL(flux_errtot)

      IF ( LAST ) THEN

! increment SNRMAX for fitted epochs only
         if ( LFITDATA ) then
           R4BAND_SNRMAX_FIT(ifilt) =  & 
                MAX ( R4BAND_SNRMAX_FIT(ifilt), SNGL(SNR_FIT) )
           R4BAND_SNRMAX_RAW(ifilt) =  & 
                MAX ( R4BAND_SNRMAX_RAW(ifilt), SNGL(SNR_RAW) )
         endif

         if ( flux_model .GT. 0.0 ) then
           mag_tmp = -2.5 * dlog10(flux_model) + ZP_FLUXCAL  ! model-mag_{obs}
           R4EP_ALL(epoch,JEP_MODELMAG)     = SNGL(mag_tmp)
           R4EP_ALL(epoch,JEP_MODELMAG_ERR) = SNGL(mag_err)
         endif

         mag_tmp = SNLC_MAG(epoch)
         IF( USE_MWCOR) mag_tmp = mag_tmp - SNLC_MWXT_MAG(ifilt)
         R4EP_ALL(epoch,JEP_DATAMAG)     = SNGL(mag_tmp)
         R4EP_ALL(epoch,JEP_DATAMAG_ERR) = SNLC_MAG_ERRPLUS(epoch)

         R4EP_ALL(epoch,JEP_XTHOST)   = SNGL(XTAV)
         R4EP_ALL(epoch,JEP_MWXT)     = SNGL(XTMW)

         IF ( LREST_FITMODEL ) THEN
           R4EP_ALL(epoch,JEP_KCOR)       = SNGL(MAG_KCOR(1))
           R4EP_ALL(epoch,JEP_KCOR_ERR)   = SNGL(MAG_KCOR(2))
           R4EP_ALL(epoch,JEP_AVWARP)     = SNGL(AVWARP)

           arg = 0.4*(MAG_KCOR(1) + DISTPAR)
           R4EP_ALL(epoch,JEP_DATAFLUX_REST) = SNGL(flux_data * 10.0**(arg))
         ENDIF


! data/Model ratio
         RATIO=0.0; RATIO_ERR=0.0; MAGDIF=-9.0
         LPOSFLUX = ( abs(flux_model) .GT. 1.0E-21 )
         if ( LPOSFLUX )      RATIO  = flux_data / flux_model
         if ( RATIO > .001 )  MAGDIF = -2.5*log10(RATIO)

         if ( LPOSFLUX .and. LFLAG_USER ) then ! limit calc to USER only
            sqsig = ( flux_data_errtot  / flux_data  )**2  & 
                    + ( flux_model_err    / flux_model )**2
            errfrac    = dsqrt(sqsig)
            RATIO_ERR  = abs(RATIO) * errfrac
         endif

         sqsig = flux_data_errtot**2 + flux_model_err**2

         R4EP_ALL(epoch,JEP_RATIO)       = SNGL(RATIO)
         R4EP_ALL(epoch,JEP_RATIO_ERR)   = SNGL(RATIO_ERR)
         R4EP_ALL(epoch,JEP_RESID)       = SNGL(dif)
         R4EP_ALL(epoch,JEP_RESID_ERR)   = SNGL( dsqrt(sqsig) )
         R4EP_ALL(epoch,JEP_MAGDIF)      = SNGL(magdif)
         R4EP_ALL(epoch,JEP_TREST)       = SNGL(Trest)
         R4EP_ALL(epoch,JEP_TOBS)        = SNGL(Tobs)
         R4EP_ALL(epoch,JEP_WAVECOR)     = SNGL(wavecor)
         R4EP_ALL(epoch,JEP_MJD)         = SNGL(MJDFIT)
         R4EP_ALL(epoch,JEP_DELCHI2)     = SNGL(DELCHI2)
         FCN_FITCHI2(0)          = SNGL(chi2tot - CHI2INI)

         DT1 = abs(Trest)
         DT2 = abs( R4BAND_TREST_NEARPEAK(ifilt_obs) )
         if ( DT1 < DT2 ) then
           R4BAND_XTMW_NEARPEAK(ifilt_obs)  = SNGL(XTMW)
           R4BAND_TREST_NEARPEAK(ifilt_obs) = SNGL(Trest)
           I4BAND_EP_NEARPEAK(ifilt_obs)    = epoch
         endif

! check for epochs to reject at end of 1st iteration only (note LAST=T here)

         if ( FIRST_ITER .and. IFLAG <= 4 ) then  ! includes iter=1 repeat

            signoise_data  = flux_data  / flux_data_errtot
            signoise_model = flux_model / flux_data_errtot

            REJECT_TREST   =  & 
                 (Trest < FITWIN_TREST_FILT(1,ifilt_obs) ) .or.  & 
                 (Trest > FITWIN_TREST_FILT(2,ifilt_obs) )
            REJECT_MJD =  & 
                (MJD < FITWIN_MJD(1)) .or. (MJD > FITWIN_MJD(2))

            REJECT_DELCHI2  = (delchi2_nofudge  > DELCHI2_REJECT  )
            REJECT_SIGNOISE = (signoise_data < SIGNOISE_REJECT)

            LREJECT  =  & 
                    REJECT_DELCHI2 .or. REJECT_SIGNOISE .or.  &   
                    REJECT_TREST   .or. REJECT_MJD

            LREJECT2  =  & 
                  (REJECT_DELCHI2 .or. REJECT_SIGNOISE) .and.  & 
                  (.not. REJECT_TREST )

            if ( epoch <= MXFIT_DATA ) then
              I4EP_ALL(epoch,IEP_REJECT)  = 0
              I4EP_ALL(epoch,IEP_REJECT2) = 0
              if ( LREJECT  ) I4EP_ALL(epoch,IEP_REJECT)  = 1
              if ( LREJECT2 ) I4EP_ALL(epoch,IEP_REJECT2) = 1  ! Mar 2020
            endif

         endif  ! end FIRST_ITERATION

         if ( LFITDATA .and. (.NOT.LFLAG_USESIM) ) then

           FCN_FITCHI2(ifilt)  =  & 
             FCN_FITCHI2(ifilt)  + SNGL(sqdif / sqsig_nofudge)  ! DELCHI2

           if ( Trest .LT. R4SN_Tearly ) R4SN_Tearly = SNGL(Trest)
           if ( Trest .GT. R4SN_Tlate  ) R4SN_Tlate  = SNGL(Trest)

           if ( MJD .LT. R4SN_MJDmin ) R4SN_MJDmin = SNGL(MJD)
           if ( MJD .GT. R4SN_MJDmax ) R4SN_MJDmax = SNGL(MJD)

           ! sums used for initializing photoz x0/MU
           if ( LFLAG_USER .and. SNR_RAW > 3.0 .and. SCALE_NBIN_COURSE_PHOTOZ > 0 ) then
              R4SN_FFSUM_DATA   = SNGL(R4SN_FFSUM_DATA   + (flux_data**2 )*inv_sqsig )
              R4SN_FFSUM_MODEL  = SNGL(R4SN_FFSUM_MODEL  + (flux_model**2)*inv_sqsig )
              R4SN_FFSUM_CROSS  = SNGL(R4SN_FFSUM_CROSS  + (flux_data*flux_model)*inv_sqsig )
           endif

         endif

      ENDIF  ! end of LAST if-block

102   CONTINUE  ! end of IFITDATA loop

! -----------------------

! check DUMP flags.

    IF ( NDMPFCN(0) .GT. 0 ) THEN

      star = ' '
      if ( LREPEAT_ITER ) star = '*'

      DO ifilt = 1, MXFILT_OBS

        LTMP = NFITDATA_FILT(ifilt)>0 .and. NDMPFCN(ifilt).GT.0
        IF ( LTMP ) THEN
          ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
          cfilt     = filtdef_string(ifilt_obs:ifilt_obs)

         write(6,672) ITER, star  & 
                ,NEPOCH_ALL(ifilt)  & 
                ,NEPOCH_REJECT(ifilt)  & 
                ,cfilt, chi2filt(ifilt)  & 
                ,chi2filt_sigma(ifilt)

672        format(T3, 'ITER=',I1,A, '  NEPOCH=',I3,'-',I2,' : ',  & 
               'CHI2-TOT(',A1,')=', G10.5, 2x ,  & 
               'CHI2(SIGMA)=', G12.3 )

        ENDIF
      ENDDO
      print*,'   CHI2-DIAGONAL(all filters) = ', chi2tot
      CALL FLUSH(6)
    ENDIF

! ----------------------------------

    IF ( LFLAG_SIGMA_ONLY ) RETURN
    IF ( LFLAG_USESIM     ) RETURN

! ----------------------
! compute chi2tot from covariance matrix

    DUMP_FCNCHI2 =  CCID_DUMP_CHI2_MATRIX(1:ISNLC_LENCCID) .EQ.  & 
                      SNLC_CCID(1:ISNLC_LENCCID)

    IF ( USE_FITCOV ) THEN
      chi2tot    = CHI2INI + chi2sum_sigma

!  check option to re-compute covariance inside minuit function
      if ( OPT_COVAR_FLUX .EQ. 2 ) then
         DO ipar = 1, NFITPAR_MN
           XVAL4COV(ipar) = XVAL(ipar)  ! used for COV opt
         ENDDO

!    modify x1 for SALT2 model.
         if  ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
           x1 = XVAL4COV(IPAR_SHAPE)
           XVAL4COV(IPAR_SHAPE)  = SALT2xx1(ITER,x1)
         endif

!  re-compute COVARIANCE and its inverse => COVMAT2
!  1st arg OPT=0 suppresses printing.
         CALL FITINI_COV(0,iter,XVAL4COV,IERR)
      endif

! loop over COV_INV elements and compute chi2
      DO_LOGDET = (IAND(OPT_CHI2_SIGMA,MASK_CHI2_SIGMA_LOGDET)>0)
      chi2_offdiag = 0.0

      DO 801 irow = 1,    NFITDATA
      DO 802 icol = irow, NFITDATA
       COV_INV  = covmat2(irow,icol)
       if ( abs(COV_INV) < 1.0E-30 ) GOTO 802

       FF   = del_flux(irow) * del_flux(icol)
       if ( irow .EQ. icol ) then
         if (DO_LOGDET) THEN
          ep = EPLIST_FIT(irow)
          LAST_FLUXERR = DBLE(R4EP_LAST(ep,JEP_DATAFLUX_ERR) )
          logdet_offset = logdet_offset + 2.* log( LAST_FLUXERR )
         ENDIF
         delchi2   = (FF * COV_INV)
         chi2tot   = chi2tot + delchi2
       else
         delchi2         = (FF * COV_INV * 2.)   ! include ij + ji terms
         chi2_offdiag    = chi2_offdiag + delchi2
         chi2tot         = chi2tot      + delchi2
       endif

       if ( LFLAG_LAST_MN .and. ITER > 1 .and. DUMP_FCNCHI2 )  then
           CALL PRINT_FCNCHI2_MATRIX(iter, irow, icol, delchi2)
       endif

802     CONTINUE
801     CONTINUE

!   check option to include determinant term log[det(COV_INC)]
      IF (DO_LOGDET) THEN
       logdet= getlogdeterminant(NFITDATA, COVMAT1) - logdet_offset
       chi2tot = chi2tot + logdet
      ENDIF

      FCN_FITCHI2(0) = SNGL(chi2tot - chi2ini)

    ENDIF  ! end of USE_FITCOV if block

    if ( LFLAG_LAST_MN .and. ITER > 1 .and. DUMP_FCNCHI2 )  then
        write(6,6655) chi2tot, chi2tot-chi2_offdiag, chi2_offdiag
6655    format(' xxx FCN_CHI2(tot, diag, offdiag) = ', 3F12.1)
        print*,' '
        call flush(6)
    endif


! - - - - -
! 3/24/2026 playground test to account for tossed obs in photo-z fit due to rest-frame wave
    if ( DEBUG_FLAG == 325 .and. NFITDATA_LAM_REJECT > 0 ) then
       scale_chi2 = DBLE( NFITDATA_FILT(0)+NFITDATA_LAM_REJECT) / DBLE(NFITDATA_FILT(0))
       chi2save   = chi2tot
       chi2tot    = scale_chi2*(chi2tot-chi2ini) + chi2ini
!       write(6,6663) NFITDATA_FILT(0), NFITDATA_LAM_REJECT, scale_chi2, &
!            chi2ini, chi2save, chi2tot
!6663   format(T2,' xxx NDOF(tot,rej) = ', 2I4, '  scale_chi2=', F7.3, &
!            '  chi2tot(ini,orig,scaled) = ', 3F9.1 )
!       call flush(6)
    endif

! - - - - - - -

    IF ( LDMPFCN_LOC ) THEN
       write(6,6665) chi2tot,  NFITDATA_FILT(0)
6665   format(T5,'CHI2-FINAL(all filters)    = ', F10.2,3x,  'NFITDATA=', I5)
       print*,'      ********* END OF FCN DUMP ********** '
       print*,' '
       CALL FLUSH(6)

       TBLDMPFCN_CHI2TOT = sngl(chi2tot)
       CALL TABLE_DMPFCN(isn)
    ENDIF


    RETURN
  END SUBROUTINE FCNSNLC


! ===============================
    SUBROUTINE  PRINT_FCNCHI2_MATRIX(iter, irow, icol, delchi2)

! Created Jul 2024
! print chi2 matrix contribution for irow,icol

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FILTCOM
! +CDE,SNLCINP.

! input args
    INTEGER ITER, IROW, ICOL
    REAL*8  DELCHI2

! local args
    INTEGER ep0, ep1, IF0, IF1
    REAL    Trest0, Trest1, MJD0, MJD1
    REAL    FDATA, FDATA_ERR, FMODEL, FMODEL_ERR
    CHARACTER CFILT0*2, CFILT1*2

! ----------- BEGIN -----------

    if ( irow > icol ) return

    ep0 = EPLIST_FIT(irow)
    ep1 = EPLIST_FIT(icol)

    TREST0 = R4EP_ALL(ep0,JEP_TREST)
    TREST1 = R4EP_ALL(ep1,JEP_TREST)

    MJD0 = R4EP_ALL(ep0,JEP_MJD)
    MJD1 = R4EP_ALL(ep1,JEP_MJD)

    IF0 = I4EP_ALL(ep0,IEP_IFILT_OBS)
    IF1 = I4EP_ALL(ep1,IEP_IFILT_OBS)

    cfilt0  = filtdef_string(IF0:IF0)
    cfilt1  = filtdef_string(IF1:IF1)

    write(6,66) cfilt0(1:1), MJD0, Trest0,  & 
                  cfilt1(1:1), MJD1, Trest1,  & 
                  delchi2, iter
66    format(T2,' xxx FCN_CHI2(', A,':', F7.1, 1x, F6.2, ' / ',  & 
                                  A,':', F7.1, 1x, F6.2, ') = ',  & 
                     F10.2, 4x, '(ITER=',I2,')'   )

! print more info for large delchi2
    if ( abs(delchi2) > 60.0 ) then
        FDATA       = R4EP_ALL(ep0,JEP_DATAFLUX)
        FDATA_ERR   = R4EP_ALL(ep0,JEP_DATAFLUX_ERR)
        FMODEL      = R4EP_ALL(ep0,JEP_MODELFLUX)
        FMODEL_ERR  = R4EP_ALL(ep0,JEP_MODELFLUX_ERR)
        write(6,166) MJD0, FDATA, FDATA_ERR, FMODEL, FMODEL_ERR

        FDATA       = R4EP_ALL(ep1,JEP_DATAFLUX)
        FDATA_ERR   = R4EP_ALL(ep1,JEP_DATAFLUX_ERR)
        FMODEL      = R4EP_ALL(ep1,JEP_MODELFLUX)
        FMODEL_ERR  = R4EP_ALL(ep1,JEP_MODELFLUX_ERR)
        write(6,166) MJD1, FDATA, FDATA_ERR, FMODEL, FMODEL_ERR

166       format(T5,' xxx MJD=',F7.1, 2x, 'FLUX[DATA,MODEL] = ',  & 
                F8.2,'+_', F7.2, 3x, F8.2,'+_', F7.2 )

    endif

    call flush(6)

    RETURN
  END SUBROUTINE  PRINT_FCNCHI2_MATRIX

! ==============================================================
    DOUBLE PRECISION FUNCTION FCNCHI2_PRIOR(XVAL,CHI2PRIOR)
! 
! Created Apr 03, 2009 by R.Kessler
! Evaluate prior-chi2 and return total prior-chi2.
! 
! Apr 3 2018: include color-prior chi2
! 
! Jun 2022: check option to use zphot quantiles
! Jan 2024: check prior for IPAR_SHAPE2 (2nd SHAPE param)
! Jan 2025: call CHI2_PRIOR_SNCID_FILE for USE_PRIOR_SNCID_FILE = T
! Dec 2025: if PROBz <=0, force chi2prior = 1000 
! Mar 2026: add flat-top prior on DMU = MU - MU_THEORY
! --------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! function args
    REAL*8  & 
         XVAL(MXFITPAR)          &  ! (I) fit parameters
        ,CHI2PRIOR(0:MXFITPAR)      ! (O) prior-chi2 for SEEFF   each parameter

! local args

    INTEGER  IPAR, ISN, IPAR_DIST

    REAL*8  & 
         CHI2TMP, COLOR, COLORMAX, RV, SHAPE(2), PEAKMJD, DIST, MU, ZSN  & 
        ,arg_tmp, DIF, pull, PROBZ, DVAL

    LOGICAL LTMP, LBADVAL, DO_QUANTILES

! define max color and MU for which exponential priorchi2 is used
! to prevent MINUIT from probing extreme values.

    REAL*8, PARAMETER ::    & 
         CMAX_SALT2 = 0.5   &  ! max abs(color) for SALT2
        ,AVMAX      = 5.0   &  ! max AV for host-galaxy extinction
        ,MUMIN      = 10.   &  ! min dist mod
        ,MUMAX      = 60.      ! max distance mod.

! functions
    REAL*8  &
         CHI2_PRIOR, CHI2_PRIOR_SNCID_FILE  &
        ,PRIOR_ZPULL  &
        ,PRIOR_MUPULL  &
        ,GET_RV8  &
        ,eval_zPDF_spline, DLMAG_REF &
        ,eval_spline

    EXTERNAL eval_zPDF_spline, eval_spline

! ------------- BEGIN --------------


! init output
    FCNCHI2_PRIOR = 0.0
    LBADVAL = .FALSE.

! init CHI2PRIOR and check for crazy fit params

    CHI2PRIOR(0) = 0.0
    DO 100 IPAR = 1, MXFITPAR
       CHI2PRIOR(ipar) = 0.0

       IF ( IPAR .EQ. IPAR_ITER ) GOTO 100
       IF ( IPAR .EQ. IPAR_ISN  ) GOTO 100

! check for NANs
       LTMP = XVAL(ipar) .GE. INIBND(1,ipar)  & 
        .and. XVAL(ipar) .LE. INIBND(2,ipar)

       if ( .NOT. LTMP ) then
          CHI2PRIOR(ipar) = 1.111E9
          LBADVAL = .TRUE.
       endif
100   CONTINUE

    if ( LBADVAL ) goto 888

! strip off XVAL parameters into local variables.

    ISN        = int ( XVAL(IPAR_ISN) )
    COLOR      = XVAL(IPAR_AV)       !  AV or c
    RV         = GET_RV8(XVAL)
    SHAPE(1)   = XVAL(IPAR_SHAPE)
    SHAPE(2)   = XVAL(IPAR_SHAPE2)
    PEAKMJD    = XVAL(IPAR_PEAKMJD)
    DIST       = XVAL(IPAR_DLMAG)    ! MU or x0
    ZSN        = XVAL(IPAR_zPHOT)


    IF ( PARNAME_STORE(IPAR_DLMAG) .EQ. 'DLMAG' ) THEN
       MU = DIST
       COLORMAX = AVMAX
    ELSE

! translate SALT2 params into distance modulus
       MU = 30.0 - 2.5*log10(DIST)  & 
            + (SALT2alpha*SHAPE(1)) - (SALT2beta * COLOR)
       COLORMAX = CMAX_SALT2
    ENDIF


! priors for all models to protect against crazy MINUIT excursions

    DIF     = PEAKMJD  - INIVAL(IPAR_PEAKMJD)
    CHI2PRIOR(IPAR_PEAKMJD)  & 
              = CHI2_PRIOR(ipar_PEAKMJD,DIF)

! protect against crazy COLOR values
    if ( abs(COLOR) .GT. COLORMAX ) then
        DIF     = abs(COLOR) - COLORMAX
        arg_tmp = 0.5 * (DIF * DIF)
        CHI2PRIOR(IPAR_AV) = dexp(arg_tmp) - 1.0
    endif


! protect against against absurdly small & large distances
! (because MINUIT sometimes tries really crazy values)

    IPAR_DIST = IPAR_DLMAG  ! MU or x0

    if ( MU .LT. MUMIN ) then
       DIF     = MUMIN - MU
       arg_tmp = 0.5 * (DIF*DIF)
       CHI2PRIOR(IPAR_DIST) = dexp(arg_tmp) - 1.0
    endif
    if ( MU .GT. MUMAX ) then
       DIF     = MU - MUMAX
       arg_tmp = 0.5 * (DIF*DIF)
       CHI2PRIOR(IPAR_DIST) = dexp(arg_tmp) - 1.0
    endif

    IF ( OPT_PRIOR .EQ. 0 ) GOTO 888

! avoid crazy redshift value
    if ( ZSN .LT. Zat10pc ) then
        CHI2PRIOR(IPAR_zPHOT) = 1.0E8
        GOTO 888
    endif


! -----------------------------------------
! Prior on photoZ

    IF ( DOFIT_PHOTOZ ) THEN

!  load local variables for user-specified options from &SNLCINP OPT_PHOTOZ
      DO_QUANTILES    = btest(MASK_PHOTOZ_SOURCE,BIT_PHOTOZ_QUANTILES)

      if ( DO_QUANTILES ) then
         ! get the probability at this redshift

         if(DEBUG_FLAG == -28) then  
            PROBZ = eval_zPDF_spline(ZSN)  ! Legacy, May 2026 
         else
            PROBZ = eval_spline(IND_OFF_SPLINE_QUANTILE_ZPHOT+1, ZSN)  ! use zPDF from quantiles
         endif
        if ( PROBZ > 0.0 ) then
           CHI2PRIOR(IPAR_zPHOT) = -2.0*DLOG( PROBZ )
        else
           CHI2PRIOR(IPAR_zPHOT) = 1000.0
        endif

      else
         ! Gauss prior
         pull   = PRIOR_ZPULL(ZSN)
         CHI2PRIOR(IPAR_zPHOT) = CHI2_PRIOR(ipar_zPHOT,pull)
      endif


      if ( DEBUG_FLAG == 9088 ) then
         CALL DUMP_ZPHOT_PRIOR(ZSN,PROBZ)
      endif

      IF ( PRIOR_MUERRSCALE < 9.0 ) THEN
         pull    = PRIOR_MUPULL(isn, ZSN, MU)
         CHI2TMP = CHI2_PRIOR(ipar_DLMAG, pull) 
      ELSE IF ( PRIOR_DMU_RANGE(2) < 8.0 ) THEN
         DIF = MU - DLMAG_REF(ZSN)   ! change to interpolating grid for speed ?
         CHI2TMP = CHI2_PRIOR(ipar_DLMAG, DIF) 
      ELSE
         CHI2TMP = 0.0
      ENDIF
      CHI2PRIOR(IPAR_DLMAG) = CHI2PRIOR(IPAR_DLMAG) + CHI2TMP

    ENDIF

! -------------------------
! prior on shape
    CHI2PRIOR(IPAR_SHAPE) = CHI2_PRIOR(IPAR_SHAPE,SHAPE(1))

! prior on 2nd shape par
    IF ( NSHAPEPAR > 1 ) THEN
      CHI2PRIOR(IPAR_SHAPE2)  = CHI2_PRIOR(IPAR_SHAPE2,SHAPE(2))
    ENDIF


! ----------------------
! prior on SALT2 color (Apr 2018)

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
      CHI2PRIOR(IPAR_COLOR)  = CHI2_PRIOR(IPAR_COLOR,COLOR)
    ENDIF


! =================================================
    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) GOTO 888 ! restore 6/19/23
! =================================================

! Prior on AV
    IF ( INISTP_AV .NE. 0.0 ) then
      CHI2PRIOR(IPAR_AV)  = CHI2_PRIOR(ipar_av,COLOR)
      CHI2PRIOR(IPAR_RV)  = CHI2_PRIOR(ipar_rv,XVAL(IPAR_RV) )
    ENDIF


888   CONTINUE


! Jan 2025: add prior on each param based on fitpar read from external file
    IF ( USE_PRIOR_SNCID_FILE ) THEN
      IPAR = IPAR_PEAKMJD; DVAL = PEAKMJD
      CHI2PRIOR(IPAR) = CHI2PRIOR(IPAR)  & 
                        + CHI2_PRIOR_SNCID_FILE(IPAR,DVAL)

      IPAR = IPAR_DIST ; DVAL = DIST
      CHI2PRIOR(IPAR) = CHI2PRIOR(IPAR)  & 
                        + CHI2_PRIOR_SNCID_FILE(IPAR,DVAL)

      IPAR = IPAR_SHAPE ; DVAL = SHAPE(1)
      CHI2PRIOR(IPAR) = CHI2PRIOR(IPAR)  & 
                        + CHI2_PRIOR_SNCID_FILE(IPAR,DVAL)

      IPAR = IPAR_COLOR; DVAL = COLOR
      CHI2PRIOR(IPAR) = CHI2PRIOR(IPAR)  & 
                        + CHI2_PRIOR_SNCID_FILE(IPAR,DVAL)

      if ( OPT_PHOTOZ > 0 ) then
        IPAR = IPAR_zPHOT; DVAL = ZSN
        CHI2PRIOR(IPAR) = CHI2PRIOR(IPAR)  & 
                          + CHI2_PRIOR_SNCID_FILE(IPAR,DVAL)
      endif

    ENDIF   ! USE_PRIOR_SNCID_FILE

! - - - - - - -
! sum all the pieces
    DO IPAR = 0, MXFITPAR
       FCNCHI2_PRIOR = FCNCHI2_PRIOR + CHI2PRIOR(ipar)
    ENDDO

    RETURN
  END FUNCTION FCNCHI2_PRIOR

! ==============================================
    SUBROUTINE DUMP_ZPHOT_PRIOR(ZSN,PROBZ)
! --------------------
! Created Sep 8, 2022
! R. Chen
! Debug photo-z prior information
! --------------------
    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FILTCOM
    USE SNLCINP_NML
    REAL*8 ZSN,PROBZ
    REAL*8 CHI2PRIOR_ORIG,CHI2PRIOR_CALC,CHI2PRIOR_QUANTILE
    REAL*8 pull,sig,CHI2_LOGSIG
    REAL*8 PRIOR_ZPULL,CHI2_PRIOR
    LOGICAL USE_Q
! BEGIN
    USE_Q = btest(OPT_PHOTOZ,BIT_PHOTOZ_QUANTILES)
    sig         = SNHOST_ZPHOT_ERR(1)
    CHI2_LOGSIG = DLOG(2.0*3.14159*sig*sig)
    ! xxx ??? CHI2_LOGSIG = 0 ! unclear why this is zeroed out ?
    CHI2PRIOR_QUANTILE = -9.0 ! init
    CHI2PRIOR_CALC = ((ZSN - SNHOST_ZPHOT(1))/sig)**2 + CHI2_LOGSIG
    if (USE_Q) then
       if ( PROBZ > 0.0 )  CHI2PRIOR_QUANTILE = -2.0*DLOG( PROBZ )
      CHI2PRIOR_ORIG = -9
    else
      pull   = PRIOR_ZPULL(ZSN)
      CHI2PRIOR_ORIG = CHI2_PRIOR(ipar_zPHOT,pull) + CHI2_LOGSIG
    endif

    write(6,40) ZSN,sig,PROBZ,CHI2PRIOR_ORIG,CHI2PRIOR_CALC,  & 
       CHI2PRIOR_QUANTILE
40    format(' z=',F5.3, 3x,'sigz=',F5.3, 3x,'PROBZ= ',F5.3,3x,  & 
       'CHI2zPRIOR[ORIG,CALC,Q] = ' , 3F10.4)
    CALL flush(6)
    RETURN
  END SUBROUTINE DUMP_ZPHOT_PRIOR

! ==============================================
    DOUBLE PRECISION FUNCTION FCNCHI2_SIGMA(iter,iepoch,fluxerr)

! --------------------------
! Created April 23, 2011
! [moved code out of FCNSNLC to clean up and fix bug]
! 
! Return chi2 contribution from error-term, relatiave to last interation.
! The nominal term is -2ln(FLUXERR) but instead here we compute
! 
!      FCNCHI2_SIGMA = -2ln(FLUXERR/LAST_FLUXERR)
! 
! so that this is nominally ~zero if the flux-error does not
! change much between iterations.
! 
! LAST_FLUXERR is either defined as total error (default) or only using the data error (user option)
! To control this option, see user input OPT_CHI2_SIGMA and MASK_CHI2_SIGMA_* parameters
! 
! Also fix bug by returning zero if 1st-iteration FLUXERR=0 ...
! this can happen if a new filter is added in the 2nd iteration.
! Updated April 26 2024, W. D. Kenworthy added flexibility to LAST_FLUXERR
! ------------------

    USE SNDATCOM
    USE SNFITCOM
! +CDE,SNANAFIT.
    USE SNLCINP_NML
    USE FILTCOM

    IMPLICIT NONE

! function args
    INTEGER  & 
         ITER          &  ! (I) fit iteration
        ,IEPOCH       ! (I) index to R4EP arrays

    REAL*8 FLUXERR ! (I) error on flux

! local args

    REAL*8  SIGRAT, LAST_FLUXERR

! function
    LOGICAL FIRST_ITERATION

! ----------- BEGIN -----------

    FCNCHI2_SIGMA = 0.0               ! init to zero chi2
    IF ( FIRST_ITERATION(ITER) ) RETURN
    IF ( OPT_CHI2_SIGMA == 0 ) RETURN  ! check user option
    IF ( IAND(OPT_CHI2_SIGMA,MASK_CHI2_SIGMA_ERRTOT) > 0) THEN
          LAST_FLUXERR = DBLE( R4EP_LAST(iepoch,JEP_FLUX_ERRTOT) ) !WDK JEP_DATAFLUX_ERR
    ELSE IF ( IAND(OPT_CHI2_SIGMA,MASK_CHI2_SIGMA_ERRDATA) > 0) THEN
          LAST_FLUXERR = DBLE( R4EP_LAST(iepoch,JEP_DATAFLUX_ERR) )
    ELSE
       WRITE(c1err,601)OPT_CHI2_SIGMA
601    FORMAT('Invalid OPT_CHI2_SIGMA =',i5)
       c2err='OPT_CHI2_SIGMA must include bit for flux error baseline'
       CALL MADABORT('FCNCHI2_SIGMA', c1err, c2err );
    ENDIF

    if ( LAST_FLUXERR .LE. 1.0E-11 ) RETURN

!      ifilt_obs = I4EP_ALL(iepoch,IEP_IFILT_OBS)  ! for debug only
!      cfilt     = filtdef_string(ifilt_obs:ifilt_obs) ! for debug only

    SIGRAT = FLUXERR/LAST_FLUXERR
    FCNCHI2_SIGMA = 2.*dlog(sigrat)

    RETURN
  END FUNCTION FCNCHI2_SIGMA

! ==============================================
    DOUBLE PRECISION FUNCTION USRFUN (  & 
         ITER         &  ! (I) fit iteration used for parm-dependent error calc
        ,IFILT_OBS    &  ! (I) index of observer -filter
        ,ZSN          &  ! (I) redshift
        ,Tobs         &  ! (I) T - Tpeak, observer frame
        ,WAVECOR      &  ! (I) wavecor (A) applied to filters for model mag
        ,SHAPE        &  ! (I) shape-par (DELTA, STRETCH, ETC ... )
        ,DIST         &  ! (I) MU=5*LOG10(10pc/DL) or x0
        ,AVHOST       &  ! (I) extinction in SN host galaxy (not used)
        ,RVHOST       &  ! (I) RV in SN host gal (not used)
        ,MWEBV        &  ! (I) local MW extinction (add 1/25/2007)
        ,LDMP         &  ! (I) dump-option
        ,AVwarp       &  ! (O) "AV" used to warp spectral template
        ,mag_kcor     &  ! (O) K-correction   error used
        ,mag_xtav     &  ! (O) host-gal extinction in rest-frame filter
        ,mag_xtmw     &  ! (O) MW extinction on obs-frame filter
        ,mag_err      &  ! (O) mag-error from model
        )

! ----------------------------------------------------
!  Returns predicted Flux based on input parameters.
! 
! 
! Jan 16, 2012: fix long-standing patchy bug NOAVWARP;
!               test-code had always been included,
!               thus blowing up the errors.
! 
! Jul 2013: change name of MU argument to DIST
! 
! Sep 22 2013: add args RV and OPT_MWCOLORLAW to get_mwxt8().
! 
! Mar 19 2018: call SALT2zz to get redshift used in error calc.
!              Goal is to remove photo-z pathologies.
! 
! Aug 20 2026: pass wavecor for model passband
! ----------------------------------------------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! function args

    INTEGER ITER, IFILT_OBS  ! (I)

    DOUBLE PRECISION  & 
         ZSN, Tobs, WAVECOR, SHAPE(2), DIST      &  ! (I)
        ,AVHOST, RVHOST, MWEBV                   &  ! (I)
        ,AVWARP, MAG_KCOR(2)                     &  ! (O)
        ,MAG_XTAV, MAG_XTMW, MAG_ERR      ! (O)

! local args

    DOUBLE PRECISION  & 
         Z1, Z0  & 
        ,Trest  & 
        ,MAG_REST(MXFILT_ALL)  & 
        ,MAG_BESSELL_REST(MXFILT_ALL)  & 
        ,MAG_BESSELL_OBS(MXFILT_ALL)  & 
        ,MAG_LANDOLT_REST(MXFILT_ALL)  & 
        ,MAG_LANDOLT_OBS(MXFILT_ALL)  & 
        ,MAGERR_REST(MXFILT_ALL)  & 
        ,MAGERR_OBS_TMP(MXFILT_ALL)  & 
        ,MAG_XTAV_REST(MXFILT_ALL)  & 
        ,MAG_XTMW_OBS(MXFILT_ALL)  & 
        ,KCOR_TMP(MXFILT_ALL)  & 
        ,KCORERR_TMP(MXFILT_ALL)  & 
        ,AVWARP_TMP(MXFILT_ALL)  & 
        ,MAG_OBS_TMP(MXFILT_ALL)  & 
        ,MAG_TMP1, MAG_TMP2, MWXT_TMP  & 
        ,SQMAGERR, MAGERR_KCOR, MAG_OBS  & 
        ,FLUX, ARG, MJD, XT  & 
        ,STR1, STR2, DELTA, DM15  & 
        ,BX_synth, B_synth  & 
        ,SALT2x0, SALT2x1, xx1, SALT2c, zz, RVDUM, AVDUM  & 
        ,AVMW, LAMAVG, LAMREST, WGT1, WGT2  & 
        ,LAMDIF12, LAMDIF13, DIF  & 
        ,ERRTMP1, ERRTMP2  & 
        ,MUTMP, MWEBV_MODEL, RVMW, PARDUM(10)

    INTEGER  & 
         istat  & 
        ,ifilt  & 
        ,ifilt_rest  & 
        ,ifilt_rest1  & 
        ,ifilt_rest2  & 
        ,ifilt_rest3  & 
        ,ifilt_rest_tmp(3)  & 
        ,ifilt_tmp  & 
        ,ifilt2  & 
        ,ifilt2_obs  & 
        ,Nepoch  & 
        ,VBOSE  & 
        ,LL, LPAR_SHAPE, LPAR_COLOR, LPAR_X0  & 
        ,OPT, inear  & 
        ,ISN, CID  & 
        ,NFILT_FITMAP_REST  & 
        ,IFILT_FITMAP_REST(MXFILT_OBS)  & 
        ,MSKTMP, NFTMP  & 
        ,OPTMASK, MSKBAYESN

    INTEGER*8 MSKFILT8(2), MSKTMP8(2)

    CHARACTER CFILT*2, CTMP2*2, CCID*(MXCHAR_CCID), FNAM*8
    REAL*4 Z4, LAMDIF4(3)

! KCORFUN8 args
    INTEGER IFILT_REST_KCORFUN(3)
    REAL*8  & 
          MAG_REST_KCORFUN(3)  & 
         ,LAMDIF_KCORFUN(3)  & 
         ,AVWARP_KCORFUN(3)

    LOGICAL  & 
          LTMP  & 
         ,LBESS_OBS, LSNXTAV, LSNXTMW, ISREST, ISOBS  & 
         ,LDMP, NEEDU,  DOKCOR13, LCRAZYMAG  & 
         ,ABORT_ON_DMP, LDEBUG

! functions
    INTEGER  & 
         NEAREST_IFILTDEF_WRAPPER  & 
        ,GENMAG_STRETCH2  & 
        ,GENMAG_MLCS2K2  & 
        ,GENMAG_SNOOPY  & 
        ,LANDOLT_CONVERT

    LOGICAL FILTBTEST

    REAL*8  & 
         genmag_extinction  & 
        ,eval_kcor_table_AVWARP   &  ! C code
        ,eval_kcor_table_LCMAG    &  ! C code
        ,eval_kcor_table_MWXT    &  ! C code
        ,GET_KCOR_DRIVER         &  ! C code
        ,GET_KCORERR             &  ! C code
        ,GALextinct     &  ! returns approx MW extinction
        ,DLMAG_REF  & 
        ,SALT2x0calc, SALT2xx1, SALT2zz, SALT2x2  & 
        ,PARLIST_SN(10), PARLIST_HOST(10)

! ------------- BEGIN USRFUN ------------

    FNAM = 'USRFUN'

! init output args
    AVWARP       = NULLVAL
    MAG_KCOR(1)  = NULLVAL
    MAG_KCOR(2)  = NULLVAL
    mag_xtav     = NULLVAL
    mag_xtmw     = NULLVAL
    mag_err      = NULLVAL
! -----------------

    ABORT_ON_DMP = .FALSE.

    USRFUN   = 1.0
    Nepoch   = 1     ! 1 epoch
    VBOSE    = 0

    Z0      = Zat10pc
    Z1      = 1.0 + ZSN
    Trest   = Tobs / Z1
    RVMW    = DBLE(RV_MWCOLORLAW)

! check for special case where IFILT_OBS is really a rest-filter
    IF ( ZSN .LT. Z0*1.001 ) then
      ISREST = .TRUE.
    ELSE
      ISREST = .FALSE.
    ENDIF

    IF ( ISREST ) THEN
      LAMAVG  = DBLE( FILTREST_LAMAVG(ifilt_obs) )
      LAMREST = DBLE( FILTREST_LAMAVG(ifilt_obs) )
    ELSE
      LAMAVG  = DBLE( FILTOBS_LAMAVG(ifilt_obs) )
      LAMREST = DBLE( FILTOBS_LAMAVG(ifilt_obs) ) / Z1
    ENDIF

    NFILT_FITMAP_REST    = 0

    MWEBV_MODEL = MWEBV
    IF ( USE_MWCOR ) MWEBV_MODEL = 0.0 ! data already corrected

    LBESS_OBS = IFILT_OBS .GE. IFILT_BESS_U .and.  & 
                  IFILT_OBS .LE. IFILT_BESS_I

! get approx MW extinction (for printout only ... not for calculation)
    AVMW     = RVMW * mwebv_model ;
    PARDUM(1) = 0.0
    MAG_XTMW = GALextinct(RVMW, AVMW, LAMAVG, 94, PARDUM,  & 
                     FNAM//char(0), 8);

! if we have observer-frame model, then skip all
! the rest-frame stuff.

    IF ( LOBS_FITMODEL ) GOTO 333

! get nearest and 2nd nearest filter in rest frame.
! Note that IFILT_REST1[2] are absolute (NOT sparse) filter indices.

    IF ( ISREST ) then
      OPT = OPT_FILTREST
    ELSE
      OPT = OPT_FILTOBS
    ENDIF
    Z4  = sngl(ZSN)

    ifilt_rest1 =  & 
        NEAREST_IFILTDEF_WRAPPER( opt, ifilt_obs, 1, Z4, LAMDIF4(1))
    ifilt_rest2 =  & 
        NEAREST_IFILTDEF_WRAPPER( opt, ifilt_obs, 2, Z4, LAMDIF4(2))
    ifilt_rest3 =  & 
        NEAREST_IFILTDEF_WRAPPER( opt, ifilt_obs, 3, Z4, LAMDIF4(3))

! check if KCOR13 (based on warping other neighbor) should be
! wgt-averaged with nominal KCOR12.
! First that order is 3-1-2  or  2-1-3.

    LAMDIF12 = DBLE(  FILTREST_LAMAVG(ifilt_rest2)  & 
                      - FILTREST_LAMAVG(ifilt_rest1) )
    LAMDIF13 = DBLE( FILTREST_LAMAVG(ifilt_rest1)  & 
                     - FILTREST_LAMAVG(ifilt_rest3) )
    DOKCOR13 = (LAMDIF12/LAMDIF13) .GT. 0.0

! update rest-frame map for photoZ fit (if IFILT is defined)

    if ( DOFIT_PHOTOZ ) then
        ifilt = IFILTDEF_INVMAP_SURVEY(ifilt_obs)
        if ( ifilt .GT. 0 ) then
          IFILT_REST_MAP(ifilt) = ifilt_rest1
        endif
    endif

! check option for rest-frame mags only with no K-correction

    IF ( ISREST ) then
      NFILT_FITMAP_REST    = 1
      IFILT_FITMAP_REST(1) = IFILT_REST1
      IFILT_REST1          = IFILT_REST1
      IFILT_REST2          = IFILT_REST1
      IFILT_REST3          = IFILT_REST1
      GOTO 333
    ENDIF

    NEEDU = ifilt_rest1 .EQ. ifilt_BESS_U .or.  & 
              ifilt_rest2 .EQ. ifilt_BESS_U

    NFILT_FITMAP_REST    = 2
    IFILT_FITMAP_REST(1) = ifilt_rest1
    IFILT_FITMAP_REST(2) = ifilt_rest2

    IF ( DOKCOR13 ) THEN
      NFILT_FITMAP_REST    = 3
      IFILT_FITMAP_REST(3) = ifilt_rest3
    ELSE
      ifilt_rest3 = -9
    ENDIF

! expand filter ranges if Landolt option is set.

    IF ( USE_LANDOLT_REST  ) THEN

       NFILT_FITMAP_REST = 0
       do ifilt = 1, NFILTDEF_REST
          ifilt_rest = IFILTDEF_MAP_REST(ifilt)
          if ( ifilt_rest .NE. IFILT_BESS_BX ) then
            NFILT_FITMAP_REST = NFILT_FITMAP_REST + 1
            IFILT_FITMAP_REST(ifilt) = ifilt_rest
          endif

       enddo

    ENDIF

! init filter-dependent variables.

333   CONTINUE

    DO ifilt = 1, MXFILT_ALL
       MAG_REST(ifilt)         = 0.0
       MAGERR_REST(ifilt)      = 0.0
       MAG_XTAV_REST(ifilt)    = 0.0
       KCOR_TMP(ifilt)         = 0.0
       KCORERR_TMP(ifilt)      = 0.0
       MAG_XTMW_OBS(ifilt)     = 0.0
       MAG_OBS_TMP(ifilt)      = 0.0
       MAG_LANDOLT_REST(ifilt) = 0.0
       MAG_LANDOLT_OBS(ifilt)  = 0.0
       MAG_BESSELL_REST(ifilt) = 0.0
       MAG_BESSELL_OBS(ifilt)  = 0.0
       AVwarp_tmp(ifilt)       = 0.0
    ENDDO

! -------------------------------------------
! get MAG_REST1 = magnitude in rest frame for closest filter
!     MAG_REST1 = mag in rest-frame for 2nd closest filter (for color)
! Use "genmag_xxx" function that are used in simulation.

    IF ( FITMODEL_INDEX .EQ. MODEL_STRETCH ) THEN

       STR1       = SHAPE(1)
       STR2       = STR1

       do ifilt = 1, NFILT_FITMAP_REST
          IFILT_REST = IFILT_FITMAP_REST(ifilt)

! return MAG_REST
          istat = genmag_stretch2 (  & 
                 STR1, STR2, IFILT_REST, Nepoch, Trest     &  ! input
               , MAG_REST(ifilt_rest)           &  ! (O)
               , MAGERR_REST(ifilt_rest) )     ! (O)
       enddo

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_STRETCH2 ) THEN

       STR1       = SHAPE(1)
       STR2       = SHAPE(2)

       do ifilt = 1, NFILT_FITMAP_REST
          IFILT_REST = IFILT_FITMAP_REST(ifilt)

! return MAG_REST
          istat = genmag_stretch2 (  & 
                 STR1, STR2, IFILT_REST, Nepoch, Trest    &  ! input
               , MAG_REST(ifilt_rest)        &  ! (O)
               , MAGERR_REST(ifilt_rest) )  ! (O)

       enddo

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_MLCS2k2 ) THEN

        DELTA  = SHAPE(1)

       do ifilt       = 1, NFILT_FITMAP_REST
           IFILT_REST = IFILT_FITMAP_REST(ifilt)

! note that genmag_mlcs starts at 0, so subtract 1 from index.
           ifilt_tmp  = IFILTINVMAP_MODEL(ifilt_rest) - 1
           if ( ifilt_tmp < 0 ) then
             c1err = 'Invalid rest-frame filt for genmag_mlcs2k2: '//  & 
                     FILTDEF_STRING(IFILT_REST:IFILT_REST)
             c2err = 'Valid rest-frame filters: ' //  & 
                     FILTLIST_MODEL(1:NFILT_MODEL)
             CALL MADABORT(FNAM, c1err, c2err )
           endif

           istat = genmag_mlcs2k2(  & 
                    ifilt_tmp, DELTA, Nepoch, Trest   &  ! (I)
                  , MAG_REST(ifilt_rest)        &  ! (O)
                  , MAGERR_REST(ifilt_rest) )  ! (O)

        enddo

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SNOOPY ) THEN

       DM15     = SHAPE(1)

       do ifilt = 1, NFILT_FITMAP_REST
          IFILT_REST = IFILT_FITMAP_REST(ifilt)
          ifilt_tmp  = IFILTINVMAP_MODEL(ifilt_rest) - 1  ! C index

          if ( ifilt_tmp < 0 ) then
             c1err = 'Invalid rest-frame filter for genmag_snoopy: '//  & 
                     FILTDEF_STRING(IFILT_REST:IFILT_REST)
             c2err = 'Valid rest-frame filters: ' //  & 
                     FILTLIST_MODEL(1:NFILT_MODEL)
             CALL MADABORT(FNAM, c1err, c2err )
          endif

          istat = genmag_snoopy(ifilt_tmp, DM15, Nepoch, Trest  & 
                  ,MAG_REST(ifilt_rest)        &  ! (O)
                  ,MAGERR_REST(ifilt_rest) )  ! (O)

        enddo

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN

        OPTMASK  = 0   ! bit0 => nominal, return flux
        SALT2x1 = SHAPE(1)
        SALT2x2 = SHAPE(2)    ! Dec 2023
        SALT2c  = AVHOST
        xx1     = SALT2xx1(ITER,SALT2x1)  ! x1 used in model-err calc
        zz      = SALT2zz(ITER,ZSN)       ! z  used in model-err calc

! translate fit-params into SALT2 language

        if ( OPT_SALT2FIT .EQ. 0  ) then  ! default
           SALT2x0 = DIST
        else if ( OPT_SALT2FIT .EQ. 1  ) then
           SALT2x0 = TEN8**DIST    ! MU
        else if ( OPT_SALT2FIT .EQ. 2  ) then
           MUTMP = (DIST + DLMAG_REF(ZSN))   ! DIST is really MUDIF
           SALT2x0 = SALT2x0calc(ZERO8,ZERO8, ZERO8, ZERO8, MUTMP )
        else if ( OPT_SALT2FIT .EQ. 4  ) then  ! emulate Julien/snfit
           SALT2x0 = DIST      ! same as for default
           if ( ITER .LE. 2 ) then
              OPTMASK  = 4     ! set errors to zero
              xx1      = 0.0   ! redundant
           endif
        endif

        LDEBUG = .FALSE.
        if ( LDEBUG ) then
        ! .xyz
           MJD  = R8EP_MJD(IFITDATA_USRFUN)          ! ,  IFILT_OBS 
           if ( abs(MJD - 62453.3946) < 0.001 .and. SNLC_CID == 1793194) then 
              OPTMASK = OPTMASK + 8
           endif 
        ENDIF

        MSKFILT8(1) = IFILT_OBS_EVAL_MASK(1,ifilt_obs)
        MSKFILT8(2) = IFILT_OBS_EVAL_MASK(2,ifilt_obs)

        NFTMP = NFILTDEF_SURVEY

! loop over all needed obs-filters;
! multiple filters are needed for Landolot color transf.

        RVDUM = 0.0 ; AVDUM=0.0  ! cannot fit for Mandel's extinc params
        PARLIST_SN(1) = SALT2x0
        PARLIST_SN(2) = SALT2x1
        PARLIST_SN(3) = SALT2c
        PARLIST_SN(4) = xx1
        PARLIST_SN(5) = SALT2x2
        PARLIST_HOST(1) = RVDUM
        PARLIST_HOST(2) = AVDUM
        PARLIST_HOST(3) = -9.0   ! logMass

        DO ifilt2 = 1, NFTMP
           ifilt2_obs = IFILTDEF_MAP_SURVEY(ifilt2)
           mag_obs_tmp(ifilt2_obs) = 0.0
           LTMP = FILTBTEST(MSKFILT8,ifilt2_obs)
           if ( LTMP ) then
              ! print*,' xxx Tobs, ifilt_obs, wavecor = ', sngl(Tobs), ifilt_obs, sngl(wavecor)
              CALL genmag_salt2( OPTMASK, ifilt2_obs      & 
                , PARLIST_SN, PARLIST_HOST, MWEBV_MODEL   & 
                , ZSN, ZZ, Nepoch, Tobs                   &  !
                , WAVECOR                                 &  ! Aug 30 2026 
                , MAG_OBS_TMP(ifilt2_obs)                 &  ! return arg
                , MAGERR_OBS_TMP(ifilt2_obs)  ) ! return arg

           endif
        ENDDO  ! ifilt2 loop


! mag error is from the nominal filter ... ignore mag_err
! from other filters used for Landolt color trans.

        MAG_ERR = MAGERR_OBS_TMP(ifilt_obs)

        GOTO 501  ! skip K-corrections and other rest-frame stuff

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_BAYESN ) THEN

        MSKBAYESN = 0
        PARLIST_SN(1) = DIST      ! distance modulus
        PARLIST_SN(2) = SHAPE(1)  ! THETA
        PARLIST_SN(3) = AVHOST    ! host extiction
        PARLIST_SN(4) = RVHOST    ! RV for host

        CALL genmag_BAYESN( MSKBAYESN, ifilt_obs  & 
                , PARLIST_SN, PARLIST_HOST, MWEBV_MODEL  & 
                , ZSN, Nepoch, Tobs  & 
                , MAG_OBS_TMP(ifilt_obs)        &  ! return arg
                , MAG_ERR                    ) ! return arg

        GOTO 501  ! skip K-corrections and other rest-frame stuff

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SIMSED ) THEN

! translate fit-params into SALT2 language

        MUTMP   = (DIST + DLMAG_REF(ZSN))   ! DIST is really MUDIF
        SALT2x0 = TEN8** (-0.4*MUTMP )      ! borrow SALT2x0 for now

        SALT2x1 = 0.0  ! unused shape-par variable for SIMSED

        MSKTMP  = 1  ! bit0 => return flux instead of mag
! xxxxxxx
!          CALL genmag_simsed( MSKTMP, ifilt_obs
!     &          , SALT2x0, SALT2x1
!     &          , MWEBV_MODEL, ZSN, Nepoch, Tobs
!     &          , flux, mag_err )  ! returns FLUX and MAG_ERR
! xxxxxxx
        GOTO 502  ! skip K-corrections and other rest-frame stuff

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_FIXMAG ) THEN


    ENDIF

! -----------------------------------
! check option for rest-frame mag only
! Include host extinction to get rest-frame colors.

    IF ( ISREST ) THEN

      XT = genmag_extinction(ifilt_obs, Trest, RVHOST, AVHOST)
      MAG_XTAV_REST(ifilt_obs) = XT

      MAG_OBS_TMP(ifilt_obs) =  & 
        MAG_REST(IFILT_OBS) + MAG_XTAV_REST(ifilt_obs)

      GOTO 777  ! skip K-corr and extinction
    ENDIF

! check for option to smooth rest-frame model
! across filter boundaries

    IF ( LREST_FITMODEL ) THEN

       CALL RESTFILT_WGT(LAMREST, ifilt_rest1, ifilt_rest2,    &  ! (I)
                   WGT1, WGT2) ! (O) return wgts (sum to 1)

       ERRTMP1 = MAGERR_REST(ifilt_rest1)
       ERRTMP2 = MAGERR_REST(ifilt_rest2)

! smooth the errors
       MAGERR_REST(ifilt_rest1) = WGT1*ERRTMP1 + WGT2*ERRTMP2
       MAGERR_REST(ifilt_rest2) = WGT1*ERRTMP2 + WGT2*ERRTMP1

    ENDIF

! set temp arrays MAG_BESSELL and MAG_LANDOLT

    DO ifilt      = 1, NFILT_FITMAP_REST
       ifilt_rest = IFILT_FITMAP_REST(ifilt)
       MAG_BESSELL_REST(ifilt_rest) = MAG_REST(ifilt_rest)
       MAG_LANDOLT_REST(ifilt_rest) = MAG_REST(ifilt_rest)
    ENDDO  ! end of IFILT loop

! -----------------------------------------------------------
! If Landolt option is set, then assume MAG_REST is in Landolt system
! and convert to Bessell system before applying Kcor to observer frame.

    IF ( USE_LANDOLT_REST ) THEN  ! rest-frame conversions

! If U-band is needed (NEEDU), first get synthetic BX-B needed to
! convert Landolt-U back to synth Bessell.
! Store BX-B in the memory slot for Landolt-BX.

       MAG_LANDOLT_REST(IFILT_BESS_BX) = 0.0

       if ( NEEDU ) then

            AVWARP = EVAL_KCOR_TABLE_AVWARP(IFILT_REST1, IFILT_REST2,  & 
                    MAG_LANDOLT_REST(ifilt_rest1),  & 
                    MAG_LANDOLT_REST(ifilt_rest2),  & 
                    Trest, ISTAT)
            BX_synth = EVAL_KCOR_TABLE_LCMAG(ifilt_bess_BX, Trest,  & 
                           Z0, AVwarp)
            B_synth  = EVAL_KCOR_TABLE_LCMAG(ifilt_bess_B, Trest,  & 
                           Z0, AVwarp)

         MAG_LANDOLT_REST(IFILT_BESS_BX) = BX_synth - B_synth

       endif

! now convert to synthetic Bessell.

       opt   = -1   ! flag for Landolt -> Bessell conversion
       istat = Landolt_convert(opt  & 
                    ,MAG_LANDOLT_REST(IFILT_BESS_U)   &  ! input  UBVRI,BX-B
                    ,MAG_BESSELL_REST(IFILT_BESS_U)   &  ! output UBVRI
                        )

       DO IFILT = 1,NFILT_FITMAP_REST
          IFILT_REST = IFILT_FITMAP_REST(ifilt)
          MAG_REST(ifilt_rest) = MAG_BESSELL_REST(ifilt_rest)
       ENDDO

! convert synthetic U into reported U by subtracting BX-B :
       MAG_REST(IFILT_BESS_U) = MAG_BESSELL_REST(IFILT_BESS_U)  & 
                                - MAG_LANDOLT_REST(IFILT_BESS_BX)  ! -(BX-B)

       MAG_REST(ifilt_bess_BX) = MAG_REST(ifilt_bess_B)      &  ! B
                                 + MAG_LANDOLT_REST(IFILT_BESS_BX) ! BX-B

    ENDIF  !  end of USE_LANDOLT_REST  if-block

! ----------------------------------------------------
! Now MAG_REST is in synthetic Bessell system;
! apply host extinction for rest-frame models.

    LSNXTAV = LREST_FITMODEL .and. AVHOST .NE. 0.0

    DO IFILT      = 1, NFILT_FITMAP_REST
       IFILT_REST = IFILT_FITMAP_REST(ifilt)

      IF ( LSNXTAV ) THEN

         XT = genmag_extinction(ifilt_rest, Trest, RVHOST, AVHOST)

         MAG_XTAV_REST(ifilt_rest) = XT

         MAG_REST(ifilt_rest) =  & 
           MAG_REST(ifilt_rest) + MAG_XTAV_REST(ifilt_rest)

         MAG_BESSELL_REST(ifilt_rest) =  & 
           MAG_BESSELL_REST(ifilt_rest) + MAG_XTAV_REST(ifilt_rest)

      ENDIF
    ENDDO

! --------------------------------------------
! determine K-correction; note that rest-frame mags
! include host-galaxy extinction.

    LSNXTMW = (ZSN .GT. 1.1 * Zat10pc) .and. (MWEBV .NE. 0.0)
    MSKTMP8(1) = IFILT_OBS_EVAL_MASK(1,ifilt_obs)
    MSKTMP8(2) = IFILT_OBS_EVAL_MASK(2,ifilt_obs)

    DO 155 ifilt2  = 1, NFILTDEF_SURVEY
       ifilt2_obs = IFILTDEF_MAP_SURVEY(ifilt2)

! check filter bit-mask to see if this IFILT needs to be evaluated.

      LTMP = FILTBTEST(MSKTMP8,ifilt2_obs)

      IF ( .not. LTMP ) goto 155

! get closest rest-frame filters for this observer "ifilt2_obs"
      OPT = OPT_FILTOBS
      DO inear = 1, 3
        ifilt_rest_tmp(inear) =  & 
          NEAREST_IFILTDEF_WRAPPER(opt,ifilt2_obs,  & 
                              inear,Z4,LAMDIF4(inear) )

! load KCORFUN8 args
        ifilt_tmp                 = ifilt_rest_tmp(inear)
        IFILT_REST_KCORFUN(inear) = ifilt_tmp
        MAG_REST_KCORFUN(inear)   = MAG_BESSELL_REST(ifilt_tmp)
        LAMDIF_KCORFUN(inear)     = DBLE( LAMDIF4(inear) )
      ENDDO

        KCOR_TMP(ifilt2_obs) =  & 
          GET_KCOR_DRIVER(ifilt2_obs, IFILT_REST_KCORFUN,  & 
                  MAG_REST_KCORFUN,  & 
                  LAMDIF_KCORFUN, Trest, ZSN, AVWARP_KCORFUN )

! save AVwarp
      AVwarp                 = AVwarp_KCORFUN(2)
      AVwarp_tmp(ifilt2_obs) = AVwarp  ! save in case of dump

      KCORERR_TMP(ifilt2_obs) =  & 
            GET_KCORERR ( OPT_KCORERR, ifilt2_obs, ZSN )

      MAG_XTMW_OBS(ifilt2_obs) = 0.0
      if ( LSNXTMW ) then
         MWXT_TMP = EVAL_KCOR_TABLE_MWXT(ifilt2_obs, Trest, ZSN,  & 
                          AVWARP, MWEBV, RVMW, OPT_MWCOLORLAW )
         MAG_XTMW_OBS(ifilt2_obs) = MWXT_TMP
      endif

! Add up all the pieces for observer mag prediction.

      MAG_OBS_TMP(ifilt2_obs) =  & 
             MAG_BESSELL_REST(ifilt_rest_tmp(1))  &  ! rest-mag including host-AV
           + KCOR_TMP(ifilt2_obs)         &  ! K correction
           + DIST                         &  ! MU = 5*log10(10pc/DL)
           + MAG_XTMW_OBS(ifilt2_obs)    ! MilkyWay extinction

! check for option to subtract MWgalaxy extinction from model
! just like for the data.

      if ( USE_MWCOR ) then
        MAG_OBS_TMP(ifilt2_obs) =  & 
          MAG_OBS_TMP(ifilt2_obs) - MAG_XTMW_REF(ifilt2_obs)
      endif

155   CONTINUE

! ---------------------------------------------
! load output args for function
! note that MAG_OBS is loaded below the 501-continue

777   CONTINUE
    AVwarp       = AVwarp_tmp(ifilt_obs)
    MAG_KCOR(1)  = KCOR_TMP(ifilt_obs)
    MAG_KCOR(2)  = KCORERR_TMP(ifilt_obs)
    MAGERR_KCOR  = KCORERR_TMP(ifilt_obs)
    MAG_XTAV     = MAG_XTAV_REST(ifilt_rest1)
    MAG_XTMW     = MAG_XTMW_OBS(ifilt_obs)

! determine model error as contribution from model and K-corr.

    SQMAGERR = 0.0
    IF ( USE_MODEL_MAGERR ) THEN
       SQMAGERR = MAGERR_REST(ifilt_rest1)**2 + MAGERR_KCOR**2
    ENDIF
    MAG_ERR = DSQRT(SQMAGERR)

! -------------------------------------

501   CONTINUE  ! come here when observer mag is calculate

! -------------------------------------------------
! if observer-frame is Bessell, and Landolt option is set,
! then transform observer-frame Bessell mags (MAG_BESSELL)
! to Landolt.

    IF ( USE_LANDOLT_OBS .and.  & 
           LBESS_OBS       .and.  & 
           .not. ISREST   ) THEN

! transfer MAG_OBS_TMP to temporary MAG_BESSELL_OBS array
! => input argument for LANDOLOT_CONVERT below.

       LCRAZYMAG = .FALSE.
       DO  ifilt2  = 1, NFILTDEF_SURVEY
         ifilt2_obs = IFILTDEF_MAP_SURVEY(ifilt2)
         if ( ifilt2_obs > 0 ) then
           MAG_TMP2 = MAG_OBS_TMP(ifilt2_obs)
           MAG_BESSELL_OBS(ifilt2_obs) = MAG_TMP2
           if ( MAG_TMP2 .GT. 40.0 ) LCRAZYMAG = .TRUE.
         endif
       ENDDO

       if ( .not. LCRAZYMAG ) then
         opt   = +1   ! flag for Bessell -> Landolt
         istat = Landolt_convert(opt  & 
                    ,MAG_BESSELL_OBS(IFILT_BESS_U)   &  ! input  UBVRI,BX
                    ,MAG_OBS_TMP(IFILT_BESS_U)       &  ! output Landolt UBVRI
                        )
       endif

! abort if Landolt correction makes more than 3 mag change.
! Check only if SHAPE and COLOR have sane values,
! and also require reasonable Trest.
! 
! 
       DIF = MAG_BESSELL_OBS(ifilt_obs)-MAG_OBS_TMP(ifilt_obs)
       if (   abs(DIF)     .GT. 4.0    &  ! was 3.0
          .and. TREST        .LT. +50.0  & 
          .and. TREST        .GT. -16.0  & 
          .and. SHAPE(1)     .GT. PRIOR_SHAPE_RANGE(1)  & 
          .and. SHAPE(1)     .LT. PRIOR_SHAPE_RANGE(2)  & 
          .and. abs(AVHOST)  .LT. 10.0 ) then

         CALL PRINT_PREABORT_BANNER(FNAM//CHAR(0), 8)
         cfilt = filtdef_string(ifilt_obs:ifilt_obs)
         print*,' Filter = ', cfilt,' : '
         print*,' MAG(LANDOLT)-MAG(BESSELL) = ',  & 
               MAG_OBS_TMP(ifilt_obs), ' - ',  & 
               MAG_BESSELL_OBS(ifilt_obs), ' = ', DIF

         ABORT_ON_DMP = .TRUE.
         LDMP = .TRUE.

         c1err = 'Landolt-Bessell mag-dif is too large'
         c2err = 'Check Landolt transformation'
       endif

    ENDIF  ! end of USE_LANDOLT_OBS

!  strip off final observer-frame mag

    MAG_OBS      = MAG_OBS_TMP(ifilt_obs)

! ------------------------------------------
! Convert to calibrated flux if MAG_OBS has reasonable value;
! otherwise set flux to zero.

    ISOBS = (ZSN .GT. 1.0E-7)

    IF ( ISOBS ) THEN
       LTMP = (MAG_OBS .LT.  40.0) .and. (MAG_OBS .GT. 5.0)
    ELSE
       LTMP = (MAG_OBS .LT. -10.0) .and. (MAG_OBS .GT. -30.0)
    endif

! allow any MAG for TEST option
    if ( FITMODEL_INDEX .EQ. MODEL_FIXMAG ) LTMP = .TRUE.

    if ( LTMP ) then
       arg   = -0.4 * (MAG_OBS - ZP_FLUXCAL)
       FLUX  =  TEN8**(ARG)
    else
       FLUX = 0.0
    endif

! --------------------------------------------------------
502   CONTINUE  ! come here when observer-flux is calculated

    USRFUN = FLUX

    IF ( .not. USE_MODEL_MAGERR ) THEN
        MAG_ERR = 0.0   ! Apr 5 2016
    ENDIF
    IF ( FUDGE_MAGERR_MODEL .GE. 0.0 ) THEN
       MAG_ERR = FUDGE_MAGERR_MODEL
    ENDIF

! --------------------------------------------
! CHECK DUMP UTILITIES

    IF ( LDMP ) THEN  ! strip things for both obs- and rest-frame model

      ISN  = int( INIVAL(ipar_isn) )
      CID  = SNLC_CID
      MJD  = R8EP_MJD(IFITDATA_USRFUN)

      LPAR_SHAPE = index(PARNAME_STORE(IPAR_SHAPE), ' ' ) - 1
      LPAR_COLOR = index(PARNAME_STORE(IPAR_COLOR), ' ' ) - 1
      LPAR_X0    = index(PARNAME_STORE(IPAR_X0), ' ' ) - 1
    ENDIF

    IF ( LDMP .and. LREST_FITMODEL ) THEN

! write fit parameters

      print*,' - - -  - - - - - - - - - - - - - - - - - - - - -'
      write(6,701)  & 
          PARNAME_STORE(IPAR_X0)(1:LPAR_X0), DIST,  & 
          PARNAME_STORE(IPAR_COLOR)(1:LPAR_COLOR), AVHOST,  & 
          PARNAME_STORE(IPAR_SHAPE)(1:LPAR_SHAPE), SHAPE(1),  & 
          MJD, ZSN

701     format(T2,'USRFUN: ',A,'=',F7.3, 2x,A,'=',F7.4,2x,  & 
                    A,'=',F7.4, 2x, 'MJD=',F10.4, 2x,'Z=',F7.5 )

      cfilt = filtdef_string(ifilt_obs:ifilt_obs)
      ctmp2 = filtdef_string(ifilt_rest1:ifilt_rest1)
      write(6,702) cfilt, Tobs, ctmp2, Trest
702   format(T10, 'Tobs(',A1,')=',F8.3,2x,  & 
           'Trest(',A1,')=',F8.3  )

      CALL FLUSH(6)

#if defined(DEBUG_USRFUN)
      print*,' xxxxxxxxxxxx '
      print*,'  MAG_XTAV= ', MAG_XTAV_REST
      print*,'  MAG_REST= ', MAG_REST
      print*,'  KCOR_TMP= ', KCOR_TMP

      print*,'  IFILT_REST[1,2,3] = ',  & 
              IFILT_REST1, IFILT_REST2, IFILT_REST3,  & 
              '   LAMREST=', SNGL(LAMREST)

      print*,'  AVWARP_TMP=', AVWARP_TMP
      print*,'  MAG_XTMW= ', MAG_XTMW_OBS
      print*,'  MAG_OBS = ', MAG_OBS_TMP
      print*,'  MAG_LAND_REST = ', MAG_LANDOLT_REST
      print*,'  MAG_BESS_REST = ', MAG_BESSELL_REST
      print*,'  MAG_BESS_OBS  = ', MAG_BESSELL_OBS
      print*,'  IFILT_FITMAP_REST   = ',IFILT_FITMAP_REST

      print*,'  ifilt_rest1 = ', ifilt_rest1
      print*,'  MAGERR[REST,KCOR,TOTAL] = ',  & 
          MAGERR_REST(ifilt_rest1), MAGERR_KCOR, MAG_ERR
      print*,' xxxxxxxxxxxx '
#endif

! write rest-frame info

! unextincted mag in rest frame
      MAG_TMP1 = MAG_REST(ifilt_rest1) - MAG_XTAV_REST(ifilt_rest1)

      write(6,703)  & 
         filtdef_string(ifilt_rest1:ifilt_rest1), MAG_TMP1  & 
        ,int(100.0*MAG_ERR+0.5)  & 
        ,filtdef_string(ifilt_rest1:ifilt_rest1)  & 
        ,MAG_REST(ifilt_rest1)

703     FORMAT(T10,'Mrest(',A,')=',F9.4,'(',I2.2,')',  2x,  & 
                  'XMrest(',A,')=',F9.4 )

! write rest color, AVwarp and Kcor

      write(6,704)  & 
            filtdef_string(ifilt_rest1:ifilt_rest1)  & 
           ,filtdef_string(ifilt_rest2:ifilt_rest2)  & 
           ,MAG_REST(ifilt_rest1) - MAG_REST(ifilt_rest2)  & 
           ,AVwarp  & 
           ,filtdef_string(ifilt_rest1:ifilt_rest1)  & 
           ,filtdef_string(ifilt_obs:ifilt_obs)  & 
           ,MAG_KCOR(1), MAG_KCOR(2)

704      format(T10,'Xcol(',A,'-',A,')=', F7.4, 2x,'AVwarp=',F7.4,  & 
                 2x,'K_',A,A,'=',F7.4,'+-',F7.4 )

! write observer mag and flux

       write(6,706) filtdef_string(ifilt_obs:ifilt_obs),  & 
                      MAG_OBS, MAG_XTMW, FLUX
706      format(T10,'m_obs(',A,')=',F8.4, 2x, 'm(XTMW)=',F7.4,  & 
                    2x, 'Flux_obs=',G14.6 )

! now write single line with CID keyword ;
! grep "CID" > bla creates easy-to-read column-formatted file
! Columns are
!   1. CID
!   2. obsFilt
!   3. restColor
!   4. MJD
!   5. Trest
!   6. Unextincted mag in rest-frame
!   7. rest-frame mag
!   8. rest-frame color used for SED warping
!   9. AV warp
!  10. Kcor
!  11. observed mag

       CALL CIDSTRING(CID,CCID,LL)
       write(6,710) CCID(1:LL)  & 
           ,filtdef_string(ifilt_obs:ifilt_obs)  & 
           ,filtdef_string(ifilt_rest1:ifilt_rest1)  & 
           ,filtdef_string(ifilt_rest2:ifilt_rest2)  & 
           ,MJD, Trest  & 
           ,MAG_TMP1, MAG_REST(ifilt_rest1)  & 
           ,MAG_REST(ifilt_rest1) - MAG_REST(ifilt_rest2)  & 
           ,AVwarp, MAG_KCOR(1), MAG_OBS

710      format(T2,A,  2x,A,1x,A,'-',A,1x,  F10.3, 7F9.4 )
       CALL FLUSH(6)

       IF ( ABORT_ON_DMP ) THEN
         CALL MADABORT(FNAM, c1err, c2err )
       ENDIF

    ENDIF  ! end of dump for rest-frame model


! ===========================
! Now check dump for observer-frame model

    IF ( LDMP .and. LOBS_FITMODEL ) THEN

      print*,' - - -  - - - - - - - - - - - - - - - - - - - - -'

      write(6,751)  & 
          PARNAME_STORE(IPAR_X0)(1:LPAR_X0), DIST,  & 
          PARNAME_STORE(IPAR_COLOR)(1:LPAR_COLOR), AVHOST,  & 
          PARNAME_STORE(IPAR_SHAPE)(1:LPAR_SHAPE), SHAPE(1),  & 
          MJD

751     format(T2,'USRFUN: ',A,'=',G10.5, 2x, A,'=',F6.3, 2x,  & 
                    A,'=',F6.3, 2x, 'MJD=',F9.3 )

      write(6,752) Tobs, Trest, Zsn
752   format(T10, 'Tobs=',F7.2,2x, 'Trest=',F7.2, 2x,'Z=',F6.4 )

      cfilt = filtdef_string(ifilt_obs:ifilt_obs)
      write(6,754) cfilt, Flux, MAG_ERR
754   format(T5,'model Flux_OBS(',A1,') = ',  & 
           G14.5, 3x,'MAG_ERR=', F8.5 )

      CALL FLUSH(6)

      IF ( USE_LANDOLT_OBS .and. LBESS_OBS ) then

         write(6,766) 'BESSELL', (MAG_BESSELL_OBS(ifilt_tmp), ifilt_tmp=IFILT_BESS_U, IFILT_BESS_BX)
         write(6,766) 'LANDOLT', (MAG_OBS_TMP(ifilt_tmp),  ifilt_tmp=IFILT_BESS_U, IFILT_BESS_BX)
766      format(T5,'model MAG_',A,'(UBVRIX)=', 6F9.4 )

         print*, '      MAG_BESSELL(',cfilt,') = ',  & 
           MAG_BESSELL_OBS(ifilt_obs),' -> ', MAG_OBS_TMP(ifilt_obs),  ' (Landolt)'
         
      ELSE
          write(6,812) cfilt(1:1), MAG_OBS, Trest, ITER
812       format(T5,'model MAG_OBS(', A, ')=', F9.4,  ' at Trest=',F7.2, 2x, 'ITER=',I1)
      ENDIF
      call FLUSH(6)

      IF ( ABORT_ON_DMP ) THEN
        CALL MADABORT(FNAM, c1err, c2err )
      ENDIF

    END IF  ! end of dump for observer-frame model


    RETURN
  END FUNCTION USRFUN 

! ====================================================
    DOUBLE PRECISION FUNCTION GET_DIST8(Z, SHAPE, COLOR, SCALE)
! 
! Created Aug 13, 2009 by R.Kessler
! 
! Return "DISTANCE" estimate based on model;
! => MUREF - 2.5log10(SCALE) (distance modulus) for mlcs, stretch ...
! => X0*SCALE for SALT2
! 
! -------------------------------------

    USE SNDATCOM
    USE SNFITCOM

    IMPLICIT NONE

! +CDE,SNANAFIT.
! +CDE,FILTCOM.
! +CDE,SNLCINP.

! function inputs

    DOUBLE PRECISION  & 
         Z, SHAPE, COLOR   &  ! (I) z, DELTA/x1,   c/AV
        ,SCALE                ! (I) include this multiplicative scale

! local var
    DOUBLE PRECISION  S2a, S2b, x0, MUREF

! function
    DOUBLE PRECISION  SALT2x0calc, DLMAG_REF

! ---------- BEGIN -----------

    GET_DIST8 = 0.0
    MUREF     = DLMAG_REF(Z)

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
       S2a = DBLE(SALT2alpha)
       S2b = DBLE(SALT2beta)
       x0  = SCALE * SALT2x0calc( S2a, S2b, SHAPE, COLOR, MUREF)

       if ( OPT_SALT2FIT .EQ. 0 ) then
         GET_DIST8 = x0
       else if ( OPT_SALT2FIT .EQ. 1 ) then
         GET_DIST8 = log10(x0)
       else if ( OPT_SALT2FIT .EQ. 2 ) then
         GET_DIST8 = 0.0 ! MUDIF  estimate
       endif

    ELSE
       GET_DIST8 = MUREF - 2.5*LOG10(SCALE)
    ENDIF

    RETURN
  END FUNCTION GET_DIST8


! ====================================================
    SUBROUTINE FITMODEL_INI()
! 
! Created Nov 2010 by R.Kessler
! Use namelist input FITMODEL_NAME to initialize global
! variables
!   FITMODEL_PATH, FITMODEL_VERSION, FITMODEL_INDEX
! 
! Feb 22 2017:
!   + allow FITMODEL_NAME to include path; see EXTRACT_MODELNAME().
! 
! May 31 2019: check for SALT3 model.
! 
! -----------------------------------------
    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

! local var

    INTEGER  j, LM, L0, LEN_MODELNAME, LEN_ROOT, LEN_PATH, LEN_VERS

    character  & 
         STRUP*(MXCHAR_MODELNAME)  & 
        ,STRLO*(MXCHAR_MODELNAME)  & 
        ,mtmp*(MXCHAR_MODELNAME)  & 
        ,USER_FITMODEL_NAME*(MXCHAR_FILENAME)  & 
        ,C_FITMODEL*(MXCHAR_FILENAME)  & 
        ,C_PATH*(MXCHAR_FILENAME), C_VERSION*(MXCHAR_MODELNAME)

! ------------ BEGIN --------------

    LM = INDEX(FITMODEL_NAME,' ') - 1
    IF ( LM .GE. MXCHAR_FILENAME .or. LM < 1 ) THEN
       write(c1err,61) MXCHAR_FILENAME
 61      format('len(FITMODEL_NAME) exceeds MXCHAR_FILENAME=',I3)
       c2err = 'Please try a shorter FITMODEL_NAME.'
       CALL MADABORT("FITMODEL_INI", c1err, c2err)
    ENDIF

    FITMODEL_INDEX   = -9
    FITMODEL_PATH    = ''
    FITMODEL_VERSION = ''

    DO 10  j = 1, MXMODEL_INDEX
      FITMODEL_LIST(j) = ''
10    CONTINUE

! first  hard-wird generic name for each model
    FITMODEL_LIST(MODEL_STRETCH)  = 'stretch'
    FITMODEL_LIST(MODEL_STRETCH2) = 'stretch2'
    FITMODEL_LIST(MODEL_mlcs2k2)  = 'mlcs2k2'
    FITMODEL_LIST(MODEL_SALT2)    = 'SALT2'
    FITMODEL_LIST(MODEL_SALT3)    = 'SALT3'
    FITMODEL_LIST(MODEL_BAYESN)   = 'BAYESN'
    FITMODEL_LIST(MODEL_snoopy)   = 'snoopy'
    FITMODEL_LIST(MODEL_SIMSED)   = 'SIMSED'

    USER_FITMODEL_NAME = FITMODEL_NAME ! transfer to local variable

! Special case for backward compatibility: for mlcs, change to mlcs2k2 ...
! remove this dumb logic if/when a new MLCS model is provided by the ESSENCE group.
    if ( FITMODEL_NAME .EQ. 'mlcs' .or.  & 
           FITMODEL_NAME .EQ. 'MLCS' ) then
      USER_FITMODEL_NAME = FITMODEL_LIST(MODEL_mlcs2k2)
    endif

! Feb 22 2017:
!  check if FITMODEL_NAME includes path.
!  Note that C function return termination string
    L0 = INDEX(USER_FITMODEL_NAME,' ') - 1
    C_FITMODEL = USER_FITMODEL_NAME(1:L0) // char(0)

    CALL EXTRACT_MODELNAME(C_FITMODEL,     &  ! input
            C_PATH, C_VERSION,               &  ! output
            MXCHAR_FILENAME, MXCHAR_FILENAME, MXCHAR_MODELNAME)

    LEN_PATH = INDEX(C_PATH,    char(0) ) - 1
    LEN_VERS = INDEX(C_VERSION, char(0) ) - 1
    FITMODEL_PATH    = C_PATH(1:LEN_PATH)
    FITMODEL_VERSION = C_VERSION(1:LEN_VERS)

! now get FITMODEL_INDEX ....

    DO 20  j = 1, MXMODEL_INDEX
       if ( FITMODEL_LIST(j) .EQ. ' ' ) GOTO 20

! check both upper & lower case
       CALL UPCASE(FITMODEL_LIST(j),STRUP)
       CALL LOCASE(FITMODEL_LIST(j),STRLO)
       LM = INDEX(FITMODEL_LIST(j),' ') - 1

       IF ( STRUP(1:LM) .EQ. FITMODEL_VERSION(1:LM)  .or.  & 
              STRLO(1:LM) .EQ. FITMODEL_VERSION(1:LM) ) THEN
          FITMODEL_INDEX = j
          LEN_MODELNAME  = LM
       ENDIF
20    CONTINUE

! May 31 2019 hack: if SALT3, switch to SALT2 to avoid lots of code refactor.
    if ( FITMODEL_INDEX == MODEL_SALT3 ) FITMODEL_INDEX=MODEL_SALT2

! abort if FITMODEL_INDEX has not been found.

    IF ( FITMODEL_INDEX .LE. 0 ) THEN
      LM = INDEX(FITMODEL_NAME,' ') - 1
      c1err = 'Unknown FITMODEL_NAME = ' //  FITMODEL_NAME(1:LM)
      c2err = 'Check &FITINP namelist parameter'
      CALL MADABORT("FITMODEL_INI", c1err, c2err)
    ENDIF



! ----------------------------
! finally, if FITMODEL_PATH is not already set above
! with EXTRACT_MODELNAME, then set it here to default path.

    LEN_PATH = INDEX(FITMODEL_PATH, ' ') -1
    IF ( LEN_PATH == 0 ) THEN
       LEN_VERS = INDEX(FITMODEL_VERSION,' ') - 1
       FITMODEL_VERSION = FITMODEL_VERSION(1:LEN_VERS)

       LEN_ROOT = INDEX(SNDATA_ROOT,' ') - 1
       FITMODEL_PATH = SNDATA_ROOT(1:LEN_ROOT) //  & 
             '/models/' // MTMP(1:L0)  //  '/' //  & 
             FITMODEL_VERSION(1:LEN_VERS)
    ENDIF

    RETURN
  END SUBROUTINE FITMODEL_INI

! ========================
    SUBROUTINE GET_FITFLUX(ep, FIT_FLUXCAL, FIT_FLUXCAL_ERR, REJECT)

! Created Mar 17 2021
! Interface for snana to fetch fitted FLUXCAL and error;
! e.g., for OUTLIER table.


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER EP                         ! (I) epoch index
    REAL FIT_FLUXCAL, FIT_FLUXCAL_ERR  ! (O) fitted flux and erro
    LOGICAL  REJECT                    ! (O) T -> epoch rejected

!  -------------- BEGIN ------------
    FIT_FLUXCAL       = R4EP_ALL(ep,JEP_MODELFLUX)
    FIT_FLUXCAL_ERR   = R4EP_ALL(ep,JEP_MODELFLUX_ERR)

    REJECT =  & 
        ( I4EP_ALL(ep,IEP_REJECT)  > 0 ) .or.  & 
        ( I4EP_ALL(ep,IEP_REJECT2) > 0 )

    RETURN
  END SUBROUTINE GET_FITFLUX

! ========================================================
    DOUBLE PRECISION FUNCTION GET_FLUX_FITFUN  & 
                          ( ifilt_obs, Tobs, wavecor, opt )
! 
! Wrapper to call USRFUN with final "FITVAL" arguments.
! Call this after fit to get function value; do NOT use
! this before or during fit !!!
! 
! OPT = 0  : return nominal function: observer-frame flux
! OPT = 1  : return rest-frame flux
!                (i.e.; no K-cor, no dL, include AV)
! 
! OPT = 2  : return rest-frame flux based on cosmology and XMW
!              (for training)
! OPT = 3  : same as OPT=2, but subtract host-extinction too
! 
! OPT = 6  : return rest-frame mag-error instead of flux
! OPT = 10 : return K-correction only
! OPT = 60 : return error on observer-frame flux
! OPT = 99 : return simulated observer flux with no smearing (LSIM=T only)
! 
! 
!     HISTORY
!  ~~~~~~~~~~~~
!
! Aug 20 2026: pass wavecor arg
! --------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! define function input
    INTEGER IFILT_OBS        ! (I) SN and obs filter index
    REAL*8  Tobs             ! (I) MJD - MJDatPk1
    REAL*8  Wavecor          ! (I) waveshift (A) for model mag
    INTEGER opt              ! (I) option

! local args

    REAL*8  & 
         Flux, Z, DISTPAR, COLORPAR  & 
        ,RVHOST, DLMAG, SHAPEPAR(2)  & 
        ,AVwarp, KCOR(2), MAGERR, MWEBV  & 
        ,ERRFRAC, XTAV, XTMW   & 
        ,FITPARLOC(IPAR_MAX)  & 
        ,SIMPARLOC(IPAR_MAX)  & 
        ,MAGTMP, ARG  

    INTEGER ipar
    LOGICAL LDMP, LREST_COSMO, LMUFIX

    CHARACTER FNAM*16
! function
    REAL*8  USRFUN, DLMAG_REF, GET_RV8, GET_DIST8

! -------------- BEGIN ----------------

    FNAM = 'GET_FLUX_FITFUN'
    GET_FLUX_FITFUN = -9.0

    DO ipar = 1, IPAR_MAX
      FITPARLOC(ipar) = LCVAL_STORE(ipar)
      SIMPARLOC(ipar) = SIMVAL_STORE(ipar)
    ENDDO
    MWEBV = DBLE ( SNLC_MWEBV )

    LREST_COSMO = OPT.EQ.2 .or. OPT.EQ. 3

    IF ( OPT.EQ.1 .or.  OPT.EQ.6 ) then  ! fit-model flux, rest-frame
        Z           = Zat10pc
        COLORPAR    = FITPARLOC(IPAR_AV)
        RVHOST      = GET_RV8(FITPARLOC)
        SHAPEPAR(1) = FITPARLOC(IPAR_SHAPE)
        SHAPEPAR(2) = FITPARLOC(IPAR_SHAPE2)
        DISTPAR     = GET_DIST8(Zat10pc,SHAPEPAR(1),COLORPAR,ONE8)
        MWEBV       = 0.0

    ELSE IF ( OPT .EQ.  0 .or.  & 
                OPT .EQ. 60 .or.  & 
                OPT .EQ. 10 .or.  & 
                LREST_COSMO  & 
                  ) THEN

!  fit-model flux, observer
        Z            = FITPARLOC(IPAR_zPHOT)
        DISTPAR      = FITPARLOC(IPAR_DLMAG)
        COLORPAR     = FITPARLOC(IPAR_AV)
        RVHOST       = GET_RV8(FITPARLOC)
        SHAPEPAR(1)  = FITPARLOC(IPAR_SHAPE)
        SHAPEPAR(2)  = FITPARLOC(IPAR_SHAPE2)

        LMUFIX = DOFIT_PHOTOZ .and. (INISTP_DLMAG .EQ. 0.0)
        if ( LMUFIX ) THEN
           DLMAG   = DLMAG_REF(Z)
           DISTPAR = GET_DIST8(Z,SHAPEPAR(1),COLORPAR,ONE8)
        endif  ! LMMUFIX

    ELSE IF ( OPT .EQ. 99 ) THEN
        Z            = SIMPARLOC(IPAR_zPHOT)
        COLORPAR     = SIMPARLOC(IPAR_AV)
        RVHOST       = GET_RV8(SIMPARLOC)
        DISTPAR      = SIMPARLOC(IPAR_DLMAG)
        SHAPEPAR(1)  = SIMPARLOC(IPAR_SHAPE)
        SHAPEPAR(2)  = SIMPARLOC(IPAR_SHAPE2)
    ELSE
       write(c1err,660) OPT
660      format('Invalid OPT=',I4 )
       CALL MADABORT("GET_FLUX_FITFUN", c1err, "")
    ENDIF


    LDMP = LDMPFUN(IFILT_OBS)

    FLUX =  & 
         USRFUN ( NFIT_ITERATION  & 
         ,ifilt_obs           &  ! (I) obs-frame filter
         ,Z, Tobs             &  ! (I) redshift and MJD-PEAKMJD
         ,WAVECOR             &  ! (I) waveshift (A) for model mag
         ,SHAPEPAR            &  ! (I) Delta, stretch, x1 ...
         ,DISTPAR             &  ! (I) MU or x0
         ,COLORPAR            &  ! (I) AV or c
         ,RVHOST              &  ! (I) RV
         ,MWEBV               &  ! (I) MW extinction
         ,LDMP                &  ! (I) dump flag
         ,AVwarp, KCOR        &  ! (O)
         ,XTAV, XTMW          &  ! (O)
         ,MAGERR              &  ! (O) return args
         )
    
    IF ( OPT .EQ. 6 ) then
      GET_FLUX_FITFUN = MAGERR

    ELSE IF ( LREST_COSMO ) THEN

      magtmp = -2.5*DLOG10(FLUX) + ZP_FLUXCAL  -(XTMW + KCOR(1) + DLMAG_REF(Z) )

      if ( OPT .EQ. 3 ) magtmp = magtmp - XTAV

      ARG = -0.4 * ( MAGTMP - ZP_FLUXCAL)
      GET_FLUX_FITFUN = TEN8**ARG

! -------------
!        print*,' XXXXX ------------------------------------- '
!        print*,' XXXXX ifilt_obs, Tobs = ', ifilt_obs, T8obs
!        print*,' XXXXX XTMW, KCOR = ', XTMW, KCOR8(1)
!        print*,' XXXXX Z, MU = ', Z8, DLMAG_REF(Z8)
!        print*,' XXXXX FLUX8, MAGTMP8 = ', FLUX8, MAGTMP8
! -------------

    ELSE IF ( OPT .EQ. 60 ) then
      errfrac        = 1.0 - TEN8**(-0.4*MAGERR)
      GET_FLUX_FITFUN = FLUX * errfrac
    ELSE IF ( OPT .EQ. 10 ) then
      GET_FLUX_FITFUN = KCOR(1)
    ELSE
      GET_FLUX_FITFUN = FLUX
    ENDIF

    RETURN
  END FUNCTION GET_FLUX_FITFUN


! ================================================
    DOUBLE PRECISION FUNCTION GET_RV8(FITPAR8)
! 
! Sep 29, 2007
! Returns RV for fitter-function USRFUN
! 
! Aug 1, 2009: RV8=1000 (instead of RV_MWDUST) if AV/RV=0
! 
! ----------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    REAL*8  FITPAR8(IPAR_MAX)  ! (I) fit-params

! local var

    LOGICAL LDMP
    REAL*8  RV8, AV8, AV8RV8

! ------------ BEGIN ---------

    LDMP = .FALSE.

    GET_RV8 = RV_MWCOLORLAW

    IF ( INISTP_AVRV .NE. 0.0 ) THEN
       AV8RV8 = FITPAR8(IPAR_AVRV)   ! AV/RV ratio
       AV8    = FITPAR8(IPAR_AV)
       if ( abs(AV8RV8) .GT. 1.0E-5 ) then
         RV8    = AV8 / AV8RV8
       else
         RV8    = 10.
       endif
    ELSE
       RV8  = FITPAR8(IPAR_RV)
    ENDIF

    GET_RV8 = RV8

    RETURN
  END FUNCTION GET_RV8

! ==============================
    SUBROUTINE RESTFILT_WGT (  & 
          LAMREST             &  ! (I) rest-frame wavelegth
         ,ifilt_rest1         &  ! (I) index of nearest rest-filter
         ,ifilt_rest2         &  ! (I) index of 2nd nearest filter
         ,WGT1, WGT2          &  ! (O) return wgts (sum to 1)
            )

! Created Aug 26,2009 by R.Kessler
! 
! Return rest-filter weights to allow a smooth transition
! across filters. At a transition wavelength (i.e., 3900 A
! between U & B), WGT1 = WGT2 = 0.5. If more than
! "LAMREST_MODEL_SMOOTH" Anstroms away from transition
! wavelength, return WGT=1 and WGT=0
! 
! These weights can then be used to smooth out the
! model mags and/or errors
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    USE FILTCOM

    IMPLICIT NONE

! subroutine args

    REAL*8  LAMREST, WGT1, WGT2
    INTEGER ifilt_rest1, ifilt_rest2

! local var

    REAL*8  & 
         LAMAVG(2)  & 
        ,LAMBOUNDARY  & 
        ,LAMDIST  & 
        ,LAMDIST_MAX

! function
    REAL*8 SMOOTH_STEPFUN8

! -------------- BEGIN ------------

    WGT1 = 1.0 ! default output
    WGT2 = 0.0

    IF ( LAMREST_MODEL_SMOOTH .LE. 0.0 ) RETURN
    IF ( IFILT_REST1 .EQ. IFILT_REST2  ) RETURN

    LAMAVG(1) = FILTREST_LAMAVG(ifilt_rest1)
    LAMAVG(2) = FILTREST_LAMAVG(ifilt_rest2)

    IF ( LAMAVG(1) .GT. LAMAVG(2) ) THEN
      LAMBOUNDARY = FILTREST_LAMRANGE(1,ifilt_rest1)
    ELSE
      LAMBOUNDARY = FILTREST_LAMRANGE(2,ifilt_rest1)
    ENDIF

! get distance (Ansgrroms) from boundary
    LAMDIST = abs(LAMREST - LAMBOUNDARY)

! bail if too far from boundary
    IF ( LAMDIST .GT. LAMREST_MODEL_SMOOTH ) RETURN

! use SMMOOTH_STEPFUN function normalized to be
! zero  at LAMBOUNDARY - LAMREST_MODEL_SMOTH, and
! one   at LAMBOUNDARY + LAMREST_MODEL_SMOTH

    LAMDIST_MAX = DBLE ( LAMREST_MODEL_SMOOTH )
    WGT1   = SMOOTH_STEPFUN8(LAMDIST, LAMDIST_MAX )
    WGT2   = 1.0 - WGT1

    RETURN
  END SUBROUTINE RESTFILT_WGT 


! ===========================================
    REAL FUNCTION DATA_MODEL_RATIO(ifilt)

! 
! Return wgt average of data/model for point on lightcurve.
! This is used for adjusting initial "fluxnorms" for fit.
! Uses EP_XXX arrays, and assumes that they have been
! filled with a call to FCNSNLC with IFLAG=FCNFLAG_USER
! 
! Aug 15, 2012: remove obsolet ISN arg.
! Jan 25, 2014: use new I4/R4EP_ALL arrays
! ---------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    USE FILTCOM

    IMPLICIT NONE

    INTEGER  ifilt   ! (I) sparse filter index

! local
    INTEGER imjd, ifilt_obs, i, ep

    REAL RAT, ERR, RSUM, WSUM, w, TREST
    INTEGER NEPFIT

! functions
    LOGICAL MJDSELECT

! ------------- BEGIN ---------

    DATA_MODEL_RATIO = 1.0E-9

    ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
    if ( .NOT. USE_FILT(ifilt_obs) ) return

    RSUM = 0.0
    WSUM = 0.0
    NEPFIT = 0

    DO 100 i = 1, NFITDATA + NFITDATA_REJECT

       ep   =   EPLIST_FIT(i)

! pick out epochs from only the input IFILT
       IF ( IFILT .NE. I4EP_ALL(ep,IEP_IFILT) ) goto 100

       IMJD =   I4EP_ALL(ep,IEP_IMJD)
       if ( .not. MJDSELECT(imjd,0) ) goto 100

! exclude early or late times to be safe
       TREST = R4EP_ALL(ep,JEP_TREST)
       if ( TREST .LT. -10. ) goto 100
       if ( TREST .GT.  40. ) goto 100

       RAT  = R4EP_ALL(ep,JEP_RATIO) ! data/fit ratio
       ERR  = R4EP_ALL(ep,JEP_RATIO_ERR)

       if ( RAT > 0.0 .and. ERR > 0.0 ) then
          w      = 1.0/ERR**2
          RSUM   = RSUM + W * RAT
          WSUM   = WSUM + W
          NEPFIT = NEPFIT + 1
       endif

 100  CONTINUE

    if ( WSUM .NE. 0.0 ) then
       DATA_MODEL_RATIO = RSUM / WSUM
    else
       DATA_MODEL_RATIO = 1.0
    endif

    RETURN
  END FUNCTION DATA_MODEL_RATIO

! ===========================================
    SUBROUTINE RDFITNML(IERR)
! 
! 
! Read &FITINP namelist.
! 
! HISTORY
! ---------------------
! 
! -------------------------------------

    USE SNFITPAR
    USE SNDATCOM
    USE SNLCINP_NML
    USE FILTCOM
    USE FITINP_NML

    IMPLICIT NONE

    INTEGER IERR ! (O) 0 => OK

! local var

    INTEGER IFILT, i
    REAL CUTINI(2), TMPCUT
    LOGICAL USE_AVPRIOR

! ------------------- BEGIN ---------------------

    CALL PRBANNER ( " READ &FITINP NAMELIST" )
    IERR = 0

    CUTINI(1) = -9.0E8
    CUTINI(2) = +9.0E8

    LTRACE = .FALSE.
    NFIT_VERBOSE  = 20

! init namelist defaults

    FITMODEL_NAME       = ' '

    RESTLAMBDA_FITRANGE(1) =     0.0
    RESTLAMBDA_FITRANGE(2) = 25000.0
    UVLAM_EXTRAPFLUX       = -9.0

! set defgaults to no rejected epochs at 2nd iteration
    DELCHI2_REJECT   = 1.0E9
    FITWIN_TREST(1)  = -999.0
    FITWIN_TREST(2)  = +999.0

    FITWIN_TREST_FILTER = ' '

    FITWIN_MJD(1)        = 20000.0
    FITWIN_MJD(2)        = 90000.0
    FITWIN_PEAKMJD(1)    = 20000.0
    FITWIN_PEAKMJD(2)    = 90000.0

    PEAKMJD_SANITY(1) = 0.0   ! 0 => -20/+5 days from start/end of season
    PEAKMJD_SANITY(2) = 1.0E6

    SIGNOISE_REJECT  = -9.0

    DO i = 1, 20
      CONTOUR_LIST(1,i) = 0
      CONTOUR_LIST(2,i) = 0
      CONTOUR_LIST(3,i) = 0
      CONTOUR_LIST(4,i) = 0
    ENDDO

    DO i = 1, 2
      FITWIN_ZPULL(i)        = CUTINI(i)
      FITWIN_ZPHOT(i)        = CUTINI(i)
      FITWIN_COLOR(i)        = CUTINI(i)
      FITWIN_SHAPE(i)        = CUTINI(i)
      FITWIN_PROB(i)         = CUTINI(i)
      FITWIN_PROB_ITER1(i)   = CUTINI(i)
      FITWIN_SHAPE_ITER1(i)  = CUTINI(i)
      FITWIN_COLOR_ITER1(i)  = CUTINI(i)
      FITWIN_CHI2RED_INI(i)  = CUTINI(i)
      FITWIN_CHI2RED_INI2(i) = CUTINI(i)
      FITWIN_NOMARG_PROB(i)  = CUTINI(i)
      FITWIN_CHI2SIGMA(i)    = CUTINI(i)
      FITWIN_TREST(i)        = CUTINI(i)
      FITWIN_MJD(i)          = CUTINI(i)
      FITWIN_PEAKMJD(i)      = CUTINI(i)

      FITWIN_COV_OFFDIAG(i)  = CUTINI(i)

      if ( i .eq. 1 ) TMPCUT = 0.0
      if ( i .eq. 2 ) TMPCUT = sqrt(CUTINI(i)) ! so that COVCUT is ok
      FITWIN_PEAKMJD_ERR(i)  = TMPCUT  ! cut in sigma(fitPar)
      FITWIN_MB_ERR(i)       = TMPCUT
      FITWIN_SHAPE_ERR(i)    = TMPCUT
      FITWIN_COLOR_ERR(i)    = TMPCUT

      FITWIN_PEAKMJD_ERRz1(i)  = TMPCUT ! cut on sigma(fitPar)/(1+z)
      FITWIN_MB_ERRz1(i)       = TMPCUT
      FITWIN_SHAPE_ERRz1(i)    = TMPCUT
      FITWIN_COLOR_ERRz1(i)    = TMPCUT
    ENDDO

! hard-wire a few very loose cuts on SALT2-fitted errors
! to reject crazy fits
    FITWIN_COV_OFFDIAG(1)   = -8.0
    FITWIN_COV_OFFDIAG(2)   = +8.0
    FITWIN_MB_ERR(2)        = +1.0

    SNMAGRMS_for_PHOTOZ = 0.12

    INISTP_PEAKMJD   = 2.0
    INISTP_AV        = 0.2
    INISTP_COLOR     = 0.03   ! Mar 17 2018 (was 0.2)
    INISTP_RV        = 0.0
    INISTP_AVRV      = 0.0
    INISTP_SHAPE     = 0.3
    INISTP_SHAPE2    = 0.0
    INISTP_DLMAG     = 0.5
    INISTP_X0        = 1.0E-5
    INISTP_PHOTOZ    = 0.0

    INIVAL_PEAKMJD       = NULLVAL
    INIVAL_AV        = NULLVAL
    INIVAL_RV        = RV_MWCOLORLAW
    INIVAL_AVRV      = 0.1
    INIVAL_COLOR     = 0.01
    INIVAL_DLMAG     = NULLVAL
    INIVAL_X0        = NULLVAL
    INIVAL_SHAPE     = NULLVAL
    INIVAL_SHAPE2    = NULLVAL
    INIVAL_PHOTOZ    = NULLVAL
    INIVAL_SHIFT_ERRFRAC = 0.0
    FRACERRDIF_REPEATFIT = 1.0E9

! setup default grid w.r.t. peakmjd-estimate
    INIVAL_GRIDSEARCH_DPEAKMJD(1) = -4.0  ! min MJD - PEAKMJD_APPROX (days)
    INIVAL_GRIDSEARCH_DPEAKMJD(2) = +4.0  ! max
    INIVAL_GRIDSEARCH_DPEAKMJD(3) = +2.0  ! bin size , days
    INIVAL_GRIDSEARCH_COLOR(1)   = 0.0
    INIVAL_GRIDSEARCH_COLOR(2)   = 0.0
    INIVAL_GRIDSEARCH_COLOR(3)   = 0.0


    USESIM_AV       = .FALSE.
    USESIM_COLOR    = .FALSE.
    USESIM_RV       = .FALSE.
    USESIM_SHAPE    = .FALSE.
    USESIM_LUMIPAR  = .FALSE.  ! legacy variable
    USESIM_PEAKMJD  = .FALSE.
    USESIM_DLMAG    = .FALSE.
! xxx      USESIM_REDSHIFT = .FALSE.
    USESIM_INIVAL   = .FALSE.

    LKCOR_AVWARP  = .TRUE.
    LKCOR_STRETCH = .FALSE.
    LFIXPAR_ALL   = .FALSE.
    LFIXPAR_ADJUST = .FALSE.

    DOCHI2_SIGMA = .FALSE.  ! May 8, 2009
    OPT_CHI2_SIGMA = 0
    CHECK_CRAZYFITERR  = .TRUE.

    LDMP_PHOTOZ_DROPFILTER = .FALSE.
    DOFIT_PHOTOZ       = .FALSE.
    SKIP_PHOTOZ_INIT = .FALSE.
    LAMREST_MODEL_SMOOTH = -9.0

    OPT_PHOTOZ       = 0
    PHOTODZ_REJECT   = 0.05    ! initial W.A.G; users should test this
    PHOTODZ1Z_REJECT = -99.0   ! no cut

    PHOTOZ_BOUND(1)  = 1.0E-6
    PHOTOZ_BOUND(2)  = 1.4
    PHOTOZ_ITER1_LAMRANGE(1) =  4000.  ! default => skip UV region;
    PHOTOZ_ITER1_LAMRANGE(2) = 26000.  ! note this is obs-frame !
    
    SCALE_NBIN_COURSE_PHOTOZ  = 1
    NBINc_COURSE_PHOTOZ  =  -9
    NBINs_COURSE_PHOTOZ  =  -9
    NBINt_COURSE_PHOTOZ  =  -9
    NBINz_COURSE_PHOTOZ  =  -9 

    RANGEc_COURSE_PHOTOZ(1) =  -99.0;   RANGEc_COURSE_PHOTOZ(2) = -99.0
    RANGEs_COURSE_PHOTOZ(1) =  -99.0;   RANGEs_COURSE_PHOTOZ(2) = -99.0
    RANGEt_COURSE_PHOTOZ(1) =  -99.0;   RANGEt_COURSE_PHOTOZ(2) = -99.0
    RANGEz_COURSE_PHOTOZ(1) =  -99.0;   RANGEz_COURSE_PHOTOZ(2) = -99.0

    NEVAL_MCMC_PHOTOZ      =  0
    PARLIST_MCMC_PHOTOZ(1) =  float(NEVAL_MCMC_PHOTOZ)
    PARLIST_MCMC_PHOTOZ(2) =  20.0  ! NEVAL before reducing step size
    PARLIST_MCMC_PHOTOZ(3) =  0.33  ! initial STEP = range * par(3)
    PARLIST_MCMC_PHOTOZ(4) =  0.90  ! step reduction factor
    PARLIST_MCMC_PHOTOZ(5) =  1.00  ! dmu range on mu constraint

    MINOS_ERRMAX_BAD  = .TRUE.
    MINOS_ERR_DLMAG   = .FALSE.
    MINOS_ERR_REQALL0 = .FALSE.
    MINOS_ERR_REQALL1 = .FALSE.
    OPT_COVAR_LCFIT = 0   ! default: do not fix un-invertible COV(x0,x1,c)

    STRETCH_TEMPLATE_FILE = ' '
    SALT2_DICTFILE        = ' '
    SALT2alpha            = 0.14  ! -> JLA value, Dec 2014
    SALT2beta             = 3.20  ! -> JLA value
    OPT_SALT2FIT          = 0  ! 0 => nominal SALT2 defn

    TREST_PEAKRENORM(1) = 0.0  ! default is no peak renorm
    TREST_PEAKRENORM(2) = 0.0

! Set option for covariance matrix.
! -9 => use default for each model (Aug 28, 2012)
!  0 => use diagonal elements only
!  1 => use covariance matrix evaluated between iterations
!  2 => use covaraince matrix evaluated each fit trial (slower)
    OPT_COVAR      = -99 ! legacy variable
    OPT_COVAR_FLUX = -9  ! new variable name, Nov 9 2018

! option for covariance errors on Galactic-extinction
    OPT_XTMW_ERR      = -9 ! Sep 22: legacy variable off
    OPT_COVAR_MWXTERR =  1 ! Aug 28, 2012: default is ON

    FUDGE_MAG_COVERR = ' '

! extinction options (also see GET_SNXT8 in snana.car):
!  1 => use default extinction from CCM89 law
!  2 => use Saurabh's parametrized extinction from alphs,beta,zeta

    OPT_SNXT     = OPT_SNXT_CCM89

! set algorithm for picking rest-frame color
!   1 => use two closest rest-frame filters
!   5 => use closest filter, and then use color corresponding
!        to Saurabh's lookup (use this option for sync-tests only)

    OPT_NEARFILT   = OPT_FILTOBS  ! obsolete : Feb 3 2012

! set option for Kcor errors; use SJ option (=2) as default
    OPT_KCORERR = OPT_KCORERR_SJ

! scale covariance matrix.
    SCALE_COVAR    = 1.0  ! default scale is 1 => nominal matrix

    FUDGE_COVAR    = 0.0  ! default is no fudge

    USE_MODEL_MAGERR = .TRUE.

    ADD_SALT2ERR_FROMz     = .FALSE.
    ENABLE_MAGSHIFT_SALT2  = .TRUE.
    ENABLE_WAVESHIFT_SALT2 = .TRUE.
    ALLOW_NEGFLUX_SALT2    = .TRUE.  ! default: allow UV Flam<0

! set default Landolt option OFF
    OPT_LANDOLT = 0
    do i = 1, 10
      LANDOLT_COLOR_SHIFT(i) = 0.0
    enddo

    UCOR_BXB    = .FALSE.

! ---------------------------------
    NGRID_PDF      = 0
    NSIGMA_PDF     = 4
    VARLIST_PDF    = 'ALL'
    MAX_INTEGPDF   = 3

    PRIOR_AVEXP(1)   = 1.0E9   ! prior = exp(-AV/PRIOR_AVEXP)
    PRIOR_AVEXP(2)   = 1.0E9   ! prior = exp(-AV/PRIOR_AVEXP)
    PRIOR_AVWGT(1)   = 1.0     ! relative wgt of 1st expon
    PRIOR_AVWGT(2)   = 0.0     ! relative wgt of 2nd expon

    PRIOR_AVRES      = 0.0     ! smear AV prior by this resolution
    PRIOR_MJDSIG     = 1.04    ! sigma for gauss prior on PEAKMJD (days)
    PRIOR_ZERRSCALE  = 1000.01   ! default is no prior
    PRIOR_MUERRSCALE = 1000.01   ! default is no prior
    DOPRIOR_DLMAG    = .FALSE.

    OPT_PRIOR      = 1
    OPT_PRIOR_AV   = 1

    OPT_MNSTAT_COV = 1   ! 1-> repeat fit on MNSTAT_COV<3 (bad cov)

    SIMFIT_IDEAL_PRESCALE = 0  ! zero --> OFF

! init to wide open
    PRIOR_LUMIPAR_RANGE(1) = -9.0  ! legacy variable
    PRIOR_LUMIPAR_RANGE(2) = +9.0  ! idem
    PRIOR_LUMIPAR_SIGMA    =  0.1  ! idem

    PRIOR_SHAPE_RANGE(1) = -9.0  ! LUMIPAR -> SHAPE (Apr 2013)
    PRIOR_SHAPE_RANGE(2) = +9.0
    PRIOR_SHAPE_SIGMA    =  0.1  ! Gauss roll-off at edges of flat prior


    PRIOR_SHAPE2_RANGE(1) = -9.0  !
    PRIOR_SHAPE2_RANGE(2) = +9.0
    PRIOR_SHAPE2_SIGMA    =  0.1  ! Gauss roll-off at edges of flat prior

    PRIOR_COLOR_RANGE(1) = -9.0
    PRIOR_COLOR_RANGE(2) = +9.0
    PRIOR_COLOR_SIGMA    =  0.01  ! Gauss roll-off at edges of flat prior 

    PRIOR_DMU_RANGE(1) = -9.0  ! 3/2026
    PRIOR_DMU_RANGE(2) = +9.0
    PRIOR_DMU_SIGMA    =  0.1

! Aug 17 2015: from snlc_sim.defaults since this is no longer read
    PRIOR_DELTA_PROFILE(1) =  0.23  ! sigma(low)
    PRIOR_DELTA_PROFILE(2) =  0.48  ! sigma(upper)
    PRIOR_DELTA_PROFILE(3) = -0.24 ! bifurcate Gaussian peak
    PRIOR_DELTA_PROFILE(4) =  0.1  ! minimum prob (allows tails)

    DOFIT_FILT(0) = .FALSE.  ! protect against passing ifilt_obs=0

    FILTER_FITMAGDIF = ''

    FILTLIST_FITRESTMAG  = ''
    COLORFIX_FITRESTMAG  = 999.  ! crazy value -> use best-fit value
    LUMIFIX_FITRESTMAG   = 999.  ! crazy value -> use best-fit value
    SHAPEFIX_FITRESTMAG  = 999.
    LAMEXTRAP_FITRESTMAG = 0.0
    DLAMTOL_FITRESTMAG   = 0.0  ! Mar 28 2020

    FILTLIST_FIT    = ''
    FILTLIST_DMPFCN = ''
    FILTLIST_DMPFUN = ''
    TREST_DMPFUN(1) = -999.
    TREST_DMPFUN(2) = +999.
    SCALE_PLOTCHI2 = 1.0  ! scale range to plot chi2

    NEARFILT_IGNORE_REST = ''

    LDMPFCN(0)     = .FALSE.
    DO ifilt    = 1, MXFILT_ALL
        DOFIT_FILT(ifilt)  = .FALSE.
        LDMPFCN(ifilt)     = .FALSE.
        LDMPFUN(ifilt)     = .FALSE.
        DOFUDGE_FITERR(ifilt)       = .FALSE.
    ENDDO

    USE_FUDGE_FITERR = .FALSE.
    FUDGE_FITERR_MAXITER   = 9
    FUDGE_FITERR_MAXFRAC   = 0.0
    FUDGE_FITERR_TREST(1)  = 999.
    FUDGE_FITERR_TREST(2)  = 999.
    FUDGE_FITERR_TREST(3)  = 999.
    FUDGE_FITERR_TREST(4)  = 999.
    FUDGE_FITERR_RESTLAM(1)  = 1000.
    FUDGE_FITERR_RESTLAM(2)  = 1000.
    FUDGE_FITERR_RESTLAM(3)  = 90000.
    FUDGE_FITERR_RESTLAM(4)  = 90000.
    FUDGE_FITERR_PASSBANDS = 'NULL'

    FUDGEALL_MAXFRAC       = 0.0
    FUDGEALL_ITER1_MAXFRAC = 0.0

    FUDGE_MAGERR_MODEL = -9.0
    FUDGE_DATAERR_SCALE = 1.0
    FUDGE_MODELERR_SCALE = 1.0

    FITCOVAR_FILE = ''

    MAGLIM_VMAX = ''
    OPT_VMAX    = 0
    CCID_DUMP_CHI2_MATRIX = ''

! -----------------------

! c      CALL READ_DEFAULT_PRIORS ! removed Aug 13 2015

! ---------------------
! read the 'snana' namelist file for the FITINP namelist

    OPEN (  & 
          UNIT   = LUNNML  & 
         ,file   = nmlfile  & 
         ,status = 'OLD'  & 
         ,ERR    = 900  & 
             )

    READ(LUNNML, NML = FITINP, ERR=901, END=902 )
    CLOSE ( UNIT = LUNNML )

    print*,' '

    CALL FITNML_OVERRIDE(IERR)

! ------------
! check legacy nml variables.
    if ( PRIOR_LUMIPAR_RANGE(1) .NE.  -9.0  ) THEN
      PRIOR_SHAPE_RANGE(1) = PRIOR_LUMIPAR_RANGE(1)
    endif
    if ( PRIOR_LUMIPAR_RANGE(2) .NE.  9.0  ) THEN
      PRIOR_SHAPE_RANGE(2) = PRIOR_LUMIPAR_RANGE(2)
    endif

    if ( PRIOR_LUMIPAR_SIGMA .NE.  0.1  ) THEN
      PRIOR_SHAPE_SIGMA = PRIOR_LUMIPAR_SIGMA
    endif

    IF ( OPT_XTMW_ERR > -8 ) THEN
       OPT_COVAR_MWXTERR = OPT_XTMW_ERR   ! Sep 22, 2013
    ENDIF
    IF ( OPT_COVAR > -98 ) THEN
       OPT_COVAR_FLUX = OPT_COVAR   ! Nov 9 2018
    ENDIF

! ------------------
! check option to turn off all priors.
    IF ( OPT_PRIOR .LE. 0 ) THEN
      PRIOR_AVEXP(1)         = -1.0
      PRIOR_AVEXP(2)         = -1.0
      PRIOR_SHAPE_RANGE(1)   = -8.0
      PRIOR_SHAPE_RANGE(2)   = +8.0
      PRIOR_SHAPE2_RANGE(1)   = -8.0
      PRIOR_SHAPE2_RANGE(2)   = +8.0
      PRIOR_COLOR_RANGE(1)   = -8.0
      PRIOR_COLOR_RANGE(2)   = +8.0
      PRIOR_DMU_RANGE(1)     = -9.0
      PRIOR_DMU_RANGE(2)     =  9.0
      PRIOR_DELTA_PROFILE(4) =  1.0
    ENDIF

! -------------------------------------
! Convert FILTLIST_XXX strings into logical arrays

    CALL PARSE_NML_FILTLISTS

! ------------------
! make a few checks
    if ( SCALE_COVAR .LE. 0.0 ) then
       USE_MODEL_MAGERR = .FALSE.
    endif

    USE_AVPRIOR = (OPT_PRIOR_AV   .GT. 0) .and. (prior_avexp(1) .GT. 0.0 )

! check PHOTOZ stuff.

! first, allow user to set integer option or logical flag.

    if ( OPT_PHOTOZ > 0 ) then
       DOFIT_PHOTOZ = .TRUE.
    endif
    if ( DOFIT_PHOTOZ .and. OPT_PHOTOZ .LE. 0 ) then
   ! use host-galaxy prior by default.
   ! But note PRIOR_ZERRSCALE=1000.01 by default
       OPT_PHOTOZ = IBSET(OPT_PHOTOZ,BIT_PHOTOZ_GAUSS)
    endif

! Set non-zero step-size for PHOTOZ or DLMAG,
! depending on type of fit.
    if ( DOCHI2_SIGMA) OPT_CHI2_SIGMA = MASK_CHI2_SIGMA_ERRTOT  ! Preserve original option WDK
    if ( DOFIT_PHOTOZ ) THEN
       if ( INISTP_PHOTOZ < 1.0E-5 ) INISTP_PHOTOZ    = 0.05
       if (OPT_CHI2_SIGMA == 0) OPT_CHI2_SIGMA= MASK_CHI2_SIGMA_ERRTOT  ! Default
       INTERP_OPT       = INTERP_ZSMOOTH
       if ( LAMREST_MODEL_SMOOTH .LE. 0.0 ) then
         LAMREST_MODEL_SMOOTH = 200.  ! smooth model over this lambda range
       endif

       NEVAL_MCMC_PHOTOZ = int(PARLIST_MCMC_PHOTOZ(1))
       if ( NEVAL_MCMC_PHOTOZ > 0 )  SCALE_NBIN_COURSE_PHOTOZ = 0
    endif

! dump namelist to std out

    IF ( .not. REDUCE_STDOUT_BATCH ) THEN
      WRITE ( 6 , NML = FITINP )
      CALL FLUSH(6)
    ENDIF

    RETURN

! ---------------------------------------------------
900   C1ERR = 'Could not open namelist file '
    CALL MADABORT('RDFITNML', C1ERR,  nmlfile)

901   C1ERR = 'could not read &FITINP namelist from '
    CALL MADABORT('RDFITNML', C1ERR,  nmlfile)

902   C1ERR = 'Could not find &FITINP namelist in'
    CALL MADABORT('RDFITNML', C1ERR,  nmlfile)

    RETURN
  END SUBROUTINE RDFITNML


! =================================
    SUBROUTINE PARSE_NML_FILTLISTS
! 
! Created Nov 24 by R.Kessler
! Prcoess namelist strings FILTLIST_XXX and NEARFILT_IGNORE_REST,
! and fill integer arrays.
! 
! Check every character to allow spaces or no spaces
! betweeh filters: i.e, 'gri' and 'g r i' are both allowed.
! 
! Apr 14, 2013:
!   Allow fitting peak-mags in extra filters. For example,
!   to fit ugriz and also compute peak mags in B & V,
!      FILTLIST_FIT   = 'ugriz+BV'
! 
! Apr 17 2017: check ABORT_ON_BADFILTER

! ---------------------


    USE SNFITPAR
    USE SNDATCOM
    USE SNLCINP_NML
    USE FILTCOM
    USE FITINP_NML

    IMPLICIT NONE

    INTEGER  i, ifilt, ifiltdef, L1, L2, N
    CHARACTER FNAM*20, ctmp*4
    LOGICAL LDEF

! function
    INTEGER FILTINDX

! --------------- BEGIN -------------

    FNAM     = 'PARSE_NML_FILTLISTS'

! --------------------------------

    DO 100 i = 1, MXFILT_ALL

      ctmp = FILTLIST_FIT(i:i)
      if ( ctmp .NE. ' ' ) then
         ifiltdef = FILTINDX(ctmp)
         if ( ifiltDEF .LE.  0 ) then
           c1err = 'Invalid FILTLIST_FIT = ' // FILTLIST_FIT(1:60)
           c2err = 'Check &FITINP namelist'
           CALL MADABORT(FNAM, c1err, c2err)
         endif
         DOFIT_FILT(ifiltdef) = .TRUE.

         ifilt = IFILTDEF_INVMAP_SURVEY(ifiltdef)

         LDEF = (ifilt .GT. 0 .and. ifilt .LE. NFILTDEF_SURVEY)
         if ( (.NOT. LDEF) .and. ABORT_ON_BADFILTER ) then

            write(c1err,662) ctmp(1:1)
662           format('Fit-filter ',A,' is not a survey filter.')

            L1 = INDEX ( FILTLIST_FIT, ' ' ) - 1
            L2 = INDEX (SURVEY_FILTERS, ' ' ) - 1

            c2err = 'FILTLIST_FIT = ' // FILTLIST_FIT(1:L1) //  & 
                 '  but SURVEY_FILTERS = ' // SURVEY_FILTERS(1:L2)
            CALL MADABORT(FNAM, c1err, c2err)
         endif
      endif

!  skip DUMP options after 20 filters
      if ( i .GE. 20 ) GOTO 100

      ctmp = FILTLIST_DMPFCN(i:i)
      if ( ctmp .NE. ' ' ) then
         ifilt = FILTINDX(ctmp)
         if ( ifilt .LE.  0 ) then
           c1err = 'Invalid FILTLIST_DMPFCN = ' // FILTLIST_DMPFCN
           c2err = 'Check &FITINP namelist'
           CALL MADABORT(FNAM, c1err, c2err)
         endif
            LDMPFCN(ifilt) = .TRUE.
            LDMPFCN(0)     = .TRUE.
      endif

      ctmp = FILTLIST_DMPFUN(i:i)
      if ( ctmp .NE. ' ' ) then
         ifilt = FILTINDX(ctmp)
         if ( ifilt .LE.  0 ) then
           c1err = 'Invalid FILTLIST_DMPFUN = ' // FILTLIST_DMPFUN
           c2err = 'Check &FITINP namelist'
           CALL MADABORT(FNAM, c1err, c2err)
         endif
         LDMPFUN(ifilt) = .TRUE.
      endif

      ctmp = NEARFILT_IGNORE_REST(i:i)
      if ( ctmp .NE. ' ' ) then
         ifilt = FILTINDX(ctmp)
         if ( ifilt .GT. 0 .and. ifilt .LT. MXFILT_ALL ) then
           NFILTDEF_IGNORE_REST = NFILTDEF_IGNORE_REST + 1
           N = NFILTDEF_IGNORE_REST
           ifiltdef_ignore_rest(N) = ifilt
         endif
      endif

100   CONTINUE

    RETURN
  END SUBROUTINE PARSE_NML_FILTLISTS

! ========================================
    SUBROUTINE FITNML_OVERRIDE(IERR)

    USE SNDATCOM
    USE FITINP_NML
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER IERR ! (O) 0 => OK

! local var
    CHARACTER ARG*(MXCHAR_ARG), ARGLIST(MXKEY_ARGS)*(MXCHAR_ARG)
    INTEGER i, LL, ilast, iuse
    LOGICAL FOUND_MATCH
! functions
    LOGICAL MATCH_NMLKEY, FOUND_MATCH_NMLKEY

! -------------- BEGIN --------------

    IERR = 0

    i = 2
    ilast = 2

    DO WHILE ( i .LE. NLINE_ARGS )

      CALL GETARG(i,ARG)
      LL = INDEX ( ARG, ' ' ) - 1

      if ( MATCH_NMLKEY('FITMODEL_NAME', 1,i,ARGLIST) ) then
          FITMODEL_NAME = ARGLIST(1)(1:MXCHAR_FILENAME)

      else if ( MATCH_NMLKEY('SALT2alpha', 1,i,ARGLIST) ) then
          READ(ARGLIST(1),*) SALT2alpha

      else if ( MATCH_NMLKEY('SALT2beta', 1,i,ARGLIST) ) then
          READ(ARGLIST(1),*) SALT2beta

      else if ( MATCH_NMLKEY('OPT_SALT2FIT', 1,i,ARGLIST) ) then
          READ(ARGLIST(1),*) OPT_SALT2FIT

      else if ( MATCH_NMLKEY('TREST_PEAKRENORM', 2,i,ARGLIST) ) then
          READ(ARGLIST(1),*) TREST_PEAKRENORM(1)
          READ(ARGLIST(2),*) TREST_PEAKRENORM(2)

      else if ( MATCH_NMLKEY('DELCHI2_REJECT', 1,i,ARGLIST) ) then
          READ(ARGLIST(1),*) DELCHI2_REJECT

      else if ( MATCH_NMLKEY('SIGNOISE_REJECT', 1,i,ARGLIST) ) then
          READ(ARGLIST(1),*) SIGNOISE_REJECT

! --- keep legacy variables TREST_REJECT and MJD_REJECT

      else if ( MATCH_NMLKEY('TREST_REJECT', 2,i,ARGLIST) ) then
          READ(ARGLIST(1),*) TREST_REJECT(1)
          READ(ARGLIST(2),*) TREST_REJECT(2)

      else if ( MATCH_NMLKEY('MJD_REJECT', 2, i,ARGLIST) ) then
          READ(ARGLIST(1),*) MJD_REJECT(1)
          READ(ARGLIST(2),*) MJD_REJECT(2)

      else if (MATCH_NMLKEY('FITWIN_TREST_FILTER',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_TREST_FILTER

      else if ( MATCH_NMLKEY('FITWIN_TREST', 2, i, ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_TREST(1)
          READ(ARGLIST(2),*) FITWIN_TREST(2)

      else if ( MATCH_NMLKEY('FITWIN_MJD', 2, i, ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_MJD(1)
          READ(ARGLIST(2),*) FITWIN_MJD(2)
      else if ( MATCH_NMLKEY('FITWIN_PEAKMJD', 2, i, ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_PEAKMJD(1)
          READ(ARGLIST(2),*) FITWIN_PEAKMJD(2)

      else if ( MATCH_NMLKEY('ADD_SALT2ERR_FROMZ', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) ADD_SALT2ERR_FROMz

      else if ( MATCH_NMLKEY('ENABLE_MAGSHIFT_SALT2',  & 
                  1, i, ARGLIST)) then
          READ(ARGLIST(1),*) ENABLE_MAGSHIFT_SALT2
      else if ( MATCH_NMLKEY('ENABLE_WAVESHIFT_SALT2',  & 
                  1, i, ARGLIST)) then
          READ(ARGLIST(1),*) ENABLE_WAVESHIFT_SALT2

      else if ( MATCH_NMLKEY('ALLOW_NEGFLUX_SALT2',  & 
                  1, i, ARGLIST)) then
          READ(ARGLIST(1),*) ALLOW_NEGFLUX_SALT2

      else if ( MATCH_NMLKEY('USE_MODEL_MAGERR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USE_MODEL_MAGERR

      else if ( MATCH_NMLKEY('FUDGE_MAGERR_MODEL', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGE_MAGERR_MODEL

      else if ( MATCH_NMLKEY('FUDGE_DATAERR_SCALE', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGE_DATAERR_SCALE

      else if (MATCH_NMLKEY('FUDGE_MODELERR_SCALE',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGE_MODELERR_SCALE

      else if (MATCH_NMLKEY('FUDGE_FITERR_MAXFRAC',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGE_FITERR_MAXFRAC

      else if (MATCH_NMLKEY('FUDGE_FITERR_TREST', 4,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGE_FITERR_TREST(1)
          READ(ARGLIST(2),*) FUDGE_FITERR_TREST(2)
          READ(ARGLIST(3),*) FUDGE_FITERR_TREST(3)

      else if (MATCH_NMLKEY('FUDGE_FITERR_RESTLAM', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGE_FITERR_RESTLAM(1)
          READ(ARGLIST(2),*) FUDGE_FITERR_RESTLAM(2)

      else if(MATCH_NMLKEY('FUDGE_FITERR_PASSBANDS',1,i,ARGLIST)) then
          FUDGE_FITERR_PASSBANDS = ARGLIST(1)(1:80)

      else if(MATCH_NMLKEY('FUDGEALL_MAXFRAC',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGEALL_MAXFRAC

      else if(MATCH_NMLKEY('FUDGEALL_ITER1_MAXFRAC',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FUDGEALL_ITER1_MAXFRAC

      else if(MATCH_NMLKEY('MAX_INTEGPDF',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) MAX_INTEGPDF

      else if ( MATCH_NMLKEY('FITWIN_PROB', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_PROB(1)
          READ(ARGLIST(2),*) FITWIN_PROB(2)

      else if ( MATCH_NMLKEY('FITWIN_PROB_ITER1', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_PROB_ITER1(1)
          READ(ARGLIST(2),*) FITWIN_PROB_ITER1(2)

      else if ( MATCH_NMLKEY('FITWIN_SHAPE_ITER1', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_SHAPE_ITER1(1)
          READ(ARGLIST(2),*) FITWIN_SHAPE_ITER1(2)

      else if ( MATCH_NMLKEY('FITWIN_COLOR_ITER1', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_COLOR_ITER1(1)
          READ(ARGLIST(2),*) FITWIN_COLOR_ITER1(2)

      else if ( MATCH_NMLKEY('FITWIN_CHI2RED_INI', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_CHI2RED_INI(1)
          READ(ARGLIST(2),*) FITWIN_CHI2RED_INI(2)

      else if ( MATCH_NMLKEY('FITWIN_CHI2RED_INI2', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_CHI2RED_INI2(1)
          READ(ARGLIST(2),*) FITWIN_CHI2RED_INI2(2)

      else if ( MATCH_NMLKEY('FITWIN_NOMARG_PROB',2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_NOMARG_PROB(1)
          READ(ARGLIST(2),*) FITWIN_NOMARG_PROB(1)

      else if ( MATCH_NMLKEY('FITWIN_CHI2SIGMA', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_CHI2SIGMA(1)
          READ(ARGLIST(2),*) FITWIN_CHI2SIGMA(2)

      else if ( MATCH_NMLKEY('FITWIN_ZPULL', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_ZPULL(1)
          READ(ARGLIST(2),*) FITWIN_ZPULL(2)

      else if ( MATCH_NMLKEY('FITWIN_ZPHOT', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_ZPHOT(1)
          READ(ARGLIST(2),*) FITWIN_ZPHOT(2)

      else if ( MATCH_NMLKEY('FITWIN_SHAPE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_SHAPE(1)
          READ(ARGLIST(2),*) FITWIN_SHAPE(2)

      else if ( MATCH_NMLKEY('FITWIN_COLOR', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_COLOR(1)
          READ(ARGLIST(2),*) FITWIN_COLOR(2)

      else if ( MATCH_NMLKEY('FITWIN_COV_OFFDIAG',2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_COV_OFFDIAG(1)
          READ(ARGLIST(2),*) FITWIN_COV_OFFDIAG(2)

      else if ( MATCH_NMLKEY('FITWIN_PEAKMJD_ERR', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_PEAKMJD_ERR(1)
          READ(ARGLIST(2),*) FITWIN_PEAKMJD_ERR(2)

      else if ( MATCH_NMLKEY('FITWIN_MB_ERR', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_MB_ERR(1)
          READ(ARGLIST(2),*) FITWIN_MB_ERR(2)

      else if ( MATCH_NMLKEY('FITWIN_SHAPE_ERR', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_SHAPE_ERR(1)
          READ(ARGLIST(2),*) FITWIN_SHAPE_ERR(2)

      else if ( MATCH_NMLKEY('FITWIN_COLOR_ERR', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_COLOR_ERR(1)
          READ(ARGLIST(2),*) FITWIN_COLOR_ERR(2)

      else if (MATCH_NMLKEY('FITWIN_PEAKMJD_ERRz1',2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_PEAKMJD_ERRz1(1)
          READ(ARGLIST(2),*) FITWIN_PEAKMJD_ERRz1(2)

      else if (MATCH_NMLKEY('FITWIN_MB_ERRz1', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_MB_ERRz1(1)
          READ(ARGLIST(2),*) FITWIN_MB_ERRz1(2)

      else if (MATCH_NMLKEY('FITWIN_SHAPE_ERRz1', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_SHAPE_ERRz1(1)
          READ(ARGLIST(2),*) FITWIN_SHAPE_ERRz1(2)

      else if (MATCH_NMLKEY('FITWIN_COLOR_ERRz1', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) FITWIN_COLOR_ERRz1(1)
          READ(ARGLIST(2),*) FITWIN_COLOR_ERRz1(2)

      else if (MATCH_NMLKEY('PRIOR_ZERRSCALE', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_ZERRSCALE

      else if (MATCH_NMLKEY('PRIOR_MUERRSCALE', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_MUERRSCALE

      else if (MATCH_NMLKEY('OPT_MNSTAT_COV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_MNSTAT_COV

      else if (MATCH_NMLKEY('OPT_PRIOR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_PRIOR

      else if (MATCH_NMLKEY('OPT_PRIOR_AV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_PRIOR_AV

      else if (MATCH_NMLKEY('OPT_PHOTOZ', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_PHOTOZ

      else if (MATCH_NMLKEY('PHOTODZ_REJECT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PHOTODZ_REJECT

      else if (MATCH_NMLKEY('PHOTODZ1Z_REJECT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PHOTODZ1Z_REJECT

      else if (MATCH_NMLKEY('PHOTOZ_ITER1_LAMRANGE',2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PHOTOZ_ITER1_LAMRANGE(1)
          READ(ARGLIST(2),*) PHOTOZ_ITER1_LAMRANGE(2)

      else if (MATCH_NMLKEY('PHOTOZ_BOUND', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PHOTOZ_BOUND(1)
          READ(ARGLIST(2),*) PHOTOZ_BOUND(2)

! - - - -
      else if (MATCH_NMLKEY('SCALE_NBIN_COURSE_PHOTOZ',  1, i, ARGLIST) ) then
          READ(ARGLIST(1),*) SCALE_NBIN_COURSE_PHOTOZ

      else if (MATCH_NMLKEY('NBINc_COURSE_PHOTOZ',  1, i, ARGLIST) ) then
          READ(ARGLIST(1),*) NBINc_COURSE_PHOTOZ
      else if (MATCH_NMLKEY('NBINs_COURSE_PHOTOZ',  1, i, ARGLIST) ) then
          READ(ARGLIST(1),*) NBINs_COURSE_PHOTOZ
      else if (MATCH_NMLKEY('NBINt_COURSE_PHOTOZ',  1, i, ARGLIST) ) then
          READ(ARGLIST(1),*) NBINt_COURSE_PHOTOZ
      else if (MATCH_NMLKEY('NBINz_COURSE_PHOTOZ',  1, i, ARGLIST) ) then
          READ(ARGLIST(1),*) NBINz_COURSE_PHOTOZ

      else if (MATCH_NMLKEY('RANGEc_COURSE_PHOTOZ',  2, i, ARGLIST) ) then
          READ(ARGLIST(1),*) RANGEc_COURSE_PHOTOZ(1)
          READ(ARGLIST(2),*) RANGEc_COURSE_PHOTOZ(2)
      else if (MATCH_NMLKEY('RANGEs_COURSE_PHOTOZ',  2, i, ARGLIST) ) then
          READ(ARGLIST(1),*) RANGEs_COURSE_PHOTOZ(1)
          READ(ARGLIST(2),*) RANGEs_COURSE_PHOTOZ(2)
      else if (MATCH_NMLKEY('RANGEt_COURSE_PHOTOZ',  2, i, ARGLIST) ) then
          READ(ARGLIST(1),*) RANGEt_COURSE_PHOTOZ(1)
          READ(ARGLIST(2),*) RANGEt_COURSE_PHOTOZ(2)
      else if (MATCH_NMLKEY('RANGEz_COURSE_PHOTOZ',  2, i, ARGLIST) ) then
          READ(ARGLIST(1),*) RANGEz_COURSE_PHOTOZ(1)
          READ(ARGLIST(2),*) RANGEz_COURSE_PHOTOZ(2)
! - - - - 

      else if (MATCH_NMLKEY('PARLIST_MCMC_PHOTOZ',5,i,ARGLIST)) then
          READ(ARGLIST(1),*) PARLIST_MCMC_PHOTOZ(1)
          READ(ARGLIST(2),*) PARLIST_MCMC_PHOTOZ(2)
          READ(ARGLIST(3),*) PARLIST_MCMC_PHOTOZ(3)
          READ(ARGLIST(4),*) PARLIST_MCMC_PHOTOZ(4)
          READ(ARGLIST(5),*) PARLIST_MCMC_PHOTOZ(5)

      else if (MATCH_NMLKEY('PRIOR_MJDSIG', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_MJDSIG

      else if (MATCH_NMLKEY('PRIOR_AVEXP', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_AVEXP(1)
          READ(ARGLIST(2),*) PRIOR_AVEXP(2)

      else if (MATCH_NMLKEY('PRIOR_AVWGT', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_AVWGT(1)
          READ(ARGLIST(2),*) PRIOR_AVWGT(2)

      else if (MATCH_NMLKEY('PRIOR_AVRES', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_AVRES

! -------- legacy --------
      else if (MATCH_NMLKEY('PRIOR_LUMIPAR_RANGE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_LUMIPAR_RANGE(1)
          READ(ARGLIST(2),*) PRIOR_LUMIPAR_RANGE(2)

      else if (MATCH_NMLKEY('PRIOR_LUMIPAR_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_LUMIPAR_SIGMA
! -------------------------

      else if (MATCH_NMLKEY('PRIOR_SHAPE_RANGE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_SHAPE_RANGE(1)
          READ(ARGLIST(2),*) PRIOR_SHAPE_RANGE(2)

      else if (MATCH_NMLKEY('PRIOR_SHAPE_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_SHAPE_SIGMA

! - - -
      else if (MATCH_NMLKEY('PRIOR_SHAPE2_RANGE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_SHAPE2_RANGE(1)
          READ(ARGLIST(2),*) PRIOR_SHAPE2_RANGE(2)

      else if (MATCH_NMLKEY('PRIOR_SHAPE2_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_SHAPE2_SIGMA

      else if (MATCH_NMLKEY('PRIOR_DELTA_PROFILE', 4,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_DELTA_PROFILE(1)
          READ(ARGLIST(2),*) PRIOR_DELTA_PROFILE(2)
          READ(ARGLIST(3),*) PRIOR_DELTA_PROFILE(3)
          READ(ARGLIST(4),*) PRIOR_DELTA_PROFILE(4)

      else if (MATCH_NMLKEY('PRIOR_COLOR_RANGE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_COLOR_RANGE(1)
          READ(ARGLIST(2),*) PRIOR_COLOR_RANGE(2)

      else if (MATCH_NMLKEY('PRIOR_COLOR_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_COLOR_SIGMA

      else if (MATCH_NMLKEY('PRIOR_DMU_RANGE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_DMU_RANGE(1)
          READ(ARGLIST(2),*) PRIOR_DMU_RANGE(2)

      else if (MATCH_NMLKEY('PRIOR_DMU_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) PRIOR_DMU_SIGMA

      else if (MATCH_NMLKEY('NGRID_PDF', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) NGRID_PDF

      else if (MATCH_NMLKEY('NSIGMA_PDF', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) NSIGMA_PDF

      else if (MATCH_NMLKEY('VARLIST_PDF', 1,i,ARGLIST)) then
          VARLIST_PDF = ARGLIST(1)(1:20)

      else if (MATCH_NMLKEY('OPT_COVAR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_COVAR

      else if (MATCH_NMLKEY('OPT_COVAR_FLUX', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_COVAR_FLUX

      else if (MATCH_NMLKEY('OPT_COVAR_LCFIT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_COVAR_LCFIT

      else if (MATCH_NMLKEY('OPT_COVAR_MWXTERR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_COVAR_MWXTERR

      else if (MATCH_NMLKEY('OPT_XTMW_ERR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_XTMW_ERR    ! legacy variable

      else if (MATCH_NMLKEY('SCALE_COVAR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) SCALE_COVAR

      else if (MATCH_NMLKEY('OPT_SNXT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_SNXT

      else if (MATCH_NMLKEY('OPT_NEARFILT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_NEARFILT

      else if (MATCH_NMLKEY('OPT_KCORERR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_KCORERR

      else if (MATCH_NMLKEY('LKCOR_AVWARP', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LKCOR_AVWARP

      else if (MATCH_NMLKEY('OPT_LANDOLT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_LANDOLT

      else if (MATCH_NMLKEY('UCOR_BXB', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) UCOR_BXB

      else if (MATCH_NMLKEY('RESTLAMBDA_FITRANGE', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) RESTLAMBDA_FITRANGE(1)
          READ(ARGLIST(2),*) RESTLAMBDA_FITRANGE(2)

      else if (MATCH_NMLKEY('UVLAM_EXTRAPFLUX', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) UVLAM_EXTRAPFLUX

      else if(MATCH_NMLKEY('SIMFIT_IDEAL_PRESCALE',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) SIMFIT_IDEAL_PRESCALE

      else if(MATCH_NMLKEY('USESIM_COLOR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_COLOR

      else if(MATCH_NMLKEY('USESIM_AV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_AV

      else if(MATCH_NMLKEY('USESIM_RV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_RV

! ------------- legacy variable
      else if(MATCH_NMLKEY('USESIM_LUMIPAR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_LUMIPAR
! -------------
      else if(MATCH_NMLKEY('USESIM_SHAPE', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_SHAPE

      else if(MATCH_NMLKEY('USESIM_PEAKMJD', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_PEAKMJD

      else if(MATCH_NMLKEY('USESIM_DLMAG', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_DLMAG

      else if(MATCH_NMLKEY('INIVAL_RV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_RV

      else if(MATCH_NMLKEY('INIVAL_AVRV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_AVRV

      else if(MATCH_NMLKEY('INISTP_AVRV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_AVRV

      else if(MATCH_NMLKEY('INISTP_PEAKMJD', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_PEAKMJD

      else if(MATCH_NMLKEY('INIVAL_PEAKMJD', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_PEAKMJD

      else if(MATCH_NMLKEY('INISTP_SHAPE',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_SHAPE

      else if(MATCH_NMLKEY('INISTP_DLMAG',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_DLMAG

      else if(MATCH_NMLKEY('INISTP_X0',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_X0
! 
      else if(MATCH_NMLKEY('INIVAL_GRIDSEARCH_DPEAKMJD',  & 
                   3,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_GRIDSEARCH_DPEAKMJD(1)
          READ(ARGLIST(2),*) INIVAL_GRIDSEARCH_DPEAKMJD(2)
          READ(ARGLIST(3),*) INIVAL_GRIDSEARCH_DPEAKMJD(3)

      else if(MATCH_NMLKEY('USESIM_INIVAL', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) USESIM_INIVAL

      else if(MATCH_NMLKEY('INIVAL_GRIDSEARCH_COLOR',  & 
                  3,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_GRIDSEARCH_COLOR(1)
          READ(ARGLIST(2),*) INIVAL_GRIDSEARCH_COLOR(2)
          READ(ARGLIST(3),*) INIVAL_GRIDSEARCH_COLOR(3)
! 
      else if(MATCH_NMLKEY('LANDOLT_COLOR_SHIFT',5,i,ARGLIST)) then
          READ(ARGLIST(1),*) LANDOLT_COLOR_SHIFT(1)  ! k0
          READ(ARGLIST(2),*) LANDOLT_COLOR_SHIFT(2)  ! k1
          READ(ARGLIST(3),*) LANDOLT_COLOR_SHIFT(3)  ! k2
          READ(ARGLIST(4),*) LANDOLT_COLOR_SHIFT(4)  ! k3
          READ(ARGLIST(5),*) LANDOLT_COLOR_SHIFT(5)  ! k4

      else if(MATCH_NMLKEY('CHECK_CRAZYFITERR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) CHECK_CRAZYFITERR

      else if(MATCH_NMLKEY('DOFIT_PHOTOZ', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) DOFIT_PHOTOZ

      else if(MATCH_NMLKEY('SKIP_PHOTOZ_INIT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) SKIP_PHOTOZ_INIT

      else if(MATCH_NMLKEY('LDMP_PHOTOZ_DROPFILTER',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LDMP_PHOTOZ_DROPFILTER

      else if(MATCH_NMLKEY('DOCHI2_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) DOCHI2_SIGMA

      else if(MATCH_NMLKEY('OPT_CHI2_SIGMA', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_CHI2_SIGMA

      else if(MATCH_NMLKEY('LAMREST_MODEL_SMOOTH',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LAMREST_MODEL_SMOOTH

      else if(MATCH_NMLKEY('FILTER_FITMAGDIF',1,i,ARGLIST)) then
          FILTER_FITMAGDIF = ARGLIST(1)(1:4)

      else if(MATCH_NMLKEY('FILTLIST_FITRESTMAG',1,i,ARGLIST)) then
          FILTLIST_FITRESTMAG = ARGLIST(1)(1:12)

      else if(MATCH_NMLKEY('LUMIFIX_FITRESTMAG',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LUMIFIX_FITRESTMAG   ! legacy

      else if(MATCH_NMLKEY('SHAPEFIX_FITRESTMAG', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) SHAPEFIX_FITRESTMAG

      else if(MATCH_NMLKEY('LAMEXTRAP_FITRESTMAG', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LAMEXTRAP_FITRESTMAG

      else if(MATCH_NMLKEY('DLAMTOL_FITRESTMAG', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) DLAMTOL_FITRESTMAG

      else if(MATCH_NMLKEY('FILTLIST_FIT', 1,i,ARGLIST)) then
          FILTLIST_FIT = ARGLIST(1)(1:80)

      else if(MATCH_NMLKEY('FILTLIST_DMPFCN', 1,i,ARGLIST)) then
          FILTLIST_DMPFCN = ARGLIST(1)(1:20)

      else if(MATCH_NMLKEY('FILTLIST_DMPFUN', 1,i,ARGLIST)) then
          FILTLIST_DMPFUN = ARGLIST(1)(1:20)

      else if(MATCH_NMLKEY('TREST_DMPFUN', 2,i,ARGLIST)) then
          READ(ARGLIST(1),*) TREST_DMPFUN(1)
          READ(ARGLIST(2),*) TREST_DMPFUN(2)

      else if(MATCH_NMLKEY('NEARFILT_IGNORE_REST',1,i,ARGLIST)) then
          NEARFILT_IGNORE_REST = ARGLIST(1)(1:20)

      else if(MATCH_NMLKEY('LTRACE',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LTRACE

      else if(MATCH_NMLKEY('LFIXPAR_ALL',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LFIXPAR_ALL

      else if(MATCH_NMLKEY('LFIXPAR_ADJUST',1,i,ARGLIST)) then
          READ(ARGLIST(1),*) LFIXPAR_ADJUST

      else if(MATCH_NMLKEY('MINOS_ERRMAX_BAD', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) MINOS_ERRMAX_BAD

      else if(MATCH_NMLKEY('INIVAL_SHAPE', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_SHAPE

      else if(MATCH_NMLKEY('INISTP_SHAPE', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_SHAPE

      else if(MATCH_NMLKEY('INIVAL_SHIFT_ERRFRAC', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_SHIFT_ERRFRAC

      else if(MATCH_NMLKEY('FRACERRDIF_REPEATFIT', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) FRACERRDIF_REPEATFIT

      else if(MATCH_NMLKEY('INIVAL_AV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_AV

      else if(MATCH_NMLKEY('INISTP_AV', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_AV

      else if(MATCH_NMLKEY('INIVAL_COLOR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_COLOR

      else if(MATCH_NMLKEY('INISTP_COLOR', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_COLOR

      else if(MATCH_NMLKEY('INIVAL_X0', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_X0

      else if(MATCH_NMLKEY('INIVAL_DLMAG', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_DLMAG

      else if(MATCH_NMLKEY('INIVAL_PHOTOZ', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INIVAL_PHOTOZ

      else if(MATCH_NMLKEY('INISTP_PHOTOZ', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) INISTP_PHOTOZ

! --- Vmax

      else if(MATCH_NMLKEY('MAGLIM_VMAX', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) MAGLIM_VMAX

      else if(MATCH_NMLKEY('OPT_VMAX', 1,i,ARGLIST)) then
          READ(ARGLIST(1),*) OPT_VMAX

! - - -
      else if(MATCH_NMLKEY('CCID_DUMP_CHI2_MATRIX', 1,i,ARGLIST)) then
          CCID_DUMP_CHI2_MATRIX = ARGLIST(1)(1:20)

       endif

! set logical flag for used LINE_ARGS

       FOUND_MATCH = FOUND_MATCH_NMLKEY(i,ilast,ARG,ARGLIST(1))
       IF ( FOUND_MATCH ) THEN
         DO iuse = ilast, i
            USE_LINE_ARGS(iuse) = .TRUE.
         ENDDO
       ENDIF

       i = i + 1
       ilast = i

    ENDDO

    RETURN
  END SUBROUTINE FITNML_OVERRIDE


! ==========================================
    SUBROUTINE FITINI_PARVAL ( iter )
! 
! Init INIVAL_ and INISTP arrays.
! 
! Apr 13 2020: fix INISTP[VAL]_SHAPE logic for MLCS2k2 and SNOOPY
! Jun 04 2021: if USESIM_REDSHIFT, set z errors to 1.0E-4
! Dec 10 2025: open default THETA window to +_4 for BAYESN
! ----------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    USE FILTCOM
    USE FITIDEALCOM

    IMPLICIT NONE

    INTEGER  & 
         iter  ! (I) fit iteration: 1,2, ... NFIT_ITERATION

! local var

    INTEGER  ipar, ITER_LAST
    REAL*8   PEAKMJD, VALTMP, ERRTMP
    LOGICAL  FIRST_ITER, JG

! SALT2 stuff
    REAL*8 MU, MUMIN, MUMAX, x0, X0MIN, X0MAX, mb, S2a, S2b

! functions
    REAL*8  SALT2x0calc, SALT2mBcalc  ! functions
    LOGICAL FIRST_ITERATION

! ---------- BEGIN -------------

    FIRST_ITER = FIRST_ITERATION(ITER) .and. (.not. LREPEAT_ITER)

    IF ( ITER .EQ. 1 ) THEN
       ITER_LAST = 1
    ELSE
       ITER_LAST = ITER - 1
    ENDIF

! init everything to BIDON value or to value of last iteration

    DO ipar = 1, NFITPAR_MN
      IF ( FIRST_ITER ) then
         INIVAL(ipar)       =  -9.0
         INISTP(ipar)       =   0.0
      ELSE
         VALTMP       =  FITVAL(ipar,ITER_LAST)
         ERRTMP       =  FITERR(ipar,ITER_LAST)
         INIVAL(ipar) =  VALTMP + ERRTMP*INIVAL_SHIFT_ERRFRAC
         INISTP(ipar) =  ERRTMP
      ENDIF

    ENDDO


! always modify ITERation parameter
    ipar            = IPAR_ITER
    INIVAL(IPAR)    = DBLE(iter)
    INISTP(IPAR)    = 0.0

! --------------------------------
! special code to emulate Julien's SALT2 recipe
    JG = OPT_SALT2FIT .EQ. 4  ! emulate Julien/snfit (for debug)
    if ( JG .and. ITER > 1 ) then !
         INISTP(IPAR_SHAPE) = INISTP_SHAPE  ! restore
    endif

! check special fitting options
    CALL FITRESTMAG_PREP(ITER)
    CALL FITMAGDIF_PREP(ITER)
    CALL SIMFIT_IDEAL_PREP(ITER)

! continue below on 1st iteration only.
    IF ( .NOT. FIRST_ITER ) RETURN

    SIMCHI2_CHEAT  = 0.0

    ipar           = IPAR_ISN
    INIVAL(IPAR)   = DBLE(N_SNLC_FIT+1) ! changed from ISN, Dec 2013
    INISTP(IPAR)   = 0.0

! - - -  AV - - - -
    ipar            =  IPAR_AV
    INIVAL(IPAR)    =  0.1
    INISTP(IPAR)    =  INISTP_AV
    INIBND(1,IPAR)  =  -2.0
    INIBND(2,IPAR)  =  +6.0

! - - - - RV - - - -
    ipar            =  IPAR_RV
    if ( INISTP_AVRV .GT. 0.0 ) THEN
      INIVAL(IPAR)    =  INIVAL(IPAR_AV) / RV_MWCOLORLAW
      INISTP(IPAR)    =  INISTP_AVRV
      INIBND(1,IPAR)  =  -20.0
      INIBND(2,IPAR)  =   20.0
    ELSE
      INIVAL(IPAR)    =  INIVAL_RV
      INISTP(IPAR)    =  INISTP_RV
      INIBND(1,IPAR)  =  -20.0
      INIBND(2,IPAR)  =   20.0
    ENDIF

! - - - - PKMJD - - -
    ipar            =  IPAR_PEAKMJD
    PEAKMJD         =  SNLC_SEARCH_PEAKMJD    ! approx peak MJD
    INIVAL(IPAR)    =  PEAKMJD - MJDOFF
    INISTP(IPAR)    =  INISTP_PEAKMJD         ! initial step size, days

    INIBND(1,IPAR)  =  INIVAL(IPAR) - 100.0
    INIBND(2,IPAR)  =  INIVAL(IPAR) + 100.0

    FITVAL(IPAR,0)  =  INIVAL(IPAR)

! - - - - - DLMAG - - - - -
    ipar            =  IPAR_DLMAG
    INIVAL(IPAR)    =  SNLC_DLMAG
    INISTP(IPAR)    =  INISTP_DLMAG         ! initial step size, mag
    INIBND(1,IPAR)  =   10.0   ! 7/29/2008: changed from -10,80
    INIBND(2,IPAR)  =  +70.0

    if ( USESIM_REDSHIFT ) THEN
       SNLC_REDSHIFT = SIM_REDSHIFT_HELIO + REDSHIFT_FINAL_SHIFT
       SNLC_ZHELIO   = SIM_REDSHIFT_HELIO + REDSHIFT_FINAL_SHIFT
       SNLC_ZCMB     = SIM_REDSHIFT_CMB   + REDSHIFT_FINAL_SHIFT
       SNLC_ZHD      = SIM_REDSHIFT_CMB   + REDSHIFT_FINAL_SHIFT

!  Jun 2021: set tiny z errors too
       SNLC_REDSHIFT_ERR = 1.0E-4
       SNLC_ZHELIO_ERR   = 1.0E-4
       SNLC_ZCMB_ERR     = 1.0E-4
       SNLC_ZHD_ERR      = 1.0E-4
    endif

! - - - -  zPHOT - - - - -
    ipar            =  IPAR_zPHOT
    INISTP(IPAR)    =  INISTP_PHOTOZ         ! initial step size
    INIVAL(IPAR)    =  SNLC_REDSHIFT
    INIBND(1,IPAR)  =  -1.0
    INIBND(2,IPAR)  =  +4.0

! - - - - shape/stretch - - - -
! note that INIVAL(IPAR_SHAPE,IPAR_SHAPE2) depend
! on the model and are evaluated below.
    ipar            =  IPAR_SHAPE
    INISTP(IPAR)    =  INISTP_SHAPE      ! initial step size
    INIBND(1,IPAR)  =  -20.0
    INIBND(2,IPAR)  =  +20.0

    ipar            =  IPAR_SHAPE2
    INIVAL(IPAR)    =  0.0
    INISTP(IPAR)    =  0.0
    INIBND(1,IPAR)  =  -20.0
    INIBND(2,IPAR)  =  +20.0

! -------------------------------------------
! check for valid model and set model-dependent parameters

    IF (  FITMODEL_INDEX .EQ. MODEL_STRETCH  & 
       .or. FITMODEL_INDEX .EQ. MODEL_STRETCH2 ) THEN

       INIVAL(IPAR_SHAPE)    =  1.0
       INIBND(1,IPAR_SHAPE)  =   0.0
       INIBND(2,IPAR_SHAPE)  =  +3.0

       IF (  FITMODEL_INDEX .EQ. MODEL_STRETCH2 ) THEN
          INIVAL(IPAR_SHAPE2)    =  1.0
          INISTP(IPAR_SHAPE2)    =  0.1
          INIBND(1,IPAR_SHAPE2)  =  0.0
          INIBND(2,IPAR_SHAPE2)  = +3.0
       ENDIF

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_MLCS2k2 ) THEN

       INIVAL(IPAR_SHAPE)    =  -0.1
       INISTP(IPAR_SHAPE)    =   0.3

       INIVAL(IPAR_COLOR)    =  INIVAL_AV
       INISTP(IPAR_COLOR)    =  INISTP_AV

! Mar 24, 2012: set bound on AV and DELTA (for photoz fit)

       INIBND(1,IPAR_COLOR) = -3.0  ! AV
       INIBND(2,IPAR_COLOR) =  5.0

       INIBND(1,IPAR_SHAPE) = -1.0  ! DELTA
       INIBND(2,IPAR_SHAPE) = +3.0

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SNOOPY ) THEN

       if (INIVAL_SHAPE==NULLVAL) INIVAL(IPAR_SHAPE) = 1.1
       INISTP(IPAR_SHAPE)    =  INISTP_SHAPE
       INIVAL(IPAR_COLOR)    =  INIVAL_AV
       INISTP(IPAR_COLOR)    =  INISTP_AV

       INIBND(1,IPAR_COLOR) =  -3.0   ! AV (July 2023)
       INIBND(2,IPAR_COLOR) =  10.0   ! extend for events like 2002cv


    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN

       if (INIVAL_SHAPE==NULLVAL) INIVAL(IPAR_SHAPE) = 0.001
       INISTP(IPAR_SHAPE)   =  INISTP_SHAPE    ! initial step size

       INIVAL(IPAR_COLOR)    =  INIVAL_COLOR
       INISTP(IPAR_COLOR)    =  INISTP_COLOR

! Dec 2023: check for M2 component
       if ( NSHAPEPAR > 1 ) then
         INISTP(IPAR_SHAPE2)   = INISTP_SHAPE2
         INIVAL(IPAR_SHAPE2)   = INIVAL_SHAPE2
         INIBND(1,IPAR_SHAPE2) = -4.0
         INIBND(2,IPAR_SHAPE2) =  4.0
       endif

! for SALT2, DLMAG is replaced by x0:

       if ( SNLC_DLMAG .GT. 0.0 ) THEN
           MU    = SNLC_DLMAG
       else
           MU  = 35.5555 ! anything to avoid NaN
       endif
       MUMIN = 20.0
       MUMAX = 70.0

! note that X08min <-> MU8MAX and vice-versa
       S2a = 0.13  ! any non-zero of alpha to avoid abort
       S2b = 3.20  ! idem for betga

       X0    = SALT2x0calc( S2a, S2b, ZERO8, ZERO8, MU )
       X0MAX = SALT2x0calc( S2a, S2b, ZERO8, ZERO8, MUMIN )
       X0MIN = SALT2x0calc( S2a, S2b, ZERO8, ZERO8, MUMAX )

       MB = SALT2mBcalc( X0 )

       IF ( OPT_SALT2FIT .EQ. 0 .or. JG) THEN
         INIVAL(IPAR_X0)    = x0
         INISTP(IPAR_X0)    = x0 * 0.1

         INIBND(1,IPAR_X0)  = x0 * 0.01
         INIBND(2,IPAR_X0)  = x0 * 100.0

         if ( JG .and. ITER .EQ. 1 ) then ! emulate Julien
            INISTP(IPAR_SHAPE) = 0.0   ! fix x1 on 1st iter
         endif

       ELSE IF ( OPT_SALT2FIT .EQ. 1 ) THEN  ! fit x0
         INIVAL(IPAR_X0)    = log10(x0)
         INISTP(IPAR_X0)    = 0.1
         INIBND(1,IPAR_X0)  = log10(x0min)
         INIBND(2,IPAR_X0)  = log10(x0max)

       ELSE IF ( OPT_SALT2FIT .EQ. 2 ) THEN  ! fit delta-mu
         INIVAL(IPAR_X0)    =   0.001   ! MUDIF
         INISTP(IPAR_X0)    =   0.1
         INIBND(1,IPAR_X0)  = -10.0
         INIBND(2,IPAR_X0)  = +10.0
       ENDIF

! if user fixes DLMAG, then fix X0.

       IF ( INISTP_DLMAG .EQ. 0.0 ) then
         INISTP(IPAR_X0) = 0.0
       ENDIF

       INIVAL(IPAR_MB) = MB
       INISTP(IPAR_MB) = 0.0

! make sure that alpha & beta are defined for photoZ fit.

       IF ( DOFIT_PHOTOZ ) THEN
         if ( SALT2alpha .EQ. -9.0 .or. SALT2beta .EQ. -9.0 ) then
           c1err = 'SALT2alpha and/or SALT2beta not defined:'
           c2err = 'these must be defined for photoZ fit'
           CALL MADABORT("FITINI_PARVAL", c1err, c2err)
         endif
       ENDIF

! set bounds on color and stretch
! Mar 24, 2012: reduce range from +-2
! Dec 5 2013: reduce max color frmo +2 to +1.
! Aug 30 2021: max color -> 2 to fit redder events

       INIBND(1,IPAR_COLOR) = -1.6  ! c
       INIBND(2,IPAR_COLOR) = +2.0

       INIBND(1,IPAR_SHAPE) = -5.0  ! x1
       INIBND(2,IPAR_SHAPE) = +5.0

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_BAYESN ) THEN
       ! May 21 2023

       INIVAL(IPAR_SHAPE)    =   0.1  ! THETA
       INISTP(IPAR_SHAPE)    =   0.1

       INIVAL(IPAR_COLOR)    =  INIVAL_AV
       INISTP(IPAR_COLOR)    =  INISTP_AV

! set bound on AV and DELTA

       INIBND(1,IPAR_COLOR) = -3.0  ! AV
       INIBND(2,IPAR_COLOR) =  5.0

       INIBND(1,IPAR_SHAPE) = -4.0  ! THETA min
       INIBND(2,IPAR_SHAPE) = +4.0  ! THETA max

    ELSE IF ( FITMODEL_INDEX .EQ. MODEL_SIMSED ) THEN

       INIVAL(IPAR_SHAPE)  =  0.0
       INISTP(IPAR_SHAPE)  =  0.0
       INIVAL(IPAR_COLOR)  =  0.0
       INISTP(IPAR_COLOR)  =  0.0

       INIVAL(IPAR_X0)    =   0.001   ! MUDIF
       INISTP(IPAR_X0)    =   0.1
       INIBND(1,IPAR_X0)  = -10.0
       INIBND(2,IPAR_X0)  = +10.0

! if user fixes DLMAG, then fix X0.
       IF ( INISTP_DLMAG .EQ. 0.0 ) then
         INISTP(IPAR_X0) = 0.0
       ENDIF

    ELSE
       write(c1err,660) FITMODEL_INDEX
660      format('Invalid FITMODEL_INDEX = ', i4 )
       CALL MADABORT("FITINI_PARVAL", c1err, "")
    ENDIF

! ------------------------

! check if user has specified any INITIAL values.
! To fix a parameter value, must also set INISTP_XXX = 0.0


    IF ( INIVAL_PEAKMJD .GT. 40000. )  & 
           INIVAL_PEAKMJD = INIVAL_PEAKMJD - SNGL(MJDOFF)

    IF ( INIVAL_PEAKMJD .GT. NULLVAL )  & 
           INIVAL(IPAR_PEAKMJD) = INIVAL_PEAKMJD

! AV & COLOR are the same parameter index;
! so allow one or the other.

    IF ( INIVAL_AV .GT. NULLVAL ) THEN
        INIVAL(IPAR_AV) = INIVAL_AV
    ELSE IF ( INIVAL_COLOR .GT. NULLVAL ) THEN
        INIVAL(IPAR_COLOR) = INIVAL_COLOR
    ENDIF

    IF ( INIVAL_RV .GT. NULLVAL .and. INISTP_AVRV .EQ. 0.0 )  & 
           INIVAL(IPAR_RV) = INIVAL_RV

    IF ( INIVAL_SHAPE .GT. NULLVAL )  & 
           INIVAL(IPAR_SHAPE) = INIVAL_SHAPE

    IF ( INIVAL_DLMAG .GT. NULLVAL )  & 
           INIVAL(IPAR_DLMAG) = INIVAL_DLMAG

    IF ( INIVAL_PHOTOZ .GT. NULLVAL )  & 
           INIVAL(IPAR_zPHOT) = INIVAL_PHOTOZ

    IF ( INIVAL_X0 .GT. NULLVAL )  & 
           INIVAL(IPAR_X0) = INIVAL_X0

! May 2022: check option to set all of the INIVAL to sim-values
!    Note that fit floats all params

    IF ( USESIM_INIVAL .or. DOFIT_IDEAL ) THEN

       if ( STDOUT_UPDATE ) then
          write(6,420) USESIM_INIVAL, DOFIT_IDEAL
420       format('   Set INIVAL = SIM value (USESIM_INIVAL=',L2,  & 
               '  DOFIT_IDEAL=',L2,')' )
          call flush(6)
       endif
       INIVAL(IPAR_PEAKMJD)  = SIM_PEAKMJD
       INIVAL(IPAR_X0)       = SIM_SALT2X0
       INIVAL(IPAR_SHAPE)    = SIM_SHAPEPAR
       INIVAL(IPAR_COLOR)    = SIM_COLORPAR
       INIVAL(IPAR_zPHOT)    = SIM_REDSHIFT_HELIO
    ENDIF
! --------------------------------------------
! store SIMVAL and check option to use sim values in fit.

    IF ( LSIM_SNANA) THEN
       SIMVAL_STORE(IPAR_AV)    = SIM_COLORPAR
       SIMVAL_STORE(IPAR_RV)    = SIM_COLORLAW

       if ( INISTP_AVRV .GT. 0.0 ) then
         SIMVAL_STORE(IPAR_AVRV)  = SIM_COLORPAR/SIM_COLORLAW
       endif

       SIMVAL_STORE(IPAR_PEAKMJD) = SIM_PEAKMJD
       SIMVAL_STORE(IPAR_SHAPE)   = SIM_SHAPEPAR
       SIMVAL_STORE(IPAR_zPHOT)   = SIM_REDSHIFT_HELIO

       IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) then
          SIMVAL_STORE(IPAR_X0)   = SIM_SALT2x0
       ELSE
          SIMVAL_STORE(IPAR_DLMAG)   = SIM_DLMAG
       ENDIF

! now check if want to fix a parameter with the simulated value.

       do ipar = 1, IPAR_MAX
          if ( USESIM_FITPAR(ipar) ) then
             INIVAL(ipar) = SIMVAL_STORE(ipar)
             INISTP(ipar) = 0.0

             IF ( ipar .EQ. IPAR_PEAKMJD ) then
                INIVAL(ipar) = INIVAL(ipar) - MJDOFF         ! Nov 2013
                INIVAL(ipar) = INIVAL(ipar) + SHIFT_SETPKMJD ! May 2020
             ENDIF
          endif
       enddo
    ENDIF  ! end LSIM_SNANA

! --------------
! set FITVAL on 1st interation since this array
! is used in the ADJUST & FITINI_XXXX routines.
! (exception for option that fixes parameters)

    do ipar = 1, IPAR_MAX
       FITVAL(ipar,iter) = INIVAL(ipar)
       FITERR(ipar,iter) = INISTP(ipar)
    enddo

    RETURN
  END SUBROUTINE FITINI_PARVAL 


! ==========================================
    SUBROUTINE FITINI_PHOTOZ ( iter , IERR)
! 
! Created Jul 11,2006 by R.Kessler
! Used only if DOFIT_PHOTOZ=T.
! Estimate initial PHOTOZ value and fill INIVAL(IPAR_zPHOT)
! 
! * if there is a valid host, then INIVAL = Zhost
! 
! * if no host and 1st iteration, loop over redshift in bins
!   of 0.05 with AV=0 and LUMIPAR=0; find min CHI2.
! 
! * if LREPEAT, set INIVAL = PHOTOZ from previous fit
! 
! Jan 2024: wrap Quantile debug prints under LDMP_Q flag
! May 2024:
!   + add IERR argument based on init_zPDF_spline
!   + fix bug and use MASK_PHOTOZ_SOURCE instead of OPT_PHOTOZ
! 
! Aug 06 2024: implement BIT_PHOTOZ_AUTO_INISTP bit in OPT_PHOTOZ
! Nov 07 2024: fix bug setting PHOTODZ_REJECT for zSPEC
! Dec 19 2024: print time to process this function
! Feb 02 2026: set LZDONE=T inside BTEST(MASK,BIT_BESTZ_GAUSS) if-block
! May 06 2026: check ABORT_ON_MISSING_QZPHOT
! --------------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE  ! added May 7 2026

! CDE,SNFITPAR.

    INTEGER  & 
         iter   &  ! (I) fit iteration: 1,2, ... NFIT_ITERATION
         ,IERR     ! (O) error flag

! local var

    INTEGER  IPAR, IPRINT, MASK, NQ
    LOGICAL  LZDONE, LPRINT
    REAL*8 ZHOST, ZHOST_ERR,  ZMIN, ZMAX, z, s, c, d
    REAL*8 ztmp_min, ztmp_max, STP
    REAL   t_start, t_end
    LOGICAL  LPZ_AUTO_INISTP, LDMP_REFAC
    CHARACTER BANNER*100, CZTMP*20, CCID_forC*(MXCHAR_CCID)

    REAL*8 MXRATIO_INIVAL_ZPHOT ! fix INIVAL_ZPHIOT if zERR/z < this
    REAL*8 MEAN, STD

    CHARACTER FNAM*14

! FCNSNLC args

    INTEGER IFLAG
    REAL*8  GRAD(MXFITPAR), CHI2GUESS, CHI2 
    REAL*8 GET_DIST8, USRFUN
    LOGICAL LEGACY
    EXTERNAL USRFUN, init_zPDF_spline

! --------------- BEGIN -----------------

    LEGACY = (DEBUG_FLAG == -202)  ! undo Feb 2 2026 fix below 

    IERR = 0
    FNAM = 'FITINI_PHOTOZ'
    LPRINT = STDOUT_UPDATE
    IPRINT = 0
    if (LPRINT) IPRINT = 1
    CCID_forC = SNLC_CCID(1:ISNLC_LENCCID) // char(0)

    IF ( USE_SNHOST_ZPHOT  ) THEN
       c1err = '&SNLCINP input USE_SNHOST_ZPHOT=T'
       c2err = 'not allowed with photo-z fits'
       CALL MADABORT(FNAM, c1err, c2err)
    ENDIF

    IF ( LFIXPAR_ALL  ) RETURN
    IF ( LSIM_SNANA .and. USESIM_REDSHIFT ) RETURN

    if ( STDOUT_UPDATE ) CALL CPU_TIME(t_start)
    PHOTOZ_ERR_SNFIT  = -9.0
    PHOTOZ_ERR_SNHOST = -9.0
    PHOTOZ_ERR_SNMAG  = -9.0
    PHOTOZ_ERR_ZPULL  = -9.0

! set global MINUIT bound each time since it may
! get over-written in FITINI_PARVAL

    ZMIN = PHOTOZ_BOUND(1)
    ZMAX = PHOTOZ_RANGE_KCOR(2)
    ZMAX = min ( ZMAX, PHOTOZ_BOUND(2) )

! reset photoz step, unless this is a 2-band 'FITRESTMAG' fit (Nov 28, 2014)

    IPAR = IPAR_zPHOT

    INIBND(1,ipar)  =  ZMIN
    INIBND(2,ipar)  =  ZMAX

! continue processing only on 1st fit iteration,
    IF ( LREPEAT_ITER  ) RETURN
    IF ( ITER > 1      ) RETURN

    IF ( LPRINT) THEN
       write(BANNER,10) FNAM, SNLC_CCID(1:ISNLC_LENCCID)
10       format(A, ' for CID=',A )
       CALL PRBANNER ( BANNER )
    endif

! --------------------------------------------


! ----------------------------------------
! set initial value and step size.

    PRIOR_PHOTOZ     =  -9.0
    PRIOR_PHOTOZ_ERR =  -9.0

    Zhost     =  SNHOST_ZPHOT(1)
    Zhost_err =  SNHOST_ZPHOT_ERR(1)

    LZDONE    = .FALSE.
    MASK      = MASK_PHOTOZ_SOURCE
    STD       = 0.0
    PHOTODZ_REJECT = PHOTODZ_REJECT_ORIG ! Nov 2024

    IF ( BTEST(MASK,BIT_BESTZ_GAUSS) ) THEN  ! Zspec prior
      INIVAL(ipar) = SNLC_REDSHIFT
      STD          = SNLC_REDSHIFT_ERR
      CZTMP        = 'zBEST-Gauss'


      if ( .NOT. LEGACY) THEN
          LZDONE       = .TRUE.  ! Feb 2 2026 fix
      endif

! Jan 2021: if user has not specified PRIOR_ZERRSCALE, then set it to 1
      if ( PRIOR_ZERRSCALE == 1000.01 )  PRIOR_ZERRSCALE = 1.0

      if ( SNLC_REDSHIFT_ERR < 0.05 ) then ! avoid crazy zSpec err
         PHOTODZ_REJECT   = SNLC_REDSHIFT_ERR
      endif


    ELSE IF ( BTEST(MASK,BIT_PHOTOZ_GAUSS) ) THEN  ! Zhost prior (1)

      if ( DOFIT_PHOTOZ_HOST ) THEN
         INIVAL(ipar) = zhost
         STD          = zhost_err
         CZTMP        = 'HOST-Gauss'
      else
         CZTMP        = 'AVG[PHOTOZ_BOUND]'
         INIVAL(IPAR) = (PHOTOZ_BOUND(2) + PHOTOZ_BOUND(1))/2.0
         STD          = 9999.
         IF( SKIP_PHOTOZ_INIT ) GOTO 888
      endif

    ELSE IF ( BTEST(MASK,BIT_PHOTOZ_QUANTILES) ) THEN ! R.Chen Jun 2022

       NQ = SNHOSTz_QUANTILE_ZPHOT(1)%NZ
       if ( NQ <= 0 ) THEN
          if ( ABORT_ON_MISSING_QZPHOT ) then
             c1err = 'Missing zPDF quantiles for photo-z fit to CID=' // SNLC_CCID
             c2err = 'To skip such events, set &SNLCINP ABORT_ON_MISSING_QZPHOT=F'
             CALL MADABORT(FNAM, c1err, c2err)
          else
             IERR = -1  ! May 2026 : skip event
             return
          endif
       endif

      MEAN = SNHOST_QZPHOT_MEAN(1) 
      STD  = SNHOST_QZPHOT_STD(1)  

!     initialize at Q50
      INIVAL(ipar) = MEAN
      CZTMP        = 'QUANTILES'
    ENDIF

! check cheat option (4/30/2012)
    IF ( DOFIT_PHOTOZ_CHEAT ) THEN  ! cheat option
      INIVAL(ipar) = SNLC_REDSHIFT
      STD          = 0.001
      LZDONE       = .TRUE.
      CZTMP        = 'zCheat'
    ENDIF

! - - - - - -
! Dec 2024: load global zprior summary here instead of in PHOTOZ_STORE
    PRIOR_PHOTOZ     =  SNGL( INIVAL(ipar) )
    PRIOR_PHOTOZ_ERR =  max(0.001, SNGL(STD) * PRIOR_ZERRSCALE)
    PRIOR_COMMENT    =  CZTMP

! - - - - - - - -
! Dec 2024
    IF ( DOFIT_PHOTOZ_HOST  ) THEN
       MXRATIO_INIVAL_ZPHOT = 0.05 ! Dec 2024 rough guess
       LZDONE  =  ( (STD/INIVAL(ipar)) < MXRATIO_INIVAL_ZPHOT )
    ENDIF

! xxxxxxxxxxxxxxx
    LDMP_REFAC = .FALSE.
    if ( LDMP_REFAC ) then
      print*,'xxx FITINI_PHOTOZ: PRIOR_PHOTOZ     =',PRIOR_PHOTOZ
      print*,'xxx FITINI_PHOTOZ: PRIOR_PHOTOZ_ERR =',PRIOR_PHOTOZ_ERR
      print*,'xxx FITINI_PHOTOZ: PRIOR_COMMENT    =',PRIOR_COMMENT
      print*,'xxx FITINI_PHOTOZ" LZDONE           =',LZDONE
      call flush(6)
    endif
! xxxxxxxxxxxxx


! skip search grid if initial params are going to be over-written
! from fit params in external FITRES file
    if ( USE_INIVAL_SNCID_FILE ) RETURN

! -------------------------------------------------
! if we get here, then we have just the SN with no hostZ to lean on;
! search course grid to find min chi2.

    IFLAG   = FCNFLAG_USER  ! flag for FCNSNLC
    DOFIT_PHOTOZ_MCMC_ADJUST =  & 
           ( NEVAL_MCMC_PHOTOZ > 0 .and. (.not. LZDONE) )

! -----------------------------------------------------
! call FCNSNLC with INIVAL and IFLAG = FCNFLAG_USER (last-call)
! to set EP_XXX arrays with initial conditions.
! This is needed to check initial data/model normalization.

! open up the x0 bound for the course grid search (Feb 4, 2014)
    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
       INIBND(1,IPAR_X0) = 1.0E-15
       INIBND(2,IPAR_X0) = 10000.
    ENDIF

! Use initial guess to get starting CHI2GUESS
    z       = INIVAL(IPAR_zPHOT)
    s       = INIVAL(IPAR_SHAPE)
    c       = INIVAL(IPAR_COLOR)
    d       = GET_DIST8(Z,s,c,ONE8);
    INIVAL(IPAR_DLMAG) = d
    if ( DOFIT_PHOTOZ_MCMC_ADJUST ) then
       INIVAL(IPAR_SPARE) = 0.0
    else
       INIVAL(IPAR_SPARE) = 1.0
    endif
    CALL FCNSNLC(NFITPAR_MN,GRAD,CHI2GUESS,INIVAL,IFLAG,USRFUN)
    if ( LPRINT ) CALL PRINT_INIPAR_ZPHOT('guess',INIVAL,CHI2GUESS)

! - - - - - -
    if ( DOFIT_PHOTOZ_MCMC_ADJUST ) then
       CALL INIPAR_PHOTOZ_MCMC(CHI2GUESS)
    else
       CALL INIPAR_PHOTOZ_COURSEGRID(CHI2GUESS,LZDONE)
    endif


! update x0-bound for SALT2
    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
       d = INIVAL(IPAR_DLMAG)
       INIBND(1,IPAR_X0) = 0.01  * d
       INIBND(2,IPAR_X0) = 100.  * d
    ENDIF

    CALL FCNSNLC(NFITPAR_MN,GRAD,CHI2,INIVAL,IFLAG,USRFUN)

! - - - - -  - -
! set INISTP for photoz
    LPZ_AUTO_INISTP = btest(OPT_PHOTOZ,BIT_PHOTOZ_AUTO_INISTP)
    if ( IFILTOBS_BRACKET(1) < 0 ) then
      STP =  INISTP_PHOTOZ     ! initial step size
      if ( LPZ_AUTO_INISTP .and. STD > 0.0 ) then
         STP = PRIOR_ZERRSCALE * STD/3.0  ! step size
         if ( STP > 0.05   ) STP = 0.05
         if ( STP < 1.0E-4 ) STP = 1.0E-4
         INISTP(IPAR) = STP
         write(BANNER,551) STP
      else
         write(BANNER,550) STP
      endif

      INISTP(IPAR)  =  STP
551   format('Dynamic INISTP_PHOTOZ -> STD(PDF)/3 = ', F6.4)
550   format('Fixed INISTP_PHOTOZ = ', F6.4)
      if(LPRINT) CALL PRINT_ITERINFO(SNLC_CCID,ITER,BANNER)
    endif

! - - - - - - - - - 
! Feb 2 2026: if zphot +_ 10*std is smaller than INIBID, make INIBND more strict.
!   This is for zPHOT fits with very precise zSPEC, in which MINUIT can settle
!   in a region with PROB ~ 0 and not converge.

    ZTMP_MIN = INIVAL(IPAR_ZPHOT) - 10*STD
    ZTMP_MAX = INIVAL(IPAR_ZPHOT) + 10*STD
    if ( ZTMP_MIN > INIBND(1,IPAR_ZPHOT) )  INIBND(1,IPAR_ZPHOT) = ZTMP_MIN
    if ( ZTMP_MAX < INIBND(2,IPAR_ZPHOT) )  INIBND(2,IPAR_ZPHOT) = ZTMP_MAX

! - - - -
    if(LPRINT) CALL PRINT_INIPAR_ZPHOT('eval', INIVAL, chi2)

    CALL FLUSH(6)

888   CONTINUE

    REDSHIFT_FIT = SNGL( INIVAL(IPAR_zPHOT) )

    if ( STDOUT_UPDATE ) then
       CALL CPU_TIME(t_end)
       write(6,890) FNAM, SNLC_CCID(1:ISNLC_LENCCID), t_end-t_start
890      format(T5,'Finished ', A,' for CID=',A,  & 
               '  in ', F6.3,' seconds.')
       call flush(6)
    endif

    RETURN
  END SUBROUTINE FITINI_PHOTOZ 

! =============================
    SUBROUTINE PRINT_INIPAR_ZPHOT(string,INIPAR_VAL,chi2)
! Created July 2012
! FITINI_PHOTOZ print utility to show
!     initial-[string]: zPhot,s,c,x0 = [values]
! - - - -


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    CHARACTER STRING*(*)          ! (I) descriptor
    REAL*8 INIPAR_VAL(*),  chi2   ! (I) values to print

    REAL*8  z, s, c, x0, d
    INTEGER LZ, LS, LC, LD, LD2
    LOGICAL LEGACY
    CHARACTER PARNAME_D*20

! ----------- BEGIN --------

    IF ( .not. STDOUT_UPDATE ) RETURN

    LEGACY  = (NEVAL_MCMC_PHOTOZ .EQ. 0)  ! legacy = course grid
    IF ( LEGACY ) THEN
       PARNAME_D = 'dScale'  ! course grid (legacy)
    ELSE
       PARNAME_D = 'dmu'   ! MCMC
    ENDIF

    LZ  = INDEX(PARNAME_STORE(IPAR_zPHOT),  ' ' ) - 1
    LS  = INDEX(PARNAME_STORE(IPAR_SHAPE),  ' ' ) - 1
    LC  = INDEX(PARNAME_STORE(IPAR_COLOR),  ' ' ) - 1
    LD  = INDEX(PARNAME_STORE(IPAR_DLMAG),  ' ' ) - 1
    LD2 = INDEX(PARNAME_D,                  ' ' ) - 1

    z       = INIPAR_VAL(IPAR_zPHOT)
    s       = INIPAR_VAL(IPAR_SHAPE)
    c       = INIPAR_VAL(IPAR_COLOR)
    x0      = INIPAR_VAL(IPAR_DLMAG)
    d       = INIPAR_VAL(IPAR_SPARE)

    write(6,43) STRING  & 
           ,PARNAME_STORE(IPAR_zPHOT)(1:LZ)  & 
           ,PARNAME_STORE(IPAR_SHAPE)(1:LS)  & 
           ,PARNAME_STORE(IPAR_COLOR)(1:LC)  & 
           ,PARNAME_STORE(IPAR_DLMAG)(1:LD)  & 
           ,PARNAME_D(1:LD2)  & 
           ,z, s, c, x0, d

 43   format(T5,'initial-',A, 2x,  & 
               5(A,1x),'= ', 3F7.3, 1x, G8.2, 1x, F6.3 )

    write(6,44) STRING, CHI2
 44   format(T5,'initial-',A, 2x, 'CHI2 = ',G12.4 )

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE PRINT_INIPAR_ZPHOT

! ====================================
    SUBROUTINE INIPAR_PHOTOZ_COURSEGRID(CHI2INI,LZFIX)

! Created July 12 2019
! Estimate initial photo-z parameters using course grid.
! [Code moved from FITINI_PHOTOZ]
!
! Dec 11 2025; 
!   + set OPT_CHI2_SIGMA=0 and restore value after completion
!   + add optional PKMJD loop

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! subroutine arguments
    REAL*8  CHI2INI ! (I) initial chi2 from guess; try doing better
    LOGICAL LZFIX   ! (I) T=> fix redshift to INIVAL

! local args

    REAL*8 Z_SAVE, ZMIN, ZMAX, ZBIN, z,  ZBND_MIN, ZBND_MAX
    REAL*8 S_SAVE, SMIN, SMAX, SBIN, s
    REAL*8 C_SAVE, CMIN, CMAX, CBIN, c
    REAL*8 T_SAVE, TMIN, TMAX, TBIN, t  ! Dec 11 2025 PKMJD
    REAL*8 Fmodel_SCALE, Fmodel_SCALE_SAVE, d, d_SAVE, d_cospar
    REAL*8 ZVAR, ZVAR_MIN, ZVAR_MAX, ZVAR_BIN
    REAL*8 GRAD(MXFITPAR), CHI2, CHI2MIN
    REAL*8 RESTLAMBDA_SAVE(2) 
    INTEGER NZBIN, NSBIN, NCBIN, NTBIN, iz, is, ic, it, IFLAG, ITER
    REAL SCALE_ALL
    INTEGER OPT_CHI2_SIGMA_SAVE, NBIN_TOT

    LOGICAL REFAC_LAMRANGE
    CHARACTER FNAM*28
    REAL*8 GET_DIST8, USRFUN
    EXTERNAL USRFUN

! ------------- BEGIN ------------

    MARK_USED(ZBIN)

    FNAM = 'INIPAR_PHOTOZ_COURSEGRID'
    
    ITER  = 1
    IFLAG = FCNFLAG_USER  ! to fill EP_XXX arrays in FCNSNLC
    SCALE_ALL = SCALE_NBIN_COURSE_PHOTOZ
    IF ( SCALE_ALL .LE. 0. ) THEN
       write(c1err,661) SCALE_ALL
661    format('Invalid SCALE_NBIN_COURSE_PHOTOZ = ', F8.1)
       c2err = 'Check  &FITINP namelist'
       CALL MADABORT(FNAM, c1err, c2err)
    ENDIF


    CHI2MIN = CHI2INI
    T_SAVE  = INIVAL(IPAR_PEAKMJD)
    Z_SAVE  = INIVAL(IPAR_zPHOT)
    D_SAVE  = INIVAL(IPAR_DLMAG)  ! mu or x0 (distance par)
    C_SAVE  = INIVAL(IPAR_COLOR)  ! AV or c
    S_SAVE  = INIVAL(IPAR_SHAPE)   ! stretch (x1, delta...)
    OPT_CHI2_SIGMA_SAVE = OPT_CHI2_SIGMA  ! Dec 11 2025
    OPT_CHI2_SIGMA      = 0


! check option to print test chi2 for special hard-coded cases
    if ( DEBUG_FLAG == 1210 )   CALL PRINT_TEST_CHI2()

    ZBND_MIN = INIBND(1,IPAR_zPHOT)
    ZBND_MAX = INIBND(2,IPAR_zPHOT)
! loop over redshift, color, stretch to estimate INIVAL

    IF ( LZFIX ) THEN
       ! delta function for precise zPrior
       ZMIN = Z_SAVE
       ZMAX = Z_SAVE
    ELSE IF ( RANGEz_COURSE_PHOTOZ(1) > 0 ) then
       ! Dec 2025; check for &FITINP user override
       ZMIN = RANGEz_COURSE_PHOTOZ(1)
       ZMAX = RANGEz_COURSE_PHOTOZ(2)
    ELSE IF ( DOFIT_PHOTOZ_HOST ) THEN
       ! zprior that is not super precise  -> +_ 2 sigma window
       ZMIN = MAX(ZBND_MIN, PRIOR_PHOTOZ - 2.0*PRIOR_PHOTOZ_ERR)
       ZMAX = MIN(ZBND_MAX, PRIOR_PHOTOZ + 2.0*PRIOR_PHOTOZ_ERR)
    ELSE
       ! no zprior -> use entire z-range
       ZMIN  = ZBND_MIN
       ZMAX  = ZBND_MAX
    ENDIF


    ! - - - - -  - -
    CALL SET_COURSEBIN_PHOTOZ(IPAR_COLOR, ITER,  & 
         NCBIN, CBIN, CMIN, CMAX)  ! output

    CALL SET_COURSEBIN_PHOTOZ(IPAR_SHAPE, ITER,  & 
         NSBIN, SBIN, SMIN, SMAX)  ! output

    CALL SET_COURSEBIN_PHOTOZ(IPAR_PEAKMJD, ITER,  & 
         NTBIN, TBIN, TMIN, TMAX)  ! output

  
    ZVAR_MIN = ZMIN; ZVAR_MAX = ZMAX
    CALL SET_COURSEBIN_PHOTOZ(IPAR_ZPHOT, ITER,  & 
         NZBIN, ZVAR_BIN, ZVAR_MIN, ZVAR_MAX)  ! inputs ZVAR_MIN[MAX] are modified
    
    IF ( STDOUT_UPDATE ) THEN
       print*,'    COURSE-GRID minimization for initial values: '

       write(6,431) NTBIN, 'peakmjd     ',    TMIN, TMAX, TBIN
       write(6,432) NZBIN, 'zph/(1+zph) ', ZVAR_MIN, ZVAR_MAX, ZVAR_BIN       
       write(6,432) NCBIN, 'color       ',    CMIN, CMAX, CBIN
       write(6,432) NSBIN, 'shape       ',    SMIN, SMAX, SBIN

431    format(T8,I3, 2x, A12,' bins from ', F8.2,' to ', F8.2,  & 
            3x,'(binsize=',F7.2,')'  )
432    format(T8,I3, 2x, A12,' bins from ', F8.3,' to ', F8.3,  & 
            3x,'(binsize=',F7.3,')'  )

       NBIN_TOT = NTBIN * NZBIN * NCBIN * NSBIN
       print*,'    Total number of COURSE bins: ', NBIN_TOT
       call flush(6)
    ENDIF


    ! Mar 24 2026: open wavelength range if UVLAM_EXTRAPFLUX is set;
    !        DEBUG_FLAG = -324 restores legacy code to ignore UVLAM_EXTRAPFLUX.
    REFAC_LAMRANGE = ( DEBUG_FLAG .NE. -324 )
    IF ( REFAC_LAMRANGE .and. UVLAM_EXTRAPFLUX > 0.0 )  then
       RESTLAMBDA_SAVE(1) = RESTLAMBDA_USEFIT(1)
       RESTLAMBDA_SAVE(2) = RESTLAMBDA_USEFIT(2)
       RESTLAMBDA_USEFIT(1) = RESTLAMBDA_MODEL(1) 
       RESTLAMBDA_USEFIT(2) = RESTLAMBDA_MODEL(2) 

       if ( STDOUT_UPDATE ) then
          write(6,438) RESTLAMBDA_MODEL(1), RESTLAMBDA_MODEL(2)
438       format(T5,'UVLAM_EXTRAP -> extend RESTLAMBDA for COURSEGRID to: ', 2F8.0 )
       endif
    endif
! ------------------------------------------------------
! start t, z,c,s course-grid loop

    DO 53 it  = 1, NTBIN   ! MJD (time) bins
       t = TMIN + dble(it-1) * TBIN
       INIVAL(IPAR_PEAKMJD) = t

    DO 55 iz  = 1, NZBIN   ! redshift (or 1+zphot) bins

      zvar  = ZVAR_MIN + dble(iz-1)*ZVAR_BIN  ! 1/(1+z) (not z)
      z = ZVAR / ( 1 - ZVAR )                 ! translate back to z
      INIVAL(IPAR_zPHOT)  = z

    DO 57 is = 1, NSBIN    ! shape
      s = SMIN + dble(is-1) * SBIN
      INIVAL(IPAR_SHAPE) = s

    DO 59 ic  = 1, NCBIN   ! color
      c       = CMIN + dble(ic-1)*CBIN
      INIVAL(IPAR_COLOR)  = c

      d_cospar            = GET_DIST8(Z,s,c,ONE8)
      INIVAL(IPAR_DLMAG)  = d_cospar

! call function to evaluate R4SN_XXX variables needed to
! determine Fmodel_SCALE below.
      CALL FCNSNLC(NFITPAR_MN, GRAD, CHI2, INIVAL, IFLAG, USRFUN)

      ! now compute Fmodel_SCALE to minimize chi2 as a function of
      ! x0 or MU. This is an approximation assuming that the error-squared
      ! is constant, but it really depends slightly on the Fmodel_SCALE value.
      
      IF ( R4SN_FFSUM_CROSS > 0 .and. R4SN_FFSUM_MODEL > 0 ) then
         Fmodel_SCALE        = R4SN_FFSUM_CROSS/R4SN_FFSUM_MODEL
      ELSE
         Fmodel_SCALE        = 1.0  
      ENDIF
         
      d                   = GET_DIST8(Z,s,c,Fmodel_SCALE)
      INIVAL(IPAR_DLMAG)  = d
      CALL FCNSNLC(NFITPAR_MN, GRAD, CHI2, INIVAL, IFLAG,USRFUN)

! ------------
      if ( chi2 < -1300.  ) then
        write(6,667) z, PARNAME_STORE(IPAR_COLOR)(1:3),  c,s,d,chi2, Fmodel_SCALE
667       format(' xxxx Z=',F5.3, 2x, A,'=',F6.3, 2x,  & 
                 's=',F6.3, 2x, 'DIST=',G8.3, 2x, 'CHI2=',E10.3,  & 
                 2x, 'Fscale=',G8.3 )
        call flush(6)
!           STOP ! xxxxxxxx
      endif
! -------
      if ( CHI2 .LT. CHI2MIN ) then
          chi2min = chi2
          Z_SAVE = INIVAL(IPAR_zPHOT)
          C_SAVE = INIVAL(IPAR_COLOR)
          S_SAVE = INIVAL(IPAR_SHAPE)
          D_SAVE = INIVAL(IPAR_DLMAG)
          Fmodel_SCALE_SAVE = Fmodel_SCALE
      endif

59    CONTINUE  ! color
57    CONTINUE  ! lumipar
55    CONTINUE  ! photoz
53    CONTINUE  ! peakmjd (Dec 2025)

! update INIVAL
      
    INIVAL(IPAR_zPHOT)   = Z_SAVE  ! save redshift
    INIVAL(IPAR_COLOR)   = C_SAVE  ! save color
    INIVAL(IPAR_DLMAG)   = D_SAVE  ! save distance
    INIVAL(IPAR_SHAPE)   = S_SAVE  ! save lumi/shape param
    INIVAL(IPAR_SPARE)   = Fmodel_SCALE_SAVE
    OPT_CHI2_SIGMA       = OPT_CHI2_SIGMA_SAVE 

    IF ( REFAC_LAMRANGE .and. UVLAM_EXTRAPFLUX > 0.0 )  then ! restore user wave range
       if ( STDOUT_UPDATE ) then
          write(6,439) RESTLAMBDA_SAVE(1), RESTLAMBDA_SAVE(2)
439       format(T5,'UVLAM_EXTRAP -> restore RESTLAMBDA to: ', 2F8.0 )
       endif
       call flush(6)
       RESTLAMBDA_USEFIT(1) = SNGL( RESTLAMBDA_SAVE(1) )
       RESTLAMBDA_USEFIT(2) = SNGL( RESTLAMBDA_SAVE(2) )
    endif

    RETURN
  END SUBROUTINE INIPAR_PHOTOZ_COURSEGRID


  SUBROUTINE PRINT_TEST_CHI2()

    ! Created Dec 2025
    ! print chi2 for hard-wired CIDs and INIPAR
    ! This routine has no impact on nominal fits;
    ! this is only for diagnostics.
    ! First example: compute chi2 with INIVAL based on zSPEC fit,
    ! to compare chi2 for zPHOT

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE
    
    INTEGER IFLAG, ipar
    REAL*8  GRAD(MXFITPAR), CHI2, INIVAL_SAVE(MXFITPAR)
    EXTERNAL USRFUN
    REAL*8   USRFUN  

    ! ---------------- BEGIN --------------

    DO ipar = 1, MXFITPAR   
       INIVAL_SAVE(ipar) = INIVAL(ipar)
    enddo

    if ( SNLC_CID == 1310964 ) then
       INIVAL(IPAR_PEAKMJD) = 56995.934
       INIVAL(IPAR_SHAPE)   = -.70827
       INIVAL(IPAR_COLOR)   = -.13776  
       INIVAL(IPAR_X0)      = 0.58604E-05
       INIVAL(IPAR_ZPHOT)   = 0.75

    else if ( SNLC_CID == 1301933 ) then
       INIVAL(IPAR_PEAKMJD) = 56952.937 
       INIVAL(IPAR_SHAPE)   = -.21461
       INIVAL(IPAR_COLOR)   = -.14087 
       INIVAL(IPAR_X0)      = 0.42247E-04
       INIVAL(IPAR_ZPHOT)   = 0.33

    else if ( SNLC_CID == 1257605 ) then
       INIVAL(IPAR_PEAKMJD) = 56615.839
       INIVAL(IPAR_SHAPE)   = 1.4418 
       INIVAL(IPAR_COLOR)   = 0.28930E-01
       INIVAL(IPAR_X0)      = 0.58724E-05
       INIVAL(IPAR_ZPHOT)   = 0.74

    endif

    IFLAG = FCNFLAG_USER 
    CALL FCNSNLC(NFITPAR_MN, GRAD, CHI2, INIVAL, IFLAG, USRFUN)

    write(6,20) SNLC_CCID(1:ISNLC_LENCCID), CHI2
20  format(T5,' xxx TEST CHI2(',A,') = ', 2x F9.2 )
    call flush(6)
    
    ! restore INIVAL
    DO ipar = 1, MXFITPAR   
       INIVAL(ipar) = INIVAL_SAVE(ipar)
    enddo

    RETURN

  END SUBROUTINE PRINT_TEST_CHI2

! ====================================================
    SUBROUTINE INIPAR_PHOTOZ_MCMC(CHI2INI)
! Created Jul 2019
! Estimate initial all 5 photo-z params using MCMC  method.
! The goal is to significantly reduce init time compared with
! the COURSEGRID method, and maybe even do a better job.
! Works only for SALT2 model.
! 
!   !!! BEWARE: this is experimental !!!
! -------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

! subroutine args
    REAL*8 CHI2INI  ! (I) chi2 from guess params; goal is to beat this

! local var
    INTEGER, PARAMETER :: ISEED = 12379

    INTEGER NEVAL_REDUCE_STEP
    REAL*8  FRACRANGE_STEPINI, FRAC_STEP_REDUCE, DMU_MAX

    INTEGER IFLAG, NTMP, itry, NPAR, i, IPAR, IPAR_LIST(MXFITPAR)
    REAL*8 CHI2min, DIF, AVG, STEP, VAL, ran
    REAL*8 z,s,c,t0, dmu, x0cosmo, x0
    REAL*8 CHI2, CHI2_LAST, ARG, PROB, VALMIN, VALMAX
    REAL*8 MCMC_STEPVAL(MXFITPAR), MCMC_TRYVAL(MXFITPAR)
    REAL*8 GRAD(MXFITPAR), BND_LOCAL(2,MXFITPAR)
    REAL*8 INIVAL_SAVE(MXFITPAR)
    LOGICAL MOVE
    LOGICAL LDMP / .FALSE. /
    CHARACTER PARNAME*20

! function
    REAL*8 GET_DIST8, USRFUN
    EXTERNAL USRFUN

! ------------ BEGIN ----------

    CALL SRAND(ISEED)
    IFLAG   = FCNFLAG_USER
    CHI2MIN = CHI2INI
    NTMP    = 0

!     NEVAL_MCMC_PHOTOZ = int(PARLIST_MCMC_PHOTOZ(1)) ! already done
    NEVAL_REDUCE_STEP = int(PARLIST_MCMC_PHOTOZ(2))
    FRACRANGE_STEPINI = PARLIST_MCMC_PHOTOZ(3)
    FRAC_STEP_REDUCE  = PARLIST_MCMC_PHOTOZ(4)
    DMU_MAX           = PARLIST_MCMC_PHOTOZ(5)

    IF ( STDOUT_UPDATE ) THEN
       write(6,30) 'Use MCMC minimization for initial values: '
 30      format(T7,A)
       write(6,31) NEVAL_MCMC_PHOTOZ, FRAC_STEP_REDUCE,  NEVAL_REDUCE_STEP
 31      format(T7,I3,' evals, STEP*=',F4.2,' every ',I3,' evals.')
       write(6,32) FRACRANGE_STEPINI
 32      format(T7,'Initial MCMC STEP = RANGE x ', F5.2 )
    ENDIF

    NPAR         = 5
    IPAR_LIST(1) = IPAR_ZPHOT
    IPAR_LIST(2) = IPAR_SHAPE
    IPAR_LIST(3) = IPAR_COLOR
    IPAR_LIST(4) = IPAR_PEAKMJD
    IPAR_LIST(5) = IPAR_DLMAG

    BND_LOCAL(1,IPAR_ZPHOT)   = INIBND(1,IPAR_ZPHOT)
    BND_LOCAL(2,IPAR_ZPHOT)   = INIBND(2,IPAR_ZPHOT)
    BND_LOCAL(1,IPAR_SHAPE)   = -3.0  ! x1 min
    BND_LOCAL(2,IPAR_SHAPE)   = +3.0  ! x1 max
    BND_LOCAL(1,IPAR_COLOR)   = -0.2  ! c min
    BND_LOCAL(2,IPAR_COLOR  ) =  0.4  ! c max
    BND_LOCAL(1,IPAR_PEAKMJD) = SNLC_SEARCH_PEAKMJD - 7.0
    BND_LOCAL(2,IPAR_PEAKMJD) = SNLC_SEARCH_PEAKMJD + 7.0
    BND_LOCAL(1,IPAR_DLMAG) = -DMU_MAX  ! MU shift w.r.t. cosmo constraint
    BND_LOCAL(2,IPAR_DLMAG) = +DMU_MAX

! for each param, get initial start value and step size
    DO i = 1, NPAR
       IPAR = IPAR_LIST(i)
       DIF  = (BND_LOCAL(2,IPAR) - BND_LOCAL(1,IPAR))
       AVG  = (BND_LOCAL(2,IPAR) + BND_LOCAL(1,IPAR))/2.0
       STEP = DIF * FRACRANGE_STEPINI
       MCMC_STEPVAL(IPAR) = STEP
       MCMC_TRYVAL(IPAR)  = AVG
       INIVAL(IPAR)       = AVG
       PARNAME            = PARNAME_STORE(IPAR)
       if ( IPAR == IPAR_DLMAG ) PARNAME = 'dmu'

       if ( STDOUT_UPDATE ) then
          write(6,60) PARNAME, AVG, STEP
 60         format(T7,'Start ', A6,' value/step: ', F9.3,'/', F6.3 )
          call flush(6)
       endif
    ENDDO


    z = INIVAL(IPAR_ZPHOT);
    s = INIVAL(IPAR_SHAPE);
    c = INIVAL(IPAR_COLOR)
    INIVAL(IPAR_DLMAG) = GET_DIST8(z,s,c,ONE8)
    CALL FCNSNLC(NFITPAR_MN,GRAD,CHI2,INIVAL,IFLAG,USRFUN)
    CHI2_LAST = CHI2

! store initial chi2min in case we don't find better
    CHI2MIN = CHI2
    DO i = 1, NPAR
       IPAR = IPAR_LIST(i)
       INIVAL_SAVE(IPAR) = INIVAL(IPAR)
    ENDDO
    INIVAL_SAVE(IPAR_SPARE) = 0.0  ! dmu from cosmology constraint

! - - - - - - - - - - -

    DO 50 itry = 1, NEVAL_MCMC_PHOTOZ

       DO 51 i = 1, NPAR
          IPAR   = IPAR_LIST(i)
          ran    = rand()-0.5    ! between -0.5 and +0.5
          STEP   = MCMC_STEPVAL(IPAR)
          VAL    = MCMC_TRYVAL(IPAR) + (STEP*ran)
          VALMIN = BND_LOCAL(1,IPAR)
          VALMAX = BND_LOCAL(2,IPAR)
          ! respect bounds
          if ( VAL < VALMIN ) VAL = VALMIN + STEP/20.0
          if ( VAL > VALMAX ) VAL = VALMAX - STEP/20.0
          INIVAL(IPAR) = VAL
          if ( IPAR == IPAR_DLMAG ) dmu = VAL
 51      CONTINUE

! treat x0/mu a bit different
       z       = INIVAL(IPAR_ZPHOT)
       s       = INIVAL(IPAR_SHAPE)
       c       = INIVAL(IPAR_COLOR)
       t0      = INIVAL(IPAR_PEAKMJD)
       x0cosmo = GET_DIST8(z,s,c,ONE8)
       x0      = x0cosmo * 10**(-0.4*dmu)
       INIVAL(IPAR_DLMAG) = x0  ! overwrite dmu with x0

! call function to evaluate chi2 for this INIVAL trial
       CALL FCNSNLC(NFITPAR_MN,GRAD,CHI2,INIVAL,IFLAG,USRFUN)

       ARG  = -(CHI2-CHI2_LAST)/2.0
       PROB = EXP(ARG)
       IF ( PROB > 1.0 ) PROB = 1.0
       MOVE = .FALSE.
       if ( RAND() < PROB ) then
          MOVE = .TRUE.
          DO i = 1, NPAR
             IPAR = IPAR_LIST(i)
             MCMC_TRYVAL(IPAR) = INIVAL(IPAR)
          ENDDO
       endif

       if ( CHI2 < CHI2MIN ) then
          CHI2MIN = CHI2
          DO i = 1, NPAR
             IPAR = IPAR_LIST(i)
             INIVAL_SAVE(IPAR) = INIVAL(IPAR)
          ENDDO
          INIVAL_SAVE(IPAR_SPARE) = dmu
       endif

       NTMP = NTMP + 1
       if ( NTMP == NEVAL_REDUCE_STEP  ) then
! reduce step size, and move to current values with min chi2
          NTMP = 0
          DO i = 1, NPAR
             IPAR = IPAR_LIST(i)
             MCMC_STEPVAL(ipar) = MCMC_STEPVAL(ipar)*FRAC_STEP_REDUCE
             MCMC_TRYVAL(ipar)  = INIVAL_SAVE(ipar)
          ENDDO
       endif

          if ( LDMP ) then
             print*,' xxx --------------------------------------- '
             write(6,665) z, s, c, t0
             write(6,666) itry, CHI2,CHI2_LAST, PROB, MOVE
             call flush(6)
 665           format('  xxx z, s, c, PKMJD = ', 3F7.3, F11.3 )
 666           format('  xxx itry=',I3, 2x, 'CHI2(cur,last)=',2F6.0, 2x,  & 
                    'PROB=',F6.3, 2x, 'MOVE=',L2)
          endif

       CHI2_LAST = CHI2
 50   CONTINUE

! restore INIVAL_SAVE at mon chi2 to global INIVAL
    DO i = 1, NPAR
       IPAR = IPAR_LIST(i)
       INIVAL(IPAR) = INIVAL_SAVE(IPAR)
    ENDDO
    INIVAL(IPAR_SPARE) = INIVAL_SAVE(IPAR_SPARE)

    RETURN
  END SUBROUTINE INIPAR_PHOTOZ_MCMC


  SUBROUTINE INIT_COURSEBIN_PHOTOZ()

    ! Created Dec 2025
    ! for XXX_COURSE_PHOTOZ params NOT specified in &FITINP (i.e. ,still have -9 values),
    ! set default values. Also check SALT2 or BAYESN.
    ! This is a one-time init done after FITMODEL_INDEX is set, 
    ! and thus cannot be done prior to reading &FITINP from namelist file.

    USE SNANAFIT
    USE SNFITVAR
    USE FITINP_NML
    USE SNFILECOM

    IMPLICIT NONE
    LOGICAL IS_SALT2, IS_BAYESN, IS_MLCS2k2, USER_c, USER_s, USER_t

    ! ---------- BEGIN ---------

    CALL PRBANNER ( 'INIT_COURSEBIN_PHOTOZ' )

    IS_SALT2   = ( FITMODEL_INDEX .EQ. MODEL_SALT2  )
    IS_BAYESN  = ( FITMODEL_INDEX .EQ. MODEL_BAYESN )
    IS_MLCS2k2 = ( FITMODEL_INDEX .EQ. MODEL_MLCS2k2 ) 

    USER_c  = ( RANGEc_COURSE_PHOTOZ(1) >  -98.0  )
    USER_s  = ( RANGEs_COURSE_PHOTOZ(1) >  -98.0  )
    USER_t  = ( RANGEt_COURSE_PHOTOZ(2) >    0.0  ) 

    ! - - - - - - -
    if ( .NOT. USER_t ) then
       RANGEt_COURSE_PHOTOZ(1) = -15.0;   RANGEt_COURSE_PHOTOZ(2) = +15.0  ! PEAKMJD
    endif

    ! default NBINc/NBINs/NBINt is the same for all models
    if ( NBINc_COURSE_PHOTOZ < 0 ) NBINc_COURSE_PHOTOZ  =  4
    if ( NBINs_COURSE_PHOTOZ < 0 ) NBINs_COURSE_PHOTOZ  =  3
    if ( NBINt_COURSE_PHOTOZ < 0 ) NBINt_COURSE_PHOTOZ  =  1

    ! - - - - - - -
    ! color and stretch binning depends on fit model

    IF ( IS_SALT2 ) THEN

       ! NBINz determined later for each event based on prior
       
       if ( .NOT. USER_c ) then
          RANGEc_COURSE_PHOTOZ(1) =  -0.2;   RANGEc_COURSE_PHOTOZ(2) = +0.25  ! c
       endif
       
       if ( .NOT. USER_s ) then
          RANGEs_COURSE_PHOTOZ(1) =  -3.0;   RANGEs_COURSE_PHOTOZ(2) = +1.0  ! x1
       endif      

       ! RANGEz is determined later for each event.

    ELSE IF ( IS_BAYESN ) THEN
       
       if ( .NOT. USER_c ) then
          RANGEc_COURSE_PHOTOZ(1) =  0.0;   RANGEc_COURSE_PHOTOZ(2) = +0.6  ! AV
       endif
       
       if ( .NOT. USER_s ) then
          RANGEs_COURSE_PHOTOZ(1) =  -2.0;   RANGEs_COURSE_PHOTOZ(2) = +2.0  ! THETA
       endif
       
       print*,' '
       print*,' @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ '
       print*,'   Dec 2025: ' 
       print*,'   STOP in SUBROUTINE INIT_COURSEBIN_PHOTOZ()  on BAYESN model '
       print*,'   Check defaults for BAYESN. '
       print*,'           STOP'
       STOP

    ELSE IF ( IS_MLCS2k2 ) THEN
       
       if ( .NOT. USER_c ) then
          RANGEc_COURSE_PHOTOZ(1) =  0.0;   RANGEc_COURSE_PHOTOZ(2) = +1.0  ! AV
       endif
       
       if ( .NOT. USER_s ) then
          RANGEs_COURSE_PHOTOZ(1) =  -0.2;   RANGEs_COURSE_PHOTOZ(2) = +1.5  ! DELTA
       endif

    ELSE
       c1err = 'Course bins not defined for FITMODEL_NAME = '
       c2err =  FITMODEL_NAME(1:80)
       CALL MADABORT ('INIT_COURSEBIN_PHOTOZ', c1err, c2err )
    ENDIF

    write(6,41)  NBINc_COURSE_PHOTOZ, PARNAME_STORE(IPAR_COLOR),   RANGEc_COURSE_PHOTOZ
    write(6,41)  NBINs_COURSE_PHOTOZ, PARNAME_STORE(IPAR_SHAPE),   RANGEs_COURSE_PHOTOZ
    write(6,41)  NBINt_COURSE_PHOTOZ, 't0-t0_estimate  ',          RANGEt_COURSE_PHOTOZ
41  format(T8, 'Define', I3,2x, A16,' bins from ', F9.3,' to ', F9.3 )
 
    call flush(6)

    RETURN
  END SUBROUTINE INIT_COURSEBIN_PHOTOZ

! ====================================================
  SUBROUTINE SET_COURSEBIN_PHOTOZ(IPAR, ITER, NBIN, PARBIN, PARMIN, PARMAX)
! 
! Created March 25, 2012 by R.Kessler
! 
! Call by FITINI_PHOTOZ to set color (IPAR=IPAR_COLOR) or
! stretch (IPAR=IPAR_SHAPE) bins. These bins are used
! to loop over a course grid to find an approx. global min.
! 
! July 5 2019: min color bound -> -0.2 (was -0.3)
! Dec 11 2025: check for IPAR_PEAKMJD
! Dec 13 2025: refactor to use all user &FITINP inputs 
! ---------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! subroutine args.
    INTEGER IPAR                  ! (I) fit parameter index
    INTEGER ITER                  ! (I) fit-iteration to prepare
    INTEGER NBIN                  ! (O) Number of bins
    REAL*8  PARBIN,PARMIN,PARMAX  ! (O) binsize, min and max
! local args

    REAL*8 PEAKMJD_ESTIMATE, ZMIN, ZMAX
    LOGICAL IS_SALT2, IS_BAYESN, DO_COLOR, DO_SHAPE, DO_PEAKMJD, DO_ZPHOT

! --------------- BEGIN ---------------

    MARK_USED(ITER)

! hard-code color range for SALT2 model (Dec 2014)
    IS_SALT2   = ( FITMODEL_INDEX .EQ. MODEL_SALT2 )
    IS_BAYESN  = ( FITMODEL_INDEX .EQ. MODEL_BAYESN )
    DO_COLOR   = ( IPAR == IPAR_COLOR   )
    DO_SHAPE   = ( IPAR == IPAR_SHAPE   )
    DO_PEAKMJD = ( IPAR == IPAR_PEAKMJD )
    DO_ZPHOT   = ( IPAR == IPAR_ZPHOT   )
! --------------------------------------------

    IF ( INISTP(IPAR) .EQ. 0.0 ) THEN ! fixed parameter
      NBIN    = 1
      PARMIN  = INIVAL(IPAR)
      PARMAX  = INIVAL(IPAR)
      PARBIN  = 0.0
      RETURN
    ENDIF
  
! ----- nominal behavior ----

    IF ( DO_COLOR ) THEN
       PARMIN  = RANGEc_COURSE_PHOTOZ(1)
       PARMAX  = RANGEc_COURSE_PHOTOZ(2)
       NBIN    = NBINc_COURSE_PHOTOZ      ! optional user-scale

    ELSE IF ( DO_SHAPE ) THEN
       PARMIN  = RANGEs_COURSE_PHOTOZ(1)
       PARMAX  = RANGEs_COURSE_PHOTOZ(2)
       NBIN    = NBINs_COURSE_PHOTOZ    ! stretch/lumi bins * user scale
 
    ELSE IF ( DO_PEAKMJD ) THEN

       ! Stick with legacy default  1 t-bin, or a fixed PEAKMJD.
       PEAKMJD_ESTIMATE = INIVAL(IPAR_PEAKMJD)
       NBIN   = NBINt_COURSE_PHOTOZ   ! PEAKMJD bins * user scale
       PARMIN = PEAKMJD_ESTIMATE
       PARMAX = PEAKMJD_ESTIMATE

       ! If user specifies more than 1 course bin, set the range
       if ( NBIN > 1 ) then
          PARMIN = PEAKMJD_ESTIMATE + RANGEt_COURSE_PHOTOZ(1)
          PARMAX = PEAKMJD_ESTIMATE + RANGEt_COURSE_PHOTOZ(2)
       endif
    ELSE IF ( DO_ZPHOT ) THEN

       ! be careful here to set bins for zph/(1+zphot) [not zph]

       ZMIN  = PARMIN  ! strip off input zphot range
       ZMAX  = PARMAX  ! idem

       ! modify input PARMIN & PARMAX to altered definition
       PARMIN = ZMIN / (1.0 + ZMIN)
       PARMAX = ZMAX / (1.0 + ZMAX)
      
       if ( NBINz_COURSE_PHOTOZ > 0 ) then
          ! user-defined NBIN via &FITINP
          NBIN = NBINz_COURSE_PHOTOZ
       else
          ! default here is to auto-compute NBIN because
          ! the range of z/(1+z) depends on prior
          NBIN = int(42.*(PARMAX-PARMIN)) + 1
       endif

    ENDIF

! optional global scale for all NBIN
    NBIN    = NBIN * SCALE_NBIN_COURSE_PHOTOZ

! compute bin size 
    if ( NBIN > 1 ) then
       PARBIN  = (PARMAX - PARMIN) / DBLE(NBIN-1)
    else
       PARBIN = 0.0
    endif

    RETURN
  END SUBROUTINE SET_COURSEBIN_PHOTOZ

! ==========================================
    SUBROUTINE FITINI_ADJUST ( iter, IERR )
! 
! Re-Created April 6, 2009 by R.Kessler
! 
! Compute data/model ratio and adjust either MU or x0
! so that initial model matches data better.
! This is much simpler than original version.
! IERR  = 0 -> OK
! IERR != 0 -> bad adjustment; should skip fit
! 
! Aug 30 2017: use function FIRST_ITERATION instead of test on ITER.
!              --> accomodate SIMFIT_IDEAL logic
! 
! Mar 4 2020
!  + modify PKMJD sweep from -2, 2 in 1 day bins, to -4 to +4 in 2 day bins.
!  + remove CHI2TEST on 5*NEPOCH
! 
! Aug 4 2021
!  + add optional color grid search with INIVAL_GRIDSEARCH_COLOR - D. Jones
! 
! Jul 23 2024: add IERR arg
! 
! ----------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    USE FILTCOM
    USE FITIDEALCOM

    IMPLICIT NONE

    INTEGER  & 
         iter   &  ! (I) fit iteration: 1,2, ... NFIT_ITERATION
        ,IERR

! local var

    INTEGER  & 
         CID, IFILT, IFILT_OBS, NFILT, LTMP, ipar  & 
        ,IPAR_ADJUST, NF, LCHAR, LCHAR2

    LOGICAL LPRINT
    LOGICAL   FIRST_ITER, DO_PEAKMJD, DO_COLOR
    CHARACTER BANNER*100, CFILT*(MXFILT_ALL), cpar*20

    REAL  & 
         RATIO_FLUX(MXFILT_ALL), RATIO_FLUX_AVG, rflux, CHI2RED  & 
        ,PEAKMJD_INI, PEAKMJD_SAVE  & 
        ,DIFMJD_MIN, DIFMJD_MAX, DIFMJD_BIN, DIFMJD  & 
        ,COLOR_INI, COLOR_SAVE, COLOR_MIN, COLOR_MAX, COLOR_BIN, COLOR  & 
        ,INIVAL_START(IPAR_MAX), RTMP(MXFILT_ALL)

    REAL*8  T8, Z8

! FCNSNLC args
    INTEGER IFLAG
    REAL*8 GRAD(MXFITPAR), CHI8INI, CHI8END, CHI8MIN, CHI8

! functions
    REAL  DATA_MODEL_RATIO
    REAL*8  USRFUN
    EXTERNAL USRFUN
    LOGICAL  FIRST_ITERATION

! --------------- BEGIN -------------

    IERR = 0

    if ( DOFIT_PHOTOZ_MCMC_ADJUST ) RETURN

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 0")

! process only 1st fit iteration

    FIRST_ITER = FIRST_ITERATION(ITER)

    IF ( .NOT. FIRST_ITER ) RETURN
    IF ( LFIXPAR_ALL      ) RETURN
    IF ( USESIM_INIVAL    ) RETURN  ! May 2022
    IF ( DOFIT_IDEAL      ) RETURN  ! Dec 2023
    IF ( USE_PRIOR_SNCID_FILE  ) RETURN  ! Jan 2025

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 1")

    LPRINT = STDOUT_UPDATE

! init everything to zero

    DO ifilt_obs = 1, MXFILT_ALL
       RATIO_FLUX(ifilt_obs)   = -9.0
    ENDDO


    cid   = SNLC_CID
    Z8    = REDSHIFT_FIT

    IFLAG = FCNFLAG_USER  ! to fill EP_XXX arrays in FCNSNLC

    IF ( LPRINT ) THEN
       LCHAR = ISNLC_LENCCID
       write(BANNER,10) cid, SNLC_CCID(1:LCHAR)
10     format('FITINI_ADJUST for CID=',I8, 3x, '(',A,')'   )
       CALL PRBANNER ( BANNER )
    endif

! save initial values before they are modified

    DO ipar = 1, IPAR_MAX
      INIVAL_START(ipar) = SNGL( INIVAL(ipar) )
    ENDDO

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 2")

! -----------------------------------------------------
! call FCNSNLC with INIVAL and IFLAG = FCNFLAG_USER (last-call)
! to set EP_XXX arrays with initial conditions.
! This is needed to check initial data/model normalization.

    CALL FCNSNLC(NFITPAR_MN, GRAD, CHI8INI, INIVAL, IFLAG, USRFUN)
    CHI2RED        = SNGL(CHI8INI/DBLE(NEPOCH_ALL(0)))
    FITCHI2RED_INI = CHI2RED  ! store for SNANA table
    if ( CHI2RED < FITWIN_CHI2RED_INI(1) .or.  & 
           CHI2RED > FITWIN_CHI2RED_INI(2) ) then
        IERR = ERRFLAG_FITPREP_ADJUST
        RETURN
    endif

    if ( LPRINT ) then
      write(6,56) 'BEFORE', chi8INI, NEPOCH_ALL(0)
    endif

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 3")

! -----------------------------------------------------
! Now check PEAKMJD by testing 1/2-sigma steps

    PEAKMJD_INI  = SNGL( INIVAL(IPAR_PEAKMJD) )
    PEAKMJD_SAVE = SNGL( INIVAL(IPAR_PEAKMJD) )
    DIFMJD_MIN   = INIVAL_GRIDSEARCH_DPEAKMJD(1)
    DIFMJD_MAX   = INIVAL_GRIDSEARCH_DPEAKMJD(2)
    DIFMJD_BIN   = INIVAL_GRIDSEARCH_DPEAKMJD(3)

!     D. Jones color grid search
    COLOR_INI   = SNGL( INIVAL(IPAR_COLOR) )
    COLOR_SAVE  = SNGL( INIVAL(IPAR_COLOR) )
    COLOR_MIN   = INIVAL_GRIDSEARCH_COLOR(1)
    COLOR_MAX   = INIVAL_GRIDSEARCH_COLOR(2)
    COLOR_BIN   = INIVAL_GRIDSEARCH_COLOR(3)

    DO_PEAKMJD = (INISTP_PEAKMJD > 0.0 .and. DIFMJD_BIN > 0.0001)
    DO_COLOR   = (INISTP_COLOR   > 0.0 .and. COLOR_BIN  > 0.0001)

    IF ( .not. DO_COLOR ) THEN
      COLOR_MIN = COLOR_INI
      COLOR_MAX = COLOR_INI
      COLOR_BIN = 999.0   ! avoid infinite loop if no color bins
    ENDIF

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 4")

    if ( .not. DO_PEAKMJD ) GOTO 444

    CHI8MIN = CHI8INI
    COLOR   = COLOR_MIN

    DO 300 WHILE ( COLOR < COLOR_MAX+0.0001 )
      INIVAL(IPAR_COLOR) = COLOR
      DIFMJD = DIFMJD_MIN
    DO 400 WHILE ( DIFMJD < DIFMJD_MAX+0.001 )
      INIVAL(IPAR_PEAKMJD) = PEAKMJD_INI + DIFMJD

      CALL FCNSNLC(NFITPAR_MN,GRAD,CHI8,INIVAL,IFLAG,USRFUN)
      if ( CHI8 .LT. CHI8MIN ) then
          chi8min = chi8
          PEAKMJD_SAVE = SNGL( INIVAL(IPAR_PEAKMJD) )
          COLOR_SAVE   = SNGL( INIVAL(IPAR_COLOR) )
      endif
      DIFMJD = DIFMJD + DIFMJD_BIN
400   CONTINUE
      COLOR = COLOR + COLOR_BIN
300   CONTINUE

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 5")

! load inital PEAK MJD and re-run FCNSNLC to update EP_FLUX_MODEL

    IF ( CHI8MIN < CHI8INI ) THEN
     ! save new initial values at min chi2 on very course grid
      INIVAL(IPAR_PEAKMJD) = PEAKMJD_SAVE
      INIVAL(IPAR_COLOR) = COLOR_SAVE
    ELSE
     ! restore original values
      INIVAL(IPAR_PEAKMJD) = PEAKMJD_INI
      PEAKMJD_SAVE         = PEAKMJD_INI
      INIVAL(IPAR_COLOR)   = COLOR_INI
      COLOR_SAVE           = COLOR_INI
    ENDIF

    CALL FCNSNLC(NFITPAR_MN,GRAD,CHI8,INIVAL,IFLAG,USRFUN)

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 6")

! - - - - -
    if ( LPRINT ) then
       LCHAR  = INDEX(PARNAME_STORE(IPAR_PEAKMJD),' ') - 1
       LCHAR2 = INDEX(PARNAME_STORE(IPAR_COLOR),  ' ') - 1
       IF ( DO_COLOR ) THEN
         write(6,42)  & 
               PARNAME_STORE(IPAR_PEAKMJD)(1:LCHAR),  & 
               PARNAME_STORE(IPAR_COLOR)(1:LCHAR2),  & 
               PEAKMJD_INI, COLOR_INI,  & 
               INIVAL(IPAR_PEAKMJD), INIVAL(IPAR_COLOR), CHI8
       ELSE
         write(6,41) PARNAME_STORE(IPAR_PEAKMJD)(1:LCHAR),  & 
                     PEAKMJD_INI, INIVAL(IPAR_PEAKMJD), CHI8
       ENDIF

41       format(T10,'Adjust ',A,'=',F9.3, ' ==> ', F9.3,  & 
                   2x, '(CHI2=',F10.2,')'  )

42       format(T6,'Adjust ',A,'/',A, '=',  & 
              F9.3,'/',F6.3, ' ==> ', F9.3,'/',F6.3,  & 
              2x, '(CHI2=',F10.2,')'  )

    endif

444   CONTINUE

! -----------------------------------------------------
! Now check Data vs. Model;
! The data/model flux ratio-average will serve as
! an estimator for peakmag(data)-peakmag(model).

    RATIO_FLUX_AVG = 0.0
    NFILT          = 0
    DO 105 ifilt = 1, NFILTDEF_SURVEY
      ifilt_obs  = IFILTDEF_MAP_SURVEY(ifilt)
      if ( USE_FILT(ifilt_obs) ) then
        Rflux                 = DATA_MODEL_RATIO(ifilt)
        RATIO_FLUX(ifilt_obs) = Rflux
        RATIO_FLUX_AVG        = RATIO_FLUX_AVG + Rflux
        NFILT                 = NFILT + 1
      endif
105   CONTINUE

    IF ( NFILT .GT.0 ) THEN
       RATIO_FLUX_AVG = RATIO_FLUX_AVG / float(NFILT)
    ELSE
       RATIO_FLUX_AVG = 1.0
    ENDIF

    IPAR_ADJUST = 0

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 .and.  & 
           INISTP_X0 > 0.0 ) THEN

       IPAR_ADJUST         = IPAR_X0

       if ( OPT_SALT2FIT .EQ. 0 ) then   ! nominal SALT2 fit
         INIVAL(IPAR_ADJUST) = INIVAL(IPAR_ADJUST)  & 
                               * RATIO_FLUX_AVG

       else if ( OPT_SALT2FIT .EQ. 1 ) then
         INIVAL(IPAR_ADJUST) = INIVAL(IPAR_ADJUST)  & 
                               + LOG10(RATIO_FLUX_AVG)

       else if ( OPT_SALT2FIT .EQ. 2 ) then
         INIVAL(IPAR_ADJUST) = INIVAL(IPAR_ADJUST)  & 
                               - 2.5*LOG10(RATIO_FLUX_AVG)
       endif

    ELSE IF ( INISTP_DLMAG .GT. 0.0 ) THEN
       IPAR_ADJUST         = IPAR_DLMAG
       INIVAL(IPAR_ADJUST) = INIVAL(IPAR_ADJUST)  & 
                              -2.5*LOG10(RATIO_FLUX_AVG)
    ENDIF

! #########################################

    if ( LPRINT ) then

       NF = 0
       CFILT = ' '
       DO ifilt    = 1, NFILTDEF_SURVEY
         ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
         if ( USE_FILT(ifilt_obs) ) then
           NF = NF + 1
           LCHAR = INDEX(CFILT,' ') - 1
           CFILT = CFILT(1:LCHAR)  & 
                   // FILTDEF_STRING(ifilt_obs:ifilt_obs)
           RTMP(NF) = RATIO_FLUX(ifilt_obs)
        endif
       ENDDO

       write(6,51) CFILT(1:NF) // ' Data/Model flux-ratio'
       DO IFILT = 1,  NF
         write(6,52) RTMP(IFILT)
       ENDDO

       print*,' '

       if ( IPAR_ADJUST .GT. 0 ) then
         CPAR = PARNAME_STORE(IPAR_ADJUST)
         LTMP = INDEX(CPAR,' ') - 1
         write(6,54)  & 
              CPAR(1:LTMP)  & 
             ,INIVAL_START(IPAR_ADJUST)  & 
             ,INIVAL(IPAR_ADJUST)
      endif

51       format(T4, A, ' :', $ )
52       format(F7.3, $ )
54       format(T8,A,' = ', G10.3,' ==> ', G10.3 )


    ENDIF ! end of LDMP block

    if ( LTRACE ) CALL DMPTRACE("INSIDE FITINI_ADJUST: 8")


! -------------------------------------------
! check chi2 at end of adjustment

    CALL FCNSNLC(NFITPAR_MN,GRAD,CHI8END,INIVAL,IFLAG,USRFUN)
    CHI2RED         = SNGL(CHI8END/DBLE(NEPOCH_ALL(0)))
    FITCHI2RED_INI2 = CHI2RED        ! store for SNANA table
    if ( CHI2RED < FITWIN_CHI2RED_INI2(1) .or.  & 
           CHI2RED > FITWIN_CHI2RED_INI2(2) ) then
        IERR = ERRFLAG_FITPREP_ADJUST
        RETURN
    endif

    if ( LPRINT ) then
      write(6,56) 'AFTER ', chi8end,  NEPOCH_ALL(0)
    endif

56  format(T4,'FCNSNLC(',A,' FITINI_ADJUST)    returns   CHI2=',  & 
         F10.2,'/',I3)

! -----------------------------------------------
! if final chi2 is worse, then switch back to initial parameters
! and minimized PEAKMJD

    IF ( CHI8END .GT. CHI8INI ) THEN
      if ( STDOUT_UPDATE ) then
        print*,' '
        print*,'  WARNING: ADJUSTED CHI2 is WORSE => '
        print*,'           SWITCH BACK TO ORIGINAL INIVAL '
      endif

      DO ipar = 1, IPAR_MAX
        INIVAL(ipar) = INIVAL_START(ipar)
      ENDDO
      INIVAL(IPAR_PEAKMJD) = PEAKMJD_SAVE  ! save new PEAKMJD
    ENDIF

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE FITINI_ADJUST 

! ===========================================
    SUBROUTINE FORCE_BANDLIST_SNCID_FILE()

! Created Jan 2025
! Force filters used in previous fit and read from argument of SNCID_LIST_FILE.
! Set FILTLIST_FIT_USE and also USE_FILT(ifilt) array.


    USE SNDATCOM
    USE SNANAFIT
    USE FILTCOM
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER LENV, LENB, ABORT_FLAG
    INTEGER ifilt, ifilt_obs
    REAL*8 DVAL
    CHARACTER cVAR*40, CTMP*40, BANDLIST*40, cfilt*2

! --------- BEGIN ---------

    cVAR = 'BANDLIST' // char(0) ; LENV = 8
    ABORT_FLAG = 1

    CALL MATCH_CIDLIST_PARVAL(INDEX_CID_MATCH, cVAR, ABORT_FLAG,  & 
              DVAL, BANDLIST, LENV, LENB)  ! ignore DVAL

    LENB = INDEX(BANDLIST, char(0)) - 1
    PRIOR_BANDLIST_SNCID_FILE = BANDLIST(1:LENB)

    if ( STDOUT_UPDATE ) then
       CTMP = 'PRIOR-' // cVAR(1:LENV)
       write(6,54) CTMP, BANDLIST(1:LENB), SNLC_CCID
       call FLUSH(6)
    endif

 54    format(T8, A14, ' : ', A, ' from list file: CID=', A10)

! load global info to use these bands

    DO ifilt     = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       cfilt     = filtdef_string(ifilt_obs:ifilt_obs)
       if ( INDEX(BANDLIST, cfilt(1:1) ) > 0 ) then
          PRIOR_USE_FILT_SNCID_FILE(ifilt_obs) = .TRUE.
       else
          PRIOR_USE_FILT_SNCID_FILE(ifilt_obs) = .FALSE.
       endif
    ENDDO

! disable feature to add/drop filters
    PHOTODZ_REJECT   = -99.0
    PHOTODZ1Z_REJECT = -99.0

    RETURN
  END SUBROUTINE FORCE_BANDLIST_SNCID_FILE

! ==========================
    SUBROUTINE FITINI_LIST_FILE(iter)

! Created Apr 29 2022 by R.Kessler
! If &SNLCINP SNCID_LIST_FILE is set, check for previous SALT2/SALT3 fit
! values to use as INIVAL when iter=1.
! If INISTP(ipar)=0 [fixed parameter value],
! apply previous SALT2 fit value for all iterations.
! 
! Jan 2025: check new option (4-bit) to use FITPAR as prior
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER ITER ! (I) fit iteration

    INTEGER IPAR_LIST(20), NPAR, i, ipar
    INTEGER ABORT_FLAG, LENV, N_NOTVALID_INIVAL,N_NOTVALID_PRIOR
    REAL*8  DVAL, DVAL_ERR, PRIOR_VAL, PRIOR_ERR
    CHARACTER cVAR*40, cERR*40, CTMP*40, FNAM*20
    CHARACTER STATUS_INIVAL*16, STATUS_PRIOR*16
    LOGICAL VBOSE, FIRST_ITER, LSET, USE_FITPAR
    LOGICAL VALID_INIVAL, VALID_PRIOR

! functions
    REAL*8   SET_PRIOR_FITPAR_SIG
    EXTERNAL MATCH_CIDLIST_PARVAL

! ----------- BEGIN ----------

    USE_FITPAR = USE_INIVAL_SNCID_FILE .OR. USE_PRIOR_SNCID_FILE
    IF ( .NOT. USE_FITPAR ) RETURN

    FIRST_ITER = (ITER==1 .and. .not. LREPEAT_ITER)
    VBOSE = STDOUT_UPDATE

    FNAM = 'FITINI_LIST_FILE'
    if ( VBOSE ) CALL PRBANNER(FNAM)

! construct list of params to check in SNCID_LIST file

    NPAR = 0

    NPAR = NPAR + 1
    IPAR_LIST(NPAR) = IPAR_PEAKMJD
    NPAR = NPAR + 1
    IPAR_LIST(NPAR) = IPAR_X0
    NPAR = NPAR + 1
    IPAR_LIST(NPAR) = IPAR_SHAPE
    NPAR = NPAR + 1
    IPAR_LIST(NPAR) = IPAR_COLOR

    IF ( DOFIT_PHOTOZ ) THEN
      NPAR = NPAR + 1
      IPAR_LIST(NPAR) = IPAR_zPHOT
    ENDIF

    ABORT_FLAG = 0 ! do not abort on missing variable.
    N_NOTVALID_INIVAL = 0
    N_NOTVALID_PRIOR  = 0

    DO 50 i = 1, NPAR
       IPAR = IPAR_LIST(i)
       LSET = (FIRST_ITER .or. INISTP(IPAR)==0.)
       IF (.not. LSET) GOTO 50

!  first iteration below
       LENV = INDEX(PARNAME_STORE(IPAR),' ') - 1
       cVAR = PARNAME_STORE(IPAR)(1:LENV) // char(0)
       if ( IPAR == IPAR_zPHOT ) then
          cVAR = 'zHD' // char(0)
          LENV = 3
       endif

!  Jan 2025: construct column of fit par ERROR
       cERR = cVAR(1:LENV) // 'ERR' // char(0)

       CALL MATCH_CIDLIST_PARVAL(INDEX_CID_MATCH, cVAR, ABORT_FLAG,  & 
            DVAL,    CTMP, LENV, 40)  ! return DVAL
       CALL MATCH_CIDLIST_PARVAL(INDEX_CID_MATCH, cERR, ABORT_FLAG,  & 
            DVAL_ERR, CTMP, LENV, 40)  ! return DVAL_ERR

       VALID_INIVAL = ( DVAL > -999.0  )
       VALID_PRIOR  = ( DVAL > -999.0 .and. DVAL_ERR > 0.0 )
       STATUS_INIVAL = '' ; STATUS_PRIOR = ''
       if ( .NOT. VALID_INIVAL ) then
          N_NOTVALID_INIVAL = N_NOTVALID_INIVAL + 1
          STATUS_INIVAL = '*** INVALID *** '
       endif
       if ( .NOT. VALID_PRIOR ) then
          N_NOTVALID_PRIOR = N_NOTVALID_PRIOR + 1
          STATUS_PRIOR = '*** INVALID *** '
       endif

       if ( USE_INIVAL_SNCID_FILE ) then
          INIVAL(IPAR) = DVAL   ! load initial value for fit
          if ( VBOSE ) then
             CTMP = 'INIVAL-' // cVAR(1:LENV)
             write(6,44) CTMP, DVAL, SNLC_CCID, STATUS_INIVAL
          endif
       endif ! end USE_INIVAL_SNCID_FILE

       if ( USE_PRIOR_SNCID_FILE ) then
          INIVAL(IPAR) = DVAL
          PRIOR_VAL = DVAL
          PRIOR_ERR = SET_PRIOR_FITPAR_SIG(IPAR,DVAL_ERR)
          PRIOR_FITPAR_SNCID_FILE(1,IPAR) = SNGL(PRIOR_VAL)     ! Gauss mean
          PRIOR_FITPAR_SNCID_FILE(2,IPAR) = SNGL(PRIOR_ERR)     ! Gauss sigma
          
          if ( VBOSE ) then
             CTMP = 'PRIOR-' // cVAR(1:LENV)
             write(6,45) CTMP, PRIOR_VAL, PRIOR_ERR, SNLC_CCID, STATUS_PRIOR
             call FLUSH(6)
          endif
       endif

 50   CONTINUE

44     format(T8, A14, ' : ', G10.3,  & 
                  ' from list file: CID=', A10, 3x, A)
45     format(T8, A14, ' : ', G10.3, ' +_ ', G10.3,  & 
                  ' from list file: CID=', A10, 3x, A)

    CALL FLUSH(6)
! - - - -
    if ( USE_PRIOR_SNCID_FILE .and. N_NOTVALID_PRIOR > 0 ) then
      write(c1err,662) N_NOTVALID_PRIOR, NPAR, 'PRIORs', SNLC_CCID
      write(c2err,663)
      CALL MADABORT ( "FITINI_LIST_FILE", c1err, c2err )
    endif

662     format(I2,' of ', I2,' fitpar ',A,' are invalid for ', A12)
663     format('check fit pars in argument of SNCID_LIST_FILE')

    if ( USE_INIVAL_SNCID_FILE .and. N_NOTVALID_INIVAL > 0 ) then
      write(c1err,662) N_NOTVALID_INIVAL, NPAR, 'INIVALs', SNLC_CCID
      write(c2err,663)
      CALL MADABORT ( "FITINI_LIST_FILE", c1err, c2err )
    endif

    RETURN
  END SUBROUTINE FITINI_LIST_FILE

! =======================================
    DOUBLE PRECISION FUNCTION SET_PRIOR_FITPAR_SIG(IPAR,DVALSIG)

! return Gaussian sigma to use as prior; this sigma is based
! on previous LC fit, and intended to use for systmatics to
! prevent large/unphysical deviations.


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER IPAR     ! (I) fit par index
    REAL*8  DVALSIG  ! (I) fitpar sigma read from previous fit

! local args
    REAL*8  PRIOR_SIG, SCALE_SIGMA, SIG_FLOOR, MAGERR_MIN
    LOGICAL LX2, LX3

! ------------- BEGIN ----------
    PRIOR_SIG = DVALSIG

! hard-wire scale on previous fitted sigma to avoid suppressing systematic
! while still avoiding crazy outliers. This is not well tuned so may
! need more study.
    SCALE_SIGMA = 1.0

! SIG_FLOOR logic is desgined for SALT2/3, and maybe works for BayeSN ??
! But set a trap for BayeSN just to alert the user
    IF ( FITMODEL_INDEX .EQ. MODEL_BAYESN ) THEN
      c1err = 'Must check SIG_FLOOR logic below before '  & 
                // 'bypassing this abort.'
      c2err = 'Does BAYESN need different SIG_FLOOR values ?'
      CALL MADABORT ( "SET_PRIOR_FITPAR_SIG", c1err, c2err )
    ENDIF

    SIG_FLOOR  = .01
    MAGERR_MIN = 0.03  ! guess
    IF ( IPAR == IPAR_COLOR ) THEN
       SIG_FLOOR = MAGERR_MIN/3.1  ! beta*cERR >= MAGERR_MIN
    ELSE IF ( IPAR == IPAR_SHAPE ) THEN
       SIG_FLOOR = MAGERR_MIN/0.15  ! alpha*sERR >= MAGERR_MIN
    ELSE IF ( IPAR == IPAR_DLMAG ) THEN  ! MU or x0
       SIG_FLOOR = MAGERR_MIN
    ELSE IF ( IPAR == IPAR_ZPHOT ) THEN
       SIG_FLOOR = 0.02   ! guess
    ENDIF

! few debug option to play with scale
    LX2       = (IAND(DEBUG_FLAG,2) > 0)
    LX3       = (IAND(DEBUG_FLAG,4) > 0)

    IF ( LX2 ) then
       SCALE_SIGMA = 2.0
    ELSE IF ( LX3 ) THEN
       SCALE_SIGMA = 3.0
    ENDIF
    PRIOR_SIG = SCALE_SIGMA*DVALSIG

! Aug 27 2025 : avoid too-small PRIOR_SIG
    if ( PRIOR_SIG < SIG_FLOOR ) PRIOR_SIG = SIG_FLOOR

    SET_PRIOR_FITPAR_SIG = PRIOR_SIG
    RETURN
  END FUNCTION SET_PRIOR_FITPAR_SIG

! =====================================
    SUBROUTINE FITINI_TABLEVAR

! -----------------------------------------------
! define extra "PLOTVAR" variables to plot along
! with fit values. These are all plotted as a
! function of ISN.
! 
! Jul 21, 2009: fix index bug inside LSIM if-block;
!               increment NPLOTPAR at end of bloc, instead of at start.
! 
! Sep 2, 2010: check NPLOTPAR array bound before filter loop
! Feb 13,2012: check NFILTDEF_FITRESTMAG
! 
! Sep 29, 2012: call CWNT_DUPLICATE_FILTER(i)  to check for duplicate
!               filter for case-insensitive ntuple.
! 
! Jun 24 2013: always ignore FILTER_REPLACE filters for plotting.
! 
! Mar 5 2020: ad NPTFIT_REJECT (due to DELCHI2)
! 
! -----------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM
    USE TABLEVARCOM

    IMPLICIT NONE

    CHARACTER cfilt_obs*2, cfilt_rst*1, cfilt*1
    INTEGER   ipar, ifilt, ifilt_obs, ifilt_rst, i
    INTEGER   NTMP, NFADD, IFILTDEF
    LOGICAL   REPLACE, DOFIT

! function
    LOGICAL  DUPLICATE_FILTER
! -------------- BEGIN -------------

! Oct 27, 2011:
! get fixed number of filters to include in plots and ntuple,
! and create mapping between this fitted subset and
! the complete list of NFILTEDEF_SURVEY
! 

    NFILTOBS_TABLE = 0
    SURVEY_FILTERS_TABLE = ' '

    DO 624 ifilt = 1, NFILTDEF_SURVEY

         ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)

         REPLACE  = (IFILTOBS_REPLACE(ifilt_obs) .NE. IFILT_OBS)
         IF ( REPLACE ) GOTO 624  ! always ignore a replaced filter

         DOFIT   = DOFIT_FILT(ifilt_obs)

         if ( DOFIT ) then
             NFILTOBS_TABLE = NFILTOBS_TABLE + 1
             IFILTOBS_MAP_TABLE(NFILTOBS_TABLE) = ifilt_obs
             IFILT_MAP_TABLE(NFILTOBS_TABLE)    = ifilt

             SURVEY_FILTERS_TABLE =  & 
                 SURVEY_FILTERS_TABLE(1:NFILTOBS_TABLE-1) //  & 
                 FILTDEF_STRING(IFILT_OBS:IFILT_OBS)
         endif
624   CONTINUE

! - - - - - - - - - - - - - - - - - - - - -
! check filter-REMAP option (Feb 2017)
    IF ( NFILT_REMAP_TABLE > 0 ) THEN
      NFILTOBS_TABLE       = NFILT_REMAP_TABLE
      SURVEY_FILTERS_TABLE = FILTLIST_REMAP_TABLE
      DO ifilt = 1, NFILT_REMAP_TABLE
         IFILTOBS_MAP_TABLE(ifilt) = IFILTLIST_REMAP_TABLE(ifilt)
      ENDDO
    ENDIF

! ----------------------
! define names of extra calculated parameters to plot;
! these parnames are used only in HFFITRES

    NPLOTPAR = IPAR_MAX

! make sure we don't exceed bound before filling arrays
    NTMP = NPLOTPAR + 7 * NFILTDEF_SURVEY
    if ( NTMP .GT. MXFITSTORE ) then
      write(c1err,662) 'Filter', NTMP
      write(c2err,663) MXFITSTORE
      CALL MADABORT ( "FITINI_TABLEVAR", c1err, c2err )
    endif


! add chi2 info for global fit.
    PARPTR_CHI2     =  NPLOTPAR  ! mark pointer-offset to global chi2 vars

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'NDOF'
    PAROPT_STORE(NPLOTPAR)  = OPT_PARSTORE_TEXTTABLE

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'NPTFIT_REJECT'  ! Mar 2020

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'FITCHI2'
    PAROPT_STORE(NPLOTPAR)  = OPT_PARSTORE_TEXTTABLE

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'PRIORCHI2'

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'SIGCHI2'   ! used when DOCHI2_SIGMA=T

    IF ( LSIM_SNANA ) THEN
      NPLOTPAR        =  NPLOTPAR + 1
      PARNAME_STORE(NPLOTPAR) = 'SIMCHI2'
    ENDIF

! --- now the fit-probs

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'FITPROB_NOMARG' ! includes prior, before marg

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'FITPROB'    ! includes prior, after marg
    PAROPT_STORE(NPLOTPAR)  = OPT_PARSTORE_TEXTTABLE

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'FITPROB_NOPRIOR'    ! excludes prior

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'RADIUS_POP'  ! Jan 2024
    PAROPT_STORE(NPLOTPAR)  = 1

! init everything, even for unused filters.

    DO 555 i = 1, NFILTOBS_TABLE  ! loop over observer-frame filters

      ifilt_obs  = IFILTOBS_MAP_TABLE(i)
      ifilt      = IFILT_MAP_TABLE(i)
      cfilt_obs  = FILTDEF_STRING(ifilt_obs:ifilt_obs)

! check for duplicate filters such as g,G or r,R ...
! perfectly allowed in snana, but ntuples cannot distinguish
! since they are case-insensitive.
      IF ( DUPLICATE_FILTER(i,SURVEY_FILTERS_TABLE) ) THEN
         cfilt_obs = cfilt_obs(1:1) // '2'  ! for ntuple distinction
      ENDIF

      NFADD = 0
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'm0obs_' // cfilt_obs

      NFADD = NFADD + 1
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'em0obs_' // cfilt_obs

      if ( NFILTOBS_TABLE .GT. 20 ) GOTO 555

      NFADD = NFADD + 1
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'PEAKFLUX_' // cfilt_obs

      NFADD = NFADD + 1
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'EPEAKFLUX_' // cfilt_obs

      NFADD = NFADD + 1
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'Nepoch_' // cfilt_obs

      NFADD = NFADD + 1
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'chi2_' // cfilt_obs

      NFADD = NFADD + 1
      ipar = NPLOTPAR + i + NFADD*NFILTOBS_TABLE
      PARNAME_STORE(ipar) = 'FITPROB_' // cfilt_obs

555   CONTINUE

    NPLOTPAR = NPLOTPAR + (NFADD+1) * NFILTOBS_TABLE


! plot peakMags in rest-frame.
! The number of rest-frame filters can be different
! than the number of observer-frame filters,
! so do NOT put this part into the 555 loop above.

    IF ( LREST_FITMODEL ) THEN
      DO ifilt     = 1, NFILTDEF_REST
       ifilt_rst = IFILTDEF_MAP_REST(ifilt)
       cfilt_rst = FILTDEF_STRING(ifilt_rst:ifilt_rst)
       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'm0rst_' // cfilt_rst

! pointer to assoc NPLOTVAR with ifilt-rest
       PARPTR_IFILT_REST(ifilt_rst) = NPLOTPAR
      ENDDO
    ENDIF

! Feb 2012: Optional FITRESTMAGs
    PARPTR_FITRESTMAG  =  NPLOTPAR  ! mark pointer-offset
    DO ifilt           = 1, NFILTDEF_FITRESTMAG
       IFILTDEF        = IFILTDEF_FITRESTMAG(ifilt)
       cfilt           = FILTDEF_STRING(ifiltdef:ifiltdef)

       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'M0_' // cfilt
       PAROPT_STORE(ipar)  = OPT_PARSTORE_TEXTTABLE

       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'ERRM0_' // cfilt
       PAROPT_STORE(ipar)  = OPT_PARSTORE_TEXTTABLE
    ENDDO

! Mar 2013: optional FITMAGDIF
    IF ( FILTER_FITMAGDIF .NE. '' ) THEN
       cfilt = FILTER_FITMAGDIF(1:1)

       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'MAGDIF_' // cfilt
       PAROPT_STORE(ipar)  = OPT_PARSTORE_TEXTTABLE

       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'ERRMAGDIF_' // cfilt
       PAROPT_STORE(ipar)  = OPT_PARSTORE_TEXTTABLE

       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'MAGDIF_FITPROB_' // cfilt

       NPLOTPAR        = NPLOTPAR + 1
       ipar            = NPLOTPAR
       PARNAME_STORE(ipar) = 'MAGDIF_FITPROB2_' // cfilt

    ENDIF

! April 2013: optional peak-mag(s) in other observer-frame filters
!             e.g.: FILTLIST_FIT = 'ugriz+BV' -> include B&V peak mags

! ---

    NPLOTPAR            =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'delZ'

    NPLOTPAR            =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'delmu'

! Dec 5, 2006: extra Z plots for PHOTOZ fits.

    NPLOTPAR        =  NPLOTPAR + 1
    PARNAME_STORE(NPLOTPAR) = 'delZph'

    if ( NPLOTPAR .GT. MXFITSTORE ) then
      write(c1err,662) 'FINAL', NPLOTPAR
662     format(A, ' NPLOTPAR = ', I3 )
      write(c2err,663) MXFITSTORE
663     format('Exceeds MXFITSTORE = ', I4 )
      CALL MADABORT ( "FITINI_TABLEVAR", c1err, c2err )
    endif

    RETURN
  END SUBROUTINE FITINI_TABLEVAR

! =====================================
    SUBROUTINE FITINI_PRKCOR()
! 
! print info about K corrections
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

! local var

    INTEGER   ifilt_rest1, ifilt_rest2, ifilt_obs, ifilt
    REAL Z, LAMDIF_MIN

! function
    INTEGER NEAREST_IFILTDEF_WRAPPER

! -------------- BEGIN -------------


    z = REDSHIFT_FIT
    print*,' '
    DO 700 ifilt = 1, NFILTDEF_SURVEY  ! loop over observed filters

      ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
      if ( .NOT. USE_FILT(ifilt_obs) ) goto 700

      ifilt_rest1 =  & 
          NEAREST_IFILTDEF_WRAPPER( OPT_FILTOBS, ifilt_obs,  & 
                   1,Z, LAMDIF_MIN)
      ifilt_rest2 =  & 
          NEAREST_IFILTDEF_WRAPPER( OPT_FILTOBS, ifilt_obs,  & 
                   2,Z, LAMDIF_MIN)

      write(6,701)  & 
          SNLC_CCID(1:ISNLC_LENCCID)  & 
         ,filtdef_string(ifilt_obs:ifilt_obs)  & 
         ,filtdef_string(ifilt_rest1:ifilt_rest1)  & 
         ,filtdef_string(ifilt_obs:ifilt_obs)  & 
         ,filtdef_string(ifilt_rest1:ifilt_rest1)  & 
         ,filtdef_string(ifilt_rest2:ifilt_rest2)  & 
         ,OPT_FILTOBS

701      FORMAT(T5,'CID=',A, ' : ',  & 
                   A,'-band KCOR = K_', A,A,  & 
               ' ; AVwarp from ', A,'-', A, 3x,'(OPT=',I2,')' )

700   CONTINUE

    RETURN
  END SUBROUTINE FITINI_PRKCOR


! =====================================
    SUBROUTINE FITINI_COV(MSKOPT, ITER, FITPAR, IERR)

! ---------------------------
! init FITCOV arrays used in FCNSNLC and also used
! to get covariance matrix.
! MSKOPT: bit 1 => print  info to stdout
! ITER = 1, 2, ... = fit iteration.
! 
! 
! Feb 2020: add OPT_COVAR_MWXT==2 option to include only DIAG part.
! May 2021: pass param lists to gencovar_SALT2
! Jul 2024: load PARLIST_SN(4:5)
! 
! ----------------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER MSKOPT     ! (I) bit-mask of options
    INTEGER ITER       ! (I) fit iteration
    REAL*8  FITPAR(MXFITPAR) ! (I) fit parameters
    INTEGER IERR       ! (O) 0 => ok

! local var

    INTEGER  & 
         ifilt_obs, ifilt_rest, ISTAT  & 
        ,irow, icol, J1, N, ep, ep_row, ep_col  & 
        ,IFILT_COV(MXFIT_DATA), LCCID, NONZERO

    REAL*8  & 
         COVTMP, RHO, Z, MWEBV, RHO_TMP & 
        ,TOBS(MXFIT_DATA)  & 
        ,TREST(MXFIT_DATA)  & 
        ,COVMAG_ERR(MXFIT_DATA)  & 
        ,SQMAGERR, R1, R2, ERR1, ERR2, FUDGE_SQERR  & 
        ,COV_MWXT, COV_MODEL, COV_DATA, x1, xx1  & 
        ,PARLIST_SN(10), PARLIST_HOST(10)

    LOGICAL  & 
        LPRINT, USE_DIAG_ONLY, LTMP, LDIAG, FIRST_ITER, CHECK_COV  & 
       ,LMWXT

    character BANNER*80, ccid*(MXCHAR_CCID), FNAM*12

! functions
    INTEGER  & 
         gencovar_mlcs2k2  & 
        ,gencovar_SALT2

    LOGICAL FIRST_ITERATION
    REAL*8 RHOFUDGE_MODEL, COVFUDGE_DATA, SALT2xx1

    EXTERNAL INVERTMATRIX

! ------------------- BEGIN ---------------

    IERR = 0   ! init output flag to OK

    FIRST_ITER = FIRST_ITERATION(ITER)

    LPRINT = BTEST(MSKOPT,0) .and. STDOUT_UPDATE
    FNAM   = 'FITINI_COV'
    CCID   = SNLC_CCID
    LCCID  = ISNLC_LENCCID

    IF ( LPRINT ) THEN
      write(BANNER,19) CCID(1:LCCID), iter
19      format('FITINI_COV: init fit arrays for CID=',A,' ITER=',I2)
      CALL PRBANNER(BANNER)
    ENDIF

! init

! -------------------------------
!  Fill R4EP_XXX and I4EP_XXX arrays.

    CALL LOAD_EPALL(ITER, FITPAR(IPAR_PEAKMJD) )

    NFITDATA_TOTAL = NFITDATA + NFITDATA_REJECT

! -------------------------------
! load some local arrays.

      DO N = 1, NFITDATA_TOTAL
         ep = EPLIST_FIT(N)

         ifilt_obs  = I4EP_ALL(ep,IEP_IFILT_OBS)
         ifilt_rest = I4EP_ALL(ep,IEP_IFILT_REST1)

         IF ( LREST_FITMODEL ) THEN
            IFILT_COV(N) = IFILTDEF_INVMAP_REST( IFILT_REST ) - 1
         ELSE
            IFILT_COV(N) = IFILT_OBS
         ENDIF

         TREST(N)    = dble( R4EP_ALL(ep,JEP_TREST) )
         TOBS(N)     = dble( R4EP_ALL(ep,JEP_TOBS)  )

      ENDDO

! -------------------------------------------------
! set flag to use diagonal elements only if
! OPT_COVAR_FLUX <= 0 or if this is the 1st iteration

    CHECK_COV = (.NOT. FIRST_ITER)
    if ( OPT_SALT2FIT.EQ.4 ) CHECK_COV = ( ITER .EQ. 3 ) ! mimic Guy-code

    USE_FITCOV = .FALSE.
    IF ( CHECK_COV ) THEN
      if ( OPT_COVAR_FLUX     > 0    ) USE_FITCOV = .TRUE. ! model cov
      if ( OPT_COVAR_MWXTERR  > 0    ) USE_FITCOV = .TRUE. ! MWEBV cov
      if ( FUDGE_MAG_COVERR .NE. ' ' ) USE_FITCOV = .TRUE. ! data cov
    ENDIF
    USE_DIAG_ONLY = .NOT. USE_FITCOV

    IF ( LPRINT ) THEN
      write(6,21) NFITDATA,          'ACCEPTED'
      write(6,21) NFITDATA_REJECT,   'REJECTED'
21      format(T8,I4, 2x, 'Filter-epochs ', A,' for fit.' )

      if ( USE_DIAG_ONLY ) then
         CALL  PRINT_ITERINFO(CCID,ITER,  & 
                 'Use DIAGONAL Covariance elements only.')
      else
         write(BANNER,5551) NFITDATA, NFITDATA
5551       format('Use full ',I4,' x ',I4,' Covariance matrix.')
         CALL  PRINT_ITERINFO(CCID,ITER, BANNER)
      endif

      IF ( .NOT. FIRST_ITER  ) THEN
        if ( OPT_COVAR_FLUX .GT. 0 ) THEN
           CALL  PRINT_ITERINFO(CCID,ITER,  & 
                   'Add covariance from fit-model')
        endif
        if ( OPT_COVAR_MWXTERR > 0 ) then
           CALL  PRINT_ITERINFO(CCID,ITER,  & 
                   'Add covariance from Galactic extinction')
        endif

        if ( FUDGE_MAG_COVERR .NE. ' ' ) then
           CALL  PRINT_ITERINFO(CCID,ITER,  & 
                   'Add covariance fudges from data.')
        endif
      ENDIF


    ENDIF

! 670   format(T8,'Use ',I3,' x ', I3,' Covariance computed ', A)

! --------------------------------------
    IF ( NFITDATA .LE. 0 ) THEN
      print*,' '
      print*,' FITINI_COV ERROR for CID = ', CCID(1:LCCID)
      print*,'   Nothing to fit ??? [NFITDATA=',NFITDATA,']'
      print*,'   Either remove this SN, or fix it. '
      print*,' '
      call flush(6)
! 
      if ( ABORT_ON_NOEPOCHS ) then
         C1ERR = 'Nothing to fit for CID = ' // CCID(1:LCCID)
         C2ERR = 'To avoid abort, set   ABORT_ON_NOEPOCHS=F '
         CALL MADABORT(FNAM, C1ERR, C2ERR)
      else
         IERR = ERRFLAG_FITPREP_NOEPOCHS
         RETURN
      endif

    ENDIF


    IF ( NFITDATA .LT. int(CUTWIN_NEPOCH(1)) ) then
      print*,'   FITINI_COV WARNING for CID = ', CCID(1:LCCID),  & 
            ' :   too few epochs to fit. '
      IERR = ERRFLAG_FITPREP_NEPOCH
      RETURN
    ENDIF

! =====================================================
! =====================================================
! =====================================================

! alway init covariance matrix to zero

    DO irow = 1, NFITDATA
    DO icol = 1, NFITDATA
       COVMAT2(irow,icol) = 0.0
       J1 = icol + (irow-1)*NFITDATA     ! 1-dim index for COVMAT1
       COVMAT1(J1) = 0.0
    ENDDO
    ENDDO

! ---------------------------------------------
    IF ( USE_DIAG_ONLY  ) RETURN
! ---------------------------------------------


! ----------------------------------------------------
! get COVMAT1 covariance matrix on 2nd iteration
! This linear array is converted below into a 2-dim array.
! This is the model-covariance only.

    IF ( OPT_COVAR_FLUX .GT. 0 ) THEN
      IF ( FITMODEL_INDEX .EQ. MODEL_MLCS2k2 ) THEN
        ISTAT = gencovar_mlcs2k2(NFITDATA, IFILT_COV, TREST,  & 
                     COVMAT1 )  ! ==> returned

      ELSE if ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN

         Z        = REDSHIFT_FIT
         MWEBV    = SNLC_MWEBV
         x1  = FITPAR(IPAR_SHAPE)
         xx1 = SALT2xx1(ITER,x1)
         PARLIST_SN(1) = FITPAR(IPAR_x0   )
         PARLIST_SN(2) = x1
         PARLIST_SN(3) = FITPAR(IPAR_COLOR)   ! c or AV
         PARLIST_SN(4) = xx1
         PARLIST_SN(5) = 0.0                  ! x2                 (July 29 2024)

         PARLIST_HOST(1) = 0.0  ! cannot fit RV
         PARLIST_HOST(2) = 0.0  ! cannot fit AV
         PARLIST_HOST(3) = -9.0 ! cannot fit logMass

         ISTAT = gencovar_SALT2(NFITDATA, IFILT_COV, TOBS, Z  & 
                   ,PARLIST_SN, PARLIST_HOST   &  ! (I)
                   ,MWEBV                      &  ! (I) MW extinction
                   ,COVMAT1 )         ! <== returned array, MAGERR^2

      ELSE
        C1ERR = 'No covariance model for FITMODEL='  & 
                   // FITMODEL_VERSION(1:20)
        C2ERR = 'Set OPT_COVAR_FLUX = 0 for this model'
        CALL MADABORT('FITINI_COV', C1ERR, C2ERR)
      ENDIF
    ENDIF

! print rho-fudge formula by calling with args = 0
    LTMP = OPT_COVAR_FLUX .LE. 1  ! print comment for these OPT_COVAR_FLUX
    IF ( LTMP ) THEN
      RHO_TMP = RHOFUDGE_MODEL(0, 0, DBLE(0.0) )
    ENDIF

! -------------------------------------------------------------
! fill the 2d matrix, COVMAT2, and store diagonal errors.

     DO 301 irow = 1, NFITDATA
     DO 302 icol = 1, NFITDATA

       J1 = icol + (irow-1)*NFITDATA     ! 1-dim index for COVMAT1

! transfer to 2D array
       COVMAT2(irow,icol) = COVMAT1(J1)

! store diag errors in mag space
       if ( irow .EQ. icol ) then
          COVMAG_ERR(irow)  = dsqrt ( COVMAT1(J1) )
       endif

302    CONTINUE
301    CONTINUE

!        CALL DMP_COVAR(iter)  ! for DEBUG only

     FUDGE_SQERR = FUDGE_MODELERR_SCALE**2

! now convert COVMAT2 model-magerr^2 to  model-fluxerr^2,
! and add data errors. Note that COVMAT2 changes here.

! COVMAT1/COVMAT2 is the model-magerr covariance.
! Below convert to FLUXERR covariance and add the following
!  - XTMW covariance
!  - model-err cov
!  - data error covariance
! 
! Also fill the 2d matrix, COVMAT2

     DO 311 irow = 1, NFITDATA
     DO 312 icol = 1, NFITDATA

        ep_row = EPLIST_FIT(irow)
        ep_col = EPLIST_FIT(icol)

        COV_MODEL = 0.0
        COV_MWXT  = 0.0
        COV_DATA  = 0.0

        LDIAG = (IROW .EQ. ICOL)

! start with model covariance
        IF ( OPT_COVAR_FLUX .GT. 0 ) THEN
           SQMAGERR = COVMAG_ERR(irow) * COVMAG_ERR(icol)
           RHO_TMP  = COVMAT2(irow,icol) / SQMAGERR ! reduced cov.

! check user-option to  'fudge' rho
           RHO = RHOFUDGE_MODEL ( irow, icol, RHO_TMP )

! get the model covariance
           R1   = 1.0 - 10.0**(-0.4*COVMAG_ERR(irow)) ! frac err, sigF/F
           R2   = 1.0 - 10.0**(-0.4*COVMAG_ERR(icol)) ! frac err

           ERR1 = R1 * R4EP_ALL(ep_row,JEP_MODELFLUX) ! flux error
           ERR2 = R2 * R4EP_ALL(ep_col,JEP_MODELFLUX) ! flux error
           COV_MODEL =  RHO * ERR1 * ERR2 * FUDGE_SQERR

        ELSE IF ( LDIAG ) THEN
! note that FUDGE_MODELERR_SCALE has already been
! applied to R4EP_MODELFLUX_ERR
           ERR1 = R4EP_ALL(ep_row,JEP_MODELFLUX_ERR)
           COV_MODEL = ERR1 * ERR1
       ENDIF

! check option to turn off model error.
       IF ( FUDGE_MAGERR_MODEL .EQ. 0.0 ) COV_MODEL = 0.0

! check for XTMW covariance
       LMWXT = (OPT_COVAR_MWXTERR == 1) .or.         &  ! full COV
                 (OPT_COVAR_MWXTERR == 2 .and. LDIAG) ! diag only
       IF ( LMWXT ) THEN
          ERR1 = R4EP_ALL(ep_row,JEP_MWXT_FLUXERR)
          ERR2 = R4EP_ALL(ep_col,JEP_MWXT_FLUXERR)
          COV_MWXT = ERR1 * ERR2
       ENDIF

! Now add diagonal error from data and user fudges.
       if ( LDIAG ) then
          COV_DATA  = R4EP_ALL(ep_row,JEP_DATAFLUX_ERR)**2  & 
               + R4EP_ALL(ep_row,JEP_FUDGEFLUX_ERR)**2
       endif

! add cov fudge-error for data (Feb 2015)
       COV_DATA = COV_DATA + COVFUDGE_DATA( irow, icol )

! redefine COVMAT2 in fluxerr space
       COVMAT2(irow,icol) = COV_MODEL + COV_MWXT + COV_DATA

312    CONTINUE
311    CONTINUE

!        CALL DMP_COVAR(iter)  ! for DEBUG only DDDDDDDD

! invert COVMAT2 matrix.

     CALL INVERTMATRIX( MXFIT_DATA, NFITDATA, COVMAT2)

! !!! Now COVMAT2 is the inverted COV matrix !!!

! check for min value of inverted matrix

    COVMAT_MIN = +9999.
    COVMAT_MAX = -9999.
    NONZERO = 0

    DO irow = 1, NFITDATA
    DO icol = 1, NFITDATA
       COVTMP = COVMAT2(irow,icol)
       COVMAT_MIN = MIN ( COVMAT_MIN, COVTMP )
       COVMAT_MAX = MAX ( COVMAT_MAX, COVTMP )
       if ( COVTMP .NE. 0.0 ) NONZERO = NONZERO + 1
    ENDDO
    ENDDO


    if ( LPRINT ) then
      write(BANNER,5555) NONZERO
5555    format('Inverted COVMAT with ',I6,' non-zero elements')
      CALL  PRINT_ITERINFO(CCID,ITER, BANNER(1:52) )
    endif

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE FITINI_COV

! =====================================
    SUBROUTINE LOAD_EPALL(ITER,PKMJD8)

! Created Sep 28, 2012
! 
! Fill R4EP_ and I4EP_ arrays so that first NFITDATA elements
! are the ones to fit; the next NFITDATA_REJECT elements
! are rejected epochs. This sorting is done so that FCNSLNC
! can efficiently compute chi2,  and still be able to record
! rejected epochs [when LAST=T] for plotting.
! When IREJ=0, store epochs to fit;
! when IREJ=1, tack on rejected epochs.
! 
! Feb 26 2015: load CHI2FLUX_SIM for simulation (LSIM_SNANA=T).
! 
! -------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER ITER    ! (I) fit iteration
    REAL*8  PKMJD8  ! (I) peak MJD

! local var

    INTEGER  & 
         IFILT, IFILT_OBS, IREJ, IMJD, ep, EPMIN, EPMAX  & 
        ,N, OPT, IF1, IF2, ivar, REJECT, REJECT2

    INTEGER ITER_DMP / -1 /
    REAL  & 
         Z, Z1, TREST, MAXFRAC, LAMDIF_MIN, LAMREST  & 
        ,FLUX_DATA, FLUXERR_STAT, FLUXERR_DATA, FLUX_SIM  & 
        ,FLUX_MODEL, FLUXERR_MODEL, FLUXERR_TOT  & 
        ,ERR_TRUE, ERR_CALC, ARG, TOBS, WAVECOR, ERR_TMP, ZP  & 
        ,SQDIF, SQERR

    REAL*8 FTMP8, MAGERR8, MJD8

    LOGICAL  LREJECT, LREJECT2

    character cfilt*1

! functions
    INTEGER NEAREST_IFILTDEF_WRAPPER
    LOGICAL MJDSELECT
    REAL*4 GET_FUDGE_FITERR_MAXFRAC

! ----------------- BEGIN LOAD_EPALL----------------

    N = 0
    NFITDATA        = 0
    NFITDATA_REJECT = 0

    DO ifilt = 0, MXFILT_OBS
       NEPOCH_ALL(ifilt)    = 0
       NEPOCH_FIT(ifilt)    = 0
       NEPOCH_REJECT(ifilt) = 0
    ENDDO
    NEPOCH_REJECT2 = 0

    Z = REDSHIFT_FIT
    Z1 = 1. + z

    ZP = SNGL(ZP_FLUXCAL)

! -------------------------------
! save previous R4ALL values in R4_LAST array in case
! previous iteration values are needed; e.g. FCNCHI2_SIGMA

    IF ( ITER > 1 ) THEN
       do ep = 1, MXFIT_DATA
          do ivar = 1, MXVAR_R4
             R4EP_LAST(ep,ivar) = R4EP_ALL(ep,ivar)
          enddo
       enddo
    ENDIF

! ---------------------------------

    DO 200 IREJ      = 0, 1  ! 0=keep, 1=reject

    DO 101 IMJD      = 1, ISNLC_NEWMJD_STORE

      EPMIN = ISNLC_EPOCH_RANGE_NEWMJD(1,IMJD)
      EPMAX = ISNLC_EPOCH_RANGE_NEWMJD(2,IMJD)

    DO 102 ep = EPMIN, EPMAX

       MJD8   = SNLC8_MJD(ep)
       IF ( PKMJD8 .GT. 20000.0 ) then
         TOBS  = SNGL(MJD8 - PKMJD8)
       ELSE
         TOBS  = SNGL(MJD8 - (PKMJD8+MJDOFF) )
       ENDIF
       TREST   = TOBS/z1

       WAVECOR   = SNLC_WAVECOR(ep)
       IFILT_OBS = ISNLC_IFILT_OBS(ep)
       cfilt     = filtdef_string(ifilt_obs:ifilt_obs)

       lamrest = FILTOBS_LAMAVG(ifilt_obs) / Z1

       if (  .NOT. USE_FILT(ifilt_obs)   ) goto 102

! find sparse index 'ifilt' that corresponds to IFILT_OBS
       ifilt = IFILTDEF_INVMAP_SURVEY(ifilt_obs)

       if ( ifilt .LE. 0 ) then
           write(c1err,660) ifilt_obs, cfilt
660          format('Could not find sparse index for IFILT_OBS= '  & 
                 ,I3, ' (',A,')'  )
           write(c2err,661) NFILTDEF_SURVEY, IFILTDEF_MAP_SURVEY
661          format('NFILTDEF_SURVEY=',I2,'  IFILTDEF_MAP_SURVEY=',10I3)
           CALL MADABORT("FITINI_COV", c1err, c2err )
       endif

       FLUX_DATA     = SNLC_FLUXCAL(ep)
       FLUXERR_STAT  = SNLC_FLUXCAL_ERRTOT(ep)
       FLUXERR_DATA  = SNLC_FLUXCAL_ERRTOT(ep)

! immediately skip epochs that fail cuts, or epochs whose
! flux-error is negative

      IF ( .not. MJDSELECT(imjd,0) ) GOTO 101

! check if this epoch is rejected
      REJECT   = I4EP_ALL(ep,IEP_REJECT)
      REJECT2  = I4EP_ALL(ep,IEP_REJECT2)

      LREJECT  = (iter > 1  .and. REJECT  > 0)
      LREJECT2 = (iter > 1  .and. REJECT2 > 0)

! count rejected epochs within TREST window
      IF ( LREJECT2 .and. IREJ .EQ. 1 ) then
         NEPOCH_REJECT2 = NEPOCH_REJECT2 + 1
      ENDIF


      IF ( LREJECT .and. IREJ .EQ. 1 ) then
! count all rejected epochs
         NEPOCH_REJECT(ifilt) = NEPOCH_REJECT(ifilt) + 1
         NEPOCH_REJECT(0)     = NEPOCH_REJECT(0)     + 1
         NFITDATA_REJECT      = NFITDATA_REJECT + 1

      ELSE IF ( .NOT. LREJECT .and. IREJ .EQ. 0 ) THEN
! count epochs used for fitting
         NEPOCH_FIT(ifilt)    = NEPOCH_FIT(ifilt) + 1
         NEPOCH_FIT(0)        = NEPOCH_FIT(0)     + 1
         NFITDATA             = NFITDATA + 1
      ELSE
         GOTO 102
      ENDIF

! increment number of epochs (fit + rejected)

      NEPOCH_ALL(ifilt) = NEPOCH_ALL(ifilt) + 1
      NEPOCH_ALL(0)     = NEPOCH_ALL(0)     + 1

      N = N + 1

      IF ( N >= MXFIT_DATA ) GOTO 102

      EPLIST_FIT(N) = ep  ! allows FCN to quickly find useful epochs

      if ( ITER .EQ. ITER_DMP ) then
        write(6,454) N, ep, cfilt, MJD8  & 
            ,MJD8 - SNLC_SEARCH_PEAKMJD, flux_data, fluxerr_data
454       format(I3,1x,'ep=',I3, 2x,A,2x,'MJD=',F7.2,2x,  & 
              'Trest=',F6.2, 3x, 'Flux=',F6.1,'+-',F6.1 )
      endif

! get local flux and error from model (non-zero only if ITER > 1 )
      flux_model    = R4EP_ALL(ep,JEP_MODELFLUX)
      fluxerr_model = R4EP_ALL(ep,JEP_MODELFLUX_ERR)
      fluxerr_tot   = R4EP_ALL(ep,JEP_FLUX_ERRTOT)

! load FITCOV arrays
      I4EP_ALL(ep,IEP_IFILT)       = IFILT
      I4EP_ALL(ep,IEP_IFILT_OBS)   = IFILT_OBS
      I4EP_ALL(ep,IEP_IMJD)        = IMJD
      I4EP_ALL(ep,IEP_DETNUM)      = ISNLC_DETNUM(ep)
      I4EP_ALL(ep,IEP_IMGNUM)      = ISNLC_IMGNUM(ep)
      BANDEP_ALL(ep) = FILTDEF_STRING(IFILT_OBS:IFILT_OBS)

! Get nearest and 2nd nearest rest filter
! Also subtract index offsets

      IF ( LREST_FITMODEL ) THEN
        OPT = OPT_FILTOBS

        IF1 = NEAREST_IFILTDEF_WRAPPER(OPT,ifilt_obs,1,Z,LAMDIF_MIN)
        IF2 = NEAREST_IFILTDEF_WRAPPER(OPT,ifilt_obs,2,Z,LAMDIF_MIN)

        I4EP_ALL(ep,IEP_IFILT_REST1) = IF1
        I4EP_ALL(ep,IEP_IFILT_REST2) = IF2

        ARG   = 0.4*(ZP - SIM_EPMAGREST(ep))
        R4EP_ALL(ep,JEP_SIM_FLUXREST) = 10.0**(ARG)
        R4EP_ALL(ep,JEP_SIM_MAGREST) = SIM_EPMAGREST(ep)

      ENDIF

       R4EP_ALL(ep,JEP_SIM_FLUXCAL) = 0.0
       IF ( LSIM_MAGOBS .or. LSIM_SNANA ) THEN
          ARG   = 0.4*(ZP - SIM_EPMAGOBS(ep))
          FLUX_SIM = 10.0**(ARG)
          SQDIF    = (FLUX_SIM - FLUX_DATA)**2
          SQERR    = FLUXERR_DATA*FLUXERR_DATA

!           print*,' xxxx ', ep, FLUX_SIM
          R4EP_ALL(ep,JEP_SIM_FLUXCAL) = FLUX_SIM
          IF ( FLUXERR_DATA > 0 ) THEN
             R4EP_ALL(ep,JEP_SIM_DELCHI2) = SQDIF/SQERR
          ELSE
             R4EP_ALL(ep,JEP_SIM_DELCHI2) = -9.0
          ENDIF
       ENDIF

      R8EP_MJD(N)           = MJD8

      R4EP_ALL(ep,JEP_MJD)            = SNGL(MJD8)
      R4EP_ALL(ep,JEP_DATAFLUX)       = FLUX_DATA
      R4EP_ALL(ep,JEP_DATAFLUX_ERR)   = FLUXERR_DATA * FUDGE_DATAERR_SCALE
      R4EP_ALL(ep,JEP_MODELFLUX)      = FLUX_MODEL
      R4EP_ALL(ep,JEP_MODELFLUX_ERR)  = FLUXERR_MODEL * FUDGE_MODELERR_SCALE
      R4EP_ALL(ep,JEP_FLUX_ERRTOT)    = FLUXERR_TOT
      R4EP_ALL(ep,JEP_TOBS)           = TOBS
      R4EP_ALL(ep,JEP_TREST)          = TREST
      R4EP_ALL(ep,JEP_WAVECOR)        = WAVECOR

! check for epochs to add fudged errors so that these points are ignored in the fit, 
! but are included in all plots.


      MAXFRAC = GET_FUDGE_FITERR_MAXFRAC(ITER, ifilt_obs, TREST, LAMREST)
      ERR_TMP = MAXFRAC * SNLC_FLUXCALMAX    ! udpated 9.08.2026

      if ( DEBUG_FLAG ==  -908 ) then
         ERR_TMP = MAXFRAC * SNLC_FLUXCALMAX_FILT(ifilt) ! legacy
      endif

      R4EP_ALL(ep,JEP_FUDGEFLUX_ERR)  = ERR_TMP
      R4EP_ALL(ep,JEP_FUDGE_MAXFRAC)  = MAXFRAC

! set error on MilkyWay Galactic extinction
       MAGERR8 = SNLC_MWXT_MAGERR(ifilt)
       FTMP8   = 1.0 - 10**(-0.4*MAGERR8)
       R4EP_ALL(ep,JEP_MWXT_MAGERR)  =  SNGL(MAGERR8)
       R4EP_ALL(ep,JEP_MWXT_FLUXERR) =  SNGL(FTMP8) * FLUX_MODEL

       R4EP_ALL(ep,JEP_LAMREST)     = LAMREST
       R4EP_ALL(ep,JEP_PSF)         = SNLC_PSF_SIG1(ep)
       R4EP_ALL(ep,JEP_NEA)         = SNLC_PSF_NEA(ep)
       R4EP_ALL(ep,JEP_SKYSIG)      = SNLC_SKYSIG(ep)
       R4EP_ALL(ep,JEP_SKYSIG_T)    = SNLC_SKYSIG_T(ep)
       R4EP_ALL(ep,JEP_ZP)          = SNLC_ZEROPT(ep)
       R4EP_ALL(ep,JEP_ZPERR)       = SNLC_ZEROPT_ERR(ep)
       R4EP_ALL(ep,JEP_GAIN)        = SNLC_GAIN(ep)
       R4EP_ALL(ep,JEP_XPIX)        = SNLC_XPIX(ep)
       R4EP_ALL(ep,JEP_YPIX)        = SNLC_YPIX(ep)
       R4EP_ALL(ep,JEP_AREAFRAC)    = SNLC_AREAFRAC(ep)
       R4EP_ALL(ep,JEP_SKYFLUXCAL)  = SNLC_SKYFLUXCAL(ep)
       R4EP_ALL(ep,JEP_SBFLUXCAL)   = SNHOST_SBFLUXCAL(ifilt)
       R4EP_ALL(ep,JEP_PHOTPROB)    = SNLC_PHOTPROB(ep)

       ERR_TRUE  = SNLC_FLUXCAL_ERRTOT(ep)
       ERR_CALC  = SNLC_FLUXCAL_ERRCALC(ep)
       ERR_TMP   = SNLC_FLUXCAL_ERRTEST(ep)

       R4EP_ALL(ep,JEP_ERRTEST) = ERR_TMP
       R4EP_ALL(ep,JEP_ERRCALC) = ERR_CALC

102   CONTINUE   ! end of EPMIN,EPMAX loop
101   CONTINUE   ! end of IMJD loop
200   CONTINUE   ! end of IREJ loop

! - - - - - -
    IF ( N > MXFIT_DATA ) THEN
         write(c1err,670) N, MXFIT_DATA, ITER,  & 
                 SNLC_CCID(1:ISNLC_LENCCID)
 670       format('NFIT_DATA=',I4, '  exceeds MXFIT_DATA=',I4, 3x,  & 
                'for ITER=', I1, 2x,'CID=',A )
         c2err = 'Check param MXFIT_DATA'
         CALL MADABORT("LOAD_EPALL", c1err, c2err )
      ENDIF

    RETURN
  END SUBROUTINE LOAD_EPALL

! ==========================================
    SUBROUTINE LOAD_EPFIT()

! Creatd Jan 25 2014
! Transfer R4EP_ALL -> sparse R4EP_FIT
! Transfer I4EP_ALL -> sparse I4EP_FIT


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER ifit, ivar, ep

! ------------- BEGIN ----------

! load sparse _FIT arrays

    DO 400 ifit = 1, NFITDATA + NFITDATA_REJECT
       ep = EPLIST_FIT(ifit)

       DO ivar = 1, MXVAR_R4
          R4EP_FIT(ifit,ivar) = R4EP_ALL(ep,ivar)
       ENDDO

       DO ivar = 1, MXVAR_I4
          I4EP_FIT(ifit,ivar) = I4EP_ALL(ep,ivar)
       ENDDO

       BANDEP_FIT(ifit) = BANDEP_ALL(ep)  ! July 2017

 400  CONTINUE

    RETURN
  END SUBROUTINE LOAD_EPFIT

! ================================
    SUBROUTINE PRINT_ITERINFO(CCID,ITER,COMMENT)

! print line as formated as
!  [CID](ITER=[ITER]):  [COMMENT]
! 

! subroutine args
    CHARACTER CCID*(*)  ! SNID
    INTEGER   ITER
    CHARACTER COMMENT*(*)  ! comment to ptrin

! local args
    INTEGER LCCID
! -------------------- BEGIN ----------------

    LCCID = INDEX(CCID,' ') - 1
    write(6,20) CCID(1:LCCID),ITER,COMMENT
20    format(T5,A,'(ITER=',I2,'): ', A)

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE PRINT_ITERINFO
! ================================
    REAL FUNCTION GET_FUDGE_FITERR_MAXFRAC (  & 
                 ITER         &  ! (I) fit-iteration
                ,ifilt_obs    &  ! (I) observer filter index
                ,TREST        &  ! (I) Trest (days)
                ,LAMREST      &  ! (I) rest-wavelength (Angstroms)
                   )

! Created Jul 20 2011 by R.K
! Return MAXFRAC such that fudged error is MAXFRAC * PEAKFLUX
! Based on FUDGE_FITERR_XXX parameters.
! Evaluate MAXFRAC separeately from global FUDGEALL_XXX options
! and also from FUDGE_FITERR_XXX options.
! Return maximum of these two MAXFRAC  values  so that we
! essentially OR the two options.
! 
! Feb 28 2020:
!   FIRST_ITER now includes !LREPEAT_ITER. Restore old bug
!   with RESTORE_DES3YR.
! 
! -------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNLCINP_NML
    USE SNANAFIT

    IMPLICIT NONE

! input args
    INTEGER ITER, IFILT_OBS  ! (I) fit-iter and filter index
    REAL    TREST, LAMREST   ! (I) rest epoch (days), rest-lambda(A)

! local args

    REAL ALL_MAXFRAC, FITERR_MAXFRAC
    LOGICAL LT1, LT2, LAM1, LAM2, LFILT, LITER
    LOGICAL LT,  LAM, LFINAL, LTMP, FIRST_ITER

! functions
    LOGICAL FIRST_ITERATION
! ------------------ BEGIN GET_FUDGE_FITERR_MAXFRAC ----------------

    GET_FUDGE_FITERR_MAXFRAC = 0.0
    IF ( .NOT. USE_FUDGE_FITERR ) RETURN

    FIRST_ITER = FIRST_ITERATION(ITER)

    ALL_MAXFRAC         = 0.0
    FITERR_MAXFRAC      = 0.0

! check global options first

    LTMP = ( FUDGEALL_MAXFRAC > 0.000001 )
    IF ( LTMP ) THEN
       ALL_MAXFRAC =  FUDGEALL_MAXFRAC
    ENDIF

    LTMP = (FUDGEALL_ITER1_MAXFRAC > 1.0E-9 .and. FIRST_ITER )
    IF ( LTMP ) THEN
       ALL_MAXFRAC = FUDGEALL_ITER1_MAXFRAC
    ENDIF

! ---------
! check options that depend on TREST, LAMREST and filter

    LFILT = DOFUDGE_FITERR(ifilt_obs)
    LITER = ITER .LE. FUDGE_FITERR_MAXITER

    LT1 =   TREST .GE. FUDGE_FITERR_TREST(1)  .and. TREST .LE. FUDGE_FITERR_TREST(2)
    LT2 =   TREST .GE. FUDGE_FITERR_TREST(3)  .and. TREST .LE. FUDGE_FITERR_TREST(4)
    LT  = LT1  .or. LT2

    LAM1 =   LAMREST .GE. FUDGE_FITERR_RESTLAM(1)  .and. LAMREST .LE. FUDGE_FITERR_RESTLAM(2)
    LAM2 =   LAMREST .GE. FUDGE_FITERR_RESTLAM(3)  .and. LAMREST .LE. FUDGE_FITERR_RESTLAM(4)
    LAM = LAM1 .or. LAM2

    LFINAL = (LT .and. LAM  .and. LITER .and. LFILT)
    IF( LFINAL ) THEN
       FITERR_MAXFRAC =  FUDGE_FITERR_MAXFRAC
    ENDIF

    GET_FUDGE_FITERR_MAXFRAC =  MAX(ALL_MAXFRAC,FITERR_MAXFRAC)

    RETURN
  END FUNCTION GET_FUDGE_FITERR_MAXFRAC 

! ==========================================
    SUBROUTINE FITINI_PRIORS()
! 
! One time init:
! Initialize -2 * ln(prob) for prior on each fit variable.
! Fills PRIOR_CHI2GRID array so that chi2-contribution
! can be looked up via interpolation in CHI2_PRIOR function.
! 
! Priors initialized for:
!  - AV     (exponential convoluted with Gaussian)
!  - MJD    (gaussian)
!  - photoZ (Gaussian -- added Dec 30, 2006)
! 
! Apr 2 2018: call FITINI_FLATPRIOR for color
! 
! Apr 7 2020: init AV prior for SNOOPY as well as MLCS2k2
! 
! Feb 15 2026: call MAKE_TABLE_PRIORS
! ------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE CTRLCOM

    IMPLICIT NONE

    INTEGER  ibin, ipar, NPRIOR, ifilt
    LOGICAL  LSTAT

! -------------- BEGIN ----------

! initalize all chi2-prior to zero.

    DO ibin = 1, NBIN_PRIOR
    DO ipar = 1, IPAR_MAX
        PRIOR_CHI2GRID(ibin,ipar) = 0.0
        PRIOR_PROBGRID(ibin,ipar) = 0.0
        PRIOR_VALGRID(ibin,ipar)  = 0.0
    ENDDO
    ENDDO

! initialize prior ranges to zero

    DO ipar = 1, IPAR_MAX
       USE_PRIOR(ipar) = .FALSE.
       PRIOR_RANGE(1,ipar) = 0.0
       PRIOR_RANGE(2,ipar) = 0.0
       PRIOR_BINSIZE(ipar) = 0.0

       FLATPRIOR_RANGE(1,IPAR) = -9.E9
       FLATPRIOR_RANGE(2,IPAR) = -9.E9

       FLATPRIOR_BINRANGE(1,IPAR) = +999999
       FLATPRIOR_BINRANGE(2,IPAR) = -999999

       PRIOR_FITPAR_SNCID_FILE(1,IPAR) = 0.0     ! Gauss mean
       PRIOR_FITPAR_SNCID_FILE(2,IPAR) = 1.0E20  ! infinite Gauss sigma

    ENDDO
    USE_PRIOR_AV = .FALSE.

    PRIOR_BANDLIST_SNCID_FILE = ''
    DO ifilt = 1, MXFILT_ALL
       PRIOR_USE_FILT_SNCID_FILE(ifilt) = .FALSE.
    ENDDO

    NPRIOR = 0

! Set peak-MJD PRIOR for all models, and even if OPT_PRIOR=0.
! This is mainly to protect against crazy MJD values,
! and it is not meant to bias the fit.

    CALL FITINI_PKMJDPRIOR(LSTAT)
    IF ( LSTAT ) THEN
      NPRIOR = NPRIOR + 1
      USE_PRIOR(ipar_PEAKMJD)  = .TRUE.
    ENDIF

! check OPT_PRIOR after MJD prior is set.

    IF ( OPT_PRIOR .EQ. 0  ) GOTO 900
! - - - - - - -  -
! Set PhotoZ PRIOR for SN-photoZ fit.
! 
    IF ( DOFIT_PHOTOZ ) THEN
      CALL FITINI_ZPRIOR(LSTAT)
      IF ( LSTAT ) THEN
         NPRIOR = NPRIOR + 1
         USE_PRIOR(ipar_zPHOT)  = .TRUE.
      ENDIF

      CALL FITINI_MUPRIOR(LSTAT)  ! check prior using OM,w0,wa errors
      IF ( LSTAT ) THEN
         NPRIOR = NPRIOR + 1
         USE_PRIOR(ipar_DLMAG)  = .TRUE.
      ENDIF

    ENDIF

! - - - - - -  -
! now turn on prior(s) specific to model

    IF ( FITMODEL_INDEX .EQ. MODEL_MLCS2k2 .or.  & 
           FITMODEL_INDEX .EQ. MODEL_SNOOPY  .or.  & 
           FITMODEL_INDEX .EQ. MODEL_BAYESN ) THEN

      CALL FITINI_AVPRIOR(LSTAT)
      IF ( LSTAT ) THEN
         NPRIOR = NPRIOR + 1
         USE_PRIOR(ipar_AV) = .TRUE.  ! ambiguous for AV or SALT2c
         USE_PRIOR_AV       = .TRUE.  ! so set this AV-specific logical
      ENDIF

      ipar = IPAR_RV
      CALL FITINI_FLATPRIOR(IPAR,LSTAT)
      IF ( LSTAT ) THEN
         NPRIOR = NPRIOR + 1
         USE_PRIOR(IPAR)   = .TRUE.
      ENDIF

    ENDIF  ! end of AV-specific priors


    ipar = IPAR_SHAPE
    CALL FITINI_FLATPRIOR(IPAR,LSTAT)
    IF ( LSTAT ) THEN
       NPRIOR = NPRIOR + 1
       USE_PRIOR(IPAR)   = .TRUE.
    ENDIF


    IF ( NSHAPEPAR > 1 ) THEN
      ipar = IPAR_SHAPE2
      CALL FITINI_FLATPRIOR(IPAR,LSTAT)
      IF ( LSTAT ) THEN
         NPRIOR = NPRIOR + 1
         USE_PRIOR(IPAR)   = .TRUE.
      ENDIF
    ENDIF

    ipar = IPAR_COLOR
    CALL FITINI_FLATPRIOR(IPAR,LSTAT)
    IF ( LSTAT ) THEN
       NPRIOR = NPRIOR + 1
       USE_PRIOR(IPAR)   = .TRUE.
    ENDIF

    ipar = IPAR_DLMAG  ! Mar 19, 2026
    CALL FITINI_FLATPRIOR(IPAR,LSTAT)
    IF ( LSTAT ) THEN
       NPRIOR = NPRIOR + 1
       USE_PRIOR(IPAR)   = .TRUE.
    ENDIF


    IF ( NPRIOR .EQ. 0 ) THEN
      CALL PRBANNER("FITINI_PRIOR: NO PRIORS DEFINED" )
    ENDIF


! check opton to make table to monitor propr (debug/diagnostic)
900 CONTINUE

    CALL MAKE_TABLE_PRIORS()

    RETURN
  END SUBROUTINE FITINI_PRIORS


  SUBROUTINE MAKE_TABLE_PRIORS()

    ! Created Feb 2026
    ! make single diagnostic table with
    !  ROW  VARNAME  VALUE  CHI2
    !
    ! All priors are lumped into a single table and VARNAME defines which variable.
    ! Here the table is defined and loaded.

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE CTRLCOM
    USE SNLCINP_NML

    IMPLICIT NONE
    
    CHARACTER VARLIST*80, CBLOCK*20, CPGNAME*20, TEXTFMT*20, TEXTFMT_forC*20
    INTEGER   ID, LENBL, LENPG, LENVAR, LENFMT, LENTOT, IPAR, ibin, NVAR_PRIOR

    ! define variables for plot table
    CHARACTER VARNAME*20, COMMENT_forC*100, plot_example*100
    REAL*8    DVALGRID, DPROBGRID, DCHI2GRID, DCHI2FUN, dmin, dbin
    INTEGER   ROWNUM

    ! functions

    REAL*8 CHI2_PRIOR
    EXTERNAL  & 
          SNTABLE_ADDCOL  & 
         ,SNTABLE_ADDCOL_int  & 
         ,SNTABLE_ADDCOL_flt  & 
         ,SNTABLE_ADDCOL_dbl  & 
         ,SNTABLE_ADDCOL_str

! ---------------- BEGIN ------------

    IF ( OPT_TABLE(ITABLE_PRIOR) == 0 ) RETURN
    if ( JOBSPLIT(1) > 1 ) RETURN   ! only ISPLIT=1 for batch mode

    ID       = IDTABLE_PRIOR
    CBLOCK   = 'PRIOR' // char(0)  ! table name
    LENBL    = 5

    CPGNAME  = 'snlc_fit.exe' // char(0)
    LENPG    = 12

    TEXTFMT  = TEXTFORMAT_TABLE(ITABLE_PRIOR)
    LENFMT   = INDEX(TEXTFMT,' ') - 1
    TEXTFMT_forC = TEXTFMT(1:LENFMT) // char(0)
    CALL SNTABLE_CREATE(ID, CBLOCK, CPGNAME, TEXTFMT_forC,  LENBL, LENPG, LENFMT)  ! C fun

    ! make list of fit variables with prior, for comments below
    VARLIST = ' '
    LENTOT  = 1
    NVAR_PRIOR = 0
    DO 40 ipar = 1, IPAR_MAX
       if (  USE_PRIOR(ipar) ) then
          VARNAME = PARNAME_STORE(ipar)
          LENVAR  = INDEX(VARNAME,' ') - 1
          VARLIST = VARLIST(1:LENTOT) // " " // VARNAME(1:LENVAR)
          LENTOT  = LENTOT + LENVAR + 1
          NVAR_PRIOR = NVAR_PRIOR + 1
          if ( NVAR_PRIOR == 1 ) then
             plot_example = &
                  '  plot_table.py @@tfile <tfile> ' // &
                  '@V VALGRID:PROBGRID @@CUT "VARNAME=''' // &
                  VARNAME(1:LENVAR) // '''" ' // char(0)
          endif
       endif
40  continue

    ! store comments   
    CALL STORE_TABLEFILE_COMMENT(' '//char(0), 2)

    COMMENT_forC = 'Columns:' // char(0)
    CALL STORE_TABLEFILE_COMMENT(COMMENT_forC, 20)

    COMMENT_forC = '  VARNAME:   name of LC-fitted param with prior: ' &
         // VARLIST(1:LENTOT) // char(0)
    CALL STORE_TABLEFILE_COMMENT(COMMENT_forC, 80)

    COMMENT_forC = '  VALGRID:   param value on stored grid' // char(0)
    CALL STORE_TABLEFILE_COMMENT(COMMENT_forC, 60)

    COMMENT_forC = '  PROBGRID:  prior-PROB value on grid' // char(0)
    CALL STORE_TABLEFILE_COMMENT(COMMENT_forC, 60)

    COMMENT_forC = '  CHI2GRID:  prior-chi2 value on grid [-2ln(PROBGRID)]' // char(0)
    CALL STORE_TABLEFILE_COMMENT(COMMENT_forC, 60)

    COMMENT_forC = '  CHI2FUN:   CHI2_PRIOR FUNCTION value (expect CHI2FUN=CHI2GRID)' // char(0)
    CALL STORE_TABLEFILE_COMMENT(COMMENT_forC, 60)

    CALL STORE_TABLEFILE_COMMENT("Plot_example:"//char(0), 20)
    CALL STORE_TABLEFILE_COMMENT(plot_example, 90)

    CALL STORE_TABLEFILE_COMMENT(' '//char(0), 2)
    ! - - - - 

    write(6,10) CBLOCK, ID
 10   format(T6,'Create BLOCK(1:LENBL) = ',A,'  for TABLE ID = ', I5)
    call flush(6)

    ! init table

    VARLIST = 'ROW:I' // char(0)
    LENVAR  = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, ROWNUM,  & 
              VARLIST(1:LENVAR)//char(0), 1, LENBL, LENVAR )

    VARLIST = 'VARNAME:C*20' // char(0)
    LENVAR  = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_str(ID, CBLOCK, VARNAME,  & 
              VARLIST(1:LENVAR)//char(0), 1, LENBL, LENVAR )

    VARLIST = 'VALGRID:D' // char(0)
    LENVAR  = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_dbl(ID, CBLOCK, DVALGRID,  & 
              VARLIST(1:LENVAR)//char(0), 1, LENBL, LENVAR )

    VARLIST = 'PROBGRID:D' // char(0)
    LENVAR  = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_dbl(ID, CBLOCK, DPROBGRID,  & 
              VARLIST(1:LENVAR)//char(0), 1, LENBL, LENVAR )

    VARLIST = 'CHI2GRID:D' // char(0)
    LENVAR  = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_dbl(ID, CBLOCK, DCHI2GRID,  & 
              VARLIST(1:LENVAR)//char(0), 1, LENBL, LENVAR )

    VARLIST = 'CHI2FUN:D' // char(0)
    LENVAR  = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_dbl(ID, CBLOCK, DCHI2FUN,  & 
              VARLIST(1:LENVAR)//char(0), 1, LENBL, LENVAR )


    ! load table
    ROWNUM = 0   
    DO 50 ipar = 1, IPAR_MAX
       if ( .not. USE_PRIOR(ipar) ) goto 50
       dmin = PRIOR_RANGE(1,IPAR)
       dbin = PRIOR_BINSIZE(ipar)
       VARNAME = PARNAME_STORE(ipar)
    DO 51 ibin = 1, NBIN_PRIOR
       ROWNUM   = ROWNUM + 1
       DVALGRID     = dmin + dbin * DBLE(ibin)
       DPROBGRID    = PRIOR_PROBGRID(ibin,ipar)
       DCHI2GRID    = PRIOR_CHI2GRID(ibin,ipar)
       DCHI2FUN     = CHI2_PRIOR(ipar,DVALGRID)
       CALL SNTABLE_FILL(ID)  ! C function
51    CONTINUE
50    CONTINUE


  END SUBROUTINE MAKE_TABLE_PRIORS



  SUBROUTINE FITINI_PRIOR_MUERR()
    ! Created DEC 5 2025 by Jonah Medoff
    ! If using cosmology prior for photo-z fit, compute muerr on redshift grid for faster computation during fit
    ! 
    USE SNLCINP_NML
    USE FITINP_NML
    ! PHOTOZ_BOUND(2)
    
    IMPLICIT NONE
    REAL :: DZBIN = 0.01
    REAL :: ZMIN, ZMAX
    INTEGER :: NBIN
    ! begin
    ZMIN = PHOTOZ_BOUND(1)
    ZMAX = PHOTOZ_BOUND(2)
    NBIN = int((ZMAX-ZMIN)/DZBIN)+1
    
    RETURN
  END SUBROUTINE FITINI_PRIOR_MUERR
    
! ==========================================
    SUBROUTINE FITINI_ZPRIOR(LSTAT)
! 
! Created  by R.Kessler
! 
! Initialize photoZ prior using host photoZ.
! Fills PRIOR_CHI2GRID array with Gaussian with sigma=1.0
! so that chi2-contribution can be looked up via
! interpolation in CHI2_PRIOR function.
! 
! Prior chi2 =  [ (Z - Zhost) / scale*ERROR_Zhost ]^2 .
! 
! where scale = PRIOR_ZERRSCALE scales the error.
!  
! ------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    IMPLICIT NONE

    LOGICAL  LSTAT  ! (O) T => prior is defined

    INTEGER IPAR, IZ
    REAL*8 tmp, Zpull_BINSIZE, Zpull, XZ 
    REAL*8 CHI2, PROB, SQSIG, SQDIF, GNORM

! -------------- BEGIN ---------------

    LSTAT    = .FALSE.
    IPAR     = IPAR_zPHOT  ! local variable
    global_banner = ''

    if (BTEST(OPT_PHOTOZ, BIT_PHOTOZ_QUANTILES_STEFFEN) .or.  & 
         BTEST(OPT_PHOTOZ, BIT_PHOTOZ_QUANTILES_LINEAR)) then
       OPT_PHOTOZ = IBSET(OPT_PHOTOZ, BIT_PHOTOZ_QUANTILES) ! fix likely user mistake
    endif

    if ( BTEST(OPT_PHOTOZ,BIT_PHOTOZ_GAUSS) ) then
       write(global_banner,21) PRIOR_ZERRSCALE

    else if ( BTEST(OPT_PHOTOZ,BIT_BESTZ_GAUSS) ) then
       write(global_banner,22) PRIOR_ZERRSCALE
    endif

! check quantile mask independent of other mask bits
! BEWARE: METHOD_SPLINE_QUANTILES is actually not used since init_spline was moved to base code.

    if ( BTEST(OPT_PHOTOZ,BIT_PHOTOZ_QUANTILES) ) then
      METHOD_SPLINE_QUANTILES = "CUBIC"    ! default 28 Mar, 2024
      if (btest(OPT_PHOTOZ,BIT_PHOTOZ_QUANTILES_STEFFEN)) then
        METHOD_SPLINE_QUANTILES = "STEFFEN"  ! BEWARE requires gsl 2.7 or higher
      endif
      if (btest(OPT_PHOTOZ,BIT_PHOTOZ_QUANTILES_LINEAR)) then
        METHOD_SPLINE_QUANTILES = "LINEAR"
      endif
      write(global_banner,23)  PRIOR_ZERRSCALE, METHOD_SPLINE_QUANTILES
    endif

    if ( global_banner .EQ. '' ) then
      write(c1err,662) OPT_PHOTOZ
662     format('Invalid OPT_PHOTOZ = ', I5 )
      c2err = "Check &FITINP namelist."
      CALL MADABORT ( "FITINI_ZPRIOR", c1err, c2err )
    endif

21    format('INIT Gaussian HOST-PHOTOZ PRIOR with err-scale=',  & 
               F7.2 )
22    format('INIT Gaussian BEST-Z PRIOR with err-scale=',  & 
               F7.2 )
23    format('INIT quantile HOST-PHOTOZ PRIOR; err-scale=',  & 
               F7.2,' and interp-', A8 )

    CALL PRBANNER(global_banner(1:72))

    PRIOR_RANGE(1,IPAR) = -10.0  ! min Zpull for prior
    PRIOR_RANGE(2,IPAR) = +10.0  ! max

! set up binning used to store PHOTOZ prior on grid.

    tmp = PRIOR_RANGE(2,IPAR) - PRIOR_RANGE(1,IPAR)
    Zpull_binsize = tmp / float(NBIN_PRIOR)
    PRIOR_BINSIZE(ipar) = Zpull_binsize

    SQSIG = 1.0
    GNORM = 1.0/DSQRT(2.0 * PI * SQSIG)

    DO 50 IZ     = 1, NBIN_PRIOR
          XZ     = float(IZ)  - 0.5
          Zpull  = PRIOR_RANGE(1,IPAR) + (Zpull_binsize * XZ)

          SQDIF = Zpull * Zpull
          CHI2  = SQDIF / SQSIG
          PROB  = GNORM * EXP(-CHI2/2.0)

          PRIOR_VALGRID(IZ,ipar)  = Zpull
          PRIOR_CHI2GRID(IZ,IPAR) = CHI2
          PRIOR_PROBGRID(IZ,IPAR) = PROB
50    CONTINUE

    LSTAT = .TRUE.

    RETURN
  END SUBROUTINE FITINI_ZPRIOR

! ==========================================
    SUBROUTINE FITINI_MUPRIOR(LSTAT)
! 
! Created Aug 7, 2009 by R.Kessler
! 
! Initialize DISTANCE-MODULUS prior,
! Fills PRIOR_CHI2GRID array with Gaussian with sigma=1.0
! so that chi2-contribution can be looked up via
! interpolation in CHI2_PRIOR function.
! 
! Prior chi2 =  [ (MU - MUREF) / scale*MUERR ]^2 .
! 
! where scale = PRIOR_MUERRSCALE scales the error.
! 
! WARNING: this should be used only for photoZ fits
!          to get a better estimate of redshift.
!          ==> do NOT use this for cosmology !!!
! 
! ------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    LOGICAL  LSTAT  ! (O) T => prior is defined

    INTEGER IPAR, IMU

    REAL*8 TMP, pull_BINSIZE, PULL, MU
    REAL*8 CHI2, PROB, SQSIG, SQDIF, GNORM

! -------------- BEGIN ---------------

    LSTAT    = .FALSE.
    DOPRIOR_DLMAG = ( PRIOR_MUERRSCALE .LT. 999.0 )
    IF ( .NOT. DOPRIOR_DLMAG ) RETURN

    ! here we have MU prior based on OM,w0,wa errors. 
    ! abort if flat DMU prior is also specified since only one is allowed/
    if ( PRIOR_DMU_RANGE(2) < 0.8 .OR. PRIOR_DMU_RANGE(1)  > -8.0 ) then
      c1err = 'Cannot define both DMU priors; '      
      c2err = 'pick either PRIOR_MUERRSCALE  or  PRIOR_DMU_RANGE'
      CALL MADABORT ( "FITINI_MUPRIOR", c1err, c2err )
    endif

    IPAR     = IPAR_DLMAG  ! local variable

    write(global_banner,21) PRIOR_MUERRSCALE
21    format('INIT Gaussian DLMAG PRIOR with error-scale=', F6.2 )
    CALL PRBANNER(global_banner)
    print*,' '

    PRIOR_RANGE(1,IPAR) = -10.0  ! min DLMAG/DLMAGERR (not DLMAG)
    PRIOR_RANGE(2,IPAR) = +10.0  ! max

! set up binning used to store DLMAG prior on grid.

    tmp = PRIOR_RANGE(2,IPAR) - PRIOR_RANGE(1,IPAR)
    pull_binsize = tmp / float(NBIN_PRIOR)
    PRIOR_BINSIZE(ipar) = pull_binsize

    SQSIG = 1.0
    GNORM = 1.0/DSQRT(2.0 * PI * SQSIG)

    DO 50 IMU   = 1, NBIN_PRIOR
          MU    = float(IMU)  - 0.5
          pull  = PRIOR_RANGE(1,IPAR) + (pull_binsize * MU)

          SQDIF = pull * pull
          CHI2  = SQDIF / SQSIG
          PROB  = GNORM * EXP(-CHI2/2.0)

          PRIOR_VALGRID(IMU,ipar)  = pull
          PRIOR_CHI2GRID(IMU,IPAR) = CHI2
          PRIOR_PROBGRID(IMU,IPAR) = PROB
50    CONTINUE

    LSTAT = .TRUE.

    CALL FITINI_PRIOR_MUERR()
    RETURN
  END SUBROUTINE FITINI_MUPRIOR

! ==========================================
    SUBROUTINE FITINI_PKMJDPRIOR(LSTAT)
! 
! Created Aug 21, 2006 by R.Kessler
! 
! Initialize MJD prior.
! Fills PRIOR_CHI2GRID array so that chi2-contribution
! can be looked up via interpolation in CHI2_PRIOR function.
! 
! Prior chi2 =  [ (MJD - INIMJD) / PRIOR_MJDSIG ]^2 .
! 
! This is designed to protect against crazy MJD values that
! result in FLux(model) = 0 and reasonable chi2 ...
! The MJD prior will give a big chi2 when MJD wanders off.
! 
! Note that MJD really mean PEAKMJD here.
! 
! ------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    LOGICAL LSTAT  ! (O) T => prior is defined OK

! local
    INTEGER  & 
         IPAR  & 
        ,IMJD

    REAL*8  & 
         tmp  & 
        ,MJD_BINSIZE  & 
        ,XMJD  & 
        ,MJD  & 
        ,CHI2, PROB  & 
        ,SQSIG  & 
        ,SQDIF  & 
        ,GNORM  & 
        ,DT

! parameters (relative to initial SEARCH_PEAKMJD)
    REAL, PARAMETER ::             & 
          MINDEF_PKMJD1 = -30.0    &  ! defined MJD-range for prior
         ,MAXDEF_PKMJD1 = +30.0    & 
         ,MINDEF_PKMJD2 = -28.0    &  ! chi2 -> chi2*exp for MJD < this
         ,MAXDEF_PKMJD2 = +28.0       ! idem for MJD > this

! -------------- BEGIN ---------------

    LSTAT    = .FALSE.
    IPAR     = IPAR_PEAKMJD  ! local variable

    write(global_banner,23) int(PRIOR_MJDSIG)
23    format('INIT PEAKMJD PRIOR = ', 1x ,  & 
           'EXP[ -(PKMJD-PKMJD_INI)^2/', I4,'^2 ]' )

    CALL PRBANNER(global_banner(1:68))

    PRIOR_RANGE(1,IPAR) = MINDEF_PKMJD1  ! min MJD-MJD(peak) for prior
    PRIOR_RANGE(2,IPAR) = MAXDEF_PKMJD1  ! max

! set up binning used to store MJD prior on grid.

    tmp = PRIOR_RANGE(2,IPAR) - PRIOR_RANGE(1,IPAR)
    MJD_binsize = tmp / float(NBIN_PRIOR)
    PRIOR_BINSIZE(ipar) = MJD_binsize

    SQSIG = PRIOR_MJDSIG * PRIOR_MJDSIG
    GNORM = 1.0/DSQRT(2.0 * PI * SQSIG)

    DO 50 IMJD   = 1, NBIN_PRIOR
       XMJD   = float(IMJD)
       MJD    = PRIOR_RANGE(1,IPAR) + (MJD_binsize * XMJD)

       SQDIF = MJD * MJD
       CHI2  = SQDIF / SQSIG

       if ( MJD .LT. MINDEF_PKMJD2 ) then
          DT = ABS(MJD - MINDEF_PKMJD2)
       else if ( MJD .GT. MAXDEF_PKMJD2 ) then
          DT = ABS(MJD - MAXDEF_PKMJD2)
       else
          DT = 0.0
       endif

! flare the chi2 at the edges so that extrapolation
! has much larger slope. Note that CHI2 function and
! its derivative are still continuous at the MIN[MAX]DEF_PKMJD2
! boundary.

       CHI2  = CHI2 * EXP(DT*DT)
       PROB  = GNORM * EXP(-CHI2/2.0)
       PRIOR_VALGRID(IMJD,ipar)  = MJD
       PRIOR_CHI2GRID(IMJD,IPAR) = CHI2
       PRIOR_PROBGRID(IMJD,IPAR) = PROB
50    CONTINUE

    LSTAT    = .TRUE.

    RETURN
  END SUBROUTINE FITINI_PKMJDPRIOR

! ==========================================
    SUBROUTINE FITINI_FLATPRIOR(IPAR,LSTAT)
! 
! Created Aug 2,  2007 by R.Kessler
! 
! Initialize prior that is flat over defined range,
! and then has guassian roll-off.
! Fills PRIOR_CHI2GRID array so that chi2-contribution
! can be looked up via interpolation in CHI2_PRIOR function.
! 
! Works for DELTA, PHOTOZ, RV
! 
! Apr  2 2018: check PRIOR_COLOR_RANGE
! Oct 21 2021: allow PRIOR_COLOR_RANGE to apply to SNooPy model
! Jun 19 2023: check BAYESN model
! Jan 19 2024: check IPAR_SHAPE2
! Feb 03 2026: 
!      + protect |arg| of DEXP to be < 700
!      + CHI2 -> CHI2*CHI2 to further surpress boundaries
!
! ------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER IPAR   ! (I) fitpar index to define prior
    LOGICAL LSTAT  ! (O) T => prior is defined OK

! local

    INTEGER   IVAR, LL

    REAL*8  & 
         RANGE(2)  & 
        ,SIGMA  & 
        ,tmp  & 
        ,VAR_BINSIZE  & 
        ,XVAR  & 
        ,VAR  & 
        ,CHI2, PROB & 
        ,SQSIG  & 
        ,SQDIF, DIF  & 
        ,ARG  & 
        ,PTMP, PMIN, SIGTMP, ARGTMP  & 
        ,VAR0

    character comment_prior*60, PARNAME*60
    LOGICAL LLO, LHI, DO_DELTA_PROFILE, LFLAT
    LOGICAL IS_SALT2,  IS_SNOOPY
    LOGICAL IS_SHAPE, IS_SHAPE2, IS_COLOR, IS_zPHOT, IS_DMU
    LOGICAL IS_BAYESN, IS_MODEL_FLATCOLOR

! -------------- BEGIN ---------------

    LSTAT    = .FALSE.
    comment_prior = ' '
    LFLAT   = .TRUE.  ! default is flat between Guass-rolls


    IS_SALT2  = ( FITMODEL_INDEX .EQ. MODEL_SALT2 )
    IS_SNOOPY = ( FITMODEL_INDEX .EQ. MODEL_SNOOPY )
    IS_BAYESN = ( FITMODEL_INDEX .EQ. MODEL_BAYESN )
    IS_MODEL_FLATCOLOR   = ( IS_SALT2 .or. IS_SNOOPY  )

    IS_COLOR  = ( IPAR .EQ. IPAR_COLOR  ) ! SALT2 c or AV
    IS_SHAPE  = ( IPAR .EQ. IPAR_SHAPE  )
    IS_SHAPE2 = ( IPAR .EQ. IPAR_SHAPE2 )
    IS_zPHOT  = ( IPAR .EQ. IPAR_zPHOT .and. DOFIT_PHOTOZ )
    IS_DMU    = ( IPAR .EQ. IPAR_DLMAG .and. PRIOR_DMU_RANGE(2) < 8.0 )

    DO_DELTA_PROFILE = IPAR .EQ. IPAR_SHAPE  & 
                   .and. FITMODEL_INDEX .EQ. MODEL_MLCS2k2  & 
                   .and. PRIOR_DELTA_PROFILE(4) .LT. 1.0

    PARNAME = PARNAME_STORE(ipar)

    IF ( IS_SHAPE ) THEN
        RANGE(1) = PRIOR_SHAPE_RANGE(1)
        RANGE(2) = PRIOR_SHAPE_RANGE(2)
        SIGMA    = PRIOR_SHAPE_SIGMA

        if ( DO_DELTA_PROFILE ) then
          write(comment_prior,19) PRIOR_DELTA_PROFILE
19          format('DELTA-PRIOR SIG(-,+)=',2F5.2,  & 
             ', peak=',F5.2,', minProb=',F4.2)
          LFLAT = .FALSE.
        endif

    ELSE IF ( IS_SHAPE2 ) THEN  ! Jan 2024 (for D'Arcy's SALT2 x2 component
        RANGE(1) = PRIOR_SHAPE2_RANGE(1)
        RANGE(2) = PRIOR_SHAPE2_RANGE(2)
        SIGMA    = PRIOR_SHAPE2_SIGMA

    ELSE IF ( IS_COLOR .and. IS_MODEL_FLATCOLOR ) THEN  ! Apr 2 2018
        RANGE(1) = PRIOR_COLOR_RANGE(1)
        RANGE(2) = PRIOR_COLOR_RANGE(2)
        SIGMA    = PRIOR_COLOR_SIGMA

    ELSE IF ( IPAR .EQ. IPAR_RV .and. INISTP_RV .NE. 0.0) THEN
        RANGE(1) = 0.5   ! hard-wire
        RANGE(2) = 5.0
        SIGMA    = 0.1

    ELSE IF ( IPAR .EQ. IPAR_AVRV .and. INISTP_AVRV .NE. 0.0) THEN

        if ( OPT_PRIOR_AV .GT. 0 ) then
          RANGE(1) = -4.0
          RANGE(2) = +4.0
          SIGMA    = 0.02
        else
          RANGE(1) = -3.0   ! flat AV prior => negative ratio  OK
          RANGE(2) = +4.0
          SIGMA    = 0.1
        endif
    ELSE IF ( IS_zPHOT ) THEN
        RANGE(1) = PHOTOZ_RANGE_KCOR(1)
        RANGE(2) = PHOTOZ_RANGE_KCOR(2)
        SIGMA    = 0.2

    ELSE IF ( IS_DMU ) THEN  ! March 19 2026
       RANGE(1) = PRIOR_DMU_RANGE(1)
       RANGE(2) = PRIOR_DMU_RANGE(2)
       SIGMA    = PRIOR_DMU_SIGMA
       PARNAME  = 'DMU'
    ELSE
        RETURN
    ENDIF

! -------------------------------------
    LL = INDEX( PARNAME, ' ' ) - 1
    write(global_banner,23) PARNAME(1:LL), RANGE, SIGMA
23    format('INIT ',A,' PRIOR: ',F5.2,' to ',F5.2, '  Gauss roll sigma=',F5.2 )

    CALL PRBANNER(global_banner(1:68))

    if ( comment_prior .NE. ' ' ) then
       print*,' '
       print*, '  ', comment_prior
       CALL FLUSH(6)
    endif
! define range as defined range +- 10 sigmas.

    tmp = 10. * SIGMA
    if ( tmp < 2.0 ) tmp = 2.0   ! Feb 2026 : avoid prior truncation for c,x1
    PRIOR_RANGE(1,IPAR) = RANGE(1) - tmp
    PRIOR_RANGE(2,IPAR) = RANGE(2) + tmp

    IF ( LFLAT ) THEN
      FLATPRIOR_RANGE(1,IPAR) = RANGE(1)
      FLATPRIOR_RANGE(2,IPAR) = RANGE(2)
    ENDIF

! set up binning used to store prior on grid.

    tmp = PRIOR_RANGE(2,IPAR) - PRIOR_RANGE(1,IPAR)
    VAR_binsize = tmp / float(NBIN_PRIOR)
    PRIOR_BINSIZE(ipar) = VAR_binsize

    SQSIG   = SIGMA * SIGMA

    DO 50 IVAR   = 1, NBIN_PRIOR
       XVAR   = float(IVAR)
       VAR    = PRIOR_RANGE(1,IPAR) + (VAR_binsize * XVAR)

       LLO = VAR .LT. RANGE(1)
       LHI = VAR .GT. RANGE(2)

       IF ( LLO ) THEN
         DIF   = VAR - RANGE(1)
         SQDIF = DIF * DIF
         CHI2  = SQDIF / SQSIG
         ARG   = MIN(700.0, 0.5 * CHI2)  ! protect NaN for DEXP
         PROB  = DEXP(-arg)
       ELSE IF ( LHI ) THEN
         DIF   = VAR - RANGE(2)
         SQDIF = DIF * DIF
         CHI2  = SQDIF / SQSIG
         ARG   = MIN(700.0, 0.5 * CHI2)  ! protect NaN for DEXP
         PROB  = DEXP(-arg)

       ELSE
         CHI2  = DBLE(0.0)
         PROB  = DBLE(1.0)

! keep track of min/max bin in FLATPRIOR range;
! needed in CHI2_PRIOR to avoid discontinuity

         if ( LFLAT ) then
           FLATPRIOR_BINRANGE(1,IPAR) =  MIN ( IVAR, FLATPRIOR_BINRANGE(1,IPAR) )
           FLATPRIOR_BINRANGE(2,IPAR) =  MAX ( IVAR, FLATPRIOR_BINRANGE(2,IPAR) )
         endif

       ENDIF

! allow non-trivial priors to multiply flat prior

       IF ( DO_DELTA_PROFILE ) THEN
         VAR0 = PRIOR_DELTA_PROFILE(3)  ! bifurcate Gauss peak
         PMIN = PRIOR_DELTA_PROFILE(4)  ! min prob

         if ( VAR .GT. VAR0 ) then
           SIGTMP = PRIOR_DELTA_PROFILE(2) ! sig+ : dimmer SN
         else
           SIGTMP = PRIOR_DELTA_PROFILE(1) ! sig- : brighter SN
         endif
         ARGTMP = 0.5 * (VAR-VAR0)**2 / (SIGTMP*SIGTMP)

         PTMP = (1.0 - PMIN) * DEXP(-ARGTMP) + PMIN

         PROB = PROB * PTMP
         CHI2 = CHI2 - 2.0 * DLOG(PTMP)
       ENDIF

       PRIOR_VALGRID(IVAR,ipar)  = VAR
       PRIOR_CHI2GRID(IVAR,IPAR) = CHI2 * CHI2 ! intentioanl to suppress boundaries
       PRIOR_PROBGRID(IVAR,IPAR) = PROB
50    CONTINUE

    LSTAT    = .TRUE.

    RETURN
  END SUBROUTINE FITINI_FLATPRIOR


! ==========================================
    SUBROUTINE FITINI_AVPRIOR(LSTAT)
! 
! Initialize AV prior.
! Fills PRIOR_CHI2GRID array so that chi2-contribution
! can be looked up via interpolation in CHI2_PRIOR function.
! 
! Jul 27,2007: check option for ESSENCE/WV07 prior
! 
! Jun 22, 2009: check OPT_PRIOR_AV for flat-prior option
! 
! Apr 28, 2011: set C2ERR when PRIOR_AVRES < 0
! 
! Sep 08, 2011: FLOAT() -> DBLE()
!               REAL*8 AVRES = DBLE(PRIOR_AVRES)
!               to have consistent double precision usage.
! 
! ------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    LOGICAL LSTAT ! (O) T => prior is defined

! local

    INTEGER  & 
         IAV1  & 
        ,IAV2  & 
        ,IAVTMP  & 
        ,IAV1_MIN, IAV1_MAX  & 
        ,IAV2_MIN, IAV2_MAX  & 
        ,iexp, NEXP  & 
        ,LL(2)

    REAL*8  & 
         tmp  & 
        ,AV1_binsize  & 
        ,AV2_binsize  & 
        ,AV1, XAV1  & 
        ,AV2, XAV2  & 
        ,AVEXTRAP  & 
        ,WAV, WRES  & 
        ,AVRES  & 
        ,GNORM  & 
        ,prob, chi2  & 
        ,tmpchi2  & 
        ,probmin  & 
        ,probmax  & 
        ,chi2max  & 
        ,chi2_1, chi2_2, chi2slope  & 
        ,arg

!       REAL*8  CHI2_PRIOR

    LOGICAL USER_EXPSUM

    CHARACTER CPRIOR(2)*28

! -------------- BEGIN ----------

    LSTAT       = .FALSE.
    NEXP        = 0
    USER_EXPSUM = .FALSE.

! determine how many exponentials used in prior.


! check for flat prior
    IF ( OPT_PRIOR_AV .EQ. 0 ) THEN
       CALL PRBANNER( 'FITINI_AVPRIOR: FLAT-NEG AV PRIOR.')
       PRIOR_AVRES    = 10.0
       PRIOR_AVWGT(1) = 75.0  ! adjusted so that probmax = 1
       NEXP           = 1
       LSTAT          = .TRUE.
       USER_EXPSUM    = .TRUE.
       GOTO 40
    ENDIF

! ------------

    DO iexp = 1, 2
      cprior(iexp) = ':'
      if ( PRIOR_AVEXP(iexp) .GT. 0.0 .and.  & 
             PRIOR_AVWGT(iexp) .GT. 0.0 ) THEN
              NEXP = NEXP + 1

         write(cprior(iexp),12)  & 
               PRIOR_AVWGT(iexp), PRIOR_AVEXP(iexp)
12         format( F5.2,'*EXP(-AV/',F5.3,'):' )
      endif

      LL(iexp) = INDEX ( CPRIOR(iexp), ':' ) - 1

    ENDDO

    IF ( NEXP .LE. 0 ) THEN
       CALL PRBANNER( 'FITINI_AVPRIOR: NO AV-PRIOR IS USED.' )
       RETURN
    ELSE
       write(global_banner,19) NEXP
19       format('FITINI_AVPRIOR: DEFINE AV PRIOR WITH ',  & 
                I1,' EXPONENTIALS')
       CALL PRBANNER( global_banner )
       LSTAT    = .TRUE.
       USER_EXPSUM = .TRUE.
    ENDIF

! print prior formula to screen

    write(6,23)  CPRIOR(1)(1:LL(1)), CPRIOR(2)(1:LL(2))
    write(6,24)  PRIOR_AVRES
23    format(T6,'AV-PRIOR FUNCTION  = ', A, ' + ' , A )
24    format(T6,'AV-SIGMA(SMEARING) = ', F6.3 )

    print*,' '

40    CONTINUE

    AVRES  = DBLE(PRIOR_AVRES)

    if ( PRIOR_AVRES .LE. 0.0 ) then
       write(c1err,660) PRIOR_AVRES
660      format('PRIOR_AVRES = ', F9.4, ' < 0 is INVALID.   ')
       c2err = 'PRIOR_AVRES must be positive. '
       CALL MADABORT("FITINI_AVPRIOR", c1err, c2err )
    endif


    PRIOR_RANGE(1,IPAR_AV) = -1.0  ! min AV for prior
    PRIOR_RANGE(2,IPAR_AV) = +2.0  ! max AV for prior

! set up binning used to store AV prior on grid.

    tmp = PRIOR_RANGE(2,IPAR_AV) - PRIOR_RANGE(1,IPAR_AV)
    AV1_binsize = tmp / DBLE(NBIN_PRIOR)
    PRIOR_BINSIZE(ipar_AV) = AV1_binsize
    IAV1_MIN = 1
    IAV1_MAX = NBIN_PRIOR

! setup binning for Gaussian smear: bin size = smaller of
! 1/10 of sigma or AV1_binsize.
! First AV2 bin has positive AV; last AV2 bin is 3-sigma
! past range.

    AV2_binsize = min(AV1_binsize, 0.1*AVRES)

    tmp         = PRIOR_RANGE(1,IPAR_AV)
    if ( tmp .LT. 0.0 ) then
      IAV2_MIN  = int( -tmp / AV2_binsize ) - 1
    else
      IAV2_MIN  = 1
    endif

    tmp = PRIOR_RANGE(2,IPAR_AV) - PRIOR_RANGE(1,IPAR_AV)
    IAV2_MAX    = int( (tmp + 3.0*AVRES)/AV2_binsize )

! now convolve exponential AV-prior with gaussian smear
! (to allow for negative AV)
! AV1 includes unphysical AV due to smearing;
! AV2 includes only physical AV

    GNORM   = AVRES * DSQRT( DBLE(2.0) * PI )
    PROBMIN = DEXP(DBLE(-700.0))  ! ~ 10^{-305}
    CHI2MAX = 0.0

    PROBMAX = 0.0

! start with loop over AV that includes negative values.

    DO 41 IAV1  = IAV1_MIN, IAV1_MAX
       XAV1     = DBLE(IAV1)
       AV1      = PRIOR_RANGE(1,IPAR_AV) + AV1_binsize * xav1

       PRIOR_VALGRID(iav1,ipar_av) = AV1  ! store AV vs. grid index

! now loop over physical AV2 > 0, and go past defined range to
! accoount for smearing from beyond defined range.

        do 42 IAV2 = IAV2_MIN, IAV2_MAX
             XAV2  = DBLE(IAV2)
             AV2   = PRIOR_RANGE(1,IPAR_AV) + AV2_binsize * xav2

             if ( AV2 .LT. 0.0 ) goto 42

             IF ( USER_EXPSUM ) THEN
               WAV = 0.0
               DO iexp = 1, NEXP
                 ARG = AV2/PRIOR_AVEXP(iexp)
                 WAV = WAV + PRIOR_AVWGT(iexp) * DEXP(-arg)
               ENDDO
             ENDIF

             if ( AVRES .GT. 1.0E-6 ) then
                tmp   = (AV2 - AV1)/AVRES
                WRES  = DEXP(-0.5*tmp*tmp) / GNORM
             else if ( dabs(AV2-AV1) .LT. 0.0001 ) then
                WRES  = 1.0 / AV2_binsize
             else
                WRES  = 0.0
             endif

             prob = WAV * WRES
             prob = MAX ( prob, probmin )

             probmax = max ( prob, probmax )

! large AVEXP is a flag to have no prior on AV
             if ( PRIOR_AVEXP(1) .GT. 100.0 ) prob = 0.0

             if ( prob .GT. 0.0 ) then

                PRIOR_probgrid(iav1,ipar_av) =  & 
                  PRIOR_probgrid(iav1,ipar_av) + prob * AV2_binsize

! update chi2
                prob    = PRIOR_probgrid(iav1,ipar_av)
                tmpchi2 = -2.0 * dlog(prob)
                PRIOR_chi2grid(iav1,ipar_av) = tmpchi2

             endif
42       continue  ! end of AV2 loop


41    CONTINUE   ! end of AV1 loop

! -----------------------------------------------------------
! Now check if chi2 > 1400 (at negative AV) which causes prob
! to goto zero due to floating point overflow.
! To avoid discontinuity in chi2, the chi2 is extrapolated
! from a safe region.

! get chi2max from most neg AV in 1st bin

    chi2max = PRIOR_chi2grid(1,ipar_av)

! look for first bin with chi2 < chi2max

    DO IAV1 = 2, NBIN_PRIOR
       chi2 = PRIOR_CHI2GRID(iav1,ipar_av)
       if ( chi2 .LT. 0.999*chi2max ) then
          IAVTMP = IAV1
          goto 444
       endif
    ENDDO

444   CONTINUE

! get slope from two neighbor chi2 points

    AV1 =  PRIOR_VALGRID(iavtmp,  ipar_av)
    AV2 =  PRIOR_VALGRID(iavtmp+1,ipar_av)
    AVEXTRAP = AV1

    chi2_1 = PRIOR_chi2grid(iavtmp,  ipar_av)
    chi2_2 = PRIOR_chi2grid(iavtmp+1,ipar_av)

    chi2slope = (chi2_2 - chi2_1) / (AV2-AV1)

! Loop over AV bins again, and replace chi2 in overflow region
! with extrapolated chi2.

    DO IAV1 = 1, NBIN_PRIOR
       AV1 =  PRIOR_VALGRID(iav1,ipar_av)
       if ( AV1 .LT. AVEXTRAP ) then
         chi2 = chi2_1 + chi2slope * (AV1 - AVEXTRAP)
         PRIOR_CHI2GRID(iav1,ipar_av) = chi2
       endif
    ENDDO

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE FITINI_AVPRIOR


! ==========================================
    DOUBLE PRECISION FUNCTION CHI2_PRIOR(ipar, PARVAL)
! 
! Return chi2 penality for prior.
! Inputs: 
!   IPAR is the fitpar index;
!   FITPAR is the value to look up the prior; could be par value or pull
! 
! Mar 2024: refactor to use interp_1DFUN (C fun in sntools.c)
!       and get rid of very old/obscure interpolcation code.
! 
! ------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! function args.

    INTEGER IPAR    ! (I) fitpar index
    REAL*8  PARVAL  ! (I) fitpar value to compute chi2

! local var

    INTEGER OPTMASK
    CHARACTER COMMENT*40
    REAL*8    TMPVAL, MINVAL, MAXVAL

! define variables for polynomial interpolation

    REAL*8   INTERP_1DFUN
    EXTERNAL INTERP_1DFUN

! -------------- BEGIN --------------

    CHI2_PRIOR = 0.0  ! init

    if ( .NOT. USE_PRIOR(ipar) ) RETURN

! - - - - - -

! check trivial case of flat-prior region
    if ( PARVAL >= FLATPRIOR_RANGE(1,ipar) .and.  & 
         PARVAL <= FLATPRIOR_RANGE(2,ipar) ) then
       CHI2_PRIOR = 0.0
       RETURN
    endif

    OPTMASK = 1       ! 1=linear, 2=quadratic interp
    COMMENT = 'CHI2_PRIOR(' // PARNAME_STORE(ipar)(1:8) //  ')'

    TMPVAL = PARVAL
    MINVAL = PRIOR_VALGRID(1,IPAR)
    MAXVAL = PRIOR_VALGRID(NBIN_PRIOR,IPAR)
    IF ( PARVAL .LE. MINVAL ) THEN
       TMPVAL = MINVAL + 1.0E-6
    ENDIF
    IF ( PARVAL .GE. MAXVAL ) THEN
       TMPVAL = MAXVAL - 1.0E-6
    ENDIF

    CHI2_PRIOR = interp_1DFUN(OPTMASK, TMPVAL, NBIN_PRIOR,  & 
           PRIOR_VALGRID(1,IPAR), PRIOR_CHI2GRID(1,IPAR),  & 
           COMMENT//char(0), 40 )

    RETURN
  END FUNCTION CHI2_PRIOR

! ============================================
    DOUBLE PRECISION FUNCTION CHI2_PRIOR_SNCID_FILE(IPAR,VAL)

! Created Jan 2025
! Return Gauss prior chi2 for OPT_SNCID_LIST += 4 option;
! prior in each fit variable from previous fit stored in SNCID_LIST_FILE


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

! function inputs
    INTEGER IPAR ! (I) fit par index
    REAL*8  VAL  ! (I) param value

! local

    REAL DIF, MEAN, ERR

! --------- BEGIN ------------

    MEAN = PRIOR_FITPAR_SNCID_FILE(1,IPAR)
    ERR  = PRIOR_FITPAR_SNCID_FILE(2,IPAR)
    DIF  = SNGL(VAL) - MEAN
    CHI2_PRIOR_SNCID_FILE = (DIF/ERR)**2

    RETURN
  END FUNCTION CHI2_PRIOR_SNCID_FILE

! =================================
    DOUBLE PRECISION FUNCTION PRIOR_ZPULL(ZSN)
! 
! Created April 20, 2007 by R.Kessler
! 
! Returns ZPULL = (Z - Zref) / err
! to be used in chi2-fit function.
! 
! Note namelist option
!  OPT_PHOTOZ += 1  => always use host-galaxy photoZ
!  OPT_PHOTOZ += 2  => use spectro Z when available.
!  OPT_PHOTOZ += 4  => use quantiles instead of zphot point estimate
! 
! Jan 27 2018:
!  + use DOFIT_PHOTOZ_HOST to determine LPULL
! 
! Mar 02 2022: load global PRIOR_PHOTOZ[_ERR]
! Apr 16 2024: set zerr floor to E-3 instead of E-5 to avoid pathologically large prior-chi2.
! 
! Dec 20 2024: PRIOR_PHOTOZ[_ERR] is loaded before fit in FITINI_PHOTOZ
! ------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    REAL*8  ZSN  ! (I) redshift in fit

! local

    REAL*8  zPRIOR_err, zPRIOR, sqerr, Zpull, Zdif, Zsig
    LOGICAL LPULL, LPZ_PHOT, LPZ_BEST

! ------------ BEGIN -------------

    PRIOR_ZPULL = 0.0
    LPULL  = .FALSE.
    LPZ_PHOT = BTEST(MASK_PHOTOZ_SOURCE,BIT_PHOTOZ_GAUSS)
    LPZ_BEST = BTEST(MASK_PHOTOZ_SOURCE,BIT_BESTZ_GAUSS)

    if ( LPZ_PHOT ) then  ! use host photo z point estimate
       zPRIOR     = SNHOST_ZPHOT(1)
       zPRIOR_err = SNHOST_ZPHOT_ERR(1)
       LPULL = zPRIOR_err .GT. 0.005 .and. DOFIT_PHOTOZ_HOST

    else if ( LPZ_BEST ) then        ! use final redshift
       zPRIOR      = SNLC_REDSHIFT
       zPRIOR_err  = SNLC_REDSHIFT_ERR
       LPULL       = .TRUE.
    else
      write(c1err,662) OPT_PHOTOZ
662     format('Invalid OPT_PHOTOZ = ', I5 )
      c2err = 'Check &FITINP namelist.'
      CALL MADABORT ( "PRIOR_ZPULL", c1err, c2err )
    endif

! protect against error=0
    sqerr = zPRIOR_ERR*zPRIOR_ERR
    zPRIOR_ERR = SQRT(sqerr + 1.0E-6)

    if ( zPRIOR_ERR .LE. 1.0E-7 ) then
      write(c1err,666) zPRIOR_ERR, SNLC_CCID
666     format('zPRIOR_ERR=',G10.3,'  for CID=',A)
      c2err = 'Check REDSHIFT_FINAL'
      CALL MADABORT ( "PRIOR_ZPULL", c1err, c2err )
    endif

    if ( LPULL ) then
       Zpull = (ZSN - zPRIOR )/ (zPRIOR_err*PRIOR_ZERRSCALE)
    else
       Zdif = ZSN - PHOTOZ_RANGE_KCOR(2)
       Zsig = 0.2
       if ( Zdif > 0.0 ) then
          Zpull = Zdif / Zsig  ! prior is beyond Zrange_KCOR
       else
          Zpull = 0.0  ! no host => no prior
       endif
    endif

    PRIOR_ZPULL      =  Zpull  ! function return

    RETURN
  END FUNCTION PRIOR_ZPULL

! =================================
    DOUBLE PRECISION FUNCTION PRIOR_MUPULL(isn,ZSN,MUSN)
! 
! Created Aug 7, 2009 by R.Kessler
! 
! Returns MUPULL = (MU - MUref) / err^2
! to be used in chi2-fit function.
! 
! ------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER isn   ! (I) SN index
    REAL*8  ZSN   ! (I) redshift
    REAL*8  MUSN  ! (I) distance modulus

! local

    REAL*8  & 
         muerr, mudif, muref, mu_w0, mu_wa, mu_om  & 
        ,W_SAVE, OMAT_SAVE, sqdif, RHO_W0WA  & 
        ,sigmu_w0, sigmu_wa, sigmu_om

! functions
    REAL*8 DLMAG_REF
! ------------ BEGIN -------------

    MARK_USED(isn)

    PRIOR_MUPULL = 0.0
    if ( .NOT. DOPRIOR_DLMAG ) RETURN

    muref = DLMAG_REF(ZSN)

! Now get DLMAG with w shifted by its uncertainty
    W_SAVE    = W0_REF(1)
    W0_REF(1) = W0_REF(1) + W0_REF(2)
    mu_w0     = DLMAG_REF(ZSN)
    W0_REF(1) = W_SAVE

! Nov 7 2025: Now get DLMAG with wa shifted by its uncertainty
    W_SAVE    = WA_REF(1)
    WA_REF(1) = WA_REF(1) + WA_REF(2)
    mu_wa     = DLMAG_REF(ZSN)
    WA_REF(1) = W_SAVE

! now get DLMAG with OMAT shifted by its uncertainty
    OMAT_SAVE    = OMAT_REF(1)
    OMAT_REF(1)  = OMAT_REF(1) + OMAT_REF(2)
    mu_om        = DLMAG_REF(ZSN)
    OMAT_REF(1)  = OMAT_SAVE

! now add mu-shifts in quadrature (ignore correlations)
! to get distance error.

    sigmu_w0 = mu_w0-muref
    sigmu_wa = mu_wa-muref
    sigmu_om = mu_om-muref
    sqdif = sigmu_w0*sigmu_w0 + sigmu_wa*sigmu_wa + sigmu_om*sigmu_om

! Nov 7 2025: very rough correction for w0/wa correlation
    RHO_W0WA = -0.8
    sqdif = sqdif + 2.0*sigmu_w0*sigmu_wa*RHO_W0WA

    muerr = sqrt(sqdif)
    mudif = MUSN - muref

! inclucde user MUERRSCALE in evaluating the pull.

    PRIOR_MUPULL = mudif / (muerr * PRIOR_MUERRSCALE)

    RETURN
  END FUNCTION PRIOR_MUPULL


! ===================================================
    SUBROUTINE FITANA_CUTS(isn, LCUTS )
! 
! Apply quality cuts to fit results AFTER all fit-iterations
! have finished.
! Returns LCUTS = T if fit is acceptable.
! 
! Cuts on:
! 
!  * min Trest
!  * max Trest
!  * TGAPMAX & T0GAPMAX
!  * NEPOCH_FIT per filter
!  * valid LUMIPAR range
!  * all but 1 error is from MINOS
!  * DLMAG error is from MINOS
!  * ZPULL (for PHOTOZ fit only)
!  * fit prob
!  * SNRMAX & SNRMAX2
!  * SIGMACHI2
!  * FitPar and covariances
! 
! 
! Sep 17 2016: cut on fitted covariances; see CUTWIN_FITCOV
! 
! Mar 10 2017: cut on CUTWIN_FITERRz1
! 
! Jan 4 2021: check OPT_SNCID_LIST option to accept everything.
! 
! ------------------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

! subroutine args

    INTEGER  isn     ! (I) sparse SN index
    LOGICAL  LCUTS   ! (O) T => passes cuts

! local var

    INTEGER LCID, ipar, ipar2, ETYPE, MXERRBAD, NERRBAD, NERROK
    REAL PEAKMJD, xval, zpull, ERR_overz1, z1, TRESTCUT, TRESTCUT_EXTEND 
    LOGICAL LTMP, DOFIT_SPECZ, LVBOSE, LCOV
    CHARACTER  BANNER*80, CCID*(MXCHAR_CCID), CLINE*72

! functions

    LOGICAL LCUTVAR

! ----------------- BEGIN ----------------

    MARK_USED(isn)

    LVBOSE = STDOUT_UPDATE 

    CCID = SNLC_CCID
    LCID = ISNLC_LENCCID  

    if ( LVBOSE ) then
       write(BANNER,20) CCID(1:LCID)
20     format('FITANA_CUTS: APPLY FIT-CUTS TO SN ',A )
       CALL PRBANNER(BANNER)
    endif

    LCUTS = .TRUE.  ! init output argument

! Jan 4 2021
! check option to use SNCID list (for event syncing to FITOPT000)
! and skip cuts ... 
! but always reject events that are pegged to the edge of the shape prior range
! Apr 14 2026 ... and apply FITPROB cut at 10% if user cut
    if ( USE_SNCID_FILE  ) THEN
       xval = LCVAL_STORE(ipar_shape)
       if ( xval < PRIOR_SHAPE_RANGE(1) + 0.05 ) LCUTS = .FALSE.
       if ( xval > PRIOR_SHAPE_RANGE(2) - 0.05 ) LCUTS = .FALSE.

       xval = LCPROBCHI2_STORE(1)
       if ( xval < FITWIN_PROB(1)/10.0 ) LCUTS = .FALSE.  ! Aor 14 2026
       RETURN 
    endif

    DOFIT_SPECZ = .NOT. DOFIT_PHOTOZ

! ------------------------------------------------
! sanity check on PEAKMJD

    if ( PEAKMJD_SANITY(1) .EQ. 0.0 ) then
        PEAKMJD_SANITY(1) = CUTWIN_PEAKMJD(1) - 20.0
        PEAKMJD_SANITY(2) = CUTWIN_PEAKMJD(2) + 20.0
    endif

    PEAKMJD   = SNGL( LCVAL_STORE(IPAR_PEAKMJD) + MJDOFF )

    LTMP =  ( PEAKMJD .GT. PEAKMJD_SANITY(1) )  & 
        .and. ( PEAKMJD .LT. PEAKMJD_SANITY(2) )

    IF ( LTMP ) THEN
       write(CLINE,53000) 'PEAKMJD', PEAKMJD, 'PASSES'
    ELSE
       LCUTS = .FALSE.
       write(CLINE,53000) 'PEAKMJD', PEAKMJD, 'FAILED'
    ENDIF
    if ( LVBOSE ) print*,CLINE

53000   format(T10,A18,' = ', F10.3, 1x, A, ' CUT.' )

! ------------------------------------------------
! check Tobs[rest]_min,max using fit PEAKMJD instead
! of SEARCH_PEAKMJD. Use same "cutwin_Tobs[rest]*" parameters
! that snana uses.

! loop over epochs used in fit and make TLIST array

! apply Tobs cuts

    LTMP = LCUTVAR(Tobsmin_FIT, CUTBIT_Tobsmin, LVBOSE)
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

    LTMP = LCUTVAR(Tobsmax_FIT, CUTBIT_Tobsmax, LVBOSE)
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

! apply Trest cuts

    LTMP = LCUTVAR(Trestmin_FIT, CUTBIT_Trestmin, LVBOSE)
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

    LTMP = LCUTVAR(Trestmax_FIT, CUTBIT_Trestmax, LVBOSE)
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

! apply GAP cuts

    LTMP = LCUTVAR(TGAPMAX_FIT, CUTBIT_TGAPMAX, LVBOSE )
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

    LTMP = LCUTVAR(T0GAPMAX_FIT, CUTBIT_T0GAPMAX, LVBOSE)
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

! apply SNRSUM cut, July 2024
    LTMP = LCUTVAR(SNRSUM_FIT, CUTBIT_SNRSUM, LVBOSE)
    IF ( .NOT. LTMP ) LCUTS = .FALSE.

! -------------------------------------------------------
! Check that Trestmin/max are withing FITWIN_TREST,
! but allow slop in TRESTCUT_EXTEND.

! is this redundant with Trestmin[max]_FIT cuts above ??
! Feb 2014: skip this for photo-z fits.

    IF ( NFIT_ITERATION > 1 .and. (.not. DOFIT_PHOTOZ) ) THEN

      TRESTCUT_EXTEND = 3.0  ! extend from 2.0, Feb 2014

      xval     = Trestmin_FIT
      TrestCUT = FITWIN_TREST(1) - TRESTCUT_EXTEND
      LTMP     = ( xval .GE. Trestcut )

      if ( LTMP ) then
         write(CLINE,161) 'FITWIN_TREST(min)', xval, 'PASSES'
      else
         write(CLINE,161) 'FITWIN_TREST(min)', xval, 'FAILED'
         LCUTS = .FALSE.
      endif
      IF ( LVBOSE ) print*, CLINE

! - - - -
      xval     = Trestmax_FIT
      TrestCUT = FITWIN_TREST(2) + TRESTCUT_EXTEND
      LTMP     = ( xval .LE. Trestcut )

      if ( LTMP ) then
         write(CLINE,161) 'FITWIN_TREST(max)', xval, 'PASSES'
      else
         write(CLINE,161) 'FITWIN_TREST(max)', xval, 'FAILED'
         LCUTS = .FALSE.
      endif
      IF ( LVBOSE ) print*, CLINE

! - - - -
!  Dec 18 2017: add TRESTRANGE cut
      xval     = TrestRange_FIT
      TrestCUT = CUTWIN_TRESTRANGE(1)
      LTMP     = ( xval .GE. Trestcut )

      if ( LTMP ) then
         write(CLINE,161) 'FITWIN_TRESTRANGE', xval, 'PASSES'
      else
         write(CLINE,161) 'FITWIN_TRESTRANGE', xval, 'FAILED'
         LCUTS = .FALSE.
      endif
      IF ( LVBOSE ) print*, CLINE

    ENDIF

    CALL FLUSH(6)
! ---------------------------------
! cut on fit params

    DO 160 ipar = 1, IPAR_MAX
       if ( cutwin_fitpar(1,ipar) .LT. -9.0E7 ) goto 160
       if ( cutwin_fitpar(2,ipar) .GT. +9.0E7 ) goto 160

       xval = LCVAL_STORE(ipar)
       LTMP = xval .GE.  cutwin_fitpar(1,ipar) .and.  & 
                xval .LE.  cutwin_fitpar(2,ipar)

       if ( LTMP ) then
          write(CLINE,161) PARNAME_STORE(ipar), xval, 'PASSES'
       else
          write(CLINE,161) PARNAME_STORE(ipar), xval, 'FAILED'
          LCUTS = .FALSE.
       endif
       IF( LVBOSE ) print*,CLINE

160   CONTINUE

161      format(T10,A18,' = ', G10.3, 1x, A, ' CUT.' )
162      format(T10,A18,' = ', I4,    7x, A, ' CUT.' )
163      format(T10,A18, 14x, A, ' CUT.' )

! -------------------------------------------------------
! cut on fitted COVariances (Sep 2016)

    LCOV = .TRUE.
    z1   = 1. + LCVAL_STORE(IPAR_zPHOT)

    DO 170 ipar  = 1, IPAR_MAX

! Mar 10 2017 check cut on sigma/(1+z)
       ERR_overz1 = LCERR_STORE(ipar)/z1
       LTMP  = ERR_overz1 .GE. CUTWIN_FITERRz1(1,ipar) .and.  & 
                 ERR_overz1 .LE. CUTWIN_FITERRz1(2,ipar)
       if ( .not. LTMP ) LCOV=.FALSE.

    DO 172 ipar2 = 1, IPAR_MAX

       xval = SNGL( FITERRMAT(ipar,ipar2) )
       if ( abs(xval+9.0) < 1.0E-6 ) goto 172 ! not fitted

       LTMP = xval .GE.  cutwin_fitcov(1,ipar,ipar2) .and.  & 
                xval .LE.  cutwin_fitcov(2,ipar,ipar2)
       if ( .not. LTMP ) LCOV=.FALSE.

172   CONTINUE
170   CONTINUE

    IF ( LCOV ) THEN
      write(CLINE,163) 'FITCOV', 'PASSES'
    ELSE
      LCUTS = .FALSE.
      write(CLINE,163) 'FITCOV', 'FAILED'
    ENDIF
    IF( LVBOSE ) print*,CLINE

! -------------------------------------------------------
! cuts for PHOTOZ fits only: Zpull

    IF ( DOFIT_PHOTOZ ) THEN

       zpull = PHOTOZ_ERR_ZPULL
       LTMP = zpull .GE. FITWIN_ZPULL(1) .and.  & 
                zpull .LE. FITWIN_ZPULL(2)

       if ( LTMP ) then
          write(CLINE,161) 'ZPULL', zpull, 'PASSES'
       else
          write(CLINE,161) 'ZPULL', zpull, 'FAILED'
          LCUTS = .FALSE.
       endif
       IF( LVBOSE ) print*,CLINE

    ENDIF

! -------------
! Cut on fit prob

    xval = LCPROBCHI2_STORE(1)
    LTMP = xval .GE.  FITWIN_PROB(1) .and.  &  
           xval .LE.  FITWIN_PROB(2)

    if ( LTMP ) then
       write(CLINE,161) 'FITPROB', xval, 'PASSES'
    else
       write(CLINE,161) 'FITPROB', xval, 'FAILED'
       LCUTS = .FALSE.
    endif
    IF( LVBOSE ) print*,CLINE

! Cut on sigma-chi2

    xval = FITCHI2_STORE(4)
    LTMP = xval .GE. FITWIN_CHI2SIGMA(1) .and.  & 
             xval .LE. FITWIN_CHI2SIGMA(2)


    IF ( (OPT_CHI2_SIGMA > 0) .and. .NOT. LTMP ) THEN
       write(CLINE,161) 'CHI2(SIGMA)', xval, 'FAILED'
       LCUTS = .FALSE.
    ELSE
       write(CLINE,161) 'CHI2(SIGMA)', xval, 'PASSES'
    ENDIF
    IF( LVBOSE ) print*,CLINE
! -------------
! 7/13/2008 - cut on number of passbands passing SNR

    xval = float(NFILT_SNRMAX_FIT)
    LTMP = xval .GE. CUTWIN_NFILT_SNRMAX(1)

    if ( LTMP ) then
       write(CLINE,162) 'NFILT_SNRMAX', int(xval), 'PASSES'
    else
       write(CLINE,162) 'NFILT_SNRMAX', int(xval), 'FAILED'
       LCUTS = .FALSE.
    endif
    IF( LVBOSE ) print*,CLINE


! May 25, 2009 - cut on number of passbands passing 2nd SNR

    xval = float(NFILT_SNRMAX2_FIT)
    LTMP = xval .GE. CUTWIN_NFILT_SNRMAX2(1)

    if ( LTMP ) then
       write(CLINE,162) 'NFILT_SNRMAX2', int(xval), 'PASSES'
    else
       write(CLINE,162) 'NFILT_SNRMAX2', int(xval), 'FAILED'
       LCUTS = .FALSE.
    endif
    IF( LVBOSE ) print*,CLINE

! cut on Nfilt passing Trestmin & Trestmin

    xval = float(NFILT_TRESTMIN_FIT)
    LTMP = xval .GE. CUTWIN_NFILT_TRESTMIN(1)

    if ( LTMP ) then
       write(CLINE,162) 'NFILT_TRESTMIN', int(xval), 'PASSES'
    else
       write(CLINE,162) 'NFILT_TRESTMIN', int(xval), 'FAILED'
       LCUTS = .FALSE.
    endif
    IF( LVBOSE ) print*,CLINE

    xval = float(NFILT_TRESTMAX_FIT)
    LTMP = xval .GE. CUTWIN_NFILT_TRESTMAX(1)

    if ( LTMP ) then
       write(CLINE,162) 'NFILT_TRESTMAX', int(xval), 'PASSES'
    else
       write(CLINE,162) 'NFILT_TRESTMAX', int(xval), 'FAILED'
       LCUTS = .FALSE.
    endif
    IF( LVBOSE ) print*,CLINE

! -----------------------------------------------
! Allow only 1 of the errors to fail MINOS errors;
! 2 or more parabolic or BAD => skip

    MXERRBAD = 99   ! allow all bad errors
    IF ( MINOS_ERR_REQALL1 ) THEN
       MXERRBAD = 1    ! allow up to 1 bad error
    ENDIF
    IF ( MINOS_ERR_REQALL0 ) THEN
       MXERRBAD = 0    ! allow 0 bad errors
    ENDIF

! count bad-errors => number of fitpars with invalid MINOS error
! (these errors are either parabolic or crazy-valued)

    NFITPAR(0) = (NFITPAR_MN - NFIXPAR)
    NERROK     = NERRTYPE(ERRTYPE_MINOS)
    NERRBAD    = NFITPAR(0) - NERROK

    IF ( NERRBAD .LE. MXERRBAD   ) THEN
       write(CLINE,165) 'PASSES'
    ELSE
       write(CLINE,165) 'FAILED'
       LCUTS = .FALSE.
    ENDIF
    IF( LVBOSE ) print*,CLINE

165   format(T12, 'MINOS ERROR EVALUATIONS   ', A, ' CUT. ' )

! ----------------------------------------------
! require that DLMAG has MINOS-error (if requested)

    IF ( MINOS_ERR_DLMAG ) THEN
       ETYPE = ERRTYPE_STORE(IPAR_DLMAG)

       if ( ETYPE .EQ. ERRTYPE_MINOS ) then
          write(CLINE,166) 'PASSES'
       else
          write(CLINE,166) 'FAILED'
          LCUTS = .FALSE.
       endif
       IF( LVBOSE ) print*,CLINE

166      format(T12, 'VALID MINOS ERR FOR DLMAG ', A, ' CUT. ' )
    ENDIF

! ===================

    IF  ( LVBOSE ) THEN
      IF ( LCUTS ) THEN
         write(6,801) CCID(1:LCID)
 801       format(T5,'CID ',A,'  PASSES FIT-CUTS ' ,/ )
      ELSE
         write(6,901) CCID(1:LCID)
 901       format(T5,'CID ',A,'  FAILED FIT-CUTS => SKIP ', / )
      ENDIF
    ENDIF

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE FITANA_CUTS
  
! ===================================================
  SUBROUTINE FITANA_LOGMASS()
! Created May 2026 A.Mitra
! If photo-z fit and a per-galaxy logmass(z) grid was loaded,
! compute the Gaussian-marginalized logmass mean and sigma using
! eval_spline_integral and store in SNHOST_LOGMASS_ZPHOT/ZPHOTERR.

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM
    USE TABLEVARCOM
    USE SNHOSTCOM
    USE SNHOSTzCOM

    IMPLICIT NONE
    INTEGER          :: NZ, IGAL, INDEX_SPLINE
    REAL*8           :: Z_PH, Z_PH_ERR
    EXTERNAL            eval_spline_integral

    ! BEGIN
    IF ( OPT_PHOTOZ <= 0 ) RETURN   ! no photo-z fit

    IGAL = 1  ! primary (closest) host galaxy
    NZ   = SNHOSTz_LOGMASS(IGAL)%NZ
    IF ( NZ < 1 ) RETURN            ! no logmass grid loaded for this galaxy

    ! spline was already initialized by SET_LOGMASS (called from snana.F90)
    INDEX_SPLINE = IND_OFF_SPLINE_LOGMASS_ZGRID + IGAL

    ! photo-z centre and uncertainty for this host
    Z_PH     = DBLE( SNHOST_ZPHOT(IGAL) )
    Z_PH_ERR = DBLE( SNHOST_ZPHOT_ERR(IGAL) )

    CALL SET_LOGMASS(2, Z_PH, Z_PH_ERR)

    RETURN
  END SUBROUTINE FITANA_LOGMASS
! ===================================================
    SUBROUTINE FITANA_STORE()
! 
! store info in  FITVAL_STORE and FITERR_STORE arrays.
! These arrays are used for FITRES table output.
! 
! Feb 20 2017: refactor using new calls to SET_FITANA_STORE;
!              accomodates SNTABLE_FILTER_REMAP option.
! 
! --------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM
    USE TABLEVARCOM

    IMPLICIT NONE

! local var

    INTEGER  & 
         IFILT, IFILT_OBS, IFILT_RST, ifitdata, iep, ipar, NPAR, i  & 
        ,NTLIST,  NFILT, NFADD, isort  & 
        ,FLIST(MXEPOCH)  & 
        ,ORDER, INDEX_SORT(MXFILT_OBS)   &  ! SORTZV args
        ,MASK_STORE_VAL, MASK_STORE_ERR, MASK_STORE_SUM

    REAL  & 
          TLIST(MXEPOCH), XEPOCH_FIT(MXFILT_ALL), SNRLIST(MXEPOCH)  & 
         ,Tobs, Trest, MJD, PEAKMJD, z1  & 
         ,MAGVAL, MAGERR, PROB_MAGDIF(2)

    REAL*8  & 
         Z8, MU8REF, MU8FIT, MU8  & 
        ,x08, x18, c8, S2a8, S2b8, mb8

    LOGICAL USE

! function
    REAL*8 DLMAG_REF, SALT2mBcalc

    EXTERNAL SORTFLOAT

! -------------------- BEGIN ---------------

    CALL FLUSH(6)

    NFITPAR(0) = (NFITPAR_MN - NFIXPAR)

    DO ifilt           = 0, MXFILT_OBS
       if ( ifilt > 0 ) then
          NFITPAR(ifilt)  = 0
          XEPOCH_FIT(ifilt) = FLOAT( NEPOCH_FIT(ifilt) )
       endif
       NFITDOF(ifilt)  = NEPOCH_FIT(ifilt)  & 
                         - NFITPAR(ifilt)
       XNFITDOF(ifilt)   = float ( NFITDOF(ifilt) )
    END DO

! re-evaluate Trest-related variables

! set global redshift variable & local peakmjd
    REDSHIFT_FIT = LCVAL_STORE(IPAR_zPHOT)
    z1 = 1. + REDSHIFT_FIT

    PEAKMJD      = LCVAL_STORE(IPAR_PEAKMJD)

! loop over epochs used in fit: rejected epochs are excluded here.

    NTLIST = 0
    DO 100 ifitdata = 1, NFITDATA
        iep       = EPLIST_FIT(ifitdata)
        MJD       = SNGL(SNLC8_MJD(iep))
        Tobs      = MJD - SNGL(PEAKMJD + MJDOFF)
        Trest     = Tobs / z1
        NTLIST    = NTLIST + 1
        TLIST(NTLIST) = Trest
        FLIST(NTLIST) = I4EP_ALL(iep,IEP_IFILT_OBS)
        SNRLIST(NTLIST) = SNLC_SNR(iep)
100   CONTINUE

    CALL GET_TRESTVAR (  & 
              NTLIST, TLIST, FLIST, SNRLIST      &  ! (I) Trest   IFILT arrays
             ,FITANA_CUTWIN_TREST                &  ! (I) user cutwin
             ,FITANA_CUTWIN_TRESTMIN             &  ! (I) idem
             ,FITANA_CUTWIN_TRESTMAX             &  ! (I) idem
             ,FITANA_CUTWIN_TREST2               &  ! (I) idem
             ,NFILT                              &  ! (O) Nfilt
             ,TRESTMIN_FIT, TRESTMAX_FIT         &  ! (O) Trestmin,max after fit
             ,NFILT_TRESTMIN_FIT                 &  ! (O)
             ,NFILT_TRESTMAX_FIT                 &  ! (O)
             ,NFILT_TREST2_FIT                   &  ! (O)
             ,TGAPMAX_FIT, T0GAPMAX_FIT          &  ! (O)
             ,SNRSUM_FIT   )                    ! (O)

    TRESTRANGE_FIT = TRESTMAX_FIT - TRESTMIN_FIT
    TOBSMIN_FIT = TRESTMIN_FIT * z1
    TOBSMAX_FIT = TRESTMAX_FIT * z1

! -------------------------------------------------
! get peakmags in obs and rest frames.
! Make sure to get ALL of the rest-frame filters,
! even if there is no obs filter than maps on

    if ( LTRACE ) CALL DMPTRACE("CALLING PEAKMAG_CALC(OBS)")

    DO 551 IFILT = 1, NFILTDEF_SURVEY
      ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
      USE  = USE_FILT(ifilt_obs)
      if ( USE ) then
         CALL PEAKMAG_CALC(ifilt_obs, 'OBS')
      endif
551   CONTINUE


    IF ( LREST_FITMODEL ) THEN
       if ( LTRACE ) CALL DMPTRACE("CALLING PEAKMAG_CALC(REST)")
       DO 552 IFILT = 1, NFILTDEF_REST
         IFILT_RST  = IFILTDEF_MAP_REST(ifilt)
         CALL PEAKMAG_CALC(ifilt_rst, 'REST')
552     CONTINUE
    ENDIF


! compute number of fitted filters that pass global user-SNR cut
! This accounts for fudged errors so that deweighted passbands
! are not counted in NFILT_SNRMAX_FIT.

    NFILT_SNRMAX_FIT  = 0
    NFILT_SNRMAX2_FIT = 0
    DO ifilt = 1, NFILTDEF_SURVEY
      if ( R4BAND_SNRMAX_FIT(ifilt) > CUTWIN_SNRMAX(1) ) then
         NFILT_SNRMAX_FIT = NFILT_SNRMAX_FIT + 1
      endif
      if ( R4BAND_SNRMAX_FIT(ifilt) > CUTWIN_SNRMAX2(1) ) then
         NFILT_SNRMAX2_FIT = NFILT_SNRMAX2_FIT + 1
      endif
    ENDDO

! fill SNRMAX_SORT_FIT to get sorted SNRMAX for fitted bands.

    ORDER =  -1  ! -1, 0 descending,increasing order
    CALL SORTFLOAT( NFILTDEF_SURVEY, R4BAND_SNRMAX_FIT, ORDER,  & 
                       INDEX_SORT);

    DO isort  = 1, NFILTDEF_SURVEY
       ifilt  = INDEX_SORT(isort)
       SNRMAX_SORT_FIT(isort) = R4BAND_SNRMAX_FIT(ifilt)  ! for CWNT
       SNRMAX_FILT_FIT(ifilt) = R4BAND_SNRMAX_FIT(ifilt)  ! for CWNT
    ENDDO

    CALL RADIUS_CALC() ! compute RADIUS_POP

! -----------------------------------------------
! store extra info in FITVAL_STORE array so that
! all gets plotted the same way as fit-parameters.

    if ( LTRACE ) CALL DMPTRACE("START 555 LOOP in FITANA_STORE")

    NPAR = PARPTR_CHI2

! store global fit parameters: Ndof, chi2 and prob(chi2)
! Note index here is NPAR instead of ipar

    NPAR = NPAR + 1  ! Ndof
    FITVAL_STORE(NPAR) = XNFITDOF(0)
    LCVAL_STORE(NPAR)  = XNFITDOF(0)

    NPAR = NPAR + 1  ! reject epochs withing Trest range (Mar 2020)
    FITVAL_STORE(NPAR) = FLOAT(NEPOCH_REJECT2)
    LCVAL_STORE(NPAR)  = FLOAT(NEPOCH_REJECT2)

    NPAR = NPAR + 1         ! chi2
    FITVAL_STORE(NPAR) = FITCHI2_STORE(1)
    LCVAL_STORE(NPAR)  = LCCHI2_STORE(1) ! Total chi2

    NPAR = NPAR + 1             ! prior-chi2
    FITVAL_STORE(NPAR) = FITCHI2_STORE(3)
    LCVAL_STORE(NPAR)  = LCCHI2_STORE(3)

    NPAR = NPAR + 1             ! sigma-chi2
    FITVAL_STORE(NPAR) = FITCHI2_STORE(4)
    LCVAL_STORE(NPAR)  = LCCHI2_STORE(4)

    IF ( LSIM_SNANA ) THEN
      NPAR = NPAR + 1             ! SIM chi2 (Dec 2013)
      FITVAL_STORE(NPAR) = SNGL(SIMCHI2_CHEAT)
      LCVAL_STORE(NPAR)  = SNGL(SIMCHI2_CHEAT)
    ENDIF

! now the fit-probs ...

    NPAR = NPAR + 1  ! prob(chi2) including prior, before marginal.
    FITVAL_STORE(NPAR) = FITPROBCHI2_STORE(1)
    LCVAL_STORE(NPAR)  = FITPROBCHI2_STORE(1)

    NPAR = NPAR + 1  ! final prob(chi2) including prior, after marg.
    FITVAL_STORE(NPAR) = FITPROBCHI2_STORE(1) ! from fit, before marg
    LCVAL_STORE(NPAR)  = LCPROBCHI2_STORE(1)  ! after marg.

    NPAR = NPAR + 1  ! prob(chi2) excluding prior
    FITVAL_STORE(NPAR) = FITPROBCHI2_STORE(2)
    LCVAL_STORE(NPAR)  = LCPROBCHI2_STORE(2)

    NPAR = NPAR + 1      ! RADIUS_POP (Jan 2024)
    FITVAL_STORE(NPAR) = RADIUS_POP
    LCVAL_STORE(NPAR)  = RADIUS_POP

! --------------------------------------

! set store-masks. first number refers to storing VAL or error.
! Second number is to take average(4) or sum(8) for REMAPed filters.
    MASK_STORE_VAL = 1 + 4   ! VAL,AVG
    MASK_STORE_ERR = 2 + 4   ! ERR,AVG
    MASK_STORE_SUM = 1 + 8   ! VAL,SUM

    DO 555 i = 1, NFILTOBS_TABLE

      ifilt_obs  = IFILTOBS_MAP_TABLE(i)
      ifilt      = IFILT_MAP_TABLE(i)

      if ( NFILT_REMAP_TABLE == 0 ) then
        if ( .not. USE_FILT(ifilt_obs) ) goto 555
        CALL FPKRAT(ifilt_obs)  ! flux/peakFlux in rest-frame
      endif

      NFADD = 0
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_VAL, ifilt,  & 
                              PEAKMAG_OBS_MODEL)
      CALL SET_FITANA_STORE(ipar, MASK_STORE_ERR, ifilt,  & 
                              PEAKMAG_OBS_MODEL_ERR)

      NFADD = NFADD + 1
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_VAL, ifilt,  & 
                              PEAKMAG_OBS_MODEL_ERR)

      NFADD = NFADD + 1
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_VAL, ifilt,  & 
                              PEAKFLUX_OBS_MODEL )
      CALL SET_FITANA_STORE(ipar, MASK_STORE_ERR, ifilt,  & 
                              PEAKFLUX_OBS_MODEL_ERR )

      if ( NFILTOBS_TABLE .GT. 20 ) GOTO 555

      NFADD = NFADD + 1
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_VAL, ifilt,  & 
                              PEAKFLUX_OBS_MODEL_ERR )

      NFADD = NFADD + 1
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_SUM, ifilt,  & 
                              XEPOCH_FIT )

      NFADD = NFADD + 1
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_SUM, ifilt,  & 
                              LC_FITCHI2 )  ! wrong for LCVAL ???

      NFADD = NFADD + 1
      ipar = NPAR + NFADD*NFILTOBS_TABLE + i
      CALL SET_FITANA_STORE(ipar, MASK_STORE_VAL, ifilt,  & 
                              LC_FITPROB )  ! wrong for MARGPROB ???

555   CONTINUE

! now load rest-frame peakmags; use pointer to find IPAR.
! Note that number of rest-frame filters could be more
! than the number of obs-frame filters.

    IF ( LREST_FITMODEL ) THEN
      do ifilt    = 1, NFILTDEF_REST
        ifilt_rst = IFILTDEF_MAP_REST(ifilt)
        ipar      = PARPTR_IFILT_REST(ifilt_rst)
        FITVAL_STORE(ipar) = PEAKMAG_REST_MODEL(ifilt_rst)
        FITERR_STORE(ipar) = PEAKMAG_REST_MODEL_ERR(ifilt_rst)
        LCVAL_STORE(ipar)  = PEAKMAG_REST_MODEL(ifilt_rst)
        LCERR_STORE(ipar)  = PEAKMAG_REST_MODEL_ERR(ifilt_rst)
      enddo
    ENDIF

! Feb 2012: optional things to store for special fits
    NPAR = PARPTR_FITRESTMAG

    IPAROFF_FITRESTMAG    = NPAR
    DO ifilt    = 1, NFILTDEF_FITRESTMAG
       CALL GET_FITRESTMAG(ifilt, MAGVAL, MAGERR) ! return magdif and its err

       NPAR     = NPAR + 1
       FITVAL_STORE(Npar) = MAGVAL
       LCVAL_STORE(Npar)  = MAGVAL

       NPAR     = NPAR + 1
       FITVAL_STORE(Npar) = MAGERR
       LCVAL_STORE(Npar)  = MAGERR
    ENDDO


    IF ( FILTER_FITMAGDIF .NE. '' ) THEN

       CALL GET_FITMAGDIF(MAGVAL, MAGERR, PROB_MAGDIF)

       NPAR   = NPAR + 1
       FITVAL_STORE(Npar) = MAGVAL
       LCVAL_STORE(Npar)  = MAGVAL
       FITERR_STORE(Npar) = MAGERR
       LCERR_STORE(Npar)  = MAGERR

       NPAR   = NPAR + 1
       FITVAL_STORE(Npar) = MAGERR
       LCVAL_STORE(Npar)  = MAGERR

       NPAR   = NPAR + 1
       FITVAL_STORE(Npar) = PROB_MAGDIF(1)  ! FITPROB, 1 filter
       LCVAL_STORE(Npar)  = PROB_MAGDIF(1)  ! FITPROB, 1 filter

       NPAR   = NPAR + 1
       FITVAL_STORE(Npar) = PROB_MAGDIF(2) ! FITPROB, other filters
       LCVAL_STORE(Npar)  = PROB_MAGDIF(2) ! FITPROB, other filters
    ENDIF


    if ( LTRACE ) CALL DMPTRACE("FINISHED 555 LOOP in FITANA_STORE")


! store delZ = zfit - zspec
    NPAR = NPAR + 1
      FITVAL_STORE(NPAR) = FITVAL_STORE(IPAR_zPHOT)  & 
                           - SNLC_REDSHIFT
      FITERR_STORE(NPAR) = FITERR_STORE(IPAR_zPHOT)

      LCVAL_STORE(NPAR) = LCVAL_STORE(IPAR_zPHOT)  & 
                          - SNLC_REDSHIFT
      LCERR_STORE(NPAR) = LCERR_STORE(IPAR_zPHOT)

! store DELMU = MU(fit) - MU(Zspec)
! If REDSHIFT < 0 (undefined) then use photoz

    NPAR = NPAR + 1
      Z8  = FITVAL_STORE(IPAR_zPHOT)  ! Zspec or Zphot
      MU8REF = DLMAG_REF(Z8)

      IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
         x08  = FITVAL_STORE(IPAR_X0)
         mb8  = SALT2mbcalc(x08)
         x18  = FITVAL_STORE(IPAR_SHAPE)
         c8   = FITVAL_STORE(IPAR_COLOR)
         S2a8 = DBLE(SALT2alpha)
         S2b8 = DBLE(SALT2beta)

         MU8FIT = mb8 + S2a8*x18 - S2b8*c8 + 19.36
         MU8    = MU8FIT
      ELSE
         MU8FIT = FITVAL_STORE(IPAR_DLMAG) ! fitted MU
         MU8    = LCVAL_STORE(IPAR_DLMAG)  ! might be marginalized
      ENDIF

      FITVAL_STORE(NPAR) = SNGL(MU8FIT - MU8REF)
      FITERR_STORE(NPAR) = FITERR_STORE(IPAR_DLMAG)

      LCVAL_STORE(NPAR) = SNGL(MU8 - MU8REF)
      LCERR_STORE(NPAR) = LCERR_STORE(IPAR_DLMAG)

! store delzph for photoz fits.
! Make sure to always increment NPAR.

    NPAR = NPAR + 1
    if ( DOFIT_PHOTOZ ) THEN
      CALL PHOTOZ_STORE(NPAR)
    ENDIF

! store SALT2 mB in IPAR_MB index ..
! do NOT increment NPAR here
    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
      CALL SALT2_STORE()
    ENDIF


    IF ( NPAR .NE. NPLOTPAR ) THEN
      write(c1err,662) NPAR
662     format('Filled NPAR = ', I3, ' variables ' )

      write(c2err,663) NPLOTPAR
663     format('but expected NPLOTPAR = ', I4 )
      CALL MADABORT ( "FITANA_STORE", c1err, c2err )
    ENDIF

    RETURN
  END SUBROUTINE FITANA_STORE

! =============================
    SUBROUTINE  SET_FITANA_STORE(IPAR,MASK_STORE, IFILT, ARRAY)

! Created Feb 2017
! 
! Copy element of ARRAY into either FITVAL_STORE or FITERR_STORE,
! which are used to fill the SNTABLE.
! 
! For nominal jobs, load ARRAY(ifilt) into FITVAL[ERR]_STORE[IPAR].
! But for FILTER_REMAP_TABLE, then figure out which original
! filters correspond to REMAPed IFILT.
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

! function inputs
    INTEGER  & 
         IPAR         &  ! index to store for FITVAL_STORE and FITERR_STORE
        ,MASK_STORE   &  ! mask to store VAL or ERR array, and to take avg or sum
        ,IFILT       ! sparse IFILT or IFILTOBS, depending on OPT_IFILT

    REAL ARRAY(*) ! array to copy into storage

! local variables

    LOGICAL LOADVAL, LOADERR, DO_AVG, DO_SUM
    REAL    VAL_STORE
    INTEGER IFILTOBS_ORIG, IFILTOBS_REMAP, IFILT_REMAP
    INTEGER IFILT_ORIG, IFILT_REMAP_TMP, NFILT_STORE

! ---------- BEGIN -------------

! parse MASK_STORE bits
    LOADVAL = BTEST(MASK_STORE,0)  ! 1
    LOADERR = BTEST(MASK_STORE,1)  ! 2
    DO_AVG  = BTEST(MASK_STORE,2)  ! 4 --> for REMAP filters only
    DO_SUM  = BTEST(MASK_STORE,3)  ! 8 --> for REMAP filters only

    IF ( NFILT_REMAP_TABLE == 0 ) THEN
       VAL_STORE = ARRAY(IFILT)
       GOTO 500
    ENDIF

! -----------------------------------------------------
! if we get here, then figure out the FILTER-REMAP

    IFILT_REMAP = IFILT

! loop over original filters to see which one(s)
! were remapped onto IFILT_REMAP

    VAL_STORE = 0.0 ;  NFILT_STORE=0
    DO 100 ifilt_orig = 1, NFILTDEF_SURVEY

        IFILTOBS_ORIG = IFILTDEF_MAP_SURVEY(IFILT_ORIG)

        if ( .not. USE_FILT(ifiltobs_orig) ) goto 100

        CALL FILTER_REMAP_FETCH(IFILTOBS_ORIG,         &  ! (I)
                    IFILTOBS_REMAP, IFILT_REMAP_TMP)    ! (O)

        IFILT_REMAP_TMP = IFILT_REMAP_TMP + 1 ! C -> fortran index
        IF ( IFILT_REMAP .EQ. IFILT_REMAP_TMP ) THEN
           VAL_STORE     = VAL_STORE + ARRAY(IFILT_ORIG)
           NFILT_STORE   = NFILT_STORE + 1

! xxxxxxxxxxxxxxxxxxx
!        write(6,66) IFILT_ORIG, IFILTOBS_ORIG, IFILTOBS_REMAP,
!     &             IFILT_REMAP_TMP, ARRAY(IFILT_ORIG)
! 6      format(T2,'xxx IFILT_ORIG=',I2,2x,
!     &          'IFILTOBS[ORIG,REMAP]=',2I3,' IFILT_REMAP_TMP=',I2,
!     &          '  ARRAY=',F10.2 )
! xxxxxxxxxxxxxxxxxxx

        ENDIF
100   CONTINUE

    IF ( NFILT_STORE > 0 ) THEN
       IF ( DO_AVG ) THEN
         VAL_STORE = VAL_STORE / FLOAT(NFILT_STORE)
       ENDIF
    ELSE
       VAL_STORE = -9.0
    ENDIF

! ---------------
500   CONTINUE
    IF ( LOADVAL ) then
      FITVAL_STORE(IPAR) = VAL_STORE
      LCVAL_STORE(IPAR)  = VAL_STORE
    ELSE
      FITERR_STORE(IPAR) = VAL_STORE
      LCERR_STORE(IPAR)  = VAL_STORE
    ENDIF

    RETURN
  END SUBROUTINE  SET_FITANA_STORE

! ==================================
    SUBROUTINE FITERR_ADJUST()
! 
!  Created Apr 25, 2007 by R.Kessler
! 
!  If MINOS returns rediculously tiny errors,
!  then set error to a reasonable artificial error.
!  This is needed for the marginalization to work
!  properly.
! 
!  Feb 7, 2008:
!    - set FITERR(IPAR) in addition to FITERR_MINUS[PLUS]
! 
!    - if photoZ error is too big, trim errors
!      so that +-4 sigma does not give unphysical value
! 
! Dec 16, 2011:
!   photoZ error must be at least 40% of color error.
! 
! ------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNLCINP_NML
    USE SNFITCOM

    IMPLICIT NONE

!  local var

    REAL    EPLUS, EMINUS, Z1tmp, Z2tmp, RTMP, ZERR, cERR
    INTEGER IPAR, ITER
    LOGICAL LBAD

! ------------- BEGIN ------------

    ITER = NFIT_ITERATION

    IPAR = IPAR_AV
    LBAD = ERRTYPE(IPAR) .EQ. ERRTYPE_BAD
    IF ( LBAD ) THEN
       EMINUS = 0.20
       EPLUS  = 0.20
       FITERR_MINUS(IPAR,ITER) = -EMINUS
       FITERR_PLUS(IPAR,ITER)  = +EPLUS
       FITERR_RATIO(IPAR,ITER) =  EPLUS / EMINUS
       FITERR(IPAR,ITER)       =  EPLUS
       print*,'  Reset BAD AV ERROR before MARG_DRIVER: CID=',  & 
                   SNLC_CCID
    ENDIF


    IPAR = IPAR_zPHOT
    IF ( DOFIT_PHOTOZ ) THEN

! check for tiny error
       LBAD = ERRTYPE(IPAR) .EQ. ERRTYPE_BAD
       IF ( LBAD ) THEN
         EMINUS = 0.01
         EPLUS  = 0.01
         FITERR_MINUS(IPAR,ITER) = -EMINUS
         FITERR_PLUS(IPAR,ITER)  = +EPLUS
         FITERR_RATIO(IPAR,ITER) =  EPLUS / EMINUS
         FITERR(IPAR,ITER)       =  EPLUS
         print*,'  Reset BAD PHOTOZ ERROR before MARG_DRIVER: CID=',  & 
                     SNLC_CCID
       ENDIF

! check for too-big error that gives Z - 4\sigma_z < 0

       Z1tmp = SNGL( FITVAL(ipar,ITER) - NSIGMA_PDF * FITERR_MINUS(IPAR,ITER) )
       Z2tmp = SNGL( FITVAL(ipar,ITER) + NSIGMA_PDF * FITERR_PLUS(IPAR,ITER)  )

       LBAD  = Z1tmp .LT. INIBND(1,IPAR)
       if ( NGRID_PDF .GT. 0 .and. LBAD ) then
         EMINUS = SNGL( (FITVAL(ipar,ITER)-INIBND(1,IPAR))/NSIGMA_PDF )
         EPLUS  = SNGL( FITERR_PLUS(IPAR,ITER) )
         FITERR_MINUS(IPAR,ITER) = -EMINUS
         FITERR_RATIO(IPAR,ITER) =  EPLUS / EMINUS
         FITERR(IPAR,ITER)       =  (EMINUS + EPLUS)/2.
       endif

! Dec 2011:
! check for too-tiny error. Should be at least .4 * color error

       ZERR = SNGL( FITERR(IPAR,ITER) )
       cERR = SNGL( FITERR(IPAR_COLOR,ITER) )
       RTMP = ZERR/cERR 
       if ( RTMP .LT. 0.4 ) then
           ZERR = 0.4 * cERR
       endif

       FITERR(IPAR,ITER) = ZERR

    ENDIF

    RETURN
  END SUBROUTINE FITERR_ADJUST


! ======================================
    DOUBLE PRECISION FUNCTION SALT2xx1(ITER,x1)
! 
! Created Jun  2011 by R.Kessler
!  [code moved from FCNSNLS]
! 
! SALT2xx1 is the x1 value used in the SALT2  model-error
! calculation. This value is either the same x1 value in
! the fit (if DOCHI2_SIGMA=T) or it is fixed to the x1-value
! from the previous iteration.
! 
! 
! 
! Aug 30 2017: use FIRST_ITERTION(ITER) instead of ITER=1 .
!              Needed for SIMFIT_IDEAL option.
! 
! ---------------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT

    IMPLICIT NONE

    INTEGER ITER  ! (I) fit iteration
    REAL*8  x1    ! (I) x1/stretch

! local variables
    REAL*8  xx1
    LOGICAL DOFIT_zFIX
    LOGICAL FIRST_ITERATION   ! function

! --------------- BEGIN -------------

    SALT2xx1 = -999.
    DOFIT_zFIX = (.NOT. DOFIT_PHOTOZ)

    IF ( FIRST_ITERATION(ITER)  ) then
      xx1 = 0.0    ! always fix xx1 on 1st iteration
    ELSE
       if ( (OPT_CHI2_SIGMA >0) .and. DOFIT_zFIX) then
           xx1 = x1
       else
           xx1 = FITVAL(IPAR_SHAPE,iter-1) ! from previous iteration
       endif
    ENDIF

    SALT2xx1 = xx1

    RETURN
  END FUNCTION SALT2xx1


! ======================================
    DOUBLE PRECISION FUNCTION SALT2zz(ITER,z)
! 
! Created Mar 2018
! 
! Return redshift (zz) for SALT2 error calculation.
! Motivation is for photoz fit, fix zz = z(previous iteration),
! and use zz for SALT2 error calculation.
! 
! Mar 24 2020: fix logic using local DOFIT_zFIX; needed for FITRESTMAG.
! 
! ---------------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT

    IMPLICIT NONE

    INTEGER ITER  ! (I) fit iteration
    REAL*8  z     ! (I) redshift

! local variables
    REAL*8  zz
    LOGICAL FIRST_ITER, DOFIT_zFIX
    LOGICAL FIRST_ITERATION   ! function

! --------------- BEGIN -------------

    SALT2zz = -999.
    DOFIT_zFIX = (.NOT. DOFIT_PHOTOZ)

!      FIRST_ITER = FIRST_ITERATION(ITER)  ! v10_76b and earlier
    FIRST_ITER = FIRST_ITERATION(ITER) .or. DOFIT_zFIX ! >= v10_76c

    IF ( FIRST_ITER ) then
      zz = z
    ELSE
       if ( (OPT_CHI2_SIGMA > 0) .and. DOFIT_zFIX) then
           zz = z
       else
           zz = FITVAL(IPAR_ZPHOT,iter-1) ! from previous iteration
       endif
    ENDIF

    SALT2zz = zz

    RETURN
  END FUNCTION SALT2zz

! ========================================
    SUBROUTINE SALT2_STORE()
! 
! April 24, 2009 R.Kessler
! 
! Compute mB* and its error, and store in parameter
! slot IPAR_MB.  Assumes same primary system for
! each survey/filter system.
! 
! 
! Nov 6, 2009:  mB -> mB - FILT_MAGPRIMARY(IFILT_BESS_B)
!               SALT2 mB* is now the same for Vega & BD17 primaries
! 
! Jan 28, 2010: undo above after making more general fix in genmag_SALT2.
! 
! Feb 09, 2010: set redshift to 10pc (see new SAVE_Z)
! 
! Jul 27, 2010: z = ZAT10PC instead of 10.*Zat10pc.
!               No idea why there was a factor of 10 ... perhaps a debug ?
! 
! Aug 11, 2010: huge simplification: just use SALT2mbcalc and get
!               rid of all the stuff for MODELMAB_CALC
! 
! Sep 17 2016: load FITERRMAT
! Feb 16 2017: compute MBerr analytically (fix problem found by ChrisD)
! 
! -----------------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    REAL*8  mB, MBERR, x0, x0err

! functions
    REAL*8  SALT2mBcalc

! ----------- BEGIN ---------

    X0    = LCVAL_STORE(IPAR_X0)
    X0err = LCERR_STORE(IPAR_X0)

    MB    = SALT2mBcalc( X0 )
    MBERR = 2.5 * (X0err/X0)/log(10.0)

! store mB and it error, and its COV

    LCVAL_STORE(IPAR_MB)  = SNGL(mb)
    LCERR_STORE(IPAR_MB)  = SNGL(mberr)
    FITERRMAT(IPAR_MB,IPAR_MB) = mberr*mberr  ! covariance

    RETURN
  END SUBROUTINE SALT2_STORE

! =====================================
    SUBROUTINE SET_REDSHIFT_FIT(ITER)

! Created Aug 12, 2009 by R.Kessler
! 
! For each event, called from FITPAR_PREP to set initial REDSHIFT_FIT
! that is used to select filters & epochs.
! Most of the logic here is related to photoZ fits.
! 
! Dec 8 2025: fix bug seting DOFIT_PHOTOZ_HOST for quantiles
!
! ----------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER  & 
        iter  ! (I) fit iteration: 1,2, ... NFIT_ITERATION

! local
    INTEGER NQZPHOT
    REAL Zhost

! ---------------- BEGIN ---------------

    REDSHIFT_FIT = SNLC_REDSHIFT  ! start with "best" Z

    DOFIT_PHOTOZ_HOST   =  .FALSE.
    DOFIT_PHOTOZ_noHOST =  .FALSE.

! -------------------------------

    IF ( DOFIT_PHOTOZ ) THEN

! check for host photoZ

      Zhost    = SNHOST_ZPHOT(1)


      NQZPHOT = SNHOSTz_QUANTILE_ZPHOT(1)%NZ

      DOFIT_PHOTOZ_HOST =  & 
           (Zhost > 0.0 .or. NQZPHOT > 0) .and. (PRIOR_ZERRSCALE .LT. 30.0)

      DOFIT_PHOTOZ_noHOST = .NOT. DOFIT_PHOTOZ_HOST

! --------------------------------------------

       if ( ITER.EQ. 1 .and. DOFIT_PHOTOZ_HOST  )  then
         REDSHIFT_FIT = ZHOST
       endif

       if ( ITER.EQ. 1 .and. DOFIT_PHOTOZ_noHOST  )  then
! leave best Z  above ; note that initial photoZ gets modified
! in FITINI_PHOTOZ before the fit starts.
       endif

! use fitted photoZ (from 1st iteration) on 2nd iteration,
! or if 1st iteration is repeated.

       IF ( iter .GT. 1 .or. LREPEAT_ITER ) THEN
         REDSHIFT_FIT = LCVAL_STORE(IPAR_zPHOT)
       ENDIF

    ENDIF

! - - - - - - -  -

    if ( LSIM_SNANA .and. USESIM_REDSHIFT ) then
      REDSHIFT_FIT = SIM_REDSHIFT_HELIO + REDSHIFT_FINAL_SHIFT
    endif

! June 2025: abort on invalid redshift (likely missing in data file)
    if ( REDSHIFT_FIT < 0.0 .and. OPT_PHOTOZ == 0 ) then
       write(c1err,660) REDSHIFT_FIT, SNLC_CCID
660      format('Undefined REDSHIFT_FIT=', F6.3,' for CID=',A8 )
       c2err = 'Check REDSHIFT info in data file'
       CALL MADABORT("SET_REDSHIFT_FIT", c1err, c2err )
    endif

    RETURN
  END SUBROUTINE SET_REDSHIFT_FIT

! ========================================
    SUBROUTINE PHOTOZ_STORE(NPAR)
! 
! Store PHOTOZ-related variables
! 
! Mar 2024: use MASK_PHOTOZ_SOURCE instead of user-input OPT_PHOTOZ
!           because MASK_PHOTOZ_SOURCE is guaranteed to have only
!           one bit set, thus simplifying local logic.
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER  NPAR   ! (I) storage index

! local var

    REAL zfit,  zfiterr, zhost, zhosterr, zmagerr, zdif, zerr, zpull 
    INTEGER LENC
    REAL*8  MU8(2), Z8(2), DZ8, DZDMU, MUREF

    character CZPRIOR*20

! functions

    REAL*8  DLMAG_REF

! ------------ BEGIN -----------

    if ( LTRACE ) CALL DMPTRACE("BEGIN PHOTOZ_STORE" )

! extract fit photoZ and determine total error.

    zfit    = LCVAL_STORE(IPAR_zPHOT)
    zfiterr = LCERR_STORE(IPAR_zPHOT)

    zhost    = PRIOR_PHOTOZ
    zhosterr = PRIOR_PHOTOZ_ERR
    czprior  = PRIOR_COMMENT

! ---------------------
! Compute photoZ-error from intrinsic MAG-dispersion.

    DZ8   = 0.01
    Z8(1) = dble(Zfit)
    Z8(2) = Z8(1) + dZ8

    MU8(1) = DLMAG_REF(Z8(1))
    MU8(2) = DLMAG_REF(Z8(2))
    MUREF  = MU8(1)

    DZDMU = ( Z8(2) - Z8(1) ) / ( MU8(1) - MU8(2) )  ! local derivative

    zmagerr = SNGL( SNMAGRMS_for_PHOTOZ * abs(DZDMU) )

! -------
    zdif  = zfit - zhost
    zerr  = sqrt ( zfiterr**2 + zhosterr**2 + zmagerr**2)
    zerr  = max(zerr,0.00001)  ! avoid Zpull divide-by-zero
    zpull = zdif / zerr

    LCVAL_STORE(Npar) = zdif
    LCERR_STORE(Npar) = zerr
    ISTORE_ZPULL          = NPAR    ! store this index for later

! store errors in common block

    PHOTOZ_ERR_SNFIT  = zfiterr
    PHOTOZ_ERR_SNHOST = zhosterr
    PHOTOZ_ERR_SNMAG  = zmagerr
    PHOTOZ_ERR_ZPULL  = zpull

! ----------------------------------------------
! print PHOTOZ info

    IF ( STDOUT_UPDATE ) THEN
      write(6,20) SNLC_CID, ZFIT  & 
         , PHOTOZ_ERR_SNFIT  & 
         , PHOTOZ_ERR_SNMAG

      LENC = INDEX(CZPRIOR,' ') - 1
      write(6,30) SNLC_CID, CZPRIOR(1:LENC), ZHOST  & 
         , PHOTOZ_ERR_SNHOST  & 
         , PHOTOZ_ERR_ZPULL
    ENDIF

20    format(T8,'CID',I8,' PHOTOZ(SNFIT) = ', F6.4  & 
               , ' +- ',F5.4,'(stat)'  & 
               , ' +- ',F5.4,'(snmag)'  )

30    format(T8,'CID',I8,' ZPRIOR(',A,') = ', F6.4  & 
               , ' +- ',F5.4, 5x,'ZPULL=',F6.2 )

    if ( LTRACE ) CALL DMPTRACE("END PHOTOZ_STORE")

! -----------
! for photoZ fit, MU is fixed to initial photoZ.
! Here we change the 'fixed' DLMAG parameter to correspond
! to the final (fitted) photoZ. This is just for internal
! consistency and it does not affect the fit or analysis
! in any way.

    IF ( DOFIT_PHOTOZ .and. INISTP_DLMAG .EQ. 0.0 ) THEN
       LCVAL_STORE(IPAR_DLMAG) = SNGL(MUREF)
    ENDIF

    RETURN
  END SUBROUTINE PHOTOZ_STORE

! ===================================================
    SUBROUTINE FITANA_SUMMARY ( isn )
! 
! print summary of fit vs. filter.
! 
! --------------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER isn ! (I)  sn index

! local var

    REAL TCOR, RTMP(MXFILT_ALL,10)

    INTEGER  ifilt, kk, i, ifilt_obs, NFILT, NFTMP, ITMP(MXFILT_ALL,10), NTMP

    CHARACTER  & 
         BANNER*80  & 
        ,CCID*(MXCHAR_CCID)  & 
        ,CCHI2(4)*8  & 
        ,CFILT(MXFILT_ALL)*1


    DATA  CCHI2 / 'TOTAL' , 'DATA', 'PRIOR', 'SIGMA' /

! ------------------- BEGIN -----------------

    MARK_USED(isn)

    IF ( .NOT. STDOUT_UPDATE ) RETURN ! Jun 2024

    CCID = SNLC_CCID
    KK   = ISNLC_LENCCID

    write(BANNER,20) CCID(1:KK)
20    format('LC FIT SUMMARY for CID=', A )

    CALL PRBANNER ( BANNER )

! create sparse arrays for printing results-vs-filter on one line.

    NFILT = 0
    DO 444 ifilt   = 1, NFILTDEF_SURVEY
      IFILT_OBS    = IFILTDEF_MAP_SURVEY(ifilt)

      if ( .NOT. USE_FILT(ifilt_obs) ) goto 444

      NFILT = NFILT + 1
      CFILT(Nfilt)  = filtdef_string(ifilt_obs:ifilt_obs)
      ITMP(Nfilt,1) = NEPOCH_ALL(ifilt)
      ITMP(Nfilt,2) = NEPOCH_REJECT(ifilt)
      ITMP(Nfilt,3) = NFITDOF(ifilt)

      RTMP(Nfilt,1) = LC_MARGCHI2(ifilt)
      RTMP(Nfilt,2) = LC_MARGPROB(ifilt)
      RTMP(Nfilt,3) = PEAKMAG_OBS_MODEL(ifilt)
      RTMP(Nfilt,4) = PEAKMAG_OBS_MODEL_ERR(ifilt)
      RTMP(Nfilt,5) = SNLC_MWXT_MAG(ifilt)
      RTMP(Nfilt,6) = SNLC_MWXT_MAGERR(ifilt)

444   CONTINUE

! print no more than 6 filters to avoid a messsy output
    NFTMP = MIN(NFILT,6)

    write(6,700) 'Quantity', (CFILT(ifilt), ifilt = 1, NFTMP )
    write(6,799)
    write(6,706) 'NEPOCH',  (ITMP(ifilt,1),ifilt=1, NFTMP)
    write(6,706) 'NREJECT', (ITMP(ifilt,2),ifilt=1, NFTMP)
    write(6,706) 'NDOF',    (ITMP(ifilt,3),ifilt=1, NFTMP)

    write(6,725) 'CHI2',    (RTMP(ifilt,1), ifilt=1,NFTMP)
    write(6,725) 'PROB',    (RTMP(ifilt,2), ifilt=1,NFTMP)
    write(6,725) 'PeakMag', (RTMP(ifilt,3), ifilt=1,NFTMP)
    write(6,725) 'PeakErr', (RTMP(ifilt,4), ifilt=1,NFTMP)
    write(6,725) 'XTMW',    (RTMP(ifilt,5), ifilt=1,NFTMP)
    write(6,725) 'XTMWerr', (RTMP(ifilt,6), ifilt=1,NFTMP)

700   format(T2, A,  6(10x,A)  )
706   format(T2, A8, 6(I11)   )
725   format(T2, A8, 6(F11.2) )
799   format(T2, 80('-') )

    write(6,799)

    if ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) then
      write(6,21)  & 
           CCID(1:KK)  & 
          ,LCVAL_STORE(IPAR_MB)  & 
          ,LCERR_STORE(IPAR_MB)
21      format(T4,'SALT2 mB(',A,') = ', F9.4, ' +- ', F7.4 )
    endif

! write Trest fit range relative to PEAKMJD(fit)

    write(6,770) CCID(1:KK), R4SN_Tearly, R4SN_Tlate, 'FIT'
    write(6,771) CCID(1:KK), R4SN_MJDmin, R4SN_MJDmax


! write Trest fit range relative to exact SIM_PEAKMJD

    IF ( LSIM_SNANA ) THEN
       TCOR = SNGL( FITVAL_STORE(IPAR_PEAKMJD) - (SIM_PEAKMJD-MJDOFF) )
       write(6,770) CCID(1:KK),  & 
                R4SN_Tearly+TCOR, R4SN_Tlate+TCOR, 'SIM'
    ENDIF

770   format(T4, 'Trest FIT RANGE(',A,'): ', F7.2,' to ', F7.2,  & 
          3x,'(relative to ',A,'-PEAKMJD)' )

771   format(T4, 'MJD   FIT RANGE(',A,'): ', F7.1,' to ', F7.1 )

! -----------------------------------
! print chi2 and prob for 1:TOTAL,  2:DATA,  3:PRIOR,   4:SIGMA

    print*,' '

    NTMP = 3
    IF (OPT_CHI2_SIGMA > 0 ) NTMP=4
    DO i = 1, NTMP
       write(6,781) 'FIT MINIMUM ', CCID(1:KK)  & 
          ,CCHI2(i)  & 
          ,FITCHI2_STORE(i), NDOF_STORE(i)  & 
          ,FITPROBCHI2_STORE(i)
    ENDDO

    IF ( NGRID_PDF .GT. 0 ) THEN
      DO i = 1, NTMP
       write(6,781) 'MARGINALIZATION', CCID(1:KK)  & 
          ,CCHI2(i)  & 
          ,LCCHI2_STORE(i), NDOF_STORE(i)  & 
          ,LCPROBCHI2_STORE(i)
      ENDDO
    ENDIF

781   format(T4,A,'(',A,') returns ',A6,2x,  & 
         'CHI2/dof=',G10.3,'/',I3,  3x, 'PROB=',F7.5)

    print*,' '

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE FITANA_SUMMARY 

! ========================================
    REAL FUNCTION LCPROBCHI2(ifilt)


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER   IFILT  ! (I) filter index

! local

    REAL    probtmp, chi2
    INTEGER Ndof

    REAL*8  CHI8

! function
    REAL*8 PROB_CHI2NDOF

! ----------------- BEGIN -----------------

    LCPROBCHI2 = 0.0

    chi2     = LC_FITCHI2(ifilt)
    Ndof     = NFITDOF(ifilt)

    if ( Ndof .LE. 0 ) then
      write(6,20) Ndof, ifilt
20      format(T10,'LCPROBCHI2 WARNING: Ndof=',I2,' for ifilt=',I2 )
      return
    endif


    CHI8     = DBLE(CHI2)
    probtmp  = SNGL( PROB_CHI2NDOF(CHI8,NDOF) )

    probtmp  = max ( probtmp, 1.2E-10 )

    LCPROBCHI2 = probtmp

    RETURN
  END FUNCTION LCPROBCHI2

! ====================================
    SUBROUTINE FPKRAT(ifilt_obs)

! Created May 15, 2008 by R.Kessler
! 
! Fill EP_FPKRAT[ERR] = flux/peakFlux in rest frame.
! Loop over all epochs & filters inside here.
! 
! Mar 06, 2009:
!   Correct peakFlux for average data/model ratio so that
!   peakFlux is not way off if the model is off.
!   See new namelist varaible TREST_PEAKKRENORM
!   Fills new array FPKRAW to keep track of raw
!   (uncorrected) Flux/peakFlux ratio.
! 
!   Pass 'ifilt_obs' arg and process only this filter
! 
! Mar 3, 2010: apply K-correction only if kcor != NULLVALL;
!              ==> give something reasonable for SALT2
! 
! Mar 5, 2010: fix aweful bug, argument of PEAKFLUX_OBS_MODEL
!              is IFILT_OBS instead of IFILT. Previous code worked
!              by accident for SDSS, but not for any other survey.
! 
! Dec 14, 2011: avoid divide-by-zero for Fraterr calc
! 
! Nov 10 2015: move divide-by-zero protection; see Flux_model
! 
! May 12 2026: protect SQ1 and SQ2 from divide-by-zero 
! --------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

! subroutine args.
    INTEGER  IFILT_OBS    ! (I) obs filter to process

! local var

    INTEGER ifilt, ifilto, iep, ifitdata

    REAL  & 
         kcor, flux, flux_err, Flux_model, Flux_model_err  & 
        ,Frat, Fraterr, arg, FPKRAW(MXEPOCH)  & 
        ,z1, Trest, MJD, PEAKMJD  & 
        ,Tnear, ratio, ratio_err, sum_ratio, wsum_ratio  & 
        ,wgt, sq1, sq2, PEAK_MODEL_RENORM

    LOGICAL LRENORM, USE_RENORM, LDMP, LKCOR

    CHARACTER cfilt*1

! ---------------- BEGIN ------------

    LDMP       = .FALSE.  ! debug-dump flag
    USE_RENORM = .FALSE.

    cfilt   = filtdef_string(ifilt_obs:ifilt_obs)
    z1      = 1. + REDSHIFT_FIT
    PEAKMJD = SNGL( LCVAL_STORE(IPAR_PEAKMJD) + MJDOFF )

    SUM_RATIO   = 0.
    WSUM_RATIO  = 0.
    Tnear       = 99999.  ! epoch closest to peak

    if ( LDMP ) then
       print*,' xxx ------------------------------------------------- '
       print*,' xxx FPKRAT DUMP for CID=',SNLC_CCID(1:12), '    IFILT_OBS=', IFILT_OBS
       call flush(6)
    endif

    DO 50 ifitdata = 1, NFITDATA

       iep        = EPLIST_FIT(ifitdata)

       ifilto     = I4EP_ALL(iep,IEP_IFILT_OBS)
       if ( ifilto .NE. IFILT_OBS ) goto 50

       MJD        = SNGL(R8EP_MJD(ifitdata))
       Trest      = (MJD - PEAKMJD) / z1
       ifilt      = I4EP_ALL(iep,IEP_IFILT)

       Flux           = R4EP_ALL(iep,JEP_DATAFLUX)
       Flux_err       = R4EP_ALL(iep,JEP_DATAFLUX_ERR)
       Flux_model     = R4EP_ALL(iep,JEP_MODELFLUX)
       Flux_model_err = R4EP_ALL(iep,JEP_MODELFLUX_ERR)
       kcor           = R4EP_ALL(iep,JEP_KCOR)

! Compute FPKRAT:
       Frat = Flux / PEAKFLUX_OBS_MODEL(ifilt)  ! obs-frame

! now K-correct from obs-frame back to rest-frame
       LKCOR = abs(kcor-NULLVAL) > 1.0
       IF ( LREST_FITMODEL .and. LKCOR ) then
         arg     = 0.4 * (kcor - PEAK_KCOR_MODEL(ifilt))
         Frat    = Frat * 10.0**(arg)
       ENDIF

! include data and model error for error on FPKRAT:
       if ( FLux > 0.0 .or. flux_model > 0.0 ) then
          if ( LDMP ) then
             write(6,652) ifitdata, Trest, flux, flux_err, flux_model, flux_model_err
652          format(' xxx idata=',I3, 2x, 'Trest=', F6.1, 2x, &
                  'Flux=', F9.2,'+-', F8.2, 3x,   &
                  'Flux_nmodel=', F9.2,'+-', F8.2 )
             call flush(6)
          endif
          SQ1 = 0.0;  SQ2 = 0.0
          if ( FLUX       > 0.0 ) SQ1 = (flux_err/Flux)**2
          if ( FLUX_MODEL > 0.0 ) SQ2 = (flux_model_err/flux_model)**2 
          Fraterr = Frat * sqrt(SQ1+SQ2)
       ELSE
          Fraterr = -9.0
       ENDIF

       FPKRAW(iep)                 = Frat
       R4EP_ALL(iep,JEP_FPKRAT)    = Frat
       R4EP_ALL(iep,JEP_FPKRATERR) = Fraterr

! check if this epoch is used to re-normalize the peak from the model.

       LRENORM  = &
            Trest .GE. TREST_PEAKRENORM(1) .and.  & 
            Trest .LE. TREST_PEAKRENORM(2) .and.  & 
            Flux_model > 0.0    ! avoid divide-by-0

       IF ( LRENORM ) THEN
         USE_RENORM = .TRUE.
         ratio       = Flux/Flux_model
         ratio_err   = Flux_err/Flux_model

! Amplify error away from peak;
! error scale is 1 at peak, and 3 at 8 days away from peak.

         ratio_err   = ratio_err * sqrt(abs(Trest)+1.)

! compute weight at this epoch
         wgt         = 1. / (ratio_err**2)

! now add additional weight based on
! proximity to peak
         wgt = wgt + .01/(abs(Trest) + 1.0)

         WSUM_RATIO  = WSUM_RATIO  + wgt
         SUM_RATIO   = SUM_RATIO   + wgt * ratio

         if ( LDMP ) then
            write(6,660) cfilt, ratio, ratio_err, Trest
660         format(' xxxx ',A,'-Data/Model ratio = ',  & 
                 F6.3,' +- ', F6.3,'  at Trest=',F5.1,' days ' )
         endif

         if ( abs(Trest) .LT. abs(Tnear) ) then
            Tnear = Trest
         endif
       ENDIF

50    CONTINUE


! --------
! Check if model peakFlux gets renormalized

    IF ( USE_RENORM .and. WSUM_RATIO > 0.0 ) THEN

      PEAK_MODEL_RENORM = (SUM_RATIO/WSUM_RATIO)

      PEAKFLUX_OBS_MODEL_COR(ifilt) = PEAK_MODEL_RENORM

      write(6,71) SNLC_CCID, PEAK_MODEL_RENORM, cfilt
71      format(T5,'Model peakFlux(SN ', A8, ') adjusted by ',  & 
                F6.3,' for FPKRAT-', A )

! adjust all of the FPKRAT values.

      DO 70 ifitdata = 1, NFITDATA

         iep     = EPLIST_FIT(ifitdata)

         ifilto  = I4EP_ALL(iep,IEP_IFILT_OBS)
         if ( ifilto .NE. IFILT_OBS ) goto 70

         R4EP_ALL(iep,JEP_FPKRAT) =  & 
                FPKRAW(iep) / PEAK_MODEL_RENORM

         R4EP_ALL(iep,JEP_FPKRATERR) =  & 
                R4EP_ALL(iep,JEP_FPKRATERR) / PEAK_MODEL_RENORM
 70     CONTINUE
    ENDIF

    RETURN
  END SUBROUTINE FPKRAT

! =====================================
    SUBROUTINE RADIUS_CALC()

! Created Jan 2024
! Compute population radius RADIUS_POP in space of stretch and color.
! This variable is useful to reduce non-SNIa contamination.


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    REAL s, c, s_scale, c_scale

! ------------ BEGIN -------------

    RADIUS_POP = -9.0  ! init to undefined
    s = LCVAL_STORE(IPAR_SHAPE)
    c = LCVAL_STORE(IPAR_COLOR)

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
        s_scale = 3.0
        c_scale = 0.3
    ELSE
        RETURN
    ENDIF

    RADIUS_POP = sqrt( (s/s_scale)**2 + (c/c_scale)**2 )

    RETURN
  END SUBROUTINE RADIUS_CALC

! ======================================
    SUBROUTINE MODELMAG_CALC (  & 
          IFILT           &  ! (I) absolute filter index
         ,CFRAME          &  ! (I) 'REST'  or 'REST2' or 'OBS'
         ,MJD             &  ! (I) MJD to evaluate
         ,FLUX, FLUXERR   &  ! (O) Flux and error
         ,MAG,  MAGERR    &  ! (O) mag and its error
         ,KCOR            &  ! (O) K-correction (if used)
             )

! -----------------------
! 
! Created Jan 2008 by R.Kessler
! Calculate Lightcurve parmaters at MJD using best fit model.
! Returns FLUX, MAG and KCOR
! 
! [modified from PEAKMAG_CALC]
! 
! 
! ----------------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER  ifilt        ! (I) IFILT_OBS or IFILT_REST (depends on CFRAME)
    CHARACTER CFRAME*(*)  ! (I) 'REST' or 'OBS' or 'REST2'

    REAL*8  MJD, FLUX, FLUXERR, MAG, MAGERR, KCOR

! local var

    REAL*8  TREF, WAVECOR, MAGOFF, TOBS, MAGOFF_REST, SQSIG_FLUX, PKMJD
    INTEGER OPT, OPT_KCOR
    LOGICAL LOBS, LREST, LDMP

    CHARACTER CFILT1, CFRAME_LOC*8

! functions
    REAL*8  GET_FLUX_FITFUN, COVFLUXFUN

! ----------------- BEGIN --------------

! init output args
    MAG     =  99.
    MAGERR  = -9.0
    FLUX    = -9.0
    FLUXERR = -9.0

    cfilt1     = filtdef_string(ifilt:ifilt)
    WAVECOR    = 0.0 ! .xyz
    CFRAME_LOC = CFRAME

    LOBS  = .FALSE.
    LREST = .FALSE.

    PKMJD = LCVAL_STORE(IPAR_PEAKMJD) + MJDOFF
    TOBS  =  MJD - PKMJD

    IF ( PARNAME_STORE(IPAR_DLMAG) .EQ. 'DLMAG' ) THEN
       MAGOFF_REST = 19.6  ! -PEAKMAG_AT_10pc
    ELSE
       MAGOFF_REST = 0.0
    ENDIF

    IF ( CFRAME_LOC(1:3) .EQ. 'OBS' ) THEN
        LOBS   = .TRUE.
        OPT    = 0
        MAGOFF = 0.0
        TREF   = TOBS

    ELSE IF ( CFRAME_LOC(1:5) .EQ. 'REST2' ) THEN
        LOBS   = .TRUE.
        OPT    = 3  ! 2=> includes AV; 3 => subtract XTAV
        MAGOFF = MAGOFF_REST
        TREF   =  TOBS

    ELSE IF ( CFRAME_LOC(1:4) .EQ. 'REST' ) THEN
        LREST  = .TRUE.
        OPT    = 1
        MAGOFF = MAGOFF_REST
        TREF   = TOBS / ( 1. + REDSHIFT_FIT )
    ELSE
       c1err = 'Unknown CFRAME = ' // CFRAME
       write(c2err,660) SNLC_CCID, IFILT
660      format('CID=',A12, 4x, 'IFILT=', I2 )
       CALL MADABORT("MODELMAG_CALC", c1err, c2err )
    ENDIF

    LDMP =  ( LREST .and. IFILT .EQ. -IFILT_BESS_B )
! ---------------------
! get the flux

    Flux  =  GET_FLUX_FITFUN ( ifilt, TREF, WAVECOR, OPT )

    SQSIG_FLUX =  & 
         COVFLUXFUN(OPT, ifilt, ifilt, TREF, TREF, LDMP )

! -------
!      print*,' OLD/NEW= ', SNGL(SQSIG_FLUX/U12),
!     &   '  COV=',U12, '  at TREF=',sngl(TREF),'  ifilt=',ifilt
! ------

    if ( SQSIG_FLUX < 0.0 ) then
       write(c1err,661) CFILT1, SQSIG_FLUX, SNLC_CCID
661      format('SQSIG_FLUX(',A,')=', G10.4,' for CID=',A )
       c2err = ' '
       print*,' MODELMAG_CALC WARNING: ', c1err(1:50)
!          CALL MADABORT("MODELMAG_CALC", c1err, c2err )
    endif

    Fluxerr = sqrt ( abs(SQSIG_FLUX) )


! convert flux to MAG.

    if ( Flux .GT. 1.0E-20 ) then
      mag    = -2.5 * LOG10(Flux) + MAGOFF + ZP_FLUXCAL
      magerr =  2.5 * LOG10(1.0 + Fluxerr/Flux)
    else
      mag    = 99.
      magerr = 9.
    endif

! get the K-correction
    if ( LOBS .and. LKCOR_AVWARP ) THEN
      OPT_KCOR = 10
      KCOR  = GET_FLUX_FITFUN (  ifilt, TREF, WAVECOR, OPT_KCOR )
    else
      KCOR = 0.0
    endif

    RETURN
  END SUBROUTINE MODELMAG_CALC 

! ======================================
    SUBROUTINE PEAKMAG_CALC ( IFILTDEF, CFRAME )
! 
! Created Jan, 2008
! Just calls MODELMAG_CALC with PKMJD = PEAKMJD
! 
! Feb 20 2017: convert input IFILTDEF to sparse index IFILT,
!              and fill arrays with sparse IFILT.
! 
! ----------------------------------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER  & 
         ifiltdef  ! (I) IFILT_OBS or IFILT_REST (depends on CFRAME)

    CHARACTER CFRAME*(*)  ! (I) 'REST' or 'OBS'

! local var

    INTEGER IFILT
    REAL*8 PKMJD, FLUX, FLUXERR, MAG, MAGERR, KCOR

! ----------------- BEGIN --------------

    PKMJD = LCVAL_STORE(IPAR_PEAKMJD) + MJDOFF

    CALL MODELMAG_CALC(IFILTDEF,CFRAME, PKMJD,    &  ! (I) inputs
           FLUX, FLUXERR, MAG, MAGERR, KCOR)    ! (O) return args

    if ( CFRAME(1:3) .EQ. 'OBS' ) THEN
      IFILT = IFILTDEF_INVMAP_SURVEY(ifiltdef) ! get sparse index

      PEAKMAG_OBS_MODEL(ifilt)     = SNGL(MAG)
      PEAKMAG_OBS_MODEL_ERR(ifilt) = SNGL(MAGERR)

      PEAKFLUX_OBS_MODEL(ifilt)     = SNGL(FLUX)
      PEAKFLUX_OBS_MODEL_ERR(ifilt) = SNGL(FLUXERR)

      PEAK_KCOR_MODEL(ifiltdef)        = SNGL(KCOR)
    ELSE
      PEAKMAG_REST_MODEL(ifiltdef)     = SNGL(MAG)
      PEAKMAG_REST_MODEL_ERR(ifiltdef) = SNGL(MAGERR)
    ENDIF

    RETURN
  END SUBROUTINE PEAKMAG_CALC 

! =====================================
    REAL*8 FUNCTION COVFLUXFUN(OPT, ifilt1,ifilt2, T1,T2,LDMP )

! 
! Created April 6, 2008 by R.Kessler
! 
! Get the model-Flux covariance between any two epochs/filters
! using full fitpar covariance, FITERRMAT(ipar1,ipar2)
!  ( see eq. 32.24 in PDG statistics section)
! 
! COVFLUXFUN = U12,
! 
!                           dF1   dF2
! U12       = \sum_{k,l}  ------ ------ * FITERRMAT(k,l)
!                         dPAR_k dPAR_l
! 
!  where PAR_k = fit-parameter with index 'k'.
!  and F1,F2 are fluxes at days with index 1,2.
! 
! If ifilt1=ifilt2 and T1=T2,  then U12 = square of model
! uncertainty at this epoch.
! 
! Mar 26 2014: add new LDMP argument
! 
! -------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

! subroutine args:

    INTEGER  & 
         OPT      &  ! (I) option for GET_FLUX_FITFUN
        ,IFILT1   &  ! (I) ifilt_obs or ifilt_rest (depends on OPT)
        ,IFILT2  ! (I) idem for other epoch

    REAL*8  T1, T2  ! (I) epoch (days) to get covariance

    LOGICAL LDMP  ! (I) dump flag.

! local var

    INTEGER  & 
         ipar_k, ipar_l

    REAL*8  & 
         FLUX1, FLUX2  & 
        ,FTMP1, FTMP2  & 
        ,SAVEVAL_k, SAVEVAL_l  & 
        ,ERRPAR_k,  ERRPAR_l  & 
        ,dF1dVAL_k, dF2dVAL_l, FF  & 
        ,V_kl, U12, WAVECOR1, WAVECOR2

! functions
    REAL*8  GET_FLUX_FITFUN

! -------------- BEGIN -------------

    COVFLUXFUN = 0.0
    U12 = 0.0   ! init output

! get reference fluxes to computer deriviates below.

    WAVECOR1 = 0.0  ! .xyz ??
    WAVECOR2 = 0.0 
    Flux1   =  GET_FLUX_FITFUN ( ifilt1, T1, WAVECOR1, OPT )
    Flux2   =  GET_FLUX_FITFUN ( ifilt2, T2, WAVECOR2, OPT )

    DO 301 ipar_k = 1, NFITPAR_MN
       if ( .NOT. FLOATPAR(ipar_k) ) goto 301
    DO 302 ipar_l = 1, NFITPAR_MN
       if ( .NOT. FLOATPAR(ipar_l) ) goto 302

       SAVEVAL_k = LCVAL_STORE(ipar_k)
       SAVEVAL_l = LCVAL_STORE(ipar_l)

       ERRPAR_k  = LCERR_STORE(ipar_k)
       ERRPAR_l  = LCERR_STORE(ipar_l)

! change fitpar values by +1 sigma and re-evaluate Flux.

       LCVAL_STORE(ipar_k) =  & 
         LCVAL_STORE(ipar_k) + SNGL(ERRPAR_k)
       Ftmp1   =  GET_FLUX_FITFUN ( ifilt1, T1, WAVECOR1, OPT )
       LCVAL_STORE(ipar_k) = SNGL(SAVEVAL_k)

! repeat for 2nd fitpar ...
       LCVAL_STORE(ipar_l) =  & 
         LCVAL_STORE(ipar_l) + SNGL(ERRPAR_l)
       Ftmp2   =  GET_FLUX_FITFUN ( ifilt2, T2, WAVECOR2, OPT )
       LCVAL_STORE(ipar_l) = SNGL(SAVEVAL_l)

! make sure that errors are non-zero before dividing.

       c2err = ' '
       if ( ERRPAR_k .EQ. 0.0 ) then
         write(c1err,662) PARNAME_STORE(ipar_k)
         CALL MADABORT("COVFLUXFUN", c1err, c2err )
       endif
       if ( ERRPAR_l .EQ. 0.0 ) then
         write(c1err,662) PARNAME_STORE(ipar_l)
         CALL MADABORT("COVFLUXFUN", c1err, c2err )
       endif
662      format('Cannot compute FLUXERR with ERR(',A,') = 0' )

! evaluate partial deriviates for flux
       dF1dVAL_k = (Ftmp1 - Flux1) / ERRPAR_k
       dF2dVAL_l = (Ftmp2 - Flux2) / ERRPAR_l

       FF   = dF1dVAL_k * dF2dVAL_l
       V_kl = FITERRMAT(ipar_k,ipar_l)
       U12  = U12 + FF * V_kl

       if ( LDMP .and. FF .NE. 0.0 ) then
          print*,' xxx COVFLUXFUN DUMP for ',  & 
                parname_store(ipar_k)(1:10),  & 
                parname_store(ipar_l)(1:10)
          print*,' xxx   FF, V_kl, U12 ',  & 
                 sngl(FF/1.0E35), sngl(V_kl), sngl(U12/1.0E35)
          print*,' xxx   dF1,dF2 = ',  & 
                sngl(dF1dVAL_k/1.0E18), sngl(dF2dVAL_l/1.0E18)
          print*,' xxx   ERR1,ERR2 = ',  & 
                sngl(ERRPAR_k), sngl(ERRPAR_l)
          call flush(6)
       endif

302   CONTINUE
301   CONTINUE

    COVFLUXFUN = U12

    RETURN
  END FUNCTION COVFLUXFUN

! ======================================
    DOUBLE PRECISION FUNCTION COVFUDGE_DATA( irow, icol )
! 
! Created Feb 23 2015 by R.Kessler
! Compute fudged data-covariance from &SNLCINP  namelist
! input FUDGE_MAG_COVERR.
! 

    USE SNDATCOM
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER irow, icol   ! (I) matrix location

! local var

    REAL*8 R1, R2, ERR1, ERR2, F1, F2
    INTEGER IFILT1, IFILT2

! -------------- BEGIN --------------

    COVFUDGE_DATA = 0.0
    if ( FUDGE_MAG_COVERR .EQ. ' ' ) RETURN  ! no fudge requested

    ifilt1  = I4EP_ALL(irow,IEP_IFILT_OBS)
    ifilt2  = I4EP_ALL(icol,IEP_IFILT_OBS)

    if ( ifilt1 .NE. ifilt2 ) RETURN  ! no cov for different filters.

    R1   = FUDGE_MAG_COVERR_FILT(ifilt1)  ! mag error
    R1   = 1.0 - 10.0**(-0.4*R1)          ! exact sigF/F
    R2   = R1
    F1   = R4EP_ALL(irow,JEP_DATAFLUX)    ! flux
    F2   = R4EP_ALL(icol,JEP_DATAFLUX)
    ERR1 = F1 * R1                       ! error on flux
    ERR2 = F2 * R2

    COVFUDGE_DATA  = (ERR1 * ERR2)

    RETURN
  END FUNCTION COVFUDGE_DATA


! =====================================
    DOUBLE PRECISION FUNCTION RHOFUDGE_MODEL( irow, icol, RHO )

! Created Sep 20, 2006
! 
! Return fudged correlation coefficients for systematic studies
! on model errors.
! Fudge only non-zero elements using FUDGE_COVAR as explained below.
! 

    USE SNPAR
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER irow, icol   ! (I) matrix location
    REAL*8  RHO          ! (I) un-fudged rho = COV[1,2]/sig1*sig2

! local var

    REAL*8 RHOSGN, RHOABS, RHOTMP
    LOGICAL LDMP  ! print fudge formula if TRUE

! --------- BEGIN ---------

    RHOFUDGE_MODEL = RHO  ! default is no fudge

! check option to print fudge-formual

    LDMP = ( irow .LE. 0 .and. irow .LE. 0 )
    IF ( LDMP ) THEN

!          CALL PRBANNER("RHOFUDGE: FUDGE RHO = COV[i,j]/sig_i*sig_j")

       IF ( FUDGE_COVAR .EQ. 0.0 ) THEN
!             print*,'      No fudge for RHO '
       ELSE IF ( FUDGE_COVAR .LT. 0.0 ) THEN
          write(6,21) abs(FUDGE_COVAR)
21          format(T10,'FUDGE non-zero |RHO| -> ',  & 
                       '|RHO| x [ 1 - ',F5.2,' ]' )
       ELSE IF ( FUDGE_COVAR .GT. 0.0 ) THEN
          write(6,22) FUDGE_COVAR
22          format(T10,'FUDGE non-zero |RHO| -> ',  & 
                         '|RHO| + [ 1 - |RHO| ] x ',F5.2 )
       ENDIF
       RETURN
    ENDIF

! ------------------------------------
! do NOT fudge ...

    if ( irow  .EQ. icol ) return  ! skip diagonal elements
    if ( RHO   .EQ. 0.0  ) return  ! elements already = 0

! bail if fudge is not requested
    if ( FUDGE_COVAR .EQ. 0.0  ) return

! ------------------------

    RHOABS = ABS(RHO)
    RHOSGN = RHO / ABS(RHO)

! as FUDGE_COVAR spans -1 to 1, |RHO| spans 0 to 1
! Positive FUDGE_COVAR increases |RHO| up to 1.0 ;
! Negative FUDGE_COVAR decreases |RHO| down to zero.

    IF ( FUDGE_COVAR .LT. 0.0 ) THEN
       RHOTMP = RHOABS * (1.0 + FUDGE_COVAR)
    ELSE IF ( FUDGE_COVAR .GT. 0.0 ) THEN
       RHOTMP = RHOABS + (1.0 - RHOABS) * FUDGE_COVAR
    ENDIF

    RHOFUDGE_MODEL = RHOTMP * RHOSGN

!  make sure that |RHOFUDGE| < 1 to avoid singular matrix.

    IF ( RHOFUDGE_MODEL .GE.  1.00000 ) THEN
        RHOFUDGE_MODEL =  +1.0 - 1.0E-08
    ENDIF

    IF ( RHOFUDGE_MODEL .LE. -1.00000 ) THEN
       RHOFUDGE_MODEL =  -1.0 + 1.0E-08
    ENDIF

    RETURN
  END FUNCTION RHOFUDGE_MODEL

! ==================================================
    SUBROUTINE VMAX_INI

! Created Jun 2013 by R.Kessler
! 
! Initialization for 1/Vmax method.
! Parse user inputs  MAGLIM_VMAX and OPT_VMAX
! 


    USE SNDATCOM
    USE FITINP_NML
    USE FILTCOM
    USE VMAXCOM

    IMPLICIT NONE

    INTEGER IFILT, IFILT_OBS, NFTMP, IFLIST(MXFILT_OBS)
    REAL    MAGLIM,  MAGLIST(MXFILT_OBS)
    CHARACTER FNAM*12, CFILT*2

! ------------- BEGIN -------------

    NFILT_VMAX = 0
    IF ( MAGLIM_VMAX .EQ. ' ' ) RETURN

    FNAM = "VMAX_INI"
    CALL PRBANNER('VMAX_INI: Initialize Zmax for 1/Vmax method')

    IF ( BTEST(OPT_VMAX,OPTBIT_MAG) )  THEN
      write(6,42) 'Compute best-fit MAG at epoch of peak brightness.'
    ELSE
      write(6,42) 'Compute best-fit MAG at epoch of max flux.'
    ENDIF

    IF ( BTEST(OPT_VMAX,OPTBIT_ZMAX) )  THEN
      write(6,42) 'Compute Zmax at epoch of peak brightness.'
    ELSE
      write(6,42) 'Compute Zmax at epoch of max flux.'
    ENDIF

    IF ( BTEST(OPT_VMAX,OPTBIT_VERBOSE) )  THEN
       write(6,42) 'Verbose mode ON.'
    ENDIF

 42   format(T8,'VMAX: ', A)

    CALL FLUSH(6)

! ---------------------------------
! translate user string MAGLIM_VMAX

    CALL PARSE_FILTSTRING(1, MAGLIM_VMAX,           &  ! inputs
          NFILT_VMAX, IFLIST, MAGLIST )  ! return args

    IF ( NFILT_VMAX > MXFILT_VMAX ) THEN
       write(c1err,671) NFILT_VMAX, MXFILT_VMAX
 671     format('NFILT_VMAX = ', I2,' exceeds bound of MXFILT_VMAX=',I2)
       c2err = 'Reduce NFILT_VMAX or increase MXFILT_VMAX.'
       CALL MADABORT(FNAM, c1err, c2err )
    ENDIF

    FILTLIST_VMAX = ''

    DO 20 IFILT = 1, NFILT_VMAX

       IFILTOBS_LIST_VMAX(IFILT) = IFLIST(IFILT)
       MAGLIM_LIST_VMAX(IFILT)   = MAGLIST(IFILT)

       IFILT_OBS = IFILTOBS_LIST_VMAX(ifilt)
       MAGLIM    = MAGLIM_LIST_VMAX(ifilt)
       CFILT     = FILTDEF_STRING(IFILT_OBS:IFILT_OBS)
       write(6,21) CFILT, MAGLIM, IFILT_OBS
 21      format(T12,'MAGLIM(',A1,') = ', F5.2, 3x,'(IFILTOBS=',I3,')' )

       NFTMP = INDEX(FILTLIST_VMAX,' ') - 1
       FILTLIST_VMAX = FILTLIST_VMAX(1:NFTMP) // CFILT(1:1)
 20   CONTINUE

    CALL FLUSH(6)

    RETURN
  END SUBROUTINE VMAX_INI

! ==================================================
    SUBROUTINE DMPVMAX(CCID,CFILT,NITER,ZMAX,MAGDIF,MAG)

! utility to dump one line for VERBOSE option

    CHARACTER CCID*(*)
    CHARACTER CFILT*(*)   ! (I)
    INTEGER NITER         ! (I)
    REAL*8  ZMAX, MAGDIF,MAG  ! (I)

! locals
    REAL*8  MMAG
    INTEGER LCCID

! ---------- BEGIN ----------

    LCCID = INDEX(CCID,' ') - 1
    MMAG  = 1000. * MAGDIF

    write(6,505) CCID(1:LCCID),CFILT, NITER, zmax, MMAG, MAG
 505  format(T5,A,'-',A, ' :  Zmax(ITER=',I2,')=', F6.4,3x,  & 
           'MAGDIF=',F7.2,' mmag', 2x,'MAG=',F7.3 )
    CALL FLUSH(6)

    RETURN
  END SUBROUTINE DMPVMAX

! ==================================================
    SUBROUTINE VMAX_ANA(IFILT_VMAX)

! Created Jun 2013 by R.Kessler
! 
! Compute Zmax/Vmax for 1/Vmax method.
! 
! Jun 28 2013:
!  Fix bug setting x0 = LCVAL_STORE(IPAR_DLMAG)  in iterative loop.
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE VMAXCOM
    USE SNLCINP_NML
    USE FILTCOM

    IMPLICIT NONE

    INTEGER IFILT_VMAX  ! (I) sparse filter index for VMAX calc

    INTEGER, PARAMETER :: JOBS=1, JFIT=2

    INTEGER  IFITDATA, IFILT_OBS, j, ep
    INTEGER  NITER, OPTWGT, NEP

    CHARACTER CFILT*1
    LOGICAL LVBOSE

    REAL*8  & 
         PEAKMJD, MJD, FLUXCAL(2), MAGTMP(2), Tobs, Trest  & 
        ,FLUXCAL_atmax(2), Trest_atmax(2), mag_atmax(2)  & 
        ,FLUXCAL_TMP, FLUXCAL_ERR, MAG_ERR, KCOR  & 
        ,MAGDIF, MAG, MAGLIM, zmax, Vmax, COSPAR(10)  & 
        ,z_save, d_save, shape, color, d0, d

! function
    REAL*8 GET_DIST8, DVDZ_INTEGRAL

! ------------- BEGIN -------------

! init all global output to crazy values.
    MAG_LIST_VMAX(ifilt_Vmax)   =  99.
    TREST_LIST_VMAX(ifilt_Vmax) =  99.
    Z_LIST_VMAX(ifilt_Vmax)     = -99.
    VOL_LIST_VMAX(ifilt_Vmax)   = -99.
    NEP_LIST_VMAX(ifilt_Vmax)   =  0

    IF ( NFILT_VMAX .EQ. 0 ) RETURN

    LVBOSE = BTEST(OPT_VMAX,OPTBIT_VERBOSE)

! strip off a few globals into local variables
    IFILT_OBS = IFILTOBS_LIST_VMAX(ifilt_Vmax)
    MAGLIM    = MAGLIM_LIST_VMAX(ifilt_Vmax)
    PEAKMJD   = LCVAL_STORE(IPAR_PEAKMJD)
    CFILT     = FILTDEF_STRING(IFILT_OBS:IFILT_OBS)

! find brightest epoch, both observed and best-fit.
    DO j = 1, 2
       FLUXCAL_atmax(j) = -9.9E+8  ! must be negative for logic below
       Trest_atmax(j)   =  99.
       mag_atmax(j)     =  99.
    ENDDO
    NEP     = 0

    DO 200 ifitdata = 1, NFITDATA

       ep = EPLIST_FIT(ifitdata)

       if ( ifilt_obs .NE. I4EP_ALL(ep,IEP_IFILT_OBS) ) GOTO 200

!         ifilt     = I4EP_IFILT(ifitdata)  ! sparse fit index, not Vmax
!         imjd      = I4EP_IMJD(ifitdata)

       MJD     = R4EP_ALL(ep,JEP_MJD)
       Tobs    = MJD - PEAKMJD
       Trest   = Tobs / (1. + SNLC_REDSHIFT)

! extract observed flux and mag just in case;
! we should not need this.
        FLUXCAL(JOBS)      = R4EP_ALL(ep,JEP_DATAFLUX)
        MAGTMP(JOBS)       = R4EP_ALL(ep,JEP_DATAMAG)

! idem for best-fit flux and mag; use this
        FLUXCAL(JFIT)      = R4EP_ALL(ep,JEP_MODELFLUX)
        MAGTMP(JFIT)       = R4EP_ALL(ep,JEP_MODELMAG)

! keep track of max FLUXCALs
        DO j = 1, 2
           if ( FLUXCAL(j) > FLUXCAL_atmax(j) ) then
              FLUXCAL_atmax(j) = FLUXCAL(j)
              mag_atmax(j)     = MAGTMP(j)
              Trest_atmax(j)   = Trest
           endif
        ENDDO

        NEP = NEP + 1

200   CONTINUE   ! ifitdata


! --- load common block variables -------

    NEP_LIST_VMAX(ifilt_Vmax) = NEP

    IF ( BTEST(OPT_VMAX,OPTBIT_MAG) ) THEN
      MAG_LIST_VMAX(ifilt_Vmax)   = PEAKMAG_OBS_MODEL(IFILT_Vmax)
      TREST_LIST_VMAX(ifilt_Vmax) = 0.0
    ELSE
      MAG_LIST_VMAX(ifilt_Vmax)   = SNGL( MAG_atmax(JFIT) )
      TREST_LIST_VMAX(ifilt_Vmax) = SNGL( Trest_atmax(JFIT) )
    ENDIF


! bail if we have an undefined MAG to work with
    if ( abs(MAG_LIST_VMAX(ifilt_Vmax)) > 98.0 ) RETURN

    Trest    = TREST_LIST_VMAX(ifilt_Vmax)
    Tobs     = TREST*(1.0 + SNLC_REDSHIFT)
    MJD      = MJDOFF + PEAKMJD + Tobs

! save fit quantities that need to be changed to find zmax
    z_save = LCVAL_STORE(IPAR_zPHOT)
    d_save = LCVAL_STORE(IPAR_DLMAG)  ! DLMAG or x0

! need color and shape parameter for distance(zmax) calc.
    SHAPE = LCVAL_STORE(IPAR_SHAPE)
    COLOR = LCVAL_STORE(IPAR_COLOR)

    NITER  = 0
    zmax   = SNLC_REDSHIFT  ! initial guess is current redshift
    d0     = GET_DIST8(zmax,SHAPE,COLOR,ONE8)  ! reference x0/mu

! first MAG-DIF for iterative loop
    MAG    = MAG_LIST_VMAX(ifilt_Vmax)
    MAGDIF = MAGLIM - MAG

    IF ( LVBOSE  ) THEN
       print*,' '
       print*,' ########## 1/Vmax DUMP ############# '

       print*,'    MAG   = ', MAG_LIST_VMAX(ifilt_Vmax),  & 
                 '      MAGLIM,MAGDIF=', sngl(MAGLIM), sngl(MAGDIF)
       print*,'    Trest = ', TREST_LIST_VMAX(ifilt_Vmax)
       print*,'    d,c,s = ', sngl(d_save), sngl(color), sngl(shape)

       CALL DMPVMAX(SNLC_CCID,CFILT,NITER,ZMAX,MAGDIF,MAG)
    ENDIF
! ----------------------------------------
    DO 300 WHILE ( abs(MAGDIF) > MAGDIF_CONVERGE )

! modify zmax and distance before re-computing model mag at zmax;
! for each iteration,
! (zmax/z)^2  = FLux(z)/FLUXLIM = 10**[0.4*(MAGLIM - mag(z))]
       zmax = zmax * 10.0**(0.2*(MAGDIF))
       d    = GET_DIST8(zmax,SHAPE,COLOR,ONE8) ! compute dist: x0 or mu

       LCVAL_STORE(IPAR_zPHOT) = SNGL(zmax)

       IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
          LCVAL_STORE(IPAR_DLMAG)  = SNGL(d_save * d/d0)
       ELSE
          LCVAL_STORE(IPAR_DLMAG)  = SNGL(d_save + (d0-d)) ! MU-dif -> UNTESTED!
       ENDIF

       CALL MODELMAG_CALC(IFILT_OBS, 'OBS', MJD,  & 
              FLUXCAL_TMP, FLUXCAL_ERR, MAG, MAG_ERR, KCOR)

       MAGDIF = MAGLIM - MAG
       NITER  = NITER + 1

       IF ( LVBOSE  ) THEN
          CALL DMPVMAX(SNLC_CCID,CFILT,NITER,ZMAX,MAGDIF,MAG)
!             print*,'          x0 = ' , LCVAL_STORE(IPAR_DLMAG)
       ENDIF

       if ( NITER > 20 ) THEN
          print*,' '
          print*,' xxx ------------------------- '
          print*,' xxx IFILT_OBS,VMAX = ', IFILT_OBS, IFILT_VMAX
          print*,' xxx MAG_atmax  = ', MAG_atmax
          print*,' xxx MJD, Tobs  = ', MJD, Tobs
          print*,' xxx PEAKMAG    = ', PEAKMAG_OBS_MODEL(IFILT_VMAX)
          print*,' xxx PEAKMJD    = ', PEAKMJD
          print*,' xxx NEPOCH     = ', NEP
          print*,' xxx zmax, mag = ', sngl(zmax), sngl(mag), NITER
          call flush(6)

          write(c1err,661) NITER
 661        format('Too many zmax iterations: NITER = ',I3 )
          c2err = 'for CID = ' // SNLC_CCID
          CALL MADABORT("VMAX_ANA", c1err, c2err )
       endif

 300  CONTINUE

! ------------------------------
! compute volume out to zmax

    OPTWGT    = 0  ! do NOT weight by redshift
    COSPAR(1) = H0_REF(1)
    COSPAR(2) = OMAT_REF(1)
    COSPAR(3) = OLAM_REF(1)
    COSPAR(4) = W0_REF(1)
    COSPAR(5) = 0.0        ! wa
    Vmax   = 4.0 * PI * DVDZ_INTEGRAL(OPTWGT, zmax, COSPAR )

! -----------
! store results in globals
    Z_LIST_VMAX(ifilt_Vmax)     = SNGL(zmax)
    VOL_LIST_VMAX(ifilt_Vmax)   = SNGL(Vmax)

! restore LCVAL_STORE values
    LCVAL_STORE(IPAR_zPHOT)  = SNGL(z_save)
    LCVAL_STORE(IPAR_DLMAG)  = SNGL(d_save)

    RETURN
  END SUBROUTINE VMAX_ANA


! ================================================
    SUBROUTINE FITMAGDIF_INI
! 
! Created Mar 2013
! Prepare fits for 1-filter only, all other filters,
! and all filters.


    USE SNDATCOM
    USE SNLCINP_NML
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE MAGDIFCOM

    IMPLICIT NONE

    LOGICAL    L0, L1
    INTEGER  & 
         iter, IFLAG, NFILT, NFILT_ALL  & 
        ,IFILTDEF, IFILT, NFIT_PER_SN

    CHARACTER  FILTLIST*(MXFILT_ALL), CTMP*28

! function
    INTEGER FILTINDX

! ------------------ BEGIN -----------

    IF ( FILTER_FITMAGDIF .EQ. '' ) RETURN

    global_banner = 'FITMAGDIF_INI: prepare 2 fit methods for mag-'  & 
                  // FILTER_FITMAGDIF

    CALL PRBANNER ( GLOBAL_BANNER(1:60) )

    NFIT_PER_SN = 3
    CALL SNLCPAK_NFIT_PER_SN(NFIT_PER_SN)   ! see sntools_output.c

! get filter index (absolute and sparse) for test filter.
    IFILTDEF  = FILTINDX(FILTER_FITMAGDIF)
    IFILT     = IFILTDEF_INVMAP_SURVEY(IFILTDEF)
    IFILTOBS_FITMAGDIF = IFILTDEF
    IFILT_FITMAGDIF    = IFILT

    IF ( IFILT < 0 ) THEN
      c1err = 'Invalid FILTER_FITMAGDIF = ' // FILTER_FITMAGDIF
      c2err = 'Must use valid SURVEY filter: ' //  & 
             SURVEY_FILTERS(1:NFILTDEF_SURVEY)
      CALL MADABORT('FITMAGDIF_INI', c1err, c2err)
    ENDIF

! --------
    NFIT_ITERATION_ALLFILT = NFIT_ITERATION
    NFIT_ITERATION  =  & 
          NFIT_ITERATION_ALLFILT    &  ! nominal, fix t0,c,shape
        + 2*NFIT_ITER_FITMAGDIF     &  ! special fits
        + 1                        ! nominal again

    NFILT_ALL = INDEX(FILTLIST_FIT,' ') - 1
    DO 100 iter = 1, NFIT_ITERATION

          IFLAG    = -9
          NFILT    = -9
          FILTLIST = '???'
          CTMP = ' '

      L0 =     ( iter .LE. NFIT_ITERATION_ALLFILT )  & 
           .or.  ( iter .EQ. NFIT_ITERATION )

      L1 = (iter .GT. NFIT_ITERATION_ALLFILT) .and.  & 
             (iter .LE. NFIT_ITERATION_ALLFILT + NFIT_ITER_FITMAGDIF)

      IF ( L0 ) then
         IFLAG    = IFLAG_FITMAGDIF_NOMINAL
         NFILT    = NFILT_ALL
         FILTLIST = FILTLIST_FIT
      ELSE IF ( L1 ) THEN
         IFLAG    = IFLAG_FITMAGDIF_1FILT
         NFILT    = 1
         FILTLIST = FILTER_FITMAGDIF
      ELSE
         IFLAG    = IFLAG_FITMAGDIF_XFILT
         NFILT    = NFILT_ALL
         FILTLIST = FILTLIST_FIT
         CTMP = '(' // FILTER_FITMAGDIF(1:1)//'-band deweighted)'
      ENDIF


      write(6,20) iter, NFILT, FILTLIST(1:NFILT), ctmp
 20     format(T10,'ITER=',I2,' -> NFILT = ', I2, 2x, A, 3x, A)
      CALL FLUSH(6)

       IFLAG_FITMAGDIF(iter) = IFLAG
       NFILT_FITMAGDIF(iter) = NFILT
       FILTLIST_FITMAGDIF(iter) = FILTLIST
 100  CONTINUE

    RETURN
  END SUBROUTINE FITMAGDIF_INI

! =====================================
    SUBROUTINE FITMAGDIF_PREP(ITER)

! March, 2013
! Called before fit-iteration ITER to prepare fit-iteration ITER
! for fitting either FILTER_FITMAGDIF or all filters except this one.
! 
! -----------------------


    USE SNDATCOM
    USE SNLCINP_NML
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE MAGDIFCOM

    IMPLICIT NONE

! subroutine args

    INTEGER ITER ! (I) SN index and fit iteration

! local var

    LOGICAL LMATCH, USE
    INTEGER ipar, ifiltdef, iflag, LL
    CHARACTER CFILTDEF*2

! -------------- BEGIN -----------

! check global flag
    IF ( FILTER_FITMAGDIF .EQ. '' ) RETURN

! bail on the nominal ALLFILT interations
    IF ( ITER .LE. NFIT_ITERATION_ALLFILT ) RETURN

! =============================================
! store ALLFILT results just before doing first 2-band fit

    IF ( ITER .EQ. NFIT_ITERATION_ALLFILT + 1 ) THEN

! store original USE_FILT(IFILT) and FITPAR to keep track of which
! filters can be used.
       ALLFILTLIST_FIT   = FILTLIST_FIT_USE
       NOBS_ALLFILT      = NFILT_OBS_USEFIT
       DO IFILTDEF = 1, MXFILT_ALL
         USE_ALLFILT(IFILTDEF) = USE_FILT(IFILTDEF)
       ENDDO

       DO ipar = 1, MXFITPAR
          FITVAL_ALLFILT(ipar) = SNGL( FITVAL(ipar,ITER-1) )
          FITERR_ALLFILT(ipar) = SNGL( FITERR(ipar,ITER-1) )
       ENDDO

!  init final results to dummy values.

       FITMAG_1FILT    = 99.
       FITMAG_XFILT    = 99.
       FITMAGERR_1FILT = 99.
       FITMAGERR_XFILT = 99.
       FITMAGDIF       = 99.
       FITERRDIF       = -9.0
       FITPROB_1FILT   = -9.0
       FITPROB_XFILT   = -9.0
    ENDIF


! make sure that test filter is on the list; otherwise bail out.

    IF ( .not. USE_ALLFILT(IFILTOBS_FITMAGDIF)  ) RETURN

! reset global list of filters to fit.
    FILTLIST_FIT_USE = ''
    NFILT_OBS_USEFIT = 0

! always restore INIVAL and INISTP

    DO ipar = 1, MXFITPAR
       INIVAL(ipar)  = FITVAL_ALLFILT(ipar)
       INISTP(ipar)  = FITERR_ALLFILT(ipar)
    ENDDO

! always restore FUDGE_FITERR params.

    FUDGE_FITERR_PASSBANDS = 'NULL'
    FUDGE_FITERR_MAXFRAC   = 0.0

! -----------------
! if done with all test fits, do nominal fit again so that
! analysis variables correspond to nominal fit.

    IF ( ITER .EQ. NFIT_ITERATION ) THEN

       FILTLIST_FIT_USE = ALLFILTLIST_FIT(1:64)
       NFILT_OBS_USEFIT = NOBS_ALLFILT

       DO IFILTDEF = 1, MXFILT_ALL
         USE_FILT(IFILTDEF) = USE_ALLFILT(IFILTDEF)
       ENDDO

       CALL INIT_FUDGE_FITERR
       RETURN   ! bail out on last ALLFIT iteration
    ENDIF

    IFLAG = IFLAG_FITMAGDIF(iter)
    NFILT_OBS_USEFIT = 0


! fix all params except for the overall scale/distance parameter
    INISTP(IPAR_SHAPE)     = 0.0    ! fix stretch/lumipar parameter
    INISTP(IPAR_PEAKMJD)   = 0.0    ! fix time of peak

    IF ( IFLAG .EQ. IFLAG_FITMAGDIF_1FILT ) THEN
       INISTP(IPAR_COLOR)     = 0.0    ! fix color param
    ELSE
       INISTP(IPAR_COLOR)     = 0.2
    ENDIF

! use FUDGE_FITER_XXX parameters to de-wieght test filter
! to effectively exclude it.
    IF ( IFLAG .EQ. IFLAG_FITMAGDIF_XFILT ) THEN
       FUDGE_FITERR_PASSBANDS   = FILTER_FITMAGDIF
       FUDGE_FITERR_MAXFRAC     =  999.0
       FUDGE_FITERR_TREST(1)    =  -30.0
       FUDGE_FITERR_TREST(2)    = +200.0
       FUDGE_FITERR_RESTLAM(1)  =  200.0
       FUDGE_FITERR_RESTLAM(2)  = 30000.
    ENDIF


    DO 200 IFILTDEF = 1, MXFILT_ALL
      USE_FILT(IFILTDEF) = .FALSE.
      USE   = .FALSE.
      CFILTDEF = FILTDEF_STRING(IFILTDEF:IFILTDEF)

      LMATCH = IFILTDEF .EQ. IFILTOBS_FITMAGDIF

      IF ( IFLAG .EQ. IFLAG_FITMAGDIF_1FILT ) THEN
        IF ( LMATCH )  USE = .TRUE.
      ELSE
        USE = .TRUE.
      ENDIF

      IF ( USE .and. USE_ALLFILT(IFILTDEF) ) THEN
        NFILT_OBS_USEFIT   = NFILT_OBS_USEFIT + 1
        USE_FILT(IFILTDEF) = .TRUE.

        LL = NFILT_OBS_USEFIT - 1
        FILTLIST_FIT_USE = FILTLIST_FIT_USE(1:LL) //  & 
                CFILTDEF(1:1)
      ENDIF

 200  CONTINUE

    write(6,40) SNLC_CCID(1:ISNLC_LENCCID),  & 
           ITER, FILTLIST_FIT_USE(1:NFILT_OBS_USEFIT)
 40   format(T5,'FITMAGDIF_PREP(CID=',A,' ITER=',I2,') -> fit  ', A)
    call flush(6)

    CALL INIT_FUDGE_FITERR

    RETURN
  END SUBROUTINE FITMAGDIF_PREP


! =====================================
    SUBROUTINE FITMAGDIF_CALC(ITER)

! Computations for stored quantities.
! May 8 2013: compute and store FITPROB_1FILT & FITPROB_XFILT
! Feb 20 2017: load PEAKMAG_OBS_MODEL array using sparse IFILT
! 

    USE SNDATCOM
    USE SNLCINP_NML
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE MAGDIFCOM

    IMPLICIT NONE

! subroutine args

    INTEGER ITER ! (I) SN index and fit iteration

! local var

    LOGICAL DO_MAGDIF, DO_LCPLOT
    INTEGER IFLAG, IFILTOBS, LCID, NFUNPLOT, NDOF, IFILT
    REAL    ERR1, ERR2
    REAL*8  CHI8, PROB8

    CHARACTER CCID*40

! function
    REAL*8  PROB_CHI2NDOF
    LOGICAL DOPLOT_SNLC

! ------------ BEGIN -------------

! check global flag
    IF ( FILTER_FITMAGDIF .EQ. '' ) RETURN

! bail on the nominal ALLFILT interations
    IF ( ITER .LE. NFIT_ITERATION_ALLFILT ) RETURN
    IF ( ITER .EQ. NFIT_ITERATION         ) RETURN

! bail if test filter is not part of fit.
    IF ( .not. USE_ALLFILT(IFILTOBS_FITMAGDIF)  ) RETURN

! strip off useful info
    IFLAG    = IFLAG_FITMAGDIF(ITER)
    IFILTOBS = IFILTOBS_FITMAGDIF
    IFILT    = IFILTDEF_INVMAP_SURVEY(IFILTOBS) ! sparse index

! store peakMag

    CALL PEAKMAG_CALC(IFILTOBS, 'OBS')

! compute fit prob for each iteration (May 2013)
    NDOF     = NEPOCH_FIT(0) - NFITPAR(0)
    CHI8     = DBLE( FCN_FITCHI2(0) )
    PROB8    = PROB_CHI2NDOF(CHI8, NDOF)

    IF ( IFLAG .EQ. IFLAG_FITMAGDIF_1FILT ) THEN
! fit only this 1 filter.
       FITMAG_1FILT    = PEAKMAG_OBS_MODEL(IFILT)
       FITMAGERR_1FILT = PEAKMAG_OBS_MODEL_ERR(IFILT)
       FITPROB_1FILT   = SNGL(PROB8)
    ELSE IF ( IFLAG .EQ. IFLAG_FITMAGDIF_XFILT ) THEN
!  with filter Xcluded.
       FITMAG_XFILT    = PEAKMAG_OBS_MODEL(IFILT)
       FITMAGERR_XFILT = PEAKMAG_OBS_MODEL_ERR(IFILT)
       FITPROB_XFILT   = SNGL(PROB8)
    ENDIF

! ----
    DO_LCPLOT = ( ITER < NFIT_ITERATION  ) .and.  & 
                  ( DOPLOT_SNLC() )

    IF ( DO_LCPLOT ) THEN
       IF ( IFLAG .EQ. IFLAG_FITMAGDIF_1FILT ) THEN
          NFUNPLOT = 3
          CALL SNLCPAK_NFIT(NFUNPLOT)  ! store NFIT
       ENDIF

       LCID = ISNLC_LENCCID
       CCID = SNLC_CCID(1:LCID) // char(0)
       CALL MAKEDIR_OUTPUT(CCID,SNLC_CID,LCID)
       CALL FITANA_STORE()
       CALL SNLCPLOT()
       CALL CDTOPDIR_OUTPUT(STDOUT_UPDATE)  ! back to topdir
    ENDIF

! after both fits, compute mag difference & error.

    DO_MAGDIF = ITER .EQ. NFIT_ITERATION-1

    IF ( DO_MAGDIF ) THEN

       FITMAGDIF = FITMAG_XFILT - FITMAG_1FILT ! predicted - measured

       ERR1 = FITMAGERR_1FILT
       ERR2 = FITMAGERR_XFILT
       FITERRDIF = sqrt(ERR1**2 + ERR2**2)

! print one-line summary.

       write(6,50) SNLC_CCID(1:ISNLC_LENCCID),  & 
                FILTER_FITMAGDIF(1:1), FITMAGDIF, FITERRDIF
 50      format(T5,'FITMAGDIF(CCID=',A,') : ', A,'(pred-meas) = ',  & 
               F6.3, ' +- ', F6.3,' mag ')

    ENDIF

    RETURN
  END SUBROUTINE FITMAGDIF_CALC

! ========================================
    SUBROUTINE GET_FITMAGDIF(MAGDIF, MAGERR, FITPROB )

! Created Mar 2013.
! Return final results via subroutine args.
! May 8 2013: add FITPROB(2) to output
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE MAGDIFCOM

    IMPLICIT NONE

    REAL MAGDIF, MAGERR  ! (O)
    REAL FITPROB(2)      ! (O) fit prob for 1 filter, other filters

! ---------- BEGIN ---------

    MAGDIF = 77.   ! different than initialized value of 99
    MAGERR = -7.0
    FITPROB(1) = -9.0
    FITPROB(2) = -9.0

    IF ( FILTER_FITMAGDIF .NE. '' ) THEN
       MAGDIF = FITMAGDIF
       MAGERR = FITERRDIF

       FITPROB(1) = FITPROB_1FILT
       FITPROB(2) = FITPROB_XFILT
    ENDIF

    RETURN
  END SUBROUTINE GET_FITMAGDIF


! ================================================
    SUBROUTINE SIMFIT_IDEAL_INI()

! Created Aug 29 2017
! 
! One-time init for IDEAL FIT with FLUX=TRUEFLUX (sims only)
! Do nothing except print message.
! 

    USE SNDATCOM
    USE SNFITCOM
    USE FITIDEALCOM
    USE SNLCINP_NML

    IMPLICIT NONE


! ---------- BEGIN --------------

    DOFIT_IDEAL_EVENT = .FALSE.
    NFIT_ITERATION_ORIG  = NFIT_ITERATION
    NFIT_ITERATION_IDEAL = MIN(NFIT_ITERATION,2) ! no more than 2 iter for IDEAL fit

    IF ( .NOT. LSIM_SNANA ) SIMFIT_IDEAL_PRESCALE = 0
    IF ( SIMFIT_IDEAL_PRESCALE == 0 ) RETURN

    global_banner =  & 
          'SIMFIT_IDEAL_INI: include IDEAL fit using TRUEFLUX'
    CALL PRBANNER ( GLOBAL_BANNER(1:60) )
    print*,'   SIMFIT IDEAL PRESCALE = ', SIMFIT_IDEAL_PRESCALE

    RETURN
  END SUBROUTINE SIMFIT_IDEAL_INI

! ===============================================
    SUBROUTINE SIMFIT_IDEAL_PREP(ITER)

! Created Aug 29 2017
! Called for each event before fit; prepare to add IDEAL fit.
! 
! ITER=0 --> before fitting begings
! ITER>0 --> before fit iteration ITER
! 
! 

    USE SNDATCOM
    USE SNFITCOM
    USE SNLCINP_NML
    USE FITIDEALCOM
    USE SNANAFIT

    IMPLICIT NONE

    INTEGER ITER ! (I) fit iteration

! local var
    REAL*8  PS
    LOGICAL REJECT_PRESCALE  ! function

! ----------------- BEGIN ---------------

    IF ( SIMFIT_IDEAL_PRESCALE == 0 ) RETURN

! check pre-scale on ITER=0 (before fitting begins)

    IF ( ITER .EQ. 0 ) THEN

! check debug flag to NOT change fluxes, but still run the
! fit twice to see if we get the same results.
      IF ( SIMFIT_IDEAL_PRESCALE .EQ. SIMFIT_IDEAL_DEBUG ) THEN
         DOFIT_IDEAL_EVENT = .TRUE.
         NFIT_ITERATION = NFIT_ITERATION_ORIG + NFIT_ITERATION_IDEAL
         RETURN
      ENDIF

      PS = DBLE(SIMFIT_IDEAL_PRESCALE)
      IF ( REJECT_PRESCALE(NCALL_SNANA_DRIVER,PS) ) THEN
         DOFIT_IDEAL_EVENT = .FALSE.
         NFIT_ITERATION = NFIT_ITERATION_ORIG
      ELSE
         DOFIT_IDEAL_EVENT = .TRUE.
         NFIT_ITERATION = NFIT_ITERATION_ORIG + NFIT_ITERATION_IDEAL
         CALL SET_IDEAL_FLUXCAL(+1)  ! set FLUXCAL = TRUEFLUX
      ENDIF

      RETURN
    ENDIF   ! end ITER == 0

! - - - - - - -

    DOFIT_IDEAL = (ITER <= NFIT_ITERATION_IDEAL) ! Dec 2023

! check to restore nominal FLUXCAL for normal fit with Poisson fluctuations
    IF ( ITER .EQ. NFIT_ITERATION_IDEAL+1 ) THEN
      IF ( SIMFIT_IDEAL_PRESCALE .NE. SIMFIT_IDEAL_DEBUG ) THEN
        CALL SET_IDEAL_FLUXCAL(-1)  ! restore SNLC_FLUXCAL
      ENDIF
      CALL LOAD_EPALL(ITER, FITVAL(IPAR_PEAKMJD,ITER) )
    ENDIF

!       print*,' xxx IDEAL_PREP for NCAL=', NCALL_SNANA_DRIVER

    RETURN
  END SUBROUTINE SIMFIT_IDEAL_PREP

! =======================================
    SUBROUTINE SET_IDEAL_FLUXCAL(OPT)

! Created Aug 30 2017
! OPT > 0 --> set SNLC_FLUXCAL = TRUEFLUX
! OPT < 0 --> restore original FLUXCAL
! 
! Jan 28 2018:  set USESIM_PEAKMJD = T/F
! 

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FITIDEALCOM

    IMPLICIT NONE

    INTEGER OPT   ! (I)

    INTEGER IMJD, EPMIN, EPMAX, EP, IFILT_OBS
    REAL FSCALE

! -------------- BEGIN -------------

    IF ( OPT > 0 ) THEN

!   FLUXCAL -> TRUEFLUX
      DO 101 IMJD  = 1, ISNLC_NEWMJD_STORE
        EPMIN = ISNLC_EPOCH_RANGE_NEWMJD(1,IMJD)
        EPMAX = ISNLC_EPOCH_RANGE_NEWMJD(2,IMJD)
      DO 102 ep = EPMIN, EPMAX

         SAVE_FLUXCAL(ep) = SNLC_FLUXCAL(ep)

! re-apply mag-system offset
         IFILT_OBS  = ISNLC_IFILT_OBS(ep)
         Fscale     = FLUXSCALE_ZP_FILT(ifilt_obs)
         SNLC_FLUXCAL(ep) = SIM_EPFLUXCAL(ep) * FSCALE ! true flux

102     CONTINUE
101     CONTINUE

! save measured MWEBV, then MWEBV-> TRUE MWEBV
      SAVE_MWEBV     = SNLC_MWEBV
      SAVE_MWEBV_ERR = SNLC_MWEBV_ERR
      SNLC_MWEBV     = SIM_MWEBV
      SNLC_MWEBV_ERR = 0.0
      CALL MWEBV_FLUXCOR()

      USESIM_PEAKMJD              = .TRUE.  ! Jan 28 2018
      USESIM_FITPAR(IPAR_PEAKMJD) = .TRUE.

    ELSE
!        restore original MWEBV & FLUXCAL

        DO 201 IMJD      = 1, ISNLC_NEWMJD_STORE
          EPMIN = ISNLC_EPOCH_RANGE_NEWMJD(1,IMJD)
          EPMAX = ISNLC_EPOCH_RANGE_NEWMJD(2,IMJD)
        DO 202 ep = EPMIN, EPMAX
           SNLC_FLUXCAL(ep) = SAVE_FLUXCAL(ep)
202       CONTINUE
201       CONTINUE

        SNLC_MWEBV      = SAVE_MWEBV
        SNLC_MWEBV_ERR  = SAVE_MWEBV_ERR
        CALL MWEBV_FLUXCOR()

        USESIM_PEAKMJD              = .FALSE.  ! Jan 28 2018
        USESIM_FITPAR(IPAR_PEAKMJD) = .FALSE.
    ENDIF

    RETURN
  END SUBROUTINE SET_IDEAL_FLUXCAL

! ================================================
    SUBROUTINE SIMFIT_IDEAL_CALC(ITER)

! Created Aug 29 2017
! Process IDEAL fit after each fit ITER.
! Jan 28 2018: compute mB from x0
! 

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FITIDEALCOM

    IMPLICIT NONE

    INTEGER ITER ! (I) fit iteration that just completed

! local var

    INTEGER IPAR
    REAL*8  x0, mB, SALT2MBCALC

! -------------- BEGIN ---------------

    IF ( SIMFIT_IDEAL_PRESCALE == 0 ) RETURN

    IF ( ITER .EQ. 1) THEN
      DO ipar = 1, NFITPAR_MN
         FITPAR_IDEAL(ipar) = 999.
      ENDDO
    ENDIF

! check when to store results of IDEAL fit
    IF ( DOFIT_IDEAL_EVENT .and. ITER .EQ. NFIT_ITERATION_IDEAL) THEN
      DO ipar = 1, NFITPAR_MN
         FITPAR_IDEAL(ipar) = SNGL( FITVAL(IPAR,ITER) )
      ENDDO

! compute mB from x0 (Jan 28 2018)
      x0 = DBLE ( FITPAR_IDEAL(IPAR_x0) )
      mB = SALT2MBCALC(x0)
      FITPAR_IDEAL(IPAR_MB) = SNGL(mB)
    ENDIF

    RETURN
  END SUBROUTINE SIMFIT_IDEAL_CALC

! ================================================
    SUBROUTINE FITRESTMAG_INI

! Created Feb 10, 2012
! 
! One-time init.
! if FITLTER_RESTMAG is set, then add this filter
! to suryey-filter list and re-init kcor file to
! include this filter. Called only once.
! 
! --------


    USE SNDATCOM
    USE SNLCINP_NML
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE

    INTEGER  NFILT, NTMP, IERR, IFILT, IFILTDEF, i, ITER, NPLOT_PER_SN
    CHARACTER CFILT*2

! function
    INTEGER FILTINDX

! ----------------- BEGIN -----------

    IFILTOBS_BRACKET(1) = -999  ! flag that it's NOT a 2-band fit
    IFILTOBS_BRACKET(2) = -999

    NFILTDEF_FITRESTMAG = 0
    IF ( FILTLIST_FITRESTMAG .EQ. '' ) RETURN

    NFILTDEF_FITRESTMAG = INDEX(FILTLIST_FITRESTMAG,' ') - 1
    NFILT = NFILTDEF_FITRESTMAG

    global_banner = 'FITRESTMAG_INI: prepare rest-mag for  '  & 
                  // FILTLIST_FITRESTMAG(1:NFILT)

    CALL PRBANNER ( GLOBAL_BANNER(1:60) )

! -------------
! init number of LC plots per SN to prepare SNLCPAK utility
    NPLOT_PER_SN = NFILTDEF_FITRESTMAG + 1    ! each filter, and total
    CALL SNLCPAK_NFIT_PER_SN(NPLOT_PER_SN)   ! see sntools_output.c

! ------------

    NFILTDEF_SURVEY_ORIG    = NFILTDEF_SURVEY

    DO 100 i = 1, NFILT
       CFILT                  = FILTLIST_FITRESTMAG(i:i)
       IFILTDEF_FITRESTMAG(i) = FILTINDX(CFILT)
       IFILTDEF               = IFILTDEF_FITRESTMAG(i)

! add FILTLIST_FITRESTMAG to list of SURVEY_FILTERS

! skip this filter if it is already defined as a survey filter.
       IFILT     = IFILTDEF_INVMAP_SURVEY(IFILTDEF)
       IF ( IFILT .GT. 0 ) THEN
         write(6,20) CFILT
20         format(T8,A1,'-filter already defined -> skip')
         GOTO 100
       ELSE
         write(6,21) CFILT, IFILTDEF
21         format(T8,'Add ',A1,'-filter to SURVEY_FILTERS list',2x,  & 
                '(IFILTDEF=',I2,')'  )
       ENDIF
       CALL FLUSH(6)

      NTMP            = NFILTDEF_SURVEY
      SURVEY_FILTERS  = SURVEY_FILTERS(1:NTMP) // CFILT(1:1)
      NFILTDEF_SURVEY = NFILTDEF_SURVEY + 1

      IFILTDEF_INVMAP_SURVEY(IFILTDEF)     = NFILTDEF_SURVEY
      IFILTDEF_MAP_SURVEY(NFILTDEF_SURVEY) = IFILTDEF

100   CONTINUE


! -------- adjust NFIT_ITERATION ----------------

! add NFIT_ITERATION for each new filter
    NFIT_ITERATION_ALLFILT = NFIT_ITERATION
    NFIT_ITERATION      =  & 
             NFIT_ITERATION_ALLFILT         &  ! nominal fit, all bands
           + NFIT_ITER_FITRESTMAG*NFILT     &  ! 2-band fits
           + 1                              &  ! nominal again
           + 1                             ! nominal again (Dec 11 2014)


    IF ( NFIT_ITERATION .GT. MXITER ) THEN
      write(c1err,661) NFIT_ITERATION
661     format('NFIT_ITERATION = ', I2,' exceeds bound.')
      write(c2err,662) MXITER
662     format('MXITER = ', I2)
      CALL MADABORT("FITRESTMAG_INI", c1err, c2err )
    ENDIF

    write(6,40) NFIT_ITERATION_ALLFILT, NFIT_ITERATION
40    format(T8,'NFIT_ITERATION = ',I2, ' -> ', I2 )

! load IFILTDEF_ITER_FITRESTMAG array to store which filter
! to process for each fit-iteration

    ITER     = NFIT_ITERATION_ALLFILT
    DO ifilt = 1, NFILT
    DO i     = 1, NFIT_ITER_FITRESTMAG
       CFILT     = FILTLIST_FITRESTMAG(ifilt:ifilt)
       IFILTDEF  = IFILTDEF_FITRESTMAG(ifilt)
       ITER      = ITER + 1
       IFILTDEF_ITER_FITRESTMAG(ITER) = IFILTDEF
       IFILTSP_ITER_FITRESTMAG(ITER)  = IFILT
       write(6,42) ITER, CFILT
42       format(T12,'Fit-iteration ', I2,' -> ', A )

       ITERLAST_FITRESTMAG(ifilt) = ITER
    ENDDO
    ENDDO

! avoid annoying aborts
    ABORT_ON_NOEPOCHS = .FALSE.  ! Mar 20, 2012

! -------------------------
! print misc info

! check for legacy variable
    if ( LUMIFIX_FITRESTMAG < 998.0 ) THEN
      SHAPEFIX_FITRESTMAG = LUMIFIX_FITRESTMAG
    endif
    if ( SHAPEFIX_FITRESTMAG .LT. 900.0 ) then
       write(6,51) 'SHAPEFIX',  SHAPEFIX_FITRESTMAG
    endif
    if ( COLORFIX_FITRESTMAG .LT. 900.0 ) then
       write(6,51) 'COLORFIX', COLORFIX_FITRESTMAG
    endif

51       format(T8,'Evaluate RestMags for ',A,' = ' , F9.3)

    write(6,54) LAMEXTRAP_FITRESTMAG
 54   format(T8,'Allow rest-wavelength extrapolation of +- ',  & 
                F5.0,' A ')

    write(6,55) DLAMTOL_FITRESTMAG
 55   format(T8,'Include obs bands within ', F5.0,  & 
                ' A of closest bands.')

    write(6,58)       NFILTDEF_SURVEY_ORIG, NFILTDEF_SURVEY
 58   format(T8,'NFILTDEF_SURVEY = ',I3,' -> ', I3)

! -------------------------------------------------
! re-read KCOR file to include FILTLIST_FITRESTMAG
! (user must make sure that FILTLIST_FITRESTMAG is in the kcor file)

    CALL READ_CALIB_WRAPPER(IERR)

    CALL CDTOPDIR_OUTPUT(STDOUT_UPDATE)  ! back to topdir

! check that added filter(s) are all in the KCOR file.
! Abort if any filter is missing.

    DO 200 i = 1, NFILT
       CFILT          = FILTLIST_FITRESTMAG(i:i)
       IFILTDEF       = IFILTDEF_FITRESTMAG(i)
       IF ( .NOT. LFILTDEF_OBS(ifiltdef)  ) THEN
         c1err = 'FILTLIST_FITRESTMAG = ' // cfilt //  & 
                  ' is not in kcor file.'
         c2err = 'Check ' // CALIB_FILE(1:80)
         CALL MADABORT("FITRESTMAG_INI", c1err, c2err )
       ENDIF
200   CONTINUE

! set flag so that SURVEY_FILTERS are NOT re-read
! if another version header is read.
    FREEZE_SURVEY_FILTERS = .TRUE.

    RETURN
  END SUBROUTINE FITRESTMAG_INI

! =====================================
    SUBROUTINE FITRESTMAG_PREP(ITER)

! Feb 12, 2012
! Called before fit-iteration ITER to prepare fit-iteration ITER
! for fitting FILTLIST_FITRESTMAG. Do nothing for first 1/2 of iterations
! to get t0 and stretch. For 2nd half of iterations keep only
! the two observer bands that bracket FILTLIST_FITRESTMAG.
! 
! 
! Apr 24 2014:
!  Re-do SNRMAX logic; apply cut to mask filters before calling
!  BRACKET_IFILT_OBS() function, rather than applying SNRMAX cut
!  to the filters found by BRACKET_IFILT_OBS.  New logic is more
!  efficient. Should fix problem at z ~ 0.4 in which g&r are
!  BRACKET filters but then g fails SNRMAX cut; now it will find
!  r&i instead.
! 
! Dec 3 2014: for photo-z fit, set Z=ZPHOT instead of SNLC_REDSHIFT.
! 
! Mar 26 2020
!  Refactor to use new BRACKET_FILTERLIST with DLAM_TOL so that
!  more than 2 bands can be included if some bands have very
!  similar central wavelengths.
! 
! -----------------------


    USE SNDATCOM
    USE SNLCINP_NML
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE

! subroutine args

    INTEGER ITER ! (I) SN index and fit iteration

! local var

    INTEGER  & 
         i, IFILT, IFILTDEF, IFILT_TMP, IF1, IF2  & 
        ,J, JKEEP, LL, NBRA, NTRY, itry, ITERLAST, IPAR  & 
        ,IFILTDEF_MAP_SAVE(MXFILT_OBS)

    REAL LAMAVG, LAMREST(3), LAMTMP, Z, DLAM_TOL, SNRMAX
    CHARACTER CFILTOBS_LIST*(MXFILT_OBS), CTMP*4, CFILTDEF*2

    LOGICAL L_BRACKET, L_MATCH, L_USE, L_KEEP
    LOGICAL SKIPTEST, LSNR

! function
    INTEGER BRACKET_FILTERLIST

! -------------------- BEGIN ----------------

    IF ( ITER .EQ. 1 ) NLCPLOT_FITRESTMAG = 0  ! reset plot-counter

! default flag is NOT 2-band fit;
! setting IFILTOBS_BRACKET below --> 2-band fit
    IFILTOBS_BRACKET(1) = -999
    IFILTOBS_BRACKET(2) = -999

! check global flag
    IF ( NFILTDEF_FITRESTMAG .LE. 0 ) RETURN

! bail on the nominal ALLFILT interations
    IF ( ITER .LE. NFIT_ITERATION_ALLFILT ) RETURN

! =============================================
! store ALLFILT results just before doing first 2-band fit

    IF ( ITER .EQ. NFIT_ITERATION_ALLFILT + 1 ) THEN

       DO i = 1, NFILTDEF_FITRESTMAG
          FITRESTMAG(i)     = 999.
          FITRESTMAG_ERR(i) = 999.
       ENDDO

! store original USE_FILT(IFILT) and FITPAR to keep track of which
! filters can be used.
       ALLFILTLIST_FIT   = FILTLIST_FIT_USE
       NOBS_ALLFILT      = NFILT_OBS_USEFIT
       DO IFILT = 1, MXFILT_ALL
         USE_ALLFILT(IFILT) = USE_FILT(IFILT)
       ENDDO

       DO ipar = 1, MXFITPAR
           FITVAL_ALLFILT(ipar) = SNGL( FITVAL(ipar,ITER-1) )
           FITERR_ALLFILT(ipar) = SNGL( FITERR(ipar,ITER-1) )
       ENDDO

    ENDIF

! -------------------------------------------
! reset global list of filters to fit.
    FILTLIST_FIT_USE = ''
    NFILT_OBS_USEFIT = 0

! always restore INIVAL and INISTP
! Note that 1st IPAR_ITER param is not restored.

    DO ipar = 1, MXFITPAR
       IF ( ipar .NE. IPAR_ITER ) then
         INIVAL(ipar)  = FITVAL_ALLFILT(ipar)
         INISTP(ipar)  = FITERR_ALLFILT(ipar)
       ENDIF
    ENDDO

! -----------------------------------------------------------
! if done with all 2-band fits, do nominal fit again so that
! analysis variables correspond to nominal fit rather than
! to the last 2-band fit.

    ITERLAST = ITERLAST_FITRESTMAG(NFILTDEF_FITRESTMAG)
    IF ( ITER .GT. ITERLAST ) THEN

       FILTLIST_FIT_USE = ALLFILTLIST_FIT(1:64)
       NFILT_OBS_USEFIT = NOBS_ALLFILT

       DO IFILT = 1, MXFILT_ALL
         USE_FILT(IFILT) = USE_ALLFILT(IFILT)
       ENDDO

       RETURN   ! bail out on last ALLFIT iteration
    ENDIF

! set tolerance for including bands close in wavelength
    DLAM_TOL = DLAMTOL_FITRESTMAG

! =========================================

! strip off filter to process for this fit-iteration
    IFILTDEF = IFILTDEF_ITER_FITRESTMAG(ITER)
    CFILTDEF = FILTDEF_STRING(IFILTDEF:IFILTDEF)
    if ( IFILTDEF .LE. 0 .OR. IFILTDEF .GT. MXFILT_ALL ) then
       write(C1ERR,161) ITER,IFILTDEF
161      format('Invalid IFILTDEF_ITER_FITRESTMAG(ITER=',I2,') = ', I4)
       C2ERR = 'Check FILTLIST_FITRESTMAG in &FITINP'
       CALL MADABORT('FITRESTMAG_PREP', C1ERR, C2ERR)
    endif


! for remainder of the iterations (i.e., 2-band fits)
!  - float only color and distance/x0 (i.e,, fix PKMJD and LUMIPAR)
!  - keep only observer bands that bracket FILTLIST_FITRESTMAG
!  - fix redshift (for photo-z fits)

    INISTP(IPAR_SHAPE)     = 0.0  ! fix stretch/lumipar parameter
    INISTP(IPAR_PEAKMJD)   = 0.0  ! fix time of peak

    IF ( DOFIT_PHOTOZ ) THEN
       ipar = IPAR_zPHOT
       INISTP(ipar) = 0.0
       Z    =  FITVAL_ALLFILT(ipar)
    ELSE
       Z  = SNLC_REDSHIFT
    ENDIF

! set list of LAMREST to try.
    LAMAVG        = FILTOBS_LAMAVG(ifiltdef)
    LAMREST(1)    = LAMAVG
    LAMREST(2)    = LAMAVG + LAMEXTRAP_FITRESTMAG
    LAMREST(3)    = LAMAVG - LAMEXTRAP_FITRESTMAG
    IF ( LAMEXTRAP_FITRESTMAG .GT. 0.1 ) THEN
       NTRY = 3
    ELSE
       NTRY = 1
    ENDIF

! ---------------------------------------------------
! Find obs-filters that bracket FILTLIST_FITRESTMAG
! Before searching for two nearest bands,  EXCLUDE filter if
!   * it's a FITRESTMAG filter (so it does not find itself)
!   * it fails SNRMAX cut  e.g., if g&r are the closest two bands
!     but g fails SNRMAX cut, the BRACKET function will return
!     ri instead.
! 
! Note that loop is over ALL filters, not just FITRESTMAG filters.
! 

    DO ifilt = 1, NFILTDEF_SURVEY

       IFILTDEF_MAP_SAVE(ifilt) = IFILTDEF_MAP_SURVEY(ifilt)
       IFILTDEF                 = IFILTDEF_MAP_SURVEY(ifilt)  !absolute indx
       if ( ifilt .GT. NFILTDEF_SURVEY_ORIG ) then
          IFILTDEF_MAP_SURVEY(ifilt) = -999
       endif

       ! apply SNRMAX cut only if SNRMAX is defined
       SNRMAX   = SNLC_SNRMAX_FILT(ifilt)
       SKIPTEST = .not. LFILTDEF_SNRMAX(IFILTDEF)
       LSNR     = SKIPTEST .or. (SNRMAX .GE. CUTWIN_SNRMAX2(1) )

       if ( .NOT. LSNR ) then
          IFILTDEF_MAP_SURVEY(ifilt) = -999
       endif
    ENDDO  ! end ifilt loop over all filters

! -----------------------

    L_BRACKET = .FALSE.
    DO 440 itry = 1, NTRY

! Sep 2013: beware that BRACKET_IFILT_OBS() checks all filters
! selected by snana, not just the ones in FILTLIST_FIT.
! Use EPCUT_SNRMIN to reject extra filters.

       LAMTMP = LAMREST(itry)

! new default, Mar 28 2020
        NBRA = BRACKET_FILTERLIST(LAMTMP, DLAM_TOL, Z,  & 
                  IFILTOBS_BRACKET) ! <== returned

       IF1 = IFILTOBS_BRACKET(1)  ! closest band, low wavelen
       IF2 = IFILTOBS_BRACKET(2)  ! closest band, high wavelen

       IF ( IF1 .LE. 0 ) GOTO 440
       IF ( IF2 .LE. 0 ) GOTO 440

! check if IFILTOBS_BRACKET(1:2) are valid
       L_USE = USE_ALLFILT(IF1) .and. USE_ALLFILT(IF2)
       L_BRACKET = (NBRA >= 2) .and. L_USE

       if ( L_BRACKET ) goto 444
440   CONTINUE  ! end itry

! --------------------
444   CONTINUE

! ------------------
! reset filter map

    DO ifilt = 1, NFILTDEF_SURVEY
       IFILTDEF_MAP_SURVEY(ifilt) = IFILTDEF_MAP_SAVE(ifilt)
    ENDDO

    IF ( .NOT. L_BRACKET ) GOTO 455


! print message for which filter to fit, or to skip.
455   CONTINUE

    IF ( L_BRACKET ) THEN
       do i = 1, NBRA
          IFILTDEF = IFILTOBS_BRACKET(i)
          CFILTOBS_LIST(i:i) =  FILTDEF_STRING(IFILTDEF:IFILTDEF)
       enddo
       CTMP     = 'Fit '
    ELSE
       CTMP     = 'Skip'
       CFILTOBS_LIST =  '??'
    ENDIF

    LL = ISNLC_LENCCID
    write(6,20) CTMP, CFILTDEF,  & 
           SNLC_CCID(1:LL), CFILTOBS_LIST(1:NBRA)
20    format(T5, A,' RestMag-',A,'  for  CID = ',A,  & 
                     3x, 'ObsFilt = ',A,A)
    CALL FLUSH(6)


! Turn off filters that do not bracket FILTLIST_FITRESTMAG.
! If either of the BRACKET filters is not defined then
! turn off ALL filters so that nothing passes.


    DO 200 ifilt   = 1, NFILTDEF_SURVEY

       L_KEEP      = .FALSE.
       L_USE       = .FALSE.

       IFILT_TMP   = IFILTDEF_MAP_SURVEY(ifilt)
       L_USE       = USE_ALLFILT(IFILT_TMP)

    DO 202 j       = 1, NBRA  ! xxx 2 -> NBRA
         L_MATCH   = IFILT_TMP .EQ. IFILTOBS_BRACKET(J)
         IF ( L_BRACKET .and. L_MATCH .AND. L_USE ) THEN
             L_KEEP  = .TRUE.
             JKEEP = J
         ENDIF
 202  CONTINUE  ! J

       if ( L_KEEP ) then
          LL = INDEX ( FILTLIST_FIT_USE, ' ' ) - 1
          FILTLIST_FIT_USE = FILTLIST_FIT_USE(1:LL) //  & 
                  cfiltobs_list(jkeep:jkeep)
          NFILT_OBS_USEFIT = NFILT_OBS_USEFIT + 1
          USE_FILT(IFILT_TMP) = .TRUE.
       else
          USE_FILT(IFILT_TMP) = .FALSE.
       endif

 200  CONTINUE  ! ifilt

! --------------------
! sanity check

    IF ( L_BRACKET .and. NFILT_OBS_USEFIT < 2 ) THEN
       write(c1err,601)  NFILT_OBS_USEFIT
601      format('L_BRACKET=T  but  NFILT_OBS_USEFIT = ',I2)
       write(c2err,602) SNLC_CCID, ITER, CFILTDEF
602      format('CID=',A12, 2x, 'ITER=',I2,' -> RestFilt=',A1)
       CALL MADABORT('FITRESTMAG_PREP', C1ERR, C2ERR)
    ENDIF

    RETURN
  END SUBROUTINE FITRESTMAG_PREP


! ========================================
    INTEGER FUNCTION BRACKET_FILTERLIST (  & 
                LAMREST, DLAM_TOL, Z, IFILTOBS_BRACKET )

! -----------------------------------------
! Mar 25 2020
! Return IFILTOBS_BRACKET (indices) of obs-filters that bracket
! LAMREST in the rest-frame.
! In the loop over SURVEY filters, IFILT_OBS = -999 is a flag
! (externally set) to ignore this filter.
! 
! This function originally returned just 2 bands: one below and
! one above the target LAMREST. Now it has been refactored to
! return all filters within DLAM_TOL of closest filters.
! 
! Original motivatoin is to work for LOWZ in which each band
! is broken into several bands covering different time periods.
! 
! 
! Inputs:
!   LAMREST   : rest-frame wavelength to bracket
!   DLAM_TOL  : combine obs filters withing this tolerance
!   Z         : redshift
! 
! Output:
!   IFILTOBS_BRACKET(1) : closest band with LAM/z1 < LAMREST
!   IFILTOBS_BRACKET(2) : closest band with LAM/z1 > LAMREST
!   IFILTOBS_BRACKET(3) : optional additional band within DLAM_TOL
!   IFILTOBS_BRACKET(4) : optional additional band within DLAM_TOL
!   etc ...
! 
! Function returns number of bands in IFILTOBS_BRACKET list.
! If only low or high bands are found, function returns 1.
! Function returnig 2 or larger is flag for success.
! Example, if filters a,b,c all have LAM/z1 < LAMREST, then
! function returns 1. But if there is also filter d with
! LAM/z1>LAMREST, then function returns 4.
! 
! ------------------------------------------


    USE SNDATCOM
    USE SNLCINP_NML
    USE FILTCOM

    IMPLICIT NONE

! subroutine args.

    REAL LAMREST   ! (I) rest-frame lambda to match
    REAL DLAM_TOL  ! (I) tolerance to accept multiple bracket filters
    REAL Z         ! (I) redshift

    INTEGER  & 
        IFILTOBS_BRACKET(*) ! (O) IFILTOBS that brackets LAMREST

! local var

    INTEGER IFILT, NFILT, IFILTOBS, IFILTOBS_LO, IFILTOBS_HI, JLOHI
    REAL    Z1, LAMZ, LAMZ_LO, LAMZ_HI, LAMDIF, LAMDIFMIN(2)
    CHARACTER  CFILT*2

! ------------- BEGIN ------------

    Z1 = 1.0 + z

    LAMDIFMIN(1) = 99999999.
    LAMDIFMIN(2) = 99999999.

    DO 100 ifilt = 1, NFILTDEF_SURVEY

       if ( .not. EXIST_FILT(ifilt) ) goto 100
       ifiltobs = IFILTDEF_MAP_SURVEY(ifilt)
       if ( ifiltobs .EQ. -999 ) goto 100

       CFILT  = FILTDEF_STRING(IFILTOBS:IFILTOBS)
       LAMZ   = FILTOBS_LAMAVG(ifiltobs)/Z1
       LAMDIF = ABS(LAMZ-LAMREST)

       IF ( LAMZ .LE. LAMREST ) THEN
          JLOHI = 1
       ELSE
          JLOHI = 2
       ENDIF

       if ( LAMDIF .LT. LAMDIFMIN(JLOHI) ) then
           LAMDIFMIN(JLOHI)        = LAMDIF
           IFILTOBS_BRACKET(JLOHI) = IFILTOBS
       endif

100   CONTINUE

! set function value

    NFILT = 0
    IFILTOBS_LO = IFILTOBS_BRACKET(1)
    IFILTOBS_HI = IFILTOBS_BRACKET(2)
    IF ( IFILTOBS_LO > 0 ) NFILT = NFILT + 1
    IF ( IFILTOBS_HI > 0 ) NFILT = NFILT + 1
    BRACKET_FILTERLIST = NFILT

    IF ( NFILT < 2       ) RETURN
    IF ( DLAM_TOL < 0.01 ) RETURN

!       IF ( DLAM_TOL < 1.0E9 ) RETURN ! xxx REMOVE

    LAMZ_LO = FILTOBS_LAMAVG(IFILTOBS_LO)/Z1
    LAMZ_HI = FILTOBS_LAMAVG(IFILTOBS_HI)/Z1

! if we get here, check for more bands with DLAM_TOL ...

    DO 200 ifilt = 1, NFILTDEF_SURVEY

       if ( .not. EXIST_FILT(ifilt) ) goto 200
       ifiltobs = IFILTDEF_MAP_SURVEY(ifilt)
       if ( ifiltobs .EQ. -999 ) goto 200

! skip already defined bracket filters
       if ( ifiltobs == IFILTOBS_LO ) goto 200
       if ( ifiltobs == IFILTOBS_HI ) goto 200

       LAMZ   = FILTOBS_LAMAVG(IFILTOBS)/Z1

! start with lower-wavelength filter
       LAMDIF = ABS(LAMZ-LAMZ_LO)
       if ( LAMZ < LAMZ_LO .and. LAMDIF < DLAM_TOL ) then
          NFILT = NFILT + 1 ; IFILTOBS_BRACKET(NFILT) = ifiltobs
       endif

! higher-wavelength filter
       LAMDIF = ABS(LAMZ-LAMZ_HI)
       if ( LAMZ > LAMZ_HI .and. LAMDIF < DLAM_TOL ) then
          NFILT = NFILT + 1 ; IFILTOBS_BRACKET(NFILT) = ifiltobs
       endif

 200  CONTINUE

    BRACKET_FILTERLIST = NFILT

    RETURN
  END FUNCTION BRACKET_FILTERLIST 

! =====================================
    SUBROUTINE FITRESTMAG_CALC(ITER)
! 
! Feb 2012:
! If ITER corresponds to the last iteration for a rest-filter,
! compute and fill global FITRESTMAG and FITRESTMAG_IERR
! 
! Sep 19 2013: call SNLCPAK to show each single-band fit
! 
! Dec 11, 2014: return if ITER > ITERLAST_2BAND to allow more
!                than 1 fit after the 2-band fits.
! ----------------------------------


    USE SNDATCOM
    USE SNLCINP_NML
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE

! subroutine args

    INTEGER ITER ! (I) SN index and fit iteration

! local var

    INTEGER  & 
         IFILTDEF, IFILT, NFUNPLOT, ITERLAST_2BAND  & 
        ,LCHAR_CCID, LCHAR_SHAPE, LCHAR_COLOR

    REAL*8  & 
         SHAPE_FIT, COLOR_FIT, Z, x0, x0err, x0ref  & 
        ,SHAPE, COLOR, MAGCOR

    CHARACTER CFILT*2, CCID*(MXCHAR_CCID)

! function
    REAL*8  GET_DIST8
    LOGICAL DOPLOT_SNLC

! ----------- BEGIN -----------

    IF ( NFILTDEF_FITRESTMAG .LE. 0       ) RETURN
    IF ( ITER .LE. NFIT_ITERATION_ALLFILT ) RETURN

    ITERLAST_2BAND = ITERLAST_FITRESTMAG(NFILTDEF_FITRESTMAG)
    IF ( ITER > ITERLAST_2BAND ) RETURN

! get absolute filter index of rest-frame filter
    IFILTDEF = IFILTDEF_ITER_FITRESTMAG(ITER)
    IFILT    = IFILTSP_ITER_FITRESTMAG(ITER)

! ---------------------------------------
! sanity check on filter indices

    IF (     IFILTDEF .LE. 0  & 
         .or.  IFILTDEF .GT. MXFILT_ALL  & 
         .or.  IFILT    .LE. 0  & 
         .or.  IFILT    .GT. MXFILT_FITRESTMAG  & 
           ) THEN
       write(c1err,611) IFILTDEF, IFILT
611        format('Invalid  IFILTDEF=', I5, 3x,'IFILT=',I3)
       write(c2err,612) SNLC_CCID, ITER
612        format('for CID=', A8, 3x, 'and ITER=' ,I2)
       CALL MADABORT('FITRESTMAG_CALC', C1ERR, C2ERR)
    ENDIF
! ---------------------------------------

! proceed with calc only on last iteration for this filter.
    IF ( ITER .NE. ITERLAST_FITRESTMAG(ifilt) ) RETURN

! save fitted SHAPEPAR in case we use a fixed SHAPEPAR for restMag
    SHAPE_FIT  = LCVAL_STORE(IPAR_SHAPE)
    COLOR_FIT  = LCVAL_STORE(IPAR_COLOR)

! set LCVAL_STORE to get rest-frame mag

    IF ( SHAPEFIX_FITRESTMAG .LT. 990.0 ) THEN
      LCVAL_STORE(IPAR_SHAPE) = SHAPEFIX_FITRESTMAG
    ENDIF
    IF ( COLORFIX_FITRESTMAG .LT. 990.0 ) THEN
      LCVAL_STORE(IPAR_COLOR) = COLORFIX_FITRESTMAG
    ENDIF

! store fit-info in local variables (before they get restored!)
    CFILT   = FILTDEF_STRING(IFILTDEF:IFILTDEF)
    SHAPE   = DBLE( LCVAL_STORE(IPAR_SHAPE) )
    COLOR   = DBLE( LCVAL_STORE(IPAR_COLOR)   )

! put this filter on the 'EVAL' list
    CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,ifiltdef), ifiltdef )

! compute peakmag
    CALL PEAKMAG_CALC(ifiltdef, 'REST')

! restore nominal values
    LCVAL_STORE(IPAR_SHAPE)   = SNGL(SHAPE_FIT)
    LCVAL_STORE(IPAR_COLOR)   = SNGL(COLOR_FIT)

! PEAKMAG_REST was evaluated for the best-fit model assuming
! DLMAG=0 or x0=1. But we need the standardization part of x0.
! WARNING: Below is hard-wired for SALT2 ... need to fix for mlcs/snoopy.

    Z      = DBLE(REDSHIFT_FIT)
    x0     = LCVAL_STORE(IPAR_DLMAG)     ! from fit with SHAPE floated
    x0err  = LCERR_STORE(IPAR_DLMAG)     ! idem
    x0ref  = GET_DIST8(Z,SHAPE_FIT,COLOR_FIT,ONE8)
    MAGCOR = -2.5*log10(x0/x0ref)
!       print*,' xxx MAGCOR = ', MAGCOR,'  for CID=', SNLC_CCID

! save fitted rest mag and error
    FITRESTMAG(IFILT)     = SNGL(PEAKMAG_REST_MODEL(ifiltdef)  + MAGCOR)
    FITRESTMAG_ERR(IFILT) = SNGL(1.0857*x0err/x0)

! ------------------------
! print one-line summary.

    LCHAR_CCID  = ISNLC_LENCCID
    LCHAR_SHAPE = INDEX(PARNAME_STORE(IPAR_SHAPE),' ') - 1
    LCHAR_COLOR = INDEX(PARNAME_STORE(IPAR_COLOR),  ' ') - 1

    write(6,20)  & 
          CFILT(1:1)  & 
         ,SNLC_CCID(1:LCHAR_CCID)  & 
         ,FITRESTMAG(IFILT), FITRESTMAG_ERR(IFILT)  & 
         ,PARNAME_STORE(IPAR_SHAPE)(1:LCHAR_SHAPE),  SHAPE  & 
         ,PARNAME_STORE(IPAR_COLOR)(1:LCHAR_COLOR),  COLOR

20    format(T5,'FitRestMag-',A,'(',A,') = ', F8.3,' +- ' , F6.3,  & 
         3x, '(',A,'=',F6.3,  2x,  A,'=',F6.3, ')'   )


! -----------------------------------------------------
! for SALT2, get K-corrected FLUX_REST (Jan 2014)

    IF ( FITMODEL_INDEX .EQ. MODEL_SALT2 ) THEN
       CALL SALT2_FLUXREST(IFILTDEF,SHAPE,COLOR)
    ENDIF

! --------------------------
! check option for single-band plot (Sep 2013)

    IF ( DOPLOT_SNLC() ) THEN

       NLCPLOT_FITRESTMAG = NLCPLOT_FITRESTMAG + 1
       IF ( NLCPLOT_FITRESTMAG .EQ. 1 ) THEN
! problem: if next fit fails we have already committed
!          to NFUNPLOT plots ???
          NFUNPLOT = NFILTDEF_FITRESTMAG + 1
          CALL SNLCPAK_NFIT(NFUNPLOT)  ! store NFIT
       ENDIF

       CCID = SNLC_CCID(1:LCHAR_CCID) // char(0)
       CALL MAKEDIR_OUTPUT(CCID, SNLC_CID, LCHAR_CCID)
       CALL FITANA_STORE()
       CALL SNLCPLOT()
       CALL CDTOPDIR_OUTPUT(STDOUT_UPDATE)  ! back to topdir
    ENDIF

    RETURN
  END SUBROUTINE FITRESTMAG_CALC


! ========================================
    SUBROUTINE SALT2_FLUXREST(IFILTREST,SHAPE,COLOR)
! ---------------------
! 
! Created Jan 2014 by R.Kessler
! 
! For each epoch, compute K-correction and load EP_FLUX_REST array.
! 
! Dec 31, 2014:   fill I4EP_ALL(ep,IEP_IFILT_REST1)
! 
! ---------------------

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE

! subroutine args
    INTEGER IFILTREST      ! (I) absolute value of rest-frame filter
    REAL*8  SHAPE, COLOR   ! (I)
    
! local args

    INTEGER IF1, IF2, IFILTOBS, IFILT, IMJD 
    INTEGER OPTMASK, NEP, EP, EPMIN, EPMAX

    REAL*8  & 
         z1, ZSN, LAMREST, LAMDIF1, LAMDIF2, LAMDIF  & 
        ,x0, x1, xx1, c, x2, MWEBV, PKMJD  & 
        ,TOBS, Trest, MAGOBS_MODEL, MAGREST_MODEL, MAGERR, WAVECOR  & 
        ,KCOR, MAGOBS, MAGREST, FLUX_REST, ARG  & 
        ,RV, AV,  PARLIST_SN(10), PARLIST_HOST(10)

    LOGICAL LDMP
! ----------------- BEGIN -----------------
! 
! determine which of the IFILTOBS_BRACKET is closest to IFILTDEF(rest)
! Note that the rest-frame filter is defined as an obs-filter.

    LDMP = .FALSE.

    Z1      = 1.0 + REDSHIFT_FIT
    LAMREST = FILTOBS_LAMAVG(ifiltrest)
    IF1     = IFILTOBS_BRACKET(1)
    IF2     = IFILTOBS_BRACKET(2)
    LAMDIF1 = ABS(FILTOBS_LAMAVG(IF1)/z1 - LAMREST)
    LAMDIF2 = ABS(FILTOBS_LAMAVG(IF2)/z1 - LAMREST)
    MWEBV   = SNLC_MWEBV

    IF (LAMDIF1 < LAMDIF2 ) THEN
      IFILTOBS = IF1 ; LAMDIF = LAMDIF1
    ELSE
      IFILTOBS = IF2 ; LAMDIF = LAMDIF2
    ENDIF

    IF ( LDMP ) THEN
      print*,' xxxxx ------------------------------------- '
      write(6,60) SNLC_CCID, IFILTREST, IFILTOBS, LAMDIF
 60     format(' xxxxx CID=', A6, 2x,'IFILT[REST,OBS]=',2I3, 3x,  & 
                'LAMDIF=',F5.0 )
    ENDIF

    OPTMASK   = 0   ! -> return mag
    x0       = 1.0
    x1       = SHAPE
    xx1      = SHAPE
    c        = COLOR
    x2       = 0.0  ! ?? Dec 2023
    NEP      = 1
    PKMJD    = LCVAL_STORE(IPAR_PEAKMJD) + MJDOFF
    RV=0.0 ;   AV=0.0

    PARLIST_SN(1) = x0
    PARLIST_SN(2) = x1
    PARLIST_SN(3) = xx1
    PARLIST_SN(4) = c
    PARLIST_SN(5) = x2

    PARLIST_HOST(1) = RV
    PARLIST_HOST(2) = AV
    PARLIST_HOST(3) = -9.0 ! logmass

    DO 101 IMJD      = 1, ISNLC_NEWMJD_STORE
      EPMIN = ISNLC_EPOCH_RANGE_NEWMJD(1,IMJD)
      EPMAX = ISNLC_EPOCH_RANGE_NEWMJD(2,IMJD)

    DO 102 ep = EPMIN, EPMAX

       IF ( IFILTOBS .NE.  ISNLC_IFILT_OBS(ep) ) GOTO 102

       ifilt = IFILTDEF_INVMAP_SURVEY(ifiltobs)

! start with obs-frame
       TOBS    = SNLC8_MJD(ep) - PKMJD
       Trest   = TOBS/z1

       ZSN     = REDSHIFT_FIT
       WAVECOR = 0.0 

       CALL genmag_salt2( OPTMASK, IFILTOBS,  & 
              PARLIST_SN, PARLIST_HOST, MWEBV, ZSN,ZSN,  NEP, Tobs,  & 
              WAVECOR,               &  ! dummy arg, Sep 1 2026
              MAGOBS_MODEL, MAGERR )     ! return arg

! now the rest-frame
       ZSN     = 1.0E-6
       CALL genmag_salt2( OPTMASK, IFILTREST,  & 
              PARLIST_SN, PARLIST_HOST, MWEBV, ZSN,ZSN, NEP, Trest,  & 
              WAVECOR,             &     ! dummy arg, Sep 1 2026
              MAGREST_MODEL, MAGERR )     ! return arg

       KCOR    = MAGREST_MODEL - MAGOBS_MODEL
       MAGOBS  = R4EP_ALL(ep,JEP_DATAMAG)

       IF ( MAGOBS > 0 ) THEN
         MAGREST    = MAGOBS + KCOR - SNLC_DLMAG
         ARG        = 0.4*(ZP_FLUXCAL - MAGREST)
         FLUX_REST  = 10.0**(ARG)
         R4EP_ALL(ep,JEP_DATAFLUX_REST) = SNGL(FLUX_REST)
         I4EP_ALL(ep,IEP_IFILT_REST1)   = IFILTREST
       ELSE
         MAGREST   = -999
         FLUX_REST = -999
       ENDIF

       IF ( LDMP ) THEN
         write(6,61) Trest, MAGOBS, MAGREST
 61        format(' xxxx Trest=',F6.1, 2x, 'MAG[OBS,REST]=',2G12.5 )
         call flush(6)
       ENDIF

 102  CONTINUE  ! ep
 101  CONTINUE  ! IMJD

    RETURN
  END SUBROUTINE SALT2_FLUXREST

! ========================================
    SUBROUTINE GET_FITRESTMAG(IFILT, MAGREST, MAGERR)

! created Mar 2013.
! Return fitted rest-mag and error for this sparse IFILT.
! 

    USE SNDATCOM
    USE SNANAFIT
    USE FITRESTCOM

    IMPLICIT NONE

    INTEGER  IFILT            ! (I) sparse filter index
    REAL     MAGREST, MAGERR  ! (O)

! ----------- BEGIN ----------
    MAGREST = FITRESTMAG(ifilt)
    MAGERR  = FITRESTMAG_ERR(ifilt)
    RETURN
  END SUBROUTINE GET_FITRESTMAG


! =======================================
    LOGICAL FUNCTION LFITFUN_FILT(ifilt_obs,ZTEST)
! 
! Return T if this filter should be included in fit.
! 
! ZTEST > 0 => make z-dependent tests
! ZTEST < 0 => skip z-dependent tests
! 
! Jan 2025: add logic for USE_PRIOR_SNCID_FILE
! 
! ---------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    INTEGER  & 
        ifilt_obs  ! (I) observer filter index

    REAL*8 ZTEST

! local

    INTEGER IFILT_REST, IFILT, OPT
    REAL*8 oneplusZ, LAMZ
    REAL*4 Z4, LMIN4

    LOGICAL ISSURVEY, NOEPOCHS

! function
    INTEGER NEAREST_IFILTDEF_WRAPPER

! --------------- BEGIN ----------------

    LFITFUN_FILT = .FALSE.

! did user request this filter.
    if ( .NOT. DOFIT_FILT(ifilt_obs) ) RETURN

! are there any epochs with this filter.
    ifilt    = IFILTDEF_INVMAP_SURVEY(ifilt_obs)
    ISSURVEY = .NOT. LFILTDEF_NONSURVEY(ifilt_obs)
    NOEPOCHS = .NOT. EXIST_FILT(ifilt)
    if ( ISSURVEY .and. NOEPOCHS ) RETURN

    IF ( DOFIT_PHOTOZ ) THEN
      if ( PHOTOZ_DROPFILTER(ifilt_obs)) RETURN ! drop this filter

      ! check option to force filters from previous fit stored in external file
      if ( USE_PRIOR_SNCID_FILE ) then
         LFITFUN_FILT = PRIOR_USE_FILT_SNCID_FILE(ifilt_obs)
         RETURN
      endif

   ENDIF

! -----------------------------------

    IF ( ZTEST .GT. 0.0 ) THEN

! does this observer filter transform to a valid
! rest-frame lambda range

      oneplusZ  = 1.0 + ZTEST
      LAMZ  = FILTOBS_LAMAVG(ifilt_obs) / oneplusZ

      IF ( LAMZ .LT. RESTLAMBDA_USEFIT(1) ) RETURN
      IF ( LAMZ .GT. RESTLAMBDA_USEFIT(2) ) RETURN

! does this observer filter transform to a valid rest-frame filter

      IF ( LREST_FITMODEL ) THEN
        Z4  = SNGL(ZTEST)
        OPT = OPT_FILTOBS
        ifilt_rest = NEAREST_IFILTDEF_WRAPPER(OPT,ifilt_obs,  & 
                             1, Z4, LMIN4 )
        if ( ifilt_rest .LE. 0. ) RETURN
      ENDIF
    ENDIF

! all is OK.

    LFITFUN_FILT = .TRUE.

    RETURN
  END FUNCTION LFITFUN_FILT

! =======================================
    SUBROUTINE LANDOLT_PREP()
! 
! Created Feb 10, 2012
! 
! Init stuff related to OPT_LANDOLT.
! Pulled out of FITPAR_PREP.
! 
! May 2012: if BX is defined in the KCOR file but is not
!           a SURVEY_FILTER, then define X here as a SURVEY_FILTER.
!           This part was moved from RDKCOR.
! 
! ------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER ISTAT, IFILT, i
    CHARACTER CTMP*8, FNAM*16
    LOGICAL   FORCE, LBX
    REAL MAG_PRIMARY

! function
    INTEGER  LANDOLT_INI
    EXTERNAL LANDOLT_INI

! -------------- BEGIN -------------------------

    FNAM = 'LANDOLT_PREP'

! check for Marriner's "LANDOLT" option
! OPT_LANDOLT bits (lsb=0):
!   bit0 : Landolt => Bessell in rest-frame (BD17)
!   bit1 : Bessell => Landolt in obs-frame  (BD17)
!   bit2 : idem but in Vega system

       USE_LANDOLT_REST = .FALSE.
       USE_LANDOLT_OBS  = .FALSE.

    IF ( UCOR_BXB .and. OPT_LANDOLT .EQ. 0 ) THEN
       USE_LANDOLT_REST = .TRUE.  ! color terms =0; but U -> U+BX-B
       MAG_PRIMARY = FILTREST_MAG_PRIMARY(IFILT_BESS_U)
       istat = landolt_ini( OPT_LANDOLT,  & 
                              MAG_PRIMARY, LANDOLT_COLOR_SHIFT )

       CALL LANDOLT_SNMAG_CHECK(0, 0.0, 0.0)  ! Trest, AV
    ENDIF  ! end of OPT_LANDOLT option

! ----------------------------------------------
    IF ( OPT_LANDOLT .EQ. 0 ) RETURN
! ----------------------------------------------

    USE_LANDOLT_REST = BTEST(OPT_LANDOLT,0)  ! mask = 1
    USE_LANDOLT_OBS  = BTEST(OPT_LANDOLT,1)  ! mask = 2
    FORCE            = BTEST(OPT_LANDOLT,6)  ! mask = 64 -> FORCE use in SIM

    IF ( LSIM_SNANA .and. .NOT. FORCE ) THEN
        write(c1err,670) OPT_LANDOLT
670       format('OPT_LANDOLT=',I3,' is invalid for SIM.')
        c2err = 'Must set OPT_LANDOLT = 0 in &FITINP '
        CALL MADABORT(FNAM, c1err, c2err )
    ENDIF

! -----------------------------------------------
! if BX filter is not a survey filter,
! then add it to the SURVEY_FILTERS list and call RDKCOR again.


    LBX = IFILTDEF_INVMAP_SURVEY(ifilt_BESS_BX) .GT. 0

    IF ( USE_LANDOLT_OBS .and. .NOT. LBX ) THEN
       print*,' '
       print*,'    Add observer-frame X band to SURVEY filters ' //  & 
                     'for Landolt option'
       print*,' '
       call flush(6)
       SURVEY_FILTERS  = SURVEY_FILTERS(1:NFILTDEF_SURVEY) // 'X'
       NFILTDEF_SURVEY = NFILTDEF_SURVEY + 1
       i = NFILTDEF_SURVEY
       IFILTDEF_MAP_SURVEY(i) = IFILT_BESS_BX
       IFILTDEF_INVMAP_SURVEY(ifilt_BESS_BX) = i

       CALL READ_CALIB_WRAPPER(ISTAT)

       CALL CDTOPDIR_OUTPUT(STDOUT_UPDATE)  ! back to topdir (to be safe)

    ENDIF

! -----------------------------------
! make sure that BX filters is defined
    C2err =  & 
         'Either set OPT_LANDOLT=0 or add BX filter to KCOR file.'

    IF ( USE_LANDOLT_OBS ) THEN
      IFILT = IFILTDEF_INVMAP_SURVEY(ifilt_BESS_BX)
      IF ( .NOT. EXIST_BXFILT_OBS .or. IFILT .LE. 0 ) THEN
          print*,' xxx IFILT, EXIST_BXFILT_OBS = ',  & 
                  IFILT, EXIST_BXFILT_OBS
        write(c1err,677) OPT_LANDOLT, 'OBS'
        CALL MADABORT(FNAM, c1err, c2err )
      ENDIF
    ENDIF
    IF ( USE_LANDOLT_REST ) THEN
       IFILT = IFILTDEF_INVMAP_REST(ifilt_BESS_BX)
       IF ( .not. EXIST_BXFILT_REST .or. IFILT .LE. 0) THEN
          write(c1err,677) OPT_LANDOLT, 'REST'
          print*,' xxx IFILT, EXIST_BXFILT_REST = ',  & 
                  IFILT, EXIST_BXFILT_REST
          CALL MADABORT(FNAM, c1err, c2err )
       ENDIF
    ENDIF

677      format('Cannot implement OPT_LANDOLT=',I3,  & 
            ' without ', A,'-frame BX filter.')


     istat = landolt_ini( OPT_LANDOLT,  & 
            FILTREST_MAG_PRIMARY(IFILT_BESS_U), LANDOLT_COLOR_SHIFT )


! check for VEGA or BD17 as reference;
! make crude sanity check on FILT_MAGPRIMARY to avoid
! mixing the wrong things.

    if ( BTEST(OPT_LANDOLT,2) ) then
       ctmp = 'VEGA'
    else
       ctmp = 'BD17'
    endif

    if ( USE_LANDOLT_REST ) then
         print*,'   Transform rest-Landolt => rest-Bessell',  & 
                   '  (', ctmp,')'
         call flush(6)
    endif

    if ( USE_LANDOLT_OBS ) then
         print*,'   Transform obs-Bessell => obs-Landolt ',  & 
                   '  (', ctmp,')'
         call flush(6)
    endif

    if ( USE_LANDOLT_REST ) then
      CALL LANDOLT_SNMAG_CHECK(0, 0.0, 0.0)  ! Trest, AV
    endif
    CALL LANDOLT_SNMAG_CHECK(1, 0.0, 0.0)
    CALL LANDOLT_SNMAG_CHECK(2, 0.0, 0.0)

    RETURN
  END SUBROUTINE LANDOLT_PREP

! =======================================
    SUBROUTINE LANDOLT_SNMAG_CHECK(OPT,Trest,AVwarp)
! 
! Compute SN mags at t=0 for Bessell and Landolt;
! compare with external calculations.
! 
! -----------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER OPT             ! () 0=>SN, 1=Vega, 2=BD17
    REAL    Trest, AVwarp   ! (I) test params

! local var

    INTEGER ifilt, OPT_CONVERT, istat

    REAL*8  & 
         T8, Z8, AV8  & 
        ,MAG8_BESS(MXFILT_ALL)      &  ! reported Bessell mags
        ,MAG8_SYNBESS(MXFILT_ALL)   &  ! synthetic Bessell
        ,MAG8_LAND(MXFILT_ALL)  & 
        ,MAG8_INVERT(MXFILT_ALL)  & 
        ,MAG8_BX, MAG8_B, MAG8_TMP

    character cflt*1

    REAL BD17_MAG_LANDOLT(MXFILT_ALL)
    REAL VEGA_MAG_LANDOLT(MXFILT_ALL)

! functions
    REAL*8  EVAL_KCOR_TABLE_LCMAG
    INTEGER LANDOLT_CONVERT

! --------------- BEGIN ---------------

    DO ifilt = 1, MXFILT_ALL
      MAG8_SYNBESS(ifilt) = -9.0
      MAG8_BESS(ifilt)    = -9.0
      MAG8_LAND(ifilt)    = -9.0
      MAG8_INVERT(ifilt)  = -9.0
    ENDDO

! hard-wire primary mags from John Marriner.

    BD17_MAG_LANDOLT(IFILT_BESS_U) = 9.724
    BD17_MAG_LANDOLT(IFILT_BESS_B) = 9.907
    BD17_MAG_LANDOLT(IFILT_BESS_V) = 9.464
    BD17_MAG_LANDOLT(IFILT_BESS_R) = 9.166
    BD17_MAG_LANDOLT(IFILT_BESS_I) = 8.846
    BD17_MAG_LANDOLT(IFILT_BESS_BX) = 9.907

    VEGA_MAG_LANDOLT(IFILT_BESS_U) = 0.011
    VEGA_MAG_LANDOLT(IFILT_BESS_B) = 0.015
    VEGA_MAG_LANDOLT(IFILT_BESS_V) = 0.017
    VEGA_MAG_LANDOLT(IFILT_BESS_R) = 0.024
    VEGA_MAG_LANDOLT(IFILT_BESS_I) = 0.020
    VEGA_MAG_LANDOLT(IFILT_BESS_BX) = 0.015

    print*,' '

    if ( OPT .EQ. 0 ) then
      print*,'  Check SN mags at Trest=',Trest,'  AVwarp=',AVwarp
      T8  = DBLE(Trest)
      AV8 = DBLE(AVwarp)
      Z8  = Zat10pc
      DO ifilt = IFILT_BESS_U, IFILT_BESS_BX
        MAG8_TMP = EVAL_KCOR_TABLE_LCMAG(ifilt,T8,Z8,AV8)
        MAG8_SYNBESS(ifilt) = MAG8_TMP - (-19.6)  ! PEAKMAG_AT_10pc
      ENDDO
    ELSE IF ( OPT .EQ. 1 ) then
      print*,'  Check VEGA mags. '
      DO ifilt = IFILT_BESS_U, IFILT_BESS_BX
        MAG8_LAND(ifilt) = VEGA_MAG_LANDOLT(ifilt)
      ENDDO
      MAG8_LAND(IFILT_BESS_BX) =  & 
        MAG8_LAND(IFILT_BESS_BX) - MAG8_LAND(IFILT_BESS_B)
      GOTO 400
    ELSE IF ( OPT .EQ. 2 ) then
      print*,'  Check BD17 mags. '
      DO ifilt = IFILT_BESS_U, IFILT_BESS_BX
        MAG8_LAND(ifilt) = BD17_MAG_LANDOLT(ifilt)
      ENDDO
      MAG8_LAND(IFILT_BESS_BX) =  & 
        MAG8_LAND(IFILT_BESS_BX) - MAG8_LAND(IFILT_BESS_B)
      GOTO 400
    ELSE
      print*,' '
      print*,' LANDOLT_SNMAG_CHECK: UKNOWN OPT = ', OPT
      print*,' ***** ABORT ***** '
      STOP
    ENDIF


    OPT_CONVERT = +1
    istat = Landolt_convert(opt_convert  & 
                ,MAG8_SYNBESS(IFILT_BESS_U)   &  ! input  UBVRI,X
                ,MAG8_LAND(IFILT_BESS_U)      &  ! output UBVRI
                 )

! now invert to get back Bessell from Landolt.

    MAG8_BX = EVAL_KCOR_TABLE_LCMAG(ifilt_BESS_BX,T8,Z8,AV8)
    MAG8_B  = EVAL_KCOR_TABLE_LCMAG(ifilt_BESS_B, T8,Z8,AV8)

    MAG8_LAND(IFILT_BESS_BX) = MAG8_BX - MAG8_B

400   CONTINUE

    OPT_CONVERT = -1
    istat = Landolt_convert(opt_convert  & 
                ,MAG8_LAND(IFILT_BESS_U)     &  ! input   land  UBVRI, BX-B
                ,MAG8_INVERT(IFILT_BESS_U)   &  ! output  synth UBVRI,X
                 )

! convert synthetic mags into reported BESS mags.
    DO ifilt = IFILT_BESS_U, IFILT_BESS_BX
       MAG8_BESS(ifilt) = MAG8_INVERT(ifilt)
    ENDDO
    MAG8_BESS(ifilt_BESS_U) = MAG8_INVERT(ifilt_BESS_U)  & 
                              - MAG8_INVERT(ifilt_BESS_BX)  & 
                              + MAG8_INVERT(ifilt_BESS_B)

! --------

    print*,' '
    print*,'      synth      reported   syn-Bessell   Landolt->     '
    print*,'      Bessell    Bessell    -> Landolt    syn-Bessell   '
    print*,' ----------------------------------------------------- '

    DO ifilt = IFILT_BESS_U, IFILT_BESS_I
      cflt = FILTDEF_STRING(ifilt:ifilt)
      write(6,20)  cflt  & 
          ,MAG8_SYNBESS(ifilt)  & 
          ,MAG8_BESS(ifilt)  & 
          ,MAG8_LAND(ifilt)  & 
          ,MAG8_INVERT(ifilt)

20      format(T3,A, 2x,4(F9.4,3x) )

    ENDDO

    print*,' ----------------------------------------------------- '
    CALL FLUSH(6)

    RETURN
  END SUBROUTINE LANDOLT_SNMAG_CHECK

! ====================================
    SUBROUTINE SET_IFILT_OBS(LPRINT)
! 
! Sets up appropriate observer-filter ranges before fit begins
! so that USRFUN need not compute filter ranges during each
! call.
! 
! Set the following FILTCOM varaibles for this SN:
!   IFILT_OBS_EVAL_MASK(ifilt_obs)  => mask of obs filters to evaluate
! 
!  Example: U-band needs to evaluate obs U,B,V,BX
!   => IFILT_OBS_EVAL_MASK(IFILT_BESS_U) = bits 6,7,8,11
! 
! 
! Apr 22 2022: pass LPRINT logical flag as input argument
! --------------------------------------


    USE SNDATCOM
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    LOGICAL  LPRINT  ! (I)

! local
    INTEGER  & 
         ifilt, ifilt2  & 
        ,ifilt_obs, ifilt2_obs  & 
        ,LL, NFUSE

    INTEGER*8 MSKTMP8(2)

    LOGICAL LBESS_OBS, LTMP, MULTIFILT, USE
    character cfilt*2, cfilt2*2

! functions
    LOGICAL FILTBTEST

! -------------- BEGIN --------------

    LL = ISNLC_LENCCID

    DO ifilt = 1, MXFILT_ALL
      IFILT_OBS_EVAL_MASK(1,ifilt) = 0
      IFILT_OBS_EVAL_MASK(2,ifilt) = 0
    ENDDO

! check if any of the OBS filters are in the Bessell90 system
    LBESS_OBS = .FALSE.
    DO ifilt = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       if ( ifilt_obs .GE. IFILT_BESS_U .and.  & 
              ifilt_obs .LE. IFILT_BESS_I ) LBESS_OBS = .TRUE.
    ENDDO

! set default mask to evaluate only observer filter
! (ie.. no color transformations).

    MULTIFILT = .FALSE.

    DO ifilt = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       USE = USE_FILT(ifilt_obs) .or. LFILTDEF_NONSURVEY(ifilt_obs)
       if ( USE ) then
          CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,ifilt_obs),  & 
                         ifilt_obs)
      endif
    ENDDO

! -----------------------------------------------------
! check option to correct U with BX-B
! Note that UCOR is used automatically with OPT_LANDOLT;
! this is to allow UCOR_BXB without the LANDOLT option

    IF ( UCOR_BXB .and. LBESS_OBS ) THEN

       MULTIFILT = .TRUE.

       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_U)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_B)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_BX)

    ENDIF

! -----------------------------------------------------
! check options that involve color transformations.

    IF ( USE_LANDOLT_OBS .and. LBESS_OBS ) THEN

       MULTIFILT = .TRUE.

! --- U
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_U)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_B)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_V)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_U),  & 
                      IFILT_BESS_BX)

! --- B

       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_B),  & 
                      IFILT_BESS_B)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_B),  & 
                      IFILT_BESS_V)

! --- V
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_V),  & 
                      IFILT_BESS_B)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_V),  & 
                      IFILT_BESS_V)

! --- R
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_R),  & 
                      IFILT_BESS_B)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_R),  & 
                      IFILT_BESS_V)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_R),  & 
                      IFILT_BESS_R)

! --- I
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_I),  & 
                      IFILT_BESS_B)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_I),  & 
                      IFILT_BESS_V)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_I),  & 
                      IFILT_BESS_R)
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_I),  & 
                      IFILT_BESS_I)

! --- BX
       CALL FILTBSET(IFILT_OBS_EVAL_MASK(1,IFILT_BESS_BX),  & 
                      IFILT_BESS_BX)

    ENDIF

! ----------
! write list of filters to fit
! 
    NFUSE = INDEX(FILTLIST_FIT_USE,' ') - 1

    IF ( LPRINT ) THEN
      write(6,44) SNLC_CCID(1:LL), FILTLIST_FIT_USE(1:NFUSE)
44      format(T5,'CID ',A,' : FIT OBSERVER FILTERS ', A )
    ENDIF
! ----------------------------------------
!  print obs filters for each filter when mutliple filters
!  are needed per band, such as for the Landolt correction

    LTMP = (N_SNLC_FITCUTS .LT. 20) .and. MULTIFILT

    IF ( LTMP ) THEN
      if ( LPRINT ) print*,' '

      DO 29 ifilt = 1, NFILTDEF_SURVEY

       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       USE = USE_FILT(ifilt_obs)
       if ( .NOT. USE ) goto 29

       cfilt  = filtdef_string(ifilt_obs:ifilt_obs)
       MSKTMP8(1) = IFILT_OBS_EVAL_MASK(1,ifilt_obs)
       MSKTMP8(2) = IFILT_OBS_EVAL_MASK(2,ifilt_obs)

       write(6,20) SNLC_CCID(1:LL), cfilt
20       format(T10,'SN ',A,': OBSERVER-',A1,' => evaluate obs ', $)

       DO ifilt2 = 1, NFILTDEF_SURVEY
          ifilt2_obs = IFILTDEF_MAP_SURVEY(ifilt2)
          cfilt2 = filtdef_string(ifilt2_obs:ifilt2_obs)
          LTMP = FILTBTEST(MSKTMP8,ifilt2_obs)
          if ( LTMP .and. LPRINT ) write(6,21) cfilt2(1:1)
21          format(A1, $)
       ENDDO
       if ( LPRINT ) print*, '  (ifilt=', ifilt, ')'

29      CONTINUE ! end of IFILT loop

    ENDIF    ! end of LTMP if-block

    RETURN
  END SUBROUTINE SET_IFILT_OBS


! ===================================
    SUBROUTINE INIT_FUDGE_FITERR
! 
! Created Jul 18, 2008
! (code moved from FITPAR_INI)
! 
! Feb 19 2010: abort if MAXFRAC>0, but TREST-range or LAM-range
!              is zero.
! 
! Mar 1 2017: do NOT return after FUDGEALL_MAXFRAC -->
!             allow mixing with other options.
! ---------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER LL, ifilt, ifilt_obs

    character ctmp*4

    INTEGER FILTINDX

! ------------- BEGIN ------------

    USE_FUDGE_FITERR = .FALSE.

    IF ( FUDGE_MAGERR_MODEL .GE. 0.0 ) THEN
       write(6,16) FUDGE_MAGERR_MODEL
16       format(T5,'FIT-MODEL FUDGE WARNING: ',  & 
             ' ALL MODEL-MAG ERRORS -> ', F6.3,' mag ' )
    ENDIF

    IF ( FUDGEALL_MAXFRAC .GT. 0.0 ) THEN
      write(6,179) FUDGEALL_MAXFRAC
179     format(T5,'FIT-ERROR fudge = ', F6.2,' * max(Flux)', 3x,  & 
          'for all epochs and fit-iterations.' )
     USE_FUDGE_FITERR = .TRUE.
    ENDIF

    IF ( FUDGEALL_ITER1_MAXFRAC .GT. 0.0 ) THEN
       write(6,79) FUDGEALL_ITER1_MAXFRAC, 1
       USE_FUDGE_FITERR = .TRUE.
    ENDIF

    IF ( FUDGE_FITERR_PASSBANDS .EQ. 'NULL' ) RETURN
    IF ( FUDGE_FITERR_MAXFRAC   .EQ. 0.     ) RETURN

    USE_FUDGE_FITERR = .TRUE.

    LL = INDEX ( FUDGE_FITERR_PASSBANDS, ' ' ) -  1

    DO ifilt     = 1, LL
       ctmp      = FUDGE_FITERR_PASSBANDS(ifilt:ifilt)
       ifilt_obs = FILTINDX(ctmp)
       DOFUDGE_FITERR(ifilt_obs) = .TRUE.

       write(6,77) ctmp(1:1),  & 
               FUDGE_FITERR_TREST(1), FUDGE_FITERR_TREST(2)

77       format(T5,'Fudge ',A,'-band FIT-ERRORS for ',  & 
                F6.1, ' < Trest < ', F6.1,' days ' )

       if ( FUDGE_FITERR_TREST(3) .LT. 900. ) then
           write(6,77) ctmp(1:1),  & 
               FUDGE_FITERR_TREST(3), FUDGE_FITERR_TREST(4)
       endif

       write(6,78) int(FUDGE_FITERR_RESTLAM(1))  & 
                    ,int(FUDGE_FITERR_RESTLAM(2))

       if( FUDGE_FITERR_RESTLAM(3) .LT. 80000. ) then
         write(6,78)  int(FUDGE_FITERR_RESTLAM(3))  & 
                       ,int(FUDGE_FITERR_RESTLAM(4))
       endif

78       format(T30,'and ', I5,' < RESTLAM < ', I5,' Angstroms')

    ENDDO

    write(6,79) FUDGE_FITERR_MAXFRAC, FUDGE_FITERR_MAXITER
79    format(T5,'FIT-ERROR fudge = ', F6.2,' * max(Flux)', 3x,  & 
          'for ITER <=',I2   )
    print*,'  '


! ----------------------------------------------------
! sanity checks to prevent setting bad FUDGEs

    write(c1err,661) FUDGE_FITERR_MAXFRAC
661   format('FUDGE_FITERR_MAXFRAC = ',F8.2)

    IF ( FUDGE_FITERR_TREST(1) .GE. FUDGE_FITERR_TREST(2) ) then
       c2err = 'but  FUDGE_FITERR_TREST  is not set.'
       CALL MADABORT("INIT_FUDGE_FITERR", c1err, c2err)
    ENDIF
    IF ( FUDGE_FITERR_RESTLAM(1).GE.FUDGE_FITERR_RESTLAM(2)) then
       c2err = 'but  FUDGE_FITERR_RESTLAM  is not set.'
       CALL MADABORT("INIT_FUDGE_FITERR", c1err, c2err)
    ENDIF

    RETURN
  END SUBROUTINE INIT_FUDGE_FITERR

! ==========================================
    SUBROUTINE DMP_DICTFILE(IFLAG)
! 
! Created Apr 13, 2009 by R.Kessler
! 
! Write SALT2 results to "dictFile" ...
! the particular format needed by their
! "hubblefit" program. Note that SNANA does
! NOT use this DICTFILE for anything;
! this is just a convenience option to
! use the original SALT2 hubblefit with
! the output of snlc_fit.exe
! 
! IFLAG = 0 => open file; write header
! IFLAG > 0 => update with next SN

! ------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER IFLAG ! (I) 0-> open file; 1-> write

! local

    INTEGER LTMP,  ivar

    INTEGER, PARAMETER :: NVAR_DICTFILE =  17
    REAL*8  XVAR(NVAR_DICTFILE)

! ----------- BEGIN ----------

    IF ( FITMODEL_INDEX .NE. MODEL_SALT2 ) RETURN

    IF ( IFLAG .EQ. 0 ) THEN

! init dictFile and  write header

      OPEN(UNIT= LUNSALT2, FILE = SALT2_DICTFILE,  & 
               STATUS='UNKNOWN', ERR=92)

      write(6,90) SALT2_DICTFILE(1:LTMP)
90      format(T5,'Open SALT2 DICT-FILE : ', A)
      print*,' '

! write mandatory header
      write(LUNSALT2,20) 'z',  1,'redshift'
      write(LUNSALT2,20) 'X0', 2,'10^[-0.4*(mu + alpha*x1 - beta*c)]'
      write(LUNSALT2,20) 'X0e',3,'error on x_0'
      write(LUNSALT2,20) 'X1', 4,'stretch/luminosity parameter'
      write(LUNSALT2,20) 'X1e',5,'error on x_1'
      write(LUNSALT2,20) 'X2', 6,'bidon'
      write(LUNSALT2,20) 'X2e',7,'bidon'
      write(LUNSALT2,20) 'X3', 8,'color'
      write(LUNSALT2,20) 'X3e',9,'error on color'
      write(LUNSALT2,20) 'msb',10,'reference B-mag'
      write(LUNSALT2,20) 'msbe',11,'error on above'

      write(LUNSALT2,20) 'X0X1_c', 12, 'x_0/x_1 Correlation'
      write(LUNSALT2,20) 'X0X2_c', 13, 'bidon'
      write(LUNSALT2,20) 'X0X3_c', 14, 'x_0/color Correlation'
      write(LUNSALT2,20) 'X1X2_c', 15, 'bidon'
      write(LUNSALT2,20) 'X1X3_c', 16, 'x_1/color Correlation'
      write(LUNSALT2,20) 'X2X3_c', 17, 'bidon'
      write(LUNSALT2,20) 'end'

20      format('#', A, T9,': (', I2.2,') ', A)

      RETURN

    ENDIF  ! end if IFLAG=0


! --------------

    ivar = 0

    IVAR = IVAR + 1
    XVAR(ivar) = SNLC_ZCMB

! x0
    IVAR = IVAR + 1
    XVAR(ivar) = LCVAL_STORE(IPAR_X0)
    IVAR = IVAR + 1
    XVAR(ivar) = LCERR_STORE(IPAR_X0)

! x1
    IVAR = IVAR + 1
    XVAR(ivar) = LCVAL_STORE(IPAR_SHAPE)
    IVAR = IVAR + 1
    XVAR(ivar) = LCERR_STORE(IPAR_SHAPE)

! x2
    IVAR = IVAR + 1
    XVAR(ivar) = 0.0
    IVAR = IVAR + 1
    XVAR(ivar) = 0.0

! x3 = color
    IVAR = IVAR + 1
    XVAR(ivar) = LCVAL_STORE(IPAR_COLOR)
    IVAR = IVAR + 1
    XVAR(ivar) = LCERR_STORE(IPAR_COLOR)

! mB*
    IVAR = IVAR + 1
    XVAR(ivar) = LCVAL_STORE(IPAR_MB)
    IVAR = IVAR + 1
    XVAR(ivar) = LCERR_STORE(IPAR_MB)

! now the covariances ...

! #X0X1_c :
    IVAR = IVAR + 1
    XVAR(ivar) = FITERRMAT(IPAR_X0,IPAR_SHAPE)

! #X0X2_c :  bidon
    IVAR = IVAR + 1
    XVAR(ivar) = 0.0

! #X0X3_c :  x0-color cov
    IVAR = IVAR + 1
    XVAR(ivar) = FITERRMAT(IPAR_X0,IPAR_COLOR)

! #X1X2_c :   bidon
    IVAR = IVAR + 1
    XVAR(ivar) = 0.0

! #X1X3_c :   x1-color cov
    IVAR = IVAR + 1
    XVAR(ivar) = FITERRMAT(IPAR_SHAPE,IPAR_COLOR)

! #X2X3_c : bidon
    IVAR = IVAR + 1
    XVAR(ivar) = 0.0

! -----------------------

!  write XVAR
    DO ivar = 1, NVAR_DICTFILE
      write(LUNSALT2, '(G14.6,$)' ) XVAR(ivar)
    END DO
    write(LUNSALT2, '(A)') ' '
    CALL FLUSH(LUNSALT2)

    GOTO 888

! ---------------------
92    CONTINUE
    c1err = 'Could not open SALT2_DICTFILE: '
    c2err = SALT2_DICTFILE(1:84)
    CALL MADABORT("DMP_DICTFILE", c1err, c2err)

888   CONTINUE
    RETURN
  END SUBROUTINE DMP_DICTFILE


! =======================================
    SUBROUTINE DMP_COVAR(iter)
! 
! Created Jun 2, 2011 by R.Kessler
! 
! Dump non-zero elements of COVMAT2 matrix
! before it is  inverted.
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE

    INTEGER iter  ! (I) fit-iteration to prepare
! local variables

    INTEGER NDMP, IROW, ICOL, IFILT_ROW, IFILT_COL
    INTEGER ep_row, ep_col
    REAL*8  COVTMP8

    character cfilt_row*2, cfilt_col*2

! ---------------- BEGIN ------------

     print*,' --------------------------------------- '
     print*,' COVMAT DUMP for CID=', SNLC_CCID,  & 
            '   FIT-ITER=', ITER

     NDMP = 0

     DO 301 irow = 1, NFITDATA
     DO 302 icol = 1, NFITDATA

       COVTMP8     = COVMAT2(irow,icol)
       if ( COVTMP8 .EQ. 0.0 ) GOTO 302

       ep_row = EPLIST_FIT(irow)
       ep_col = EPLIST_FIT(icol)

       NDMP = NDMP + 1
       IFILT_ROW   = I4EP_ALL(ep_row,IEP_IFILT_OBS)
       IFILT_COL   = I4EP_ALL(ep_col,IEP_IFILT_OBS)
       cfilt_row   = FILTDEF_STRING(ifilt_row:ifilt_row)
       cfilt_col   = FILTDEF_STRING(ifilt_col:ifilt_col)

       write(6,660)  & 
            R4EP_ALL(ep_row,JEP_TREST), cfilt_row,  & 
            R4EP_ALL(ep_col,JEP_TREST), cfilt_col,  & 
            COVTMP8,  & 
            R8EP_MJD(irow), R8EP_MJD(icol)
660      format(T3,'COVMAT[ ', F6.2, '(', A1, ')'  ,  & 
                F6.2, '(', A1, ') ] = ', F15.6 ,  & 
                4x,'MJD=', F9.3,','F9.3  & 
           )

302    CONTINUE
301    CONTINUE

    write(6,661) NFITDATA,  NFITDATA, NFITDATA*NFITDATA
661   format(T3,'COVMAT FULL-SIZE: ', I4,' x ', I4, ' = ', I8)

    write(6,662) NDMP
662   format(T3,'COVMAT Number of non-zero elements: ', I8)

    RETURN
  END SUBROUTINE DMP_COVAR

! ========================================
    SUBROUTINE DMP_SNMJD_INTERP(IFLAG,OPTMJD)
! 
! For specified MJDs, write MAG(obs & rest) , FLUX & KCOR
! to special dump file. List has been read from
! SNMJD_LIST_FILE. Output file has same name as input,
! but with .OUT extension.
! 
! March 24, 2008:
!       Add OPTMJD (see below)
! 
! May 28, 2008: fix dumb bug so that PEAKMJD dump happens only once.
! 
! May 18, 2012: use new GET_INTERP_MJDLIST utility
! Aug 15, 2012: protect printing info for undefined IFILT_OBS.
! 
! Jul 31 2015: write fitres [column] format to make it easier to parse.
! 
! Nov 19 2019: remove NVAR key
! Dec 04 2019: remove obsolete IFILTOBS_RST to avoid negative index
! 
! ------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML
    USE INTERPCM

    IMPLICIT NONE

! IFLAG = 0 => open output file
! IFLAG > 0 => update file with SN if MJD is specified
! IFLAG < 0 => close file.

    INTEGER  & 
         IFLAG       &  ! (I) SN sparse index
        ,OPTMJD         ! (I) 0=>use PEAKMJD, 1=> use MJD from file.

! local args

    INTEGER  LTMP, imjd, NMJD, ipar, IFILT, IFILT_OBS

    REAL*8  & 
         MJD8, MJD8_LAST, MJD8LIST(MXINTERP)  & 
        ,FLUX8, FLUX8ERR, MAG8, MAG8ERR, KCOR8

    REAL  & 
          TOBS, TREST, PKMJD  & 
         ,FLUXOBS_INTERP(MXFILT_ALL)  & 
         ,FLUXERROBS_INTERP(MXFILT_ALL)  & 
         ,MAGOBS_INTERP(MXFILT_ALL)  & 
         ,MAGERROBS_INTERP(MXFILT_ALL)  & 
         ,KCOR_INTERP(MXFILT_ALL)  & 
         ,VAL, ERR

    CHARACTER CCID*(MXCHAR_CCID), BAND*2
    LOGICAL LDMP,  ADDFLAG

! ------------ BEGIN -----------

! negative IFLAG => end of program
    IF ( IFLAG < 0 ) THEN
      CLOSE ( UNIT = LUNINTERP  )
      RETURN
    ENDIF

    PKMJD = LCVAL_STORE(IPAR_PEAKMJD) + sngl(MJDOFF)

! open output file.
    IF ( IFLAG .EQ. 0 ) THEN

      GLOBAL_BANNER = "OPEN TEXT-FILE TO DUMP INTERPOLATED MAGS"
      CALL PRBANNER (GLOBAL_BANNER )

      LTMP = INDEX ( SNMJD_LIST_FILE, ' ' ) - 1

      if ( SNMJD_OUT_FILE .EQ. ' ' ) then
        SNMJD_OUT_FILE = SNMJD_LIST_FILE(1:LTMP) // '.OUT'
      endif

      LTMP = INDEX ( SNMJD_OUT_FILE, ' ' ) - 1
      OPEN(UNIT= LUNINTERP, FILE=SNMJD_OUT_FILE,  & 
               STATUS='UNKNOWN', ERR=92)

      write(6,90) SNMJD_OUT_FILE(1:LTMP)
90      format(T5,'Open MAG-interp file : ', A)
      print*,' '

      WRITE(LUNINTERP,40) 'Interpolation Results at MJD_INTERP'
      WRITE(LUNINTERP,402)
402     FORMAT('VARNAMES: CID BAND MJD_INTERP MAG MAGERR '  & 
                         'FLUX FLUXERR TOBS TREST' )

      RETURN

    ENDIF  ! end of IFLAG = 0 block

! ----------------------------------
! search MJD(s) for this SN:

    CCID = SNLC_CCID
    CALL GET_INTERP_MJDLIST(CCID, NMJD, MJD8LIST, ADDFLAG)

    MJD8_LAST = -9.0

    DO 200 imjd = 1, NMJD

      IF ( OPTMJD .EQ. 1 ) THEN
         MJD8 = MJD8LIST(imjd)
      ELSE
         MJD8 = PKMJD
      endif

! avoid repeating an MJD ... mainly to avoid multiple PEAKMJD entries.
      IF ( MJD8 .EQ. MJD8_LAST ) GOTO 200


! get observer mags,flux,kcor at this MJD

      DO IFILT = 1, NFILTDEF_SURVEY
        ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)

        if ( USE_FILT(ifilt_obs) ) then

           CALL MODELMAG_CALC(ifilt_obs, 'OBS', MJD8,  & 
                 FLUX8, FLUX8ERR, MAG8, MAG8ERR, KCOR8 ) ! return args

           FLUXOBS_INTERP(ifilt_obs)    = SNGL(FLUX8)
           FLUXERROBS_INTERP(ifilt_obs) = SNGL(FLUX8ERR)
           MAGOBS_INTERP(ifilt_obs)     = SNGL(MAG8)
           MAGERROBS_INTERP(ifilt_obs)  = SNGL(MAG8ERR)
           KCOR_INTERP(ifilt_obs)       = SNGL(KCOR8)

        endif
      ENDDO
! -------------------------
! write results to output file.

      TOBS = SNGL(MJD8 - PKMJD)
      TREST = TOBS / ( 1.0 + REDSHIFT_FIT )

      if ( MJD8 < 1.0 ) GOTO 4000

      write(LUNINTERP,40) ' '
40      format('# ', A)
      DO 1400 IFILT = 1, NFILTDEF_SURVEY
        ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
        BAND      = FILTDEF_STRING(ifilt_obs:ifilt_obs)
        if ( .not. USE_FILT(ifilt_obs) ) GOTO 1400


         write(LUNINTERP,405)  & 
             CCID(1:ISNLC_LENCCID),  & 
             BAND, MJD8,  & 
             MAGOBS_INTERP(ifilt_obs),  MAGERROBS_INTERP(ifilt_obs),  & 
             FLUXOBS_INTERP(ifilt_obs), FLUXERROBS_INTERP(ifilt_obs),  & 
             TOBS, TREST

405        format('INTERP: ',  & 
                A, 1x, A1, 1x, F9.3,    &  ! CCID, BAND, MJD8
                2x, 2F7.3,                &  ! MAG MAGERR
                2x, 2G10.4,               &  ! FLUX FLUXERR
                2F7.2                     &  ! TOBS TREST
                   )

1400    CONTINUE

      MJD8_LAST = MJD8

200   CONTINUE  ! end of main SNMJD loop

    IF( OPTMJD > 0 ) GOTO 6000

! --------------------

4000  CONTINUE

! Write out the fit parameters
! Make sure to write out PEAKMJD even if it's fixed.

    LTMP = INDEX(FITMODEL_VERSION,' ') - 1
    write(LUNINTERP,410)  & 
          FITMODEL_VERSION(1:LTMP), CCID(1:ISNLC_LENCCID)
410   format(/,T4,A,' FIT-PARAMETERS for ',A, ': ' )

    DO 400 ipar = 1, NFITPAR_MN

       LDMP = FLOATPAR(ipar)  & 
           .or. IPAR.EQ. IPAR_PEAKMJD  & 
           .or. IPAR.EQ. IPAR_zPHOT

       if ( .not. LDMP ) goto 400

       VAL = FITVAL_STORE(ipar)
       ERR = FITERR_STORE(ipar)

       if ( IPAR .EQ. IPAR_PEAKMJD ) VAL = VAL + SNGL(MJDOFF)

       LTMP = INDEX ( PARNAME_STORE(ipar), ' ' ) - 1
       write(LUNINTERP,420) PARNAME_STORE(ipar)(1:LTMP), VAL, ERR

420      format(T10,A,'= ', T20, G12.3, ' +- ', G10.3 )

400   CONTINUE
    write(LUNINTERP,40)  & 
        '========================================================='
! ---------------------------

6000  CONTINUE
    CALL FLUSH(LUNINTERP)
    RETURN

! ----------------------------------
92    CONTINUE
    c1err = 'Could not open MAG-INTERP output file '
    c2err = SNMJD_OUT_FILE(1:80)
    CALL MADABORT("DMP_SNMJD_INTERP", c1err, c2err)

    RETURN
  END SUBROUTINE DMP_SNMJD_INTERP


! ===============================
    SUBROUTINE PREP_FITRES_TABLEVAR()

! Created Sep 2012 by R.Kessler
! Prepare some FITRES table variables.
! 
! Apr 29, 2013: fill CWNT_COV
! May 14 2014: overhaual using keep, TABLEVARCOM.
! 
! 

    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE TABLEVARCOM
    USE SNLCINP_NML
! CDE,CWNTCOM.

    INTEGER  i, ifilt, ifilt_obs, iep, ipar, ipar1, ipar2, ICOV, ITER
    LOGICAL NONSURVEY
    REAL RHO, COV
    REAL*8 PKMJD8, XTMW

! --------------- BEGIN -------------

    ITER    = NFIT_ITERATION
    PKMJD8  = FITVAL(IPAR_PEAKMJD,ITER)
    CALL LOAD_EPALL(ITER,PKMJD8)

! ----------------------------------
! load MINUIT reduced correlation matrix into linear array

    do ipar = 1, MXCOV_TBL
       TBL_COV(ipar)    = -999.
       TBL_REDCOV(ipar) = -999.
    enddo

    DO 100 ICOV = 1, NCOV_TBL

       IPAR1 = IPAR_TBL_COV(1,ICOV)
       IPAR2 = IPAR_TBL_COV(2,ICOV)

       if ( NGRID_PDF .LE. 0 ) then
          RHO = SNGL( FITCORMAT(ipar1,ipar2) )
          COV = SNGL( FITERRMAT(ipar1,ipar2) )
       else
          RHO = SNGL( PDFCORMAT(ipar1,ipar2) )
          COV = SNGL( PDFERRMAT(ipar1,ipar2) )
       endif

       TBL_COV(ICOV)    = COV
       TBL_REDCOV(ICOV) = RHO

 100  CONTINUE


! fill SNRMAX and XTMW arrays with only fitted bands.

    DO ifilt     = 1, NFILTDEF_SURVEY
       TBL_XTMW(ifilt)   = -999.
       TBL_SNRMAX(ifilt) = -999.
    ENDDO

    DO 200 i     = 1, NFILTOBS_TABLE
       ifilt_obs = IFILTOBS_MAP_TABLE(i)
       ifilt     = IFILT_MAP_TABLE(i)

       if ( use_filt(ifilt_obs) ) then
          iep   = I4BAND_EP_NEARPEAK(ifilt_obs)

          NONSURVEY = LFILTDEF_NONSURVEY(ifilt_obs)
          if ( NONSURVEY ) iep = 1 ! avoid -9999 index

!           print*,' xxx iep,ifilt, ifiltobs = ', iep, ifilt, ifilt_obs

          if ( iep > 0 ) then
             XTMW          = R4EP_ALL(iep,JEP_MWXT)        ! mag
             TBL_XTMW(i)   = SNGL(10**(-0.4*XTMW))         ! flux-frac
             TBL_SNRMAX(i) = R4BAND_SNRMAX_FIT(ifilt)
          endif
       endif
200   CONTINUE

    RETURN
  END SUBROUTINE PREP_FITRES_TABLEVAR


! ========================================
    SUBROUTINE TEST_TRANSFORM(Z4)
! 
! Test rest->observer frame transformation.
! For well-defined filter set, this transformation
! is simply a K-correction on a warped spectrum.
! For John's color transformation, it's a little more
! complicated.
! 


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML

    IMPLICIT NONE


    REAL*4  Z4  ! (I) redshift

!  local args

    REAL*4  LMIN4

    INTEGER  & 
         ifilt_obs  & 
        ,ifilt_rest1  & 
        ,ifilt_rest2  & 
        ,OPT

    REAL*8  & 
         T8, Z8, FLux8, MAG8, WAVECOR  & 
        ,DELTA8(2), AV8, MWEBV8, DLMAG8  & 
        ,AVwarp8, KCOR8(2), XTAV, XTMW,MAGERR8, RVMW8

    LOGICAL LDMP / .FALSE. /

! functions
    REAL*8 USRFUN
    INTEGER NEAREST_IFILTDEF_WRAPPER

! -------------- BEGIN ------------

    CALL PRBANNER("TEST REST -> OBSERVER TRANSFORMATION")

    Z8     = DBLE(Z4)

    T8        = ZERO8
    DELTA8(1) = ZERO8
    DELTA8(2) = ZERO8
    AV8       = INIVAL_AV
    MWEBV8    = ZERO8
    RVMW8     = DBLE(RV_MWCOLORLAW)
    DLMAG8    = ZERO8
    WAVECOR   = ZERO8

    print*,' Z=',Z4,'  Trest=',sngl(T8),'   AV=',sngl(AV8)
    print*,' MWE(B-V)=', sngl(MWEBV8), '   DLMAG=',sngl(DLMAG8)

    print*,' IFILTDEF_MAP_SURVEY = ', IFILTDEF_MAP_SURVEY

!      write(6,18) MAG_REST_TEST
! 8    format(T3,'REST UBVRI mags: ', 5F8.4 )

    print*,' '

    DO ifilt_obs = 1,10

       OPT = OPT_FILTOBS
       ifilt_rest1 = NEAREST_IFILTDEF_WRAPPER(opt,ifilt_obs,  & 
                            1, Z4, LMIN4 )
       ifilt_rest2 = NEAREST_IFILTDEF_WRAPPER(opt,ifilt_obs,  & 
                            2, Z4, LMIN4 )

       FLUX8 =  & 
           USRFUN ( NFIT_ITERATION, ifilt_obs, Z8, T8, WAVECOR  & 
                   ,DELTA8, DLMAG8, AV8, RVMW8, MWEBV8, LDMP  & 
                   ,AVwarp8, KCOR8, XTAV, XTMW, MAGERR8 )    ! (O)

! c         MAG8 = -2.5*DLOG10(FLUX8/ADUSCALE)
       MAG8 = -2.5*DLOG10(FLUX8) + ZP_FLUXCAL

       write(6,20)  & 
           filtdef_string(ifilt_obs:ifilt_obs), MAG8  & 
          ,filtdef_string(ifilt_rest1:ifilt_rest1)  & 
          ,filtdef_string(ifilt_rest2:ifilt_rest2)  & 
          ,AVwarp8, KCOR8(1)

 20      format(T5,'obsMag(',A,')=',F8.4, 3x,  & 
                   'AVwarp(',A,'-',A,')=', F7.3 , 3x,  & 
                   'Kcor=',F7.3  & 
               )

    ENDDO

! -------------------------------

    RETURN
  END SUBROUTINE TEST_TRANSFORM

! ===========================
    SUBROUTINE SNLCPLOT()

! ---------------------------------------------
! Created Feb 2013 by R.Kessler
! 
! Pack light curve & best-fit function for snlc_fit.exe.
! Also pack optional info such as marginalized distributions.
! 
! ---------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE SNLCINP_NML
    USE FILTCOM
    USE FITRESTCOM

    IMPLICIT NONE

    INTEGER, PARAMETER :: MXEP_SNLCPAK = 10*MXEPOCH

    CHARACTER  CCID*(MXCHAR_CCID)

    REAL*8  & 
         VMJD(MXEP_SNLCPAK)      & 
        ,VTOBS(MXEP_SNLCPAK)     & 
        ,VFLUXOBS(MXEP_SNLCPAK)  & 
        ,VFLUXOBS_ERR(MXEP_SNLCPAK)  & 
        ,VFLUXREST(MXEP_SNLCPAK)   &  ! K-corrected rest-frame flux
        ,VKCOR(MXEP_SNLCPAK)  & 
        ,VAVWARP(MXEP_SNLCPAK)  & 
        ,VSIMFLUXREST(MXEP_SNLCPAK)  & 
        ,VSIMFLUXOBS(MXEP_SNLCPAK)    &  ! May 20 2016
        ,VZERO(MXEP_SNLCPAK)          &  ! zeros for true simFlux error
        ,VCHI2(MXEP_SNLCPAK)  & 
        ,VREJECT(MXEP_SNLCPAK)  & 
        ,VDUMERR(MXEP_SNLCPAK)   &  ! all zeros
        ,VBAND_NDOF(MXFILT_OBS)  & 
        ,VBAND_CHI2(MXFILT_OBS)  & 
        ,VBAND_PKFLUX(MXFILT_OBS)  & 
        ,VBAND_PKFLUX_ERR(MXFILT_OBS)  & 
        ,VBAND_PKMJD(MXFILT_OBS)  & 
        ,VBAND_PKMJD_ERR(MXFILT_OBS)  & 
! 
        ,COR, FPEAK, FPERR, PKMJD  & 
        ,TMIN, TMAX, TBIN, xi, TOBS, WAVECOR

    INTEGER  & 
         LENCCID, NOBS, i, ifilt, ifilt_obs, NFILT, NBT  & 
        ,NFILTARG, IFILTARG, IFILTARG_MAP_SURVEY(MXFILT_ALL), NDOF  & 
        ,IFILTOBS_REMAP, IFILT_REMAP_TMP  & 
        ,VFILTOBS(MXEP_SNLCPAK)  & 
        ,VFILTREST(MXEP_SNLCPAK)

    LOGICAL DO_RESTFLUX

! functions
    REAL*8 GET_FLUX_FITFUN
    LOGICAL DOPLOT_SNLC

! -------------------- BEGIN ---------------

! check if plot should be made
    IF ( .NOT. DOPLOT_SNLC() ) RETURN

    LENCCID = ISNLC_LENCCID
    CCID = SNLC_CCID(1:LENCCID) // char(0)
    NFILT = NFILTDEF_SURVEY

    write(6,10) SNLC_CCID(1:LENCCID)
 10   format(T10,'SNLCPAK: pack CID = ',A,' for plotting.')
    call flush(6)

    DO_RESTFLUX = ( LREST_FITMODEL .or. NFILTDEF_FITRESTMAG > 0 )

! generate text strings
    CALL SNLCPAK_DISPLAYTEXT_FIT()

! -------------------------------------------
! load data flux, reject flags, chi2 ...

    DO IFILT = 1, MXFILT_OBS
        VBAND_NDOF(IFILT)   = 0.0
        VBAND_CHI2(IFILT)   = 0.0
        VBAND_PKMJD(IFILT)  = 0.0
        VBAND_PKFLUX(IFILT) = 0.0
    ENDDO

    DO 100 IFILT = 1, NFILT
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)

       IFILTARG  = IFILT
       NFILTARG  = NFILT
       IFILTARG_MAP_SURVEY(IFILTARG) = IFILT_OBS

       IF ( NFILT_REMAP_TABLE > 0 ) THEN
         CALL FILTER_REMAP_FETCH(IFILT_OBS,    &  ! (I)
                     IFILTOBS_REMAP, IFILTARG)    ! (O)
         IFILTARG = IFILTARG + 1   ! C -> fortran
         NFILTARG = NFILT_REMAP_TABLE
         IFILTARG_MAP_SURVEY(IFILTARG) = IFILTOBS_REMAP
       ENDIF

       NDOF = int( XNFITDOF(IFILT) )
       IF ( NDOF == 0 ) GOTO 100  ! needed for REMAP filters

!  load each filter with the same PEAK-MJD value
       PKMJD                     = LCVAL_STORE(IPAR_PEAKMJD)
       VBAND_PKMJD(IFILTARG)     = PKMJD
       VBAND_PKMJD_ERR(IFILTARG) = LCERR_STORE(IPAR_PEAKMJD)
       VBAND_NDOF(IFILTARG)      = XNFITDOF(IFILT)     ! Ndof
       VBAND_CHI2(IFILTARG)      = LC_FITCHI2(IFILT)   ! chi2 per filter

! peak flux
       cor   =  PEAKFLUX_OBS_MODEL_COR(ifilt)
       Fpeak =  PEAKFLUX_OBS_MODEL(ifilt) * cor
       Fperr =  PEAKFLUX_OBS_MODEL_ERR(ifilt) * cor
       VBAND_PKFLUX(IFILTARG)     = Fpeak
       VBAND_PKFLUX_ERR(IFILTARG) = Fperr
 100  CONTINUE


! - - - - - - - - - - -

    NOBS = 0
    DO 101 i   = 1, NFITDATA + NFITDATA_REJECT

       NOBS = NOBS + 1

       IF ( NOBS .GT. MXEP_SNLCPAK ) THEN
          write(C1ERR,661) NOBS, MXEP_SNLCPAK
 661        format('NOBS=',I5,' exceeds bound of MXEP_SNLCMAX=',I5)
          c2err = 'Increase bound for data array.'
          CALL MADABORT('SNLCPLOT(SNFIT)', C1ERR, C2ERR)
       ENDIF

       IFILT_OBS       = I4EP_FIT(i,IEP_IFILT_OBS)
       VFILTOBS(NOBS)  = IFILT_OBS

! Dec 10 2017: check for filter-remap option
       IF ( NFILT_REMAP_TABLE > 0 ) THEN
         CALL FILTER_REMAP_FETCH(IFILT_OBS,             &  ! (I)
                     IFILTOBS_REMAP, IFILT_REMAP_TMP)    ! (O)
          VFILTOBS(NOBS)  = IFILTOBS_REMAP
       ENDIF

       VMJD(NOBS)           = R4EP_FIT(i,JEP_MJD) + MJDOFF
       VTOBS(NOBS)          = R4EP_FIT(i,JEP_TOBS)
       VFLUXOBS(NOBS)       = R4EP_FIT(i,JEP_DATAFLUX)
       VFLUXOBS_ERR(NOBS)   = R4EP_FIT(i,JEP_DATAFLUX_ERR)
!         VMODELFLUX(NOBS)     = R4EP_FIT(i,JEP_MODELFLUX)       ! Mar 2025
!         VMODELFLUX_ERR(NOBS) = R4EP_FIT(i,JEP_MODELFLUX_ERR)   ! Mar 2025
       VREJECT(NOBS)        = I4EP_FIT(i,IEP_REJECT)
       VCHI2(NOBS)          = R4EP_FIT(i,JEP_DELCHI2)
       VSIMFLUXOBS(NOBS)    = R4EP_FIT(i,JEP_SIM_FLUXCAL)  ! May 20 2016
       VZERO(NOBS)          = 0.0

       IF ( DO_RESTFLUX ) THEN
         VFILTREST(NOBS)    = I4EP_FIT(i,IEP_IFILT_REST1)
         VFLUXREST(NOBS)    = R4EP_FIT(i,JEP_DATAFLUX_REST)
         VKCOR(NOBS)        = R4EP_FIT(i,JEP_KCOR)
         VAVWARP(NOBS)      = R4EP_FIT(i,JEP_AVWARP)
         VSIMFLUXREST(NOBS) = R4EP_FIT(i,JEP_SIM_FLUXREST)
       ENDIF
 101  CONTINUE

    CALL SNLCPAK_DATA(CCID, NOBS, VMJD,VTOBS, VFLUXOBS, VFLUXOBS_ERR,  & 
           VFILTOBS, SNLCPAK_EPFLAG_FLUXDATA, LENCCID)

! store REJECT flags
    CALL SNLCPAK_DATA(CCID, NOBS, VMJD,VTOBS, VREJECT, VDUMERR,  & 
           VFILTOBS, SNLCPAK_EPFLAG_REJECT, LENCCID)

! store data-FITFUN chi2
    CALL SNLCPAK_DATA(CCID, NOBS, VMJD,VTOBS, VCHI2, VDUMERR,  & 
           VFILTOBS, SNLCPAK_EPFLAG_CHI2, LENCCID)

    IF ( LSIM_SNANA .or. LSIM_MAGOBS ) THEN
!      pack generated SIM fluxes (May 20 2016)
      CALL SNLCPAK_DATA(CCID, NOBS, VMJD, VTOBS,  & 
           VSIMFLUXOBS, VZERO,    &  ! VZERO = zero error for each true flux
           VFILTOBS, SNLCPAK_EPFLAG_FLUXSIM, LENCCID)
    ENDIF

! Jan 2014: store rest-frame filter and flux (mlcs,snoopy ...)
! Jan 2020: add KCOR and AVwarp

    IF ( DO_RESTFLUX ) THEN
      CALL SNLCPAK_DATA(CCID, NOBS, VMJD, VTOBS, VFLUXREST, VDUMERR,  & 
           VFILTREST, SNLCPAK_EPFLAG_FLUXREST, LENCCID)

      CALL SNLCPAK_DATA(CCID, NOBS, VMJD, VTOBS, VKCOR, VDUMERR,  & 
           VFILTREST, SNLCPAK_EPFLAG_KCOR, LENCCID)

      CALL SNLCPAK_DATA(CCID, NOBS, VMJD, VTOBS, VAVWARP, VDUMERR,  & 
           VFILTREST, SNLCPAK_EPFLAG_AVWARP, LENCCID)

      if ( LSIM_SNANA ) then
         CALL SNLCPAK_DATA(CCID, NOBS, VMJD, VTOBS,  & 
             VSIMFLUXREST, VDUMERR, VFILTREST,  & 
             SNLCPAK_EPFLAG_SIMFLUXREST, LENCCID)
      endif
    ENDIF

! store filter-dependent quantities.

    VMJD(1)  = -9999.
    VTOBS(1) = -9999.0  ! dummy for unused TOBS arg
    CALL SNLCPAK_DATA(CCID, NFILTARG, VMJD, VTOBS,  & 
           VBAND_NDOF, VDUMERR,  & 
           IFILTARG_MAP_SURVEY, SNLCPAK_BANDFLAG_NDOF, LENCCID)

    CALL SNLCPAK_DATA(CCID, NFILTARG, VMJD, VTOBS,  & 
           VBAND_CHI2, VDUMERR,  & 
           IFILTARG_MAP_SURVEY, SNLCPAK_BANDFLAG_CHI2, LENCCID)

    CALL SNLCPAK_DATA(CCID, NFILTARG, VMJD, VTOBS,  & 
         VBAND_PKFLUX,VBAND_PKFLUX_ERR,  & 
         IFILTARG_MAP_SURVEY, SNLCPAK_BANDFLAG_PKFLUX, LENCCID)

    CALL SNLCPAK_DATA(CCID, NFILTARG, VMJD, VTOBS,  & 
         VBAND_PKMJD,VBAND_PKMJD_ERR,  & 
         IFILTARG_MAP_SURVEY, SNLCPAK_BANDFLAG_PKMJD, LENCCID)

! ---------------------------------------
! load best-fit model

    NOBS = 0
    TMIN = -60.0
    TMAX = 140.0
    TBIN = DTOBS_MODEL_PLOT
    NBT  = int( (TMAX-TMIN+1.0E-6)/TBIN )

    DO 510 IFILT = 1, NFILT

       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       if ( .not. USE_FILT(ifilt_obs) ) goto 510

    DO 520 i  = 1, NBT
      NOBS    = NOBS + 1

       IF ( NOBS .GT. MXEP_SNLCPAK ) THEN
          write(C1ERR,661) NOBS, MXEP_SNLCPAK
          c2err = 'Increase bound for best-fit array.'
          CALL MADABORT('SNLCPLOT(SNFIT)', C1ERR, C2ERR)
       ENDIF

      xi      = float(i) - 0.5
      TOBS    = TMIN + TBIN * xi
      WAVECOR = 0.0  ! .xyz ??
      VFILTOBS(NOBS)      = IFILT_OBS
      VMJD(NOBS)          = TOBS + PKMJD + MJDOFF
      VTOBS(NOBS)         = TOBS
      VFLUXOBS(NOBS)      = GET_FLUX_FITFUN(ifilt_obs, Tobs,  WAVECOR,  0)
      VFLUXOBS_ERR(NOBS)  = GET_FLUX_FITFUN(ifilt_obs, Tobs,  WAVECOR, 60)

! Dec 10 2017: check for filter-remap option
      IF ( NFILT_REMAP_TABLE > 0 ) THEN
        CALL FILTER_REMAP_FETCH(IFILT_OBS,             &  ! (I)
                    IFILTOBS_REMAP, IFILT_REMAP_TMP)    ! (O)
        VFILTOBS(NOBS)  = IFILTOBS_REMAP
      ENDIF

       IF ( DO_RESTFLUX ) THEN
         VFILTREST(NOBS) = -9
         VFLUXREST(NOBS) = -999.
       ENDIF

 520  CONTINUE
 510  CONTINUE

    call flush(6)

    CALL SNLCPAK_DATA(CCID, NOBS, VMJD,VTOBS, VFLUXOBS, VFLUXOBS_ERR,  & 
           VFILTOBS, SNLCPAK_EPFLAG_FITFUN, LENCCID)

! fill output structure and write to disk
    CALL SNLCPAK_FILL(CCID, LENCCID)

! set global flag.
    MADE_LCPLOT = .TRUE.

    RETURN
  END SUBROUTINE SNLCPLOT

! ============================================
    SUBROUTINE SNLCPAK_DISPLAYTEXT_FIT()

! Create strings and pass them to generic wrapper SNLCPAK_DISPLAYTEXT()
! 


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM

    IMPLICIT NONE

    CHARACTER  & 
         CCID*(MXCHAR_CCID), TEXT_forC*80  & 
        ,CPAR*20, SPAR*20  & 
        ,cDIST*60, cZPH*60, cCHI2*60  & 
        ,cMAGDIF*28

    INTEGER  & 
         LENCCID, LENTEXT, LENc, LENs, LENDIST, LENZPH, LENCHI2  & 
        ,NDOF

    REAL*8  D, DERR, ZPH, ZPHERR, CHI2

    REAL*4 MAGVAL4, MAGERR4, PROB_MAGDIF4(2)

    LOGICAL LTMP

! -------------- BEGIN ------------

    LENCCID = ISNLC_LENCCID
    CCID = SNLC_CCID(1:LENCCID) // char(0)

    LENTEXT = LEN(TEXT_forC)

! ----------------------------------
! type and redshift
    write(TEXT_forC,40) ISNLC_TYPE,  & 
                      SNLC_REDSHIFT, SNLC_REDSHIFT_ERR
 40   format('TYPE = ', I3, 5x,'z = ', F5.3,' +- ', F5.3 )


! tack on optional FITMAGDIF result (May 2013)
    LTMP = FILTER_FITMAGDIF .NE. ''
    CALL GET_FITMAGDIF(MAGVAL4, MAGERR4, PROB_MAGDIF4 )
    IF ( LTMP .and. MAGERR4 .GE. 0.0 ) THEN
       write(cMAGDIF,44) FILTER_FITMAGDIF, MAGVAL4, MAGERR4
44       format('DELTA',A1,' = ', F5.2, ' +-',F5.2)
       TEXT_forC = TEXT_forC(1:50) // cMAGDIF
    ENDIF

! termination char
    TEXT_forC = TEXT_forC(1:LENTEXT-1) // char(0)

    CALL SNLCPAK_DISPLAYTEXT(CCID, TEXT_forC, LENCCID, LENTEXT )

! ----------------------------------
! color and stretch params
    CPAR = PARNAME_STORE(IPAR_COLOR) ;  LENc = INDEX(CPAR, ' ') - 1
    SPAR = PARNAME_STORE(IPAR_SHAPE) ;  LENs = INDEX(SPAR, ' ') - 1
    write(TEXT_forC,41)  & 
          CPAR(1:LENc)  & 
         ,LCVAL_STORE(IPAR_COLOR), LCERR_STORE(IPAR_COLOR)  & 
         ,SPAR(1:LENs)  & 
         ,LCVAL_STORE(IPAR_SHAPE), LCERR_STORE(IPAR_SHAPE)  & 
         ,char(0)
 41   format(A,' = ',F6.3, ' +-', F6.3, 5x,  & 
             A,' = ',F6.3, ' +-', F6.3, A)
    CALL SNLCPAK_DISPLAYTEXT(CCID, TEXT_forC, LENCCID, LENTEXT )

! ---------------------------------
! now distance (MU and or PHOTOZ) and chi2

    cDIST = ''  ; LENDIST = 0
    cZPH  = ''  ; LENZPH  = 0
    cCHI2 = ''  ; LENCHI2 = 0

    if ( INISTP(IPAR_DLMAG) > 0.0 ) then
       D    = LCVAL_STORE(IPAR_DLMAG)  ! MU or x0
       DERR = LCERR_STORE(IPAR_DLMAG)  ! error on above
       if ( D < 0.01 ) then  ! x0 in units of E-4
          write(cDIST,51) 10000.*D, 10000.*DERR
          LENDIST = INDEX(cDIST,'E') + 2
       else if ( D < 2.0 ) then ! x0 in units of E-2
          write(cDIST,52) 100.*D, 100.*DERR
          LENDIST = INDEX(cDIST,'E') + 2
       else  ! it's MU
          write(cDIST,55) D, DERR
          LENDIST = INDEX(cDIST,'+') + 7
       endif
 51      format( 'x0 = ('F6.3, ' +-', F6.3, ')xE-4'  )
 52      format( 'x0 = ('F6.3, ' +-', F6.3, ')xE-2'  )
 55      format( 'mu = ',F6.3, ' +-', F6.3  )
    endif

    if ( INISTP(IPAR_zPHOT) > 0.0 ) then
       ZPH    = LCVAL_STORE(IPAR_zPHOT)
       ZPHERR = LCERR_STORE(IPAR_zPHOT)
       write(cZPH,60) ZPH, ZPHERR
 60      format('zPHOT = ', F6.3, ' +-',F6.3 )
       LENZPH = INDEX(cDIST,'+') + 7
    endif

! and finall the chi2/dof
    CHI2 = LCCHI2_STORE(1)
    NDOF = INT( XNFITDOF(0))
    if ( CHI2 .LT. 999.99 ) then
      write(cCHI2,71) CHI2, NDOF
      LENCHI2 = 24
    else
      write(cCHI2,72) CHI2, NDOF
      LENCHI2 = 27
    endif
 71   format('chi2/dof = ',F5.1,' /', I5)
 72   format('chi2/dof = ',F8.1,' /', I5)



! glue the pieces together into one string.

    TEXT_forC = cDIST(1:LENDIST) // '   '  & 
               // cZPH(1:LENZPH)   // '   '  & 
               // cCHI2(1:LENCHI2) // char(0)

    CALL SNLCPAK_DISPLAYTEXT(CCID, TEXT_forC, LENCCID, LENTEXT )

    RETURN
  END SUBROUTINE SNLCPAK_DISPLAYTEXT_FIT



! =====================================================
! =====================================================

! routines need to create fitres table and NN table

! ========================================
    SUBROUTINE TABLE_SNFIT(ID,IFLAG)

! Created Feb 1, 2013
! Book and load table.
! 
! ID    = table identifier
! IFLAG = IFLAG_INI or IFLAG_ANA
! 
! 
!     HISTORY
! July 19 2016: call TABLE_STRING_TERMINATION(+1/-1)
!               to protect strings for ROOT.
! 
! Apr 18 2022: pass ID and IFLAG args
! -----------------------------------------



    USE SNDATCOM
    USE SNFITCOM

    IMPLICIT NONE

    INTEGER ID, IFLAG  ! (I)

! local var

    INTEGER LENTB, LENPG, LENFMT
    CHARACTER TBNAME*40, PGNAME*20, TEXTFMT*20, TEXTFMT_forC*20

! ----------------- BEGIN ------------------------

    IF ( IFLAG == IFLAG_INI ) THEN

       TBNAME   = 'FITRES' // char(0)
       LENTB    = INDEX(TBNAME,   ' ') - 1

       LENPG    = 12
       PGNAME   = PROGRAM_NAME_SNFIT(1:LENPG) // char(0)

       TEXTFMT  = TEXTFORMAT_TABLE(ITABLE_FITRES)
       LENFMT   = INDEX(TEXTFMT,' ') - 1
       TEXTFMT_forC = TEXTFMT(1:LENFMT) // char(0)

       CALL SNTABLE_CREATE(ID, TBNAME, PGNAME, TEXTFMT_forC, LENPG, LENPG, LENFMT)  ! C fun

       CALL INIT_TABLE_SNANAVAR(ID, 'SNANA', 2)
       CALL INIT_TABLE_SNFITVAR(ID, 'SNFIT'   )

!         optional epoch-dependent par
        IF ( OPT_TABLE(ITABLE_FITRES) .EQ. 2 ) THEN
           CALL INIT_TABLE_SNFITEP(ID, 'SNFITEP')
        ENDIF

!       for sims ...
        IF ( LSIM_SNANA ) THEN
          CALL INIT_TABLE_SIMVAR(ID, 'SIMVAR')
        ENDIF

      RETURN
    ENDIF

! ------------------------------------
!  fill table

    IF ( IFLAG == IFLAG_ANA ) THEN

!   terminate strings for C table-functions (snana.car routine)
      CALL TABLE_STRING_TERMINATION(+1)

      CALL SNTABLE_FILL(ID)  ! generic C function

      CALL TABLE_STRING_TERMINATION(-1)  ! remove termination
    END IF

! ------------------------------------

    RETURN
  END SUBROUTINE TABLE_SNFIT


! =====================================
    SUBROUTINE INIT_TABLE_SNFITVAR(ID,BLOCK)
! 
! Created Feb 1, 2013
! 
! Initialize variables for snfitres-analysis table.
! Call generic function SNTABLE_ADDCOL() that loads a table
! for each selected format: CERNLIB, ROOT, HDF5 ...
! The VARLIST string is constructed so that it trivially
! works for ROOT; will need extra parsing (in SNTABLE_ADDCOL)
! for root and hdf5.
! 
! This routine is intended to replace CWNT_HBNAMES_SNFITVAR()
! 
! 
! Nov 11 2019:
!  Protect adding non-PKMJD covariance columns if there aren't any
!  when stretch and color are both fixed instead of floated.
! 
! Mar 02 2022: add zPRIOR and zPRIOR_ERR
! Jan 10 2025: add FILTLIST_FIT_USE
! --------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML
    USE USRTAGCM
    USE TABLEVARCOM
    USE VMAXCOM
    USE FITIDEALCOM

    IMPLICIT NONE

    INTEGER   ID          ! (I) table id
    CHARACTER BLOCK*(*)   ! (I) name of BLOCK

! local var
    INTEGER, PARAMETER :: IPAR_START=3   ! skip ISN and ITER for CWN

    INTEGER IFILT, LENLIST, LENPKMJD, LENNAME, LENBLOCK
    INTEGER NTPAR_MIN, NTPAR_MAX, ipar, USE4TEXT

    CHARACTER varlist*1000, VARNAME*60, CBLOCK*40
    CHARACTER CFILT*1, SUFFIX_R*12, SUFFIX_I*12, PNAM*40

    LOGICAL  SKIPTABLE_FITPAR  ! function

    EXTERNAL  & 
          SNTABLE_ADDCOL  & 
         ,SNTABLE_ADDCOL_int  & 
         ,SNTABLE_ADDCOL_flt  & 
         ,SNTABLE_ADDCOL_dbl  & 
         ,SNTABLE_ADDCOL_str

! ---------------- BEGIN ------------

    write(6,10) BLOCK, ID
 10   format(T6,'Create BLOCK = ',A,'  for TABLE ID = ', I5)
    call flush(6)

    LENBLOCK = INDEX(BLOCK//' ',' ') - 1
    LENLIST  = LEN(VARLIST)
    CBLOCK   = BLOCK(1:LENBLOCK) // char(0)

! Jan 2025: add list of bands used in fit;
!   (40 should be enough for joint LSST+ROMAN+EUCLID)
    VARLIST = 'BANDLIST:C*40' // char(0)
    LENLIST = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_str(ID, CBLOCK, FILTLIST_FIT_USE,  & 
              VARLIST(1:LENLIST)//char(0), 1, LENBLOCK, 40 )

    VARLIST = 'OPT_PHOTOZ:I' // char(0)
    LENLIST = INDEX(VARLIST, ' ') - 1
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, OPT_PHOTOZ,  & 
         VARLIST(1:LENLIST)//char(0), 1, LENBLOCK, LENLIST )


! - - - - start with SNANA-analogs that could not be computed in snana

    CALL TABLE_VARLIST_FILTERS('SNRMAX','F',SURVEY_FILTERS_TABLE,  & 
              VARLIST, LENLIST)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBL_SNRMAX(1),  & 
                 VARLIST(1:LENLIST)//char(0),0, LENBLOCK, LENLIST )

    CALL TABLE_VARLIST_FILTERS('XTMW', 'F', SURVEY_FILTERS_TABLE,  & 
              VARLIST, LENLIST)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBL_XTMW(1),  & 
                 VARLIST(1:LENLIST)//char(0), 0, LENBLOCK, LENLIST )
    LENLIST = LEN(VARLIST)

! - - - - fit parameters and errors (skip BIDON values)

    NTPAR_MIN = IPAR_START
    NTPAR_MAX = IPAR_MAX

    DO 380 ipar = NTPAR_MIN, NTPAR_MAX
       VARNAME = PARNAME_STORE(ipar)
       LENNAME = INDEX(VARNAME,' ') - 1

       IF( SKIPTABLE_FITPAR(VARNAME) ) GOTO 380

       VARLIST = VARNAME(1:LENNAME)// ':F'   ! include cast
       LENLIST = INDEX(VARLIST,' ') - 1
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, LCVAL_STORE(ipar),  & 
              VARLIST(1:LENLIST)//char(0), 1, LENBLOCK, LENLIST)

! now the fitted error.
       VARLIST  = VARNAME(1:LENNAME) // 'ERR:F'
       LENLIST  = INDEX(VARLIST,' ') - 1
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, LCERR_STORE(ipar),  & 
              VARLIST(1:LENLIST)//char(0), 1, LENBLOCK, LENLIST)

 380  CONTINUE


! ----------------------------------------------------
! check for additional IDEAL fit with FLUX = TRUEFLUX

    IF ( SIMFIT_IDEAL_PRESCALE > 0  ) THEN
      DO 381 ipar = NTPAR_MIN, NTPAR_MAX
        VARNAME = PARNAME_STORE(ipar)
        LENNAME = INDEX(VARNAME,' ') - 1

        IF ( SKIPTABLE_FITPAR(VARNAME) ) GOTO 381

        VARLIST = VARNAME(1:LENNAME)// '_IDEAL:F'   ! include cast
        LENLIST = INDEX(VARLIST,' ') - 1
        CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, FITPAR_IDEAL(ipar),  & 
              VARLIST(1:LENLIST)//char(0), 1, LENBLOCK, LENLIST)
 381  CONTINUE

    ENDIF

! ----------------------------------------------------
! marginalized PDF-probs
    IF ( NGRID_PDF > 0 ) THEN

       DO 388 ipar = 3, IPAR_MAX  ! skip ISN and ITER
          PNAM    = PARNAME_STORE(IPAR)
          if ( PNAM(1:5) .EQ. 'BIDON' ) GOTO 388
          LENNAME = INDEX(PNAM,' ') - 1
          VARNAME = 'PDFPROB_' // PNAM(1:LENNAME) // ':F' // char(0)
          CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, PDFPROB2_STORE(IPAR),  & 
                 VARNAME, 0, LENBLOCK, 30)
 388    CONTINUE

    ENDIF

! - - - - -  ERRFLAGs - - - - - -

    CALL TABLE_VARLIST_ERRFLAG(NTPAR_MIN, NTPAR_MAX, VARLIST, LENLIST)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, ERRTYPE_STORE(NTPAR_MIN),  & 
              VARLIST(1:LENLIST)//char(0), 0, LENBLOCK, LENLIST)

! - - - - - -
! add Covariance status (Jan 2016) from MNSTAT call
!  MNSTAT_COV  = 2 -> was forced to be pos-definite
!              = 3 -> full accurate coc matrix
!  MNSTAT_COV  < 2 -> bad matrix and is rejected

    VARLIST = 'MNSTAT_COV:I' // char(0)
    LENLIST = LEN(VARLIST)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, MNSTAT_COV, VARLIST, 0,  & 
                         LENBLOCK, LENLIST)

! - - - - correlations - - - - - -

! reduced covariance (-1 <= RHO <=  +1)
    USE4TEXT = 0
    CALL TABLE_VARLIST_COV(1, VARLIST, LENLIST, LENPKMJD )
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBL_REDCOV(1),  & 
              VARLIST(1:LENLIST)//char(0), USE4TEXT, LENBLOCK,LENLIST)


! full covariance;
    CALL TABLE_VARLIST_COV(2, VARLIST, LENLIST, LENPKMJD )

! add PKMJD-covariances
    IF (LENPKMJD > 0 ) THEN
       USE4TEXT = 0
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBL_COV(1),  & 
              VARLIST(1:LENPKMJD)//char(0), USE4TEXT, LENBLOCK,LENPKMJD)
    ENDIF

! add other [non-PKMJD] covariances and include in optional text table.
! Make sure to skip the comma after the PKMJD-covariance list.
    IF ( LENLIST > LENPKMJD ) THEN
      USE4TEXT = 1
      CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBL_COV(NCOV_TBL_PKMJD+1),  & 
              VARLIST(LENPKMJD+2:LENLIST)//char(0),  & 
              USE4TEXT, LENBLOCK, LENLIST-LENPKMJD )
    ENDIF
! - - - - - -   PHOTOZ - - - - -

    LENLIST = LEN(VARLIST)

    IF ( DOFIT_PHOTOZ ) THEN

      VARLIST = 'zPRIOR:F' // char(0)
      CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, PRIOR_PHOTOZ, VARLIST,1,  LENBLOCK, LENLIST)
      VARLIST = 'zPRIORERR:F' // char(0)
      CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, PRIOR_PHOTOZ_ERR, VARLIST,1,  LENBLOCK, LENLIST)

      VARLIST = 'ZPULL:F' // char(0)
      CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, PHOTOZ_ERR_ZPULL,  VARLIST,0,  LENBLOCK, LENLIST)

      VARLIST = 'NEARDROP:I' // char(0)
      CALL SNTABLE_ADDCOL_int(ID, CBLOCK, IFILT_NEARDROP, VARLIST,0,  LENBLOCK, LENLIST)

      VARLIST = 'DZMIN1:F,DZMIN2:F' // char(0)
      CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, PHOTODZ_MIN(1),  VARLIST,0,  LENBLOCK, LENLIST)

      VARLIST = 'DZ1ZMIN1:F,DZ1ZMIN2:F' // char(0)
      CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, PHOTODZ1Z_MIN(1), VARLIST,0, LENBLOCK, LENLIST)

    ENDIF

! - - - - -  misc. variables - - - -

    DO 333 IPAR = IPAR_MAX+1, NPLOTPAR
       VARNAME  = PARNAME_STORE(ipar)
       LENNAME  = INDEX(VARNAME,' ') - 1
       VARLIST  = VARNAME(1:LENNAME)// ':F'   ! include cast
       LENLIST  = INDEX(VARLIST,' ') - 1
       USE4TEXT = PAROPT_STORE(ipar)

       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, LCVAL_STORE(ipar),  & 
              VARLIST(1:LENLIST)//char(0), USE4TEXT,  & 
               LENBLOCK, LENLIST )

 333  CONTINUE

! - - - - - - - - - - - - - - - - - - - -

    LENLIST = LEN(VARLIST)

! - - - - - NFILT used in fit - - - - -

    VARLIST = 'NFILT_USEFIT:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, NFILT_OBS_USEFIT,  & 
                    VARLIST, 0,     LENBLOCK, LENLIST)

! - - - - - Zmax for 1/Vmax option

    DO 404 IFILT = 1, NFILT_VMAX

       CFILT = FILTLIST_VMAX(IFILT:IFILT)
       SUFFIX_R = '_' // CFILT // ':F' // char(0)
       SUFFIX_I = '_' // CFILT // ':I' // char(0)

       VARLIST = 'mag_Vmax' // SUFFIX_R
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, MAG_LIST_VMAX(ifilt),  & 
              VARLIST, 0, LENBLOCK, LENLIST)

       VARLIST = 'Trest_Vmax' // SUFFIX_R
       CALL SNTABLE_ADDCOL_flt(ID,CBLOCK,TREST_LIST_VMAX(ifilt),  & 
                 VARLIST, 0, LENBLOCK, LENLIST)

       VARLIST = 'z_Vmax' // SUFFIX_R
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, z_LIST_VMAX(ifilt),  & 
                  VARLIST, 0, LENBLOCK, LENLIST)

       VARLIST = 'vol_Vmax' // SUFFIX_R
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, VOL_LIST_VMAX(ifilt),  & 
                VARLIST, 0, LENBLOCK, LENLIST)

       VARLIST = 'NEP_Vmax' // SUFFIX_I
       CALL SNTABLE_ADDCOL_int(ID, CBLOCK, NEP_LIST_VMAX(ifilt),  & 
              VARLIST, 0, LENBLOCK, LENLIST)

 404  CONTINUE

    RETURN
  END SUBROUTINE INIT_TABLE_SNFITVAR


! =====================================
    LOGICAL FUNCTION SKIPTABLE_FITPAR(VARNAME)

! Created Mar 2018
! Return TRUE if this variable should be suppressed
! from table output.
! 
! Jan 2024: check x2


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM

    IMPLICIT NONE

    CHARACTER VARNAME*(*)  ! (I) name of fitpar variable to check
    LOGICAL  SKIP

! ------------- BEGIN -------------
    SKIP = .FALSE.

    IF ( VARNAME(1:5) .EQ. 'BIDON'    ) SKIP = .TRUE.
    IF ( VARNAME(1:8) .EQ. 'REDSHIFT' ) SKIP = .TRUE.

    IF ( VARNAME(1:2) .EQ. 'x2' .and. NSHAPEPAR==1) SKIP = .TRUE.

    IF ( VARNAME(1:5) .EQ. 'zPHOT' ) THEN
      IF ( DOFIT_PHOTOZ )then
         SKIP = .TRUE.
      ENDIF
    ENDIF

    SKIPTABLE_FITPAR = SKIP
    RETURN
  END FUNCTION SKIPTABLE_FITPAR

! ========================================
    SUBROUTINE INIT_TABLE_SNFITEP(ID,BLOCK)

! Created Feb 2, 2013

! Init table for epoch-dependent variables.
! (replaces CWNT_HBNAMES_RESID)
! 
! Feb 22 2016: always do the extra EP variables, even for TERSE format.
!              See EXTRA_EPVAR
! 
! Jul 22 2017: add BAND (character for IFILT_OBS)
! Jan 23 2020: add AVWARP for rest-frame models with k-corrections
! 
! ----------------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FITRESTCOM

    IMPLICIT NONE

    INTEGER   ID          ! (I) table id
    CHARACTER BLOCK*(*)   ! (I) name of BLOCK (optional)

! local var

    INTEGER LENB, LENV
    CHARACTER CBLK*40, CNFIT*14, VARNAME*40
    LOGICAL EXTRA_EPVAR

    EXTERNAL  & 
          SNTABLE_ADDCOL_int  & 
         ,SNTABLE_ADDCOL_flt  & 
         ,SNTABLE_ADDCOL_dbl  & 
         ,SNTABLE_ADDCOL_str

! ---------------- BEGIN ----------------

    write(6,10) BLOCK, ID
 10   format(T6,'Create BLOCK = ',A,'  for TABLE ID = ', I5)
    call flush(6)

    LENV   = LEN(VARNAME)
    LENB   = INDEX(BLOCK//' ',' ') - 1
    CBLK   = BLOCK(1:LENB) // char(0)
! --------------------------------

    write(CNFIT,15) MXFIT_DATA
15    format('NPTFIT[',I4.4,']' )  ! no spaces or commas in string
    VARNAME = CNFIT(1:12)  // char(0)  ! Nobs used in fit + NREJECT
    CALL SNTABLE_ADDCOL_int(ID, CBLK, NFITDATA_TOTAL,  & 
           VARNAME, 0, LENB,LENV)

    VARNAME = 'REJECT(NPTFIT):I' // char(0)  ! 1 -> rejected from fit
    CALL SNTABLE_ADDCOL_int(ID,CBLK, I4EP_FIT(1,IEP_REJECT),  & 
            VARNAME, 0, LENB,LENV)

    VARNAME = 'MJD(NPTFIT):F'  // char(0)   ! MJD
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_MJD),  & 
              VARNAME, 0, LENB, LENV)

    VARNAME = 'TOBS(NPTFIT):F'  // char(0)     ! MJD - PEAKMJD
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_TOBS),  & 
              VARNAME, 0, LENB, LENV)

    VARNAME = 'TREST(NPTFIT):F'  // char(0)  ! Tobs/(1+z)
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_TREST),  & 
               VARNAME, 0, LENB,LENV)

    VARNAME = 'IFILTOBS(NPTFIT):I' // char(0)  ! abs. obs-frame filter indx
    CALL SNTABLE_ADDCOL_int(ID,CBLK, I4EP_FIT(1,IEP_IFILT_OBS),  & 
            VARNAME, 0, LENB,LENV)

    VARNAME = 'FLUXCAL_DATA(NPTFIT):F' // char(0)  ! FLUXCAL, data
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_DATAFLUX),  & 
              VARNAME, 0, LENB,LENV)

    VARNAME = 'FLUXCAL_DATA_ERR(NPTFIT):F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_DATAFLUX_ERR),  & 
              VARNAME, 0, LENB,LENV)

    VARNAME = 'FLUXCAL_MODEL(NPTFIT):F' // char(0)  ! fluxcal from best-fit
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_MODELFLUX),  & 
              VARNAME, 0, LENB,LENV)

    VARNAME = 'FLUXCAL_MODEL_ERR(NPTFIT):F' // char(0)  ! error on above
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_MODELFLUX_ERR),  & 
              VARNAME, 0, LENB,LENV)

    VARNAME = 'MODELMAG_ERR(NPTFIT):F' // char(0)  ! model error, mag
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_MODELMAG_ERR),  & 
             VARNAME, 0, LENB,LENV)

    VARNAME = 'FUDGEFLUX_ERR(NPTFIT):F' // char(0) ! fudge error on flux
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_FUDGEFLUX_ERR),  & 
              VARNAME, 0, LENB,LENV)

    VARNAME = 'LAMREST(NPTFIT):F' // char(0)  ! <lam_obs>/(1+z)
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_LAMREST),  & 
             VARNAME, 0, LENB,LENV)

    VARNAME = 'FLUXDIF(NPTFIT):F' // char(0)  ! data-model flux dif
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_RESID),  & 
            VARNAME, 0, LENB,LENV)

    VARNAME = 'FLUXDIF_ERR(NPTFIT):F' // char(0)  ! dif err,include model err
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_RESID_ERR),  & 
             VARNAME, 0, LENB,LENV)

    VARNAME = 'MAGDIF(NPTFIT):F' // char(0)  ! data-model magDif
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_MAGDIF),  & 
             VARNAME, 0, LENB,LENV)

    VARNAME = 'CHI2FLUX(NPTFIT):F' // char(0)  ! (DIF/DIF_ERR)**2
    CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_DELCHI2),  & 
             VARNAME, 0, LENB,LENV)


    IF ( LSIM_SNANA .or. LSIM_MAGOBS ) THEN
       VARNAME = 'FLUXCAL_SIM(NPTFIT):F' // char(0)
       CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SIM_FLUXCAL),  & 
              VARNAME, 0, LENB,LENV)

       VARNAME = 'CHI2FLUX_SIM(NPTFIT):F' // char(0)
       CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SIM_DELCHI2),  & 
              VARNAME, 0, LENB,LENV)
    ENDIF

! extra 'observing' variables

    EXTRA_EPVAR = .TRUE.
    IF ( EXTRA_EPVAR ) THEN
      VARNAME = 'PSF(NPTFIT):F' // char(0)  ! PSF-sigma arcsec
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_PSF),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'NEA(NPTFIT):F' // char(0)  ! noise-equiv-area, asec^2
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_NEA),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'SKYSIG(NPTFIT):F' // char(0)  ! sky noise per pixel
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SKYSIG),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'SKYSIG_T(NPTFIT):F' // char(0)  ! templ noise per pixel
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SKYSIG_T),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'ZP(NPTFIT):F' // char(0)  ! zeropoint, FLUX(ADU) to mag
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_ZP),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'ZP_ERR(NPTFIT):F' // char(0)  ! error on above
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_ZPERR),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'GAIN(NPTFIT):F' // char(0)  ! e/ADU
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_GAIN),  & 
             VARNAME, 0, LENB,LENV)

      if ( SNLC_NXPIX > 0 ) then
         VARNAME = 'XPIX(NPTFIT):F' // char(0)
         CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_XPIX),  & 
                VARNAME, 0, LENB,LENV)

         VARNAME = 'YPIX(NPTFIT):F' // char(0)
         CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_YPIX),  & 
                VARNAME, 0, LENB,LENV)

         VARNAME = 'AREAFRAC(NPTFIT):F' // char(0)
         CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_AREAFRAC),  & 
                VARNAME, 0, LENB,LENV)
      endif

      VARNAME = 'SKYFLUXCAL(NPTFIT):F' // char(0)  ! FLUXCAL(SKY)/pix
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SKYFLUXCAL),  & 
             VARNAME, 0, LENB,LENV)

      VARNAME = 'SBFLUXCAL(NPTFIT):F' // char(0)  ! host surf. bright/asec^2
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SBFLUXCAL),  & 
               VARNAME, 0, LENB,LENV)

      VARNAME = 'ERRTEST(NPTFIT):F' // char(0)  ! calc/true error ratio
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_ERRTEST),  & 
              VARNAME, 0, LENB,LENV)

      VARNAME = 'FLUXERRCALC_SIM(NPTFIT):F' // char(0)  ! calc error
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_ERRCALC),  & 
              VARNAME, 0, LENB,LENV)

      VARNAME = 'PHOTPROB(NPTFIT):F' // char(0)  ! Dec 17, 2014
      CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_PHOTPROB),  & 
              VARNAME, 0, LENB,LENV)

    ENDIF

! optionl rest-frame info for rest-frame model

    IF ( LREST_FITMODEL .or. NFILTDEF_FITRESTMAG > 0 ) THEN
       VARNAME = 'IFILTREST1(NPTFIT):I' // char(0)  ! nearest IFILT_REST
       CALL SNTABLE_ADDCOL_int(ID,CBLK,I4EP_FIT(1,IEP_IFILT_REST1),  & 
               VARNAME, 0, LENB, LENV)

       VARNAME = 'IFILTREST2(NPTFIT):I' // char(0)  ! 2nd nearest IFILT_REST
       CALL SNTABLE_ADDCOL_int(ID,CBLK,I4EP_FIT(1,IEP_IFILT_REST2),  & 
               VARNAME, 0, LENB, LENV)

       VARNAME = 'AVWARP(NPTFIT):F' // char(0)  ! AVwarp for kcor
       CALL SNTABLE_ADDCOL_flt(ID,CBLK,R4EP_FIT(1,JEP_AVWARP),  & 
               VARNAME, 0, LENB,LENV)

       VARNAME = 'KCOR(NPTFIT):F' // char(0)  ! k correction
       CALL SNTABLE_ADDCOL_flt(ID,CBLK,R4EP_FIT(1,JEP_KCOR),  & 
               VARNAME, 0, LENB,LENV)

       VARNAME = 'FLUXCAL_REST(NPTFIT):F' // char(0)
       CALL SNTABLE_ADDCOL_flt(ID,CBLK,R4EP_FIT(1,JEP_DATAFLUX_REST),  & 
               VARNAME, 0, LENB,LENV)

       IF ( LSIM_SNANA ) THEN
         VARNAME = 'SIM_FLUXCAL_REST(NPTFIT):F' // char(0)
         CALL SNTABLE_ADDCOL_flt(ID,CBLK,R4EP_FIT(1,JEP_SIM_FLUXREST),  & 
                VARNAME, 0, LENB,LENV)

         VARNAME = 'SIM_MAGREST(NPTFIT):F' // char(0)
         CALL SNTABLE_ADDCOL_flt(ID,CBLK, R4EP_FIT(1,JEP_SIM_MAGREST),  & 
                VARNAME, 0, LENB,LENV)
       ENDIF

    ENDIF

    RETURN
  END SUBROUTINE INIT_TABLE_SNFITEP

! ======================
    SUBROUTINE TABLE_VARLIST_ERRFLAG(IPAR_MIN,IPAR_MAX, VARLIST,LENLIST )

! Created Sep 2012
! Return VARLIST string for HBNAME call to initialize ERRFLAGs.
! 
! ----------------------------

! subroutine args


    USE SNDATCOM
    USE SNANAFIT

    IMPLICIT NONE

    INTEGER IPAR_MIN, IPAR_MAX  ! (I) IPAR range
    CHARACTER VARLIST*(*)       ! (O) comma-separate par-name list
    INTEGER   LENLIST           ! (O) length of VARLIST

! local var

    INTEGER ipar,  LENNAME
    character CTMP*20, C2*2, NAME*40

! ----------- BEGIN ------------

    do ipar = IPAR_MIN, IPAR_MAX

       write(c2,22) ipar
22     format(I2.2)

       NAME    = PARNAME_STORE(IPAR)
       LENNAME = INDEX(NAME,' ') - 1

       CTMP = 'ERRFLAG_' // NAME(1:LENNAME) // ':I'

       if ( ipar  .EQ. IPAR_MIN ) then
          VARLIST = CTMP
       else
          LENLIST = INDEX(VARLIST,' ') - 1
          VARLIST = VARLIST(1:LENLIST) // ',' // CTMP
       endif
    enddo

    LENLIST = INDEX(VARLIST,' ') - 1

    RETURN
  END SUBROUTINE TABLE_VARLIST_ERRFLAG

! =======================================================
    SUBROUTINE TABLE_VARLIST_COV(FLAGCOV,VARLIST,LENLIST,LENPKMJD)

! Created Sep 2012
! Return covariance VARLIST to pass to SNTABLE_ADDCOL().
! 
! Input:
!   FLAGCOV   = 1, 2 --> reduced, full covariance
! 
! Outputs:
!   VARLIST  = string to pass to SNTABLE_ADDCOL.
!   LENLIST  = length of entire varlist
!   LENPKMJD = length of sub-list with only the PKMJD elements.
! 
! In addition to return arguments, the following globals
! are also computed to help evaluate the COV arrays needed
! to fill the SNTABLE(s).
! 
!   NCOV_TBL, NCOV_TBL_PKMJD, IPAR_TBL_COV
! 
! 
!          HISTORY
!        ~~~~~~~~~~~
! 
! Apr 29 2013: RHO -> REDCOV and replace IPAR with PARNAME_STORE
!              e.g., RHO34 -> REDCOV_pkmjd_x1
! 
! May 13 2014:
!   - remove terms with BIDON and add FLAGPKMJD flag.
!   - overhaul using new keep, TABLEVARCOM.
! 
! Mar 19 2018: check SKIP_ZPHOT option
! 
! ------------------------------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITPAR
    USE TABLEVARCOM

    IMPLICIT NONE

    INTEGER   FLAGCOV              ! (I)
    CHARACTER VARLIST*(*)          ! (O)
    INTEGER   LENLIST, LENPKMJD    ! (O)

! local args

    INTEGER IPAR1, IPAR2,  LENNAME, LEN1, LEN2
    character ctmp*60, NAM1*40, NAM2*40
    LOGICAL SKIP_ZPHOT

! -------------------- BEGIN ----------------

    LENLIST  = 0
    LENPKMJD = 0

    NCOV_TBL = 0  ;  NCOV_TBL_PKMJD = 0
    SKIP_ZPHOT = .FALSE.

    DO 21 ipar1 = IPAR_PEAKMJD, IPAR_MAX-1  ! start with PEAKMJD
       if ( .not. FLOATPAR(ipar1) ) GOTO 21
       if ( IPAR1 .EQ. IPAR_ZPHOT .and. SKIP_ZPHOT) goto 21

    DO 22 ipar2 = ipar1+1, IPAR_MAX
       if ( .not. FLOATPAR(ipar2) ) GOTO 22
       if ( IPAR2 .EQ. IPAR_ZPHOT .and. SKIP_ZPHOT) goto 22

       NAM1 = PARNAME_STORE(ipar1) ; LEN1 = INDEX(NAM1,' ') - 1
       NAM2 = PARNAME_STORE(ipar2) ; LEN2 = INDEX(NAM2,' ') - 1

       if ( NAM1(1:5) .EQ. 'BIDON' ) GOTO 22
       if ( NAM2(1:5) .EQ. 'BIDON' ) GOTO 22
       if ( NAM2(1:5) .EQ. 'PKMJD' ) GOTO 22

       IF ( FLAGCOV .EQ. 1 ) THEN
          write(ctmp,30) 'REDCOV', NAM1(1:LEN1), NAM2(1:LEN2)
       ELSE
          write(ctmp,30) 'COV',    NAM1(1:LEN1), NAM2(1:LEN2)
       ENDIF

30       format( A, '_', A, '_', A )

       LENNAME   = INDEX(Ctmp,' ') - 1
       LENLIST   = INDEX(VARLIST,' ') - 1
       NCOV_TBL  = NCOV_TBL + 1
       IPAR_TBL_COV(1,NCOV_TBL) = IPAR1
       IPAR_TBL_COV(2,NCOV_TBL) = IPAR2

       if ( NCOV_TBL .EQ. 1 ) then
          VARLIST = CTMP(1:LENNAME) // ':F'
       else
          VARLIST = VARLIST(1:LENLIST) // ',' //  & 
                 CTMP(1:LENNAME) // ':F'
       endif

       if ( IPAR1 .EQ. IPAR_PEAKMJD ) then
          NCOV_TBL_PKMJD = NCOV_TBL_PKMJD + 1
          LENPKMJD = INDEX(VARLIST,' ') - 1
       endif

22    CONTINUE
21    CONTINUE

    LENLIST = INDEX(VARLIST,' ') - 1

    RETURN
  END SUBROUTINE TABLE_VARLIST_COV


! ===================================================
    SUBROUTINE TABLE_DMPFCN(isn)
! 
! Created Jan 2025
! *** FIT DEBUG UTILITY ***
! Prepare table to dump FCN chi2 info per fit step.
! Beware that the output is huge, so use this only for a few events.
! 
! -------------------------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FILTCOM
    USE TABLEVARCOM

    IMPLICIT NONE

    INTEGER   ISN   ! 0->init, otherwise fill

! local
    INTEGER ID, LENTB, LENPG, LENFMT
    CHARACTER TBNAME*40, PGNAME*20, TEXTFMT*20, TEXTFMT_forC*20

! ----------------- BEGIN  TABLE_DMPFCN -----------------------

    ID = IDTABLE_DMPFCN

! ----------------------------------

    IF ( ISN .EQ. 0 ) THEN

       TBNAME  = 'DMPFCN' // char(0)
       LENTB   = INDEX(TBNAME,   ' ') - 1

       LENPG    = 12
       PGNAME   = PROGRAM_NAME_SNFIT(1:LENPG) // char(0)

       TEXTFMT  = TEXTFORMAT_TABLE(ITABLE_FITRES)
       LENFMT   = INDEX(TEXTFMT,' ') - 1
       TEXTFMT_forC = TEXTFMT(1:LENFMT) // char(0)

       CALL SNTABLE_CREATE(ID, TBNAME, PGNAME, TEXTFMT_forC, LENTB, LENPG, LENFMT)  ! C fun

       CALL INIT_TABLE_DMPFCN(ID, 'DMPFCN' )

      RETURN
    ENDIF

! ------------------------------------
!  fill table

!   terminate strings for C table-functions (snana.car routine)
    CALL TABLE_STRING_TERMINATION(+1)

    CALL SNTABLE_FILL(ID)  ! generic C function

    CALL TABLE_STRING_TERMINATION(-1)  ! remove termination

! ------------------------------------

    RETURN
  END SUBROUTINE TABLE_DMPFCN

! =====================================
    SUBROUTINE INIT_TABLE_DMPFCN(ID,BLOCK)
! 
! Created Jan 2025
! 
! --------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE TABLEVARCOM

    IMPLICIT NONE

    INTEGER   ID          ! (I) table id
    CHARACTER BLOCK*(*)   ! (I) name of BLOCK

! local var

    INTEGER  IPAR, LENNAME, LENBLOCK
    CHARACTER VARNAME*60, CBLOCK*40

    EXTERNAL  & 
           SNTABLE_ADDCOL_int  & 
          ,SNTABLE_ADDCOL_flr  & 
          ,SNTABLE_ADDCOL_dbl  & 
          ,SNTABLE_ADDCOL_str

! ---------------- BEGIN ------------

    write(6,10) BLOCK, ID
 10   format(T6,'Create BLOCK = ',A,'  for TABLE ID = ', I5)
    call flush(6)

    LENBLOCK = INDEX(BLOCK//' ',' ') - 1
    CBLOCK   = BLOCK(1:LENBLOCK) // char(0)

! - - - -
    VARNAME = 'CCID:C*20' // char(0)
    CALL SNTABLE_ADDCOL_str(ID, CBLOCK, SNLC_CCID, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'ISN:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLDMPFCN_ISN, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'NCALL:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLDMPFCN_NCALL, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'IFLAG:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLDMPFCN_IFLAG, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'ITER:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLDMPFCN_ITER, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'ZSN:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_ZSN,  & 
                   VARNAME, 1,     LENBLOCK, 20 )

    VARNAME = 'PEAKMJD:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_PEAKMJD,  & 
                   VARNAME, 1,     LENBLOCK, 20 )

    VARNAME = 'x0:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_DISTANCE,  & 
                   VARNAME, 1,     LENBLOCK, 20 )

    VARNAME = 'x1:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_SHAPEPAR,  & 
                   VARNAME, 1,     LENBLOCK, 20 )

    VARNAME = 'c:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_COLORPAR,  & 
                   VARNAME, 1,     LENBLOCK, 20 )

! - - - -
    VARNAME = 'CHI2_TOT:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_CHI2TOT,  & 
                    VARNAME, 1,     LENBLOCK, 20 )

    VARNAME = 'CHI2PRIOR_TOT:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_CHI2PRIOR(0),  & 
                    VARNAME, 1,     LENBLOCK, 20 )

    DO 900 ipar = 1, IPAR_MAX
       if ( ipar == IPAR_ITER )  GOTO 900
       if ( ipar == IPAR_ISN  )  GOTO 900
       if ( ipar == IPAR_SHAPE2) GOTO 900
       if ( ipar == IPAR_MB  )   GOTO 900
       VARNAME = 'CHI2PRIOR_' // PARNAME_STORE(ipar)
       LENNAME = INDEX(VARNAME,' ') -1
       VARNAME = VARNAME(1:LENNAME) // ':F' // char(0)
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLDMPFCN_CHI2PRIOR(ipar),  & 
                    VARNAME, 1,     LENBLOCK, 20 )
900   CONTINUE

    RETURN
  END SUBROUTINE INIT_TABLE_DMPFCN

! ===================================================
    SUBROUTINE TABLE_SNSPEC_SALT2(isn)
! 
! Prepare table for SALT2 spectra computed from LC fit params.
! 
! Mar 21 2022: compute TBLSPEC_MAG_MODEL[_ERR] for each band and MJD
! Sep 01 2206: RK: pass WAVECOR arg to getSpec_band_SALT2()
!
! -------------------------------

    USE SNDATCOM
    USE SNFITCOM
    USE SNANAFIT
    USE FILTCOM
    USE TABLEVARCOM

    IMPLICIT NONE

    INTEGER   ISN   ! 0->init, otherwise fill

! local var

    INTEGER ID, i, ep, LENTB, LENPG, LENFMT
    INTEGER IFILT, IFILTOBS, IFILTOBS_TMP
    REAL    Tobs, z, x0, x1, c, MWEBV
    REAL*8  FLUX8, FLUXERR8, MAG8, MAGERR8, KCOR8
    CHARACTER TBNAME*40, PGNAME*20, TEXTFMT*20, TEXTFMT_forC*20

! function
    INTEGER  getSpec_band_SALT2
    EXTERNAL getSpec_band_SALT2
! ----------------- BEGIN ------------------------

    ID = IDTABLE_MODELSPEC

! ----------------------------------

    IF ( ISN .EQ. 0 ) THEN

       TBNAME   = 'SPECTRA' // char(0)
       LENTB    = INDEX(TBNAME,   ' ') - 1

       LENPG    = 12
       PGNAME   = PROGRAM_NAME_SNFIT(1:LENPG) // char(0)

       TEXTFMT  = TEXTFORMAT_TABLE(ITABLE_FITRES)
       LENFMT   = INDEX(TEXTFMT,' ') - 1
       TEXTFMT_forC = TEXTFMT(1:LENFMT) // char(0)

       CALL SNTABLE_CREATE(ID, TBNAME, PGNAME, TEXTFMT_forC, LENTB, LENPG, LENFMT)  ! C fun

       CALL INIT_TABLE_SNSPECVAR(ID, 'SNSPEC' )

      RETURN
    ENDIF

! ------------------------------------
!  fill table

!   terminate strings for C table-functions (snana.car routine)
    CALL TABLE_STRING_TERMINATION(+1)

    DO 400 i = 1, NFITDATA + NFITDATA_REJECT
        ep   = EPLIST_FIT(i)
        IFILTOBS = I4EP_ALL(ep,IEP_IFILT_OBS)

        TBLSPEC_MJD         = R4EP_ALL(ep,JEP_MJD) + SNGL(MJDOFF)
        TBLSPEC8_MJD              = R8EP_MJD(i)  ! note different index
        TBLSPEC_TREST             = R4EP_ALL(ep,JEP_TREST)
        TBLSPEC_TOBS              = R4EP_ALL(ep,JEP_TOBS)
        TBLSPEC_WAVECOR           = R4EP_ALL(ep,JEP_WAVECOR)
        TBLSPEC_LAMREST           = R4EP_ALL(ep,JEP_LAMREST)
        TBLSPEC_IFILTOBS          = IFILTOBS
        TBLSPEC_DETNUM            = I4EP_ALL(ep,IEP_DETNUM)
        TBLSPEC_IMGNUM            = I4EP_ALL(ep,IEP_IMGNUM)
        TBLSPEC_FLUXCAL_DATA      = R4EP_ALL(ep,JEP_DATAFLUX)
        TBLSPEC_FLUXCAL_DATA_ERR  = R4EP_ALL(ep,JEP_DATAFLUX_ERR)
        TBLSPEC_FLUXCAL_MODEL     = R4EP_ALL(ep,JEP_MODELFLUX)
        TBLSPEC_FLUXCAL_MODEL_ERR = R4EP_ALL(ep,JEP_MODELFLUX_ERR)
        TBLSPEC_FIELD             = SNLC_FIELD(ep)
        TBLSPEC_CFILT             =  & 
              filtdef_string(IFILTOBS:IFILTOBS) // char(0)

! Mar21 2022: compute model mag for every band at every MJD
        DO ifilt = 1, NFILTDEF_SURVEY
          ifiltobs_tmp = IFILTDEF_MAP_SURVEY(ifilt)
          CALL MODELMAG_CALC(IFILTOBS_TMP, 'OBS', TBLSPEC8_MJD,  & 
                FLUX8, FLUXERR8, MAG8, MAGERR8, KCOR8 )
          TBLSPEC_MAG_MODEL(ifiltobs_tmp)     = sngl(MAG8)
          TBLSPEC_MAG_MODEL_ERR(ifiltobs_tmp) = sngl(MAGERR8)
        ENDDO

        Tobs  = TBLSPEC_TOBS
        z     = SNLC_REDSHIFT
        x0    = LCVAL_STORE(IPAR_x0)
        x1    = LCVAL_STORE(IPAR_SHAPE)
        c     = LCVAL_STORE(IPAR_COLOR)
        MWEBV = SNLC_MWEBV

        NBLAM_TBLSPEC =  & 
            getSpec_band_SALT2(IFILTOBS, Tobs,     &  ! (I)
            TBLSPEC_WAVECOR,                     &  ! (I)
            z, x0, x1, c, MWEBV,                   &  ! (I)
            TBLSPEC_LAMLIST, TBLSPEC_FLUXLIST )   ! (O)

        IF ( NBLAM_TBLSPEC > MXLAM_TBLSPEC ) THEN
          write(C1ERR,661) NBLAM_TBLSPEC, MXLAM_TBLSPEC
661         format('NBLAM=',I5,' exceeds bound of ', I5)
          c2err = 'Check MXLAM_TBLSPEC'
          CALL MADABORT('TABLE_SNSPEC_SALT2', C1ERR, C2ERR)
        ENDIF

        IF ( NBLAM_TBLSPEC > 0 ) THEN
           CALL SNTABLE_FILL(ID)  ! generic C function
        ENDIF

400   CONTINUE

    CALL TABLE_STRING_TERMINATION(-1)  ! remove termination

! ------------------------------------

    RETURN
  END SUBROUTINE TABLE_SNSPEC_SALT2

! =====================================
    SUBROUTINE INIT_TABLE_SNSPECVAR(ID,BLOCK)
! 
! Created Nov 18 2016
! 
! Initialize variables to store SALT2 spectrum for each epoch.
! Store epoch variables as scalars; e.g., MJD, TOBS, FLUXCAL.
! Store spectrum as vector array: LAMLIST and FLUXLIST.
! 
! Initial use is that spectra are needed for chromatic
! corrections for each epoch (for DES).
! 
! Call generic function SNTABLE_ADDCOL() that loads a table
! for each selected format: CERNLIB, ROOT, HDF5 ...
! 
! Mar 21 2022: load all model mags for each obs.
! 
! --------------


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITCOM
    USE FILTCOM
    USE SNLCINP_NML
    USE USRTAGCM
    USE TABLEVARCOM
    USE VMAXCOM

    IMPLICIT NONE

    INTEGER   ID          ! (I) table id
    CHARACTER BLOCK*(*)   ! (I) name of BLOCK

! local var

    INTEGER IFILT, IFILT_OBS, LENBLOCK

    CHARACTER VARNAME*60, CBLOCK*40, CNFIT*20, CFILT*2

    EXTERNAL  & 
           SNTABLE_ADDCOL_int  & 
          ,SNTABLE_ADDCOL_flr  & 
          ,SNTABLE_ADDCOL_dbl  & 
          ,SNTABLE_ADDCOL_str

! ---------------- BEGIN ------------

    write(6,10) BLOCK, ID
 10   format(T6,'Create BLOCK = ',A,'  for TABLE ID = ', I5)
    call flush(6)

    LENBLOCK = INDEX(BLOCK//' ',' ') - 1
    CBLOCK   = BLOCK(1:LENBLOCK) // char(0)

! - - - -
    VARNAME = 'CCID:C*20' // char(0)
    CALL SNTABLE_ADDCOL_str(ID, CBLOCK, SNLC_CCID, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'FIELD:C*20' // char(0)
    CALL SNTABLE_ADDCOL_str(ID, CBLOCK, TBLSPEC_FIELD, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'BAND:C*4' // char(0)
    CALL SNTABLE_ADDCOL_str(ID, CBLOCK, TBLSPEC_CFILT, VARNAME, 1,  & 
                         LENBLOCK, 4 )

    VARNAME = 'DETNUM:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLSPEC_DETNUM, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'IMGNUM:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLSPEC_IMGNUM, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'IFILTOBS:I' // char(0)
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, TBLSPEC_IFILTOBS, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'MJD:D' // char(0)
    CALL SNTABLE_ADDCOL_dbl(ID, CBLOCK, TBLSPEC8_MJD, VARNAME, 1,  & 
                         LENBLOCK, 20 )

    VARNAME = 'TREST:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLSPEC_TREST,  & 
                   VARNAME, 1,      LENBLOCK, 20 )

    VARNAME = 'LAMREST:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLSPEC_LAMREST,  & 
                   VARNAME, 1,      LENBLOCK, 20 )

    VARNAME = 'FLUXCAL_DATA:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLSPEC_FLUXCAL_DATA,  & 
                     VARNAME, 1,    LENBLOCK, 20 )

    VARNAME = 'FLUXCAL_DATA_ERR:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK,TBLSPEC_FLUXCAL_DATA_ERR,  & 
                    VARNAME,1,     LENBLOCK, 20 )

    VARNAME = 'FLUXCAL_MODEL:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLSPEC_FLUXCAL_MODEL,  & 
                  VARNAME, 1, LENBLOCK, 20 )

    VARNAME = 'FLUXCAL_MODEL_ERR:F' // char(0)
    CALL SNTABLE_ADDCOL_flt(ID, CBLOCK, TBLSPEC_FLUXCAL_MODEL_ERR,  & 
                  VARNAME, 1, LENBLOCK, 20 )

! - - - - -
! Mar 21 2022: write model mag for all bands at each obs
!   initial use is for DCR correction in DES.

    DO 20 ifilt  = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       cfilt     = FILTDEF_STRING(ifilt_obs:ifilt_obs)
       VARNAME   = 'MAG_MODEL_' // cfilt(1:1) // ':F' // char(0)
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK,  & 
             TBLSPEC_MAG_MODEL(ifilt_obs),  & 
             VARNAME, 1, LENBLOCK, 20 )
20    CONTINUE

    DO 21 ifilt  = 1, NFILTDEF_SURVEY
       ifilt_obs = IFILTDEF_MAP_SURVEY(ifilt)
       cfilt     = FILTDEF_STRING(ifilt_obs:ifilt_obs)
       VARNAME   = 'MAG_MODEL_ERR_' // cfilt(1:1) // ':F'//char(0)
       CALL SNTABLE_ADDCOL_flt(ID, CBLOCK,  & 
             TBLSPEC_MAG_MODEL_ERR(ifilt_obs),  & 
             VARNAME, 1, LENBLOCK, 20 )
21    CONTINUE

! - - - - -
    write(CNFIT,15) MXLAM_TBLSPEC
15    format('NBLAM[',I4.4,']' )  ! no spaces or commas in string
    VARNAME = CNFIT(1:11)  // char(0)  ! Num lambda bins
    CALL SNTABLE_ADDCOL_int(ID, CBLOCK, NBLAM_TBLSPEC,  & 
           VARNAME, 0, LENBLOCK, 20)

    VARNAME = 'SPEC_LAMLIST(NBLAM):F'  // char(0)   ! wavelength list
    CALL SNTABLE_ADDCOL_flt(ID,CBLOCK, TBLSPEC_LAMLIST(1),  & 
              VARNAME, 0, LENBLOCK, 20)

    VARNAME = 'SPEC_FLUXLIST(NBLAM):F'  // char(0)   ! spec-fluxList
    CALL SNTABLE_ADDCOL_flt(ID,CBLOCK, TBLSPEC_FLUXLIST(1),  & 
              VARNAME, 0, LENBLOCK, 20)

    RETURN
  END SUBROUTINE INIT_TABLE_SNSPECVAR


! ===============================
    INTEGER FUNCTION IPAR_PARNAME_STORE(VARNAME)

! Apr 23 2014, R. Kessler
! for input string VARNAME, return IPAR such that
!    VARNAME = PARNAME_STORE(IPAR).
! If VARNAME has 'ERR' at the end, then return negative IPAR value
! 
! Nov 14 2014: fix bug to allow zPHOT as well as z.
! Jan 02 2016: check for 'ERR' extension


    USE SNDATCOM
    USE SNANAFIT
    USE SNFITPAR
    USE FITINP_NML
    USE FITRESTCOM

    IMPLICIT NONE

    CHARACTER VARNAME*(*)  ! (I) variable name to analyze

! local var

    CHARACTER tmpName*40, cfilt*2, FNAM*20, VLOC*40
    INTEGER IPAR, ifilt, LENPAR, LENLOC
    LOGICAL ISERR

! ----------- BEGIN -----------

    IPAR = -99
    FNAM = 'IPAR_PARNAME_STORE'

! ------------------------------
! check for 'ERR' at the end
    ISERR  = .FALSE.
    LENPAR = INDEX(VARNAME,' ') - 1
    VLOC   = VARNAME
    IF ( LENPAR > 3 ) THEN
       IF ( VARNAME(LENPAR-2:LENPAR) .EQ. 'ERR' ) then
         ISERR = .TRUE.
         VLOC  = VARNAME(1:LENPAR-3)
       ENDIF
    ENDIF

    LENLOC = INDEX(VLOC,' ') - 1

! ------------------------------
    IF ( VLOC(1:LENLOC) .EQ. 'z' ) THEN
       IPAR = IPAR_zPHOT  ! allow 'z' instead of longer 'REDSHIFT'
    ELSE IF ( VLOC(1:LENLOC) .EQ. PARNAME_STORE(IPAR_zPHOT) ) THEN
       IPAR = IPAR_zPHOT
    ELSE IF ( VLOC(1:LENLOC) .EQ. PARNAME_STORE(IPAR_COLOR) ) THEN
       IPAR = IPAR_COLOR
    ELSE IF ( VLOC(1:LENLOC) .EQ. PARNAME_STORE(IPAR_SHAPE) ) THEN
       IPAR = IPAR_SHAPE
    ELSE IF ( VLOC(1:3) .EQ. 'M0_' ) THEN

!      check FITRESTMAG variables
       DO ifilt    = 1, NFILTDEF_FITRESTMAG
          cfilt    = FILTLIST_FITRESTMAG(ifilt:ifilt)
          tmpName  = 'M0_' // cfilt
          if ( VARNAME .EQ. tmpName ) then
             IPAR = IPAROFF_FITRESTMAG + 2*ifilt-1 ! skip errors
          endif
       ENDDO
       IF ( IPAR < 0 ) then
          c1err = 'Cannot identify VARANME = ' // VARNAME
          c2err = 'Check NEARNBR options.'
          CALL MADABORT(FNAM, c1err, c2err )
       endif
    ELSE
       CALL PRINT_PREABORT_BANNER(FNAM//CHAR(0), 40)
       print*,'   LENPAR, LENLOC, ISERR = ', LENPAR, LENLOC, ISERR
       print*,'   VARNAME = ', VARNAME(1:20)
       print*,'   VARNAME(LENPAR-3:LENPAR) = ',  & 
                    VARNAME(LENPAR-3:LENPAR)
       print*,'   VLOC    = ', VLOC(1:20)

       c1err = 'Cannot determine IPAR for VARNAME='  & 
                   // VARNAME(1:12)
       c2err = 'Check NEANBR options.'
       CALL MADABORT(FNAM, c1err, c2err )
    ENDIF

    IF ( ISERR ) THEN
      IPAR_PARNAME_STORE = -IPAR
    ELSE
      IPAR_PARNAME_STORE = +IPAR
    ENDIF

    RETURN
  END FUNCTION IPAR_PARNAME_STORE


