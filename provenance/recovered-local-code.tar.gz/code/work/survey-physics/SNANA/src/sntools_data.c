/******************************************
  Created Dec 10 2021 by R.Kessler   

  Data-handling tools that don't depend on format.
  Format-specific tools are in 
     sntools_dataformat_fits.c
     sntools_dataformat_text.c

  Initial motivation is to move data-override utility out of
  fortran code and into here, and to make it more flexible so 
  that hard-coding variable match-list isn't needed.

  May 6 2026 RK - if override QUANTILE_ZPHOT are explicitly set to -9,
                  then corresponding HOSTGAL_PHOTO[_ERR] are also set to -9

******************************************/

#include  "sntools.h"
#include  "sntools_spectrograph.h"  
#include  "sntools_data.h"
#include  "sntools_output.h"
#include  "sntools_cosmology.h"
#include  "sntools_host.h" 

#include  <sys/stat.h>


// set_refac_data_flag is for devel only
void SET_REFAC_DATA_FLAG(int refac_data_flag) { 
  printf("\n Set REFAC_DATA_FLAG = %d\n\n ", refac_data_flag);
  fflush(stdout);
  REFAC_DATA_FLAG = refac_data_flag ; 
}

void set_refac_data_flag__(int *refac_data_flag)
{ SET_REFAC_DATA_FLAG(*refac_data_flag); }


// =======================================================
bool IS_SIMKEY_SNDATA(char *key) {

  // Created Mar 8 2022
  // Return true if input *key is from simulation,
  // where key is a data key in either FITS or TEXT format.

  bool IS_KEYSIM = false;
  // ----------- BEGIN ------------

  if ( strncmp(key,"SIM",3)  ==   0 ) { IS_KEYSIM = true; }
  if ( strstr(key,"SIMSED") != NULL ) { IS_KEYSIM = true; }
  if ( strstr(key,"LCLIB" ) != NULL ) { IS_KEYSIM = true; }

  return IS_KEYSIM ;

} // end IS_SIMKEY_SNDATA


// ******************************************
void copy_int(int copyFlag, double *DVAL0, int *IVAL1) {
  if   ( copyFlag > 0)  { *IVAL1 = (int)(*DVAL0);  }  
  else                  { *DVAL0 = (double)(*IVAL1);  }
}

void copy_lli(int copyFlag, double *DVAL0, long long *IVAL1) {
  if   ( copyFlag > 0)  { *IVAL1 = (long long)(*DVAL0);  }  
  else                  { *DVAL0 = (double)(*IVAL1);  }
}

void copy_flt(int copyFlag, double *DVAL0, float *FVAL1) {
  if   ( copyFlag > 0)  { *FVAL1 = (float)(*DVAL0);  }  
  else                  { *DVAL0 = (double)(*FVAL1);  }
}

void copy_dbl(int copyFlag, double *DVAL0, double *DVAL1) {
  if   ( copyFlag > 0)  { *DVAL1 = (double)(*DVAL0);  }  
  else                  { *DVAL0 = (double)(*DVAL1);  }
}

void copy_str(int copyFlag, char *STR0, char *STR1) {
  if   ( copyFlag > 0)  { sprintf(STR1, "%s", STR0); }
  else                  { sprintf(STR0, "%s", STR1); }
}

void copy_HOSTGALz(int copyFlag, char *key, double *parVal, HOSTGALz_DEF *HOSTGALz) {

  int NZ = HOSTGALz->NZ;
  int iz;
  char fnam[] = "copy_HOSTGALz" ;  (void)fnam;

  // ---------- BEGIN --------------

  if ( strcmp(key,HOSTGALz->VARNAME_NZ) == 0 ) 
    { copy_int(copyFlag, parVal, &HOSTGALz->NZ ); }  // read number of quantile bins
  
  else if ( strcmp(key,HOSTGALz->VARNAME_Z) == 0 ) {
    for(iz=0; iz < NZ; iz++ ) 
      { copy_flt(copyFlag, &parVal[iz], &HOSTGALz->Z_LIST[iz] ); }  // read redshift grid	  
  }

  else if ( strcmp(key,HOSTGALz->VARNAME_VAL) == 0 ) {
    for(iz=0; iz < NZ; iz++ ) 
      { copy_flt(copyFlag, &parVal[iz], &HOSTGALz->VAL_LIST[iz] ); }  // read VAL grid

  }
  else if ( strcmp(key,HOSTGALz->VARNAME_VAL2) == 0 ) {
    for(iz=0; iz < NZ; iz++ ) 
      { copy_flt(copyFlag, &parVal[iz], &HOSTGALz->VAL2_LIST[iz] ); }  // read VAL2 grid

  }
  fflush(stdout);

} // end copy_HOSTGALz

// ===================================================
void copy_SNDATA_GLOBAL(int copyFlag, char *key, int NVAL, 
			char *stringVal, double *parVal ) {

  // Created Feb 2021
  //
  // Copy *key value to or from SNDATA struct.
  // Note that event has already been read, but is not stored
  // in useful arrays.
  //
  // GLOBAL refers to params that do not depend on event.
  //
  // Inputs:
  //  copyFlag : 
  //     +1 -> copy from string or parVal to SNDATA (prep  data write)
  //     -1 -> copy from SNDATA to string or parVal (after read data)
  //
  //   *key  : name of variable to copy to/from SNDATA struct
  //   NVAL  : number of values to copy
  // 
  // Output:
  //    *stringVal  : string value if *key points to string
  //    *parVal     : double value if *key points to double,float,int
  //
  // Apr 24 2021: add SIM_BIASCOR_MASK
  // Oct 08 2021: add SIM_MODEL_INDEX
  // Oct 11 2022: fix bug reading SIM_HOSTLIB params
  // Apr 20 2026: no longer reader PHOT PERCENTILES from global header

  bool ISKEY_PRIVATE = ( strstr (key,"PRIVATE")   != NULL ) ;
  bool ISKEY_BYOSED  = ( strncmp(key,"BYOSED",6)  == 0 ) ;
  bool ISKEY_SNEMO   = ( strncmp(key,"SNEMO",5)   == 0 ) ;
  bool ISKEY_SIMSED  = ( strncmp(key,"SIMSED",6)  == 0 ) ;
  bool ISKEY_LCLIB   = ( strncmp(key,"LCLIB",5)   == 0 ) ;
  bool ISKEY_SIM     = ( strncmp(key,"SIM",3)     == 0 && !ISKEY_SIMSED) ;

  int ivar, ipar ;
  char fnam[] = "copy_SNDATA_GLOBAL" ;  (void)fnam;

  // --------------- BEGIN --------------

  if(copyFlag<0) { sprintf(stringVal,"NOTSET");  parVal[0] = -999.0; }

  if ( strcmp(key,"SNANA_VERSION") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.SNANA_VERSION );  }

  else if ( strcmp(key,"SURVEY") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.SURVEY_NAME );  }

  else if ( strcmp(key,"SUBSURVEY_FLAG") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.SUBSURVEY_FLAG );  }

  else if ( strcmp(key,"ZP_FLUXCAL") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.ZP_FLUXCAL );  }

  else if ( strcmp(key,"FILTERS") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA_FILTER.LIST );  }

  else if ( strcmp(key,"DATATYPE") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.DATATYPE );  }

  //  else if ( strcmp(key,"ATMOS_FLAG") == 0 ) 
  //{ copy_int(copyFlag, stringVal, SNDATA.WRFLAG_ATMOS );  }

  else if ( strcmp(key,"PySEDMODEL") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.PySEDMODEL_NAME );  }

  else if ( strcmp(key,"NXPIX") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.NXPIX );  }
  else if ( strcmp(key,"NYPIX") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.NYPIX );  }

  else if ( ISKEY_PRIVATE  ) {
    if ( strcmp(key,"NVAR_PRIVATE") == 0 ) { 
      copy_int(copyFlag, parVal, &SNDATA.NVAR_PRIVATE );  
    }
    else {
      sscanf(&key[7], "%d", &ivar);  // PRIVATEnn
      copy_str(copyFlag, stringVal, SNDATA.PRIVATE_KEYWORD[ivar] ); 
    }
  }

  else if ( ISKEY_SIMSED  ) {

    if ( strcmp(key,"SIMSED_NPAR") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.NPAR_SIMSED );  }
    else {
      sscanf(&key[10], "%d", &ivar);  // 'SIMSED_PARnn'
      copy_str(copyFlag, stringVal, SNDATA.SIMSED_KEYWORD[ivar] ); 
    }
  }

  else if ( ISKEY_LCLIB  ) {
    if ( strcmp(key,"LCLIB_NPAR") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.NPAR_LCLIB );  }
    else {
      sscanf(&key[9], "%d", &ivar); // LCLIB_PARnn
      copy_str(copyFlag, stringVal, SNDATA.LCLIB_KEYWORD[ivar] ); 
    }
  }

  else if ( ISKEY_BYOSED  ) {
    if ( strcmp(key,"BYOSED_NPAR") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.NPAR_PySEDMODEL );  }
    else {
      sscanf(&key[10], "%d", &ivar); // BYOSED_PARnn
      copy_str(copyFlag, stringVal, SNDATA.PySEDMODEL_KEYWORD[ivar] ); 
    }
  }

  else if ( ISKEY_SNEMO  ) {
    if ( strcmp(key,"SNEMO_NPAR") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.NPAR_PySEDMODEL );  }
    else {
      sscanf(&key[9], "%d", &ivar); // SNEMO_PARnn
      copy_str(copyFlag, stringVal, SNDATA.PySEDMODEL_KEYWORD[ivar] ); 
    }
  }

  else if ( ISKEY_SIM ) {   

    if ( strcmp(key,"SIMLIB_FILE") == 0 ) 
      { copy_str(copyFlag, stringVal, SNDATA.SIMLIB_FILE ); }

    else if ( strcmp(key,"SIMLIB_MSKOPT") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIMLIB_MSKOPT ); }

    else if ( strcmp(key,"SIMOPT_MWCOLORLAW") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIMOPT_MWCOLORLAW ); }

    else if ( strcmp(key,"SIMOPT_MWEBV") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIMOPT_MWEBV ); }

    else if ( strcmp(key,"SIM_MWRV") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_MWRV ); }

    else if ( strcmp(key,"SIM_VARNAME_SNRMON") == 0 ) 
      { copy_str(copyFlag, stringVal, SNDATA.VARNAME_SNRMON ); }

    else if ( strcmp(key,"SIM_HOSTLIB_NPAR") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.NPAR_SIM_HOSTLIB ); }

    else if ( strncmp(key,"SIM_HOSTLIB_PAR",15) == 0 ) {
      sscanf(&key[15], "%d", &ipar);
      copy_str(copyFlag, stringVal, SNDATA.SIM_HOSTLIB_KEYWORD[ipar]);
    }
    else if ( strcmp(key,"SIM_SL_FLAG") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_SL_FLAG ); }

    else if ( strcmp(key,"SIM_BIASCOR_MASK") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_BIASCOR_MASK ); }

    else if ( strcmp(key,"SIM_WRITE_MASK") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_WRITE_MASK ); }  // Feb 2026

    else if ( strcmp(key,"SIM_MODEL_INDEX") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_MODEL_INDEX );  }

    else {
      // error message
      sprintf(c1err,"Unknown SIM key = %s (copyFlag=%d)", key, copyFlag);
      sprintf(c2err,"stringVal='%s'  parVal=%f", stringVal, parVal[0] );
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
    }

  }
  else {
    // error message
    sprintf(c1err,"Unknown key = %s  (copyFlag=%d)", key, copyFlag);
    sprintf(c2err,"stringVal='%s'  parVal=%f", stringVal, parVal[0] );
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
  }

  return;

} // end copy_SNDATA_GLOBAL


// = = = = = = = = = = = = = = = = = = = = = = = =
void copy_SNDATA_HEAD(int copyFlag, char *key, int NVAL, 
		      char *stringVal, double *parVal ) {

  // Created Feb 2021:
  //
  // Copy *key value to or from SNDATA struct.
  // Note that event has already been read, but is not stored
  // in useful arrays.
  //
  // HEAD refers SN-dependent HEADER that updates for each event.
  //   (i.e., depends on SN; does NOT depend on MJD)

  // Inputs:
  //  copyFlag : 
  //     +1 -> copy from string or parVal to SNDATA (prep  data write)
  //     -1 -> copy from SNDATA to string or parVal (after read data)
  //
  //   *key  : name of variable to copy to/from SNDATA struct
  //   NVAL  : number of values to copy
  // 
  // Output:
  //    *stringVal  : string value if *key points to string
  //    *parVal     : double value if *key points to double,float,int
  //
  // History:
  // Sep 9 2021 A. Gagliano: Load igal dimension of SNDATA.SIM_HOSTLIB_PARVAL
  // Dec 1 2025 R.Kessler check for HOSTGAL_MAGERR

  int NFILT = SNDATA_FILTER.NDEF ;
  char *PySEDMODEL_NAME = SNDATA.PySEDMODEL_NAME ; // BYOSED or SNEMO
  int  len_PySEDMODEL   = strlen(PySEDMODEL_NAME);
  int  ncmp_PySEDMODEL  = strncmp(key,PySEDMODEL_NAME,len_PySEDMODEL) ;
  int igal, NGAL, ifilt, ifilt_obs, NVAR, ivar, ipar ;
  HOSTGALz_DEF *HOSTGALz;
  char PREFIX[40], PREFIXz[40], KEY_TEST[60] ;
  char fnam[] = "copy_SNDATA_HEAD" ; (void)fnam;

  // ------------- BEGIN ------------

  if ( copyFlag < 0 ) 
    { sprintf(stringVal,"NOTSET");  parVal[0] = -999.0; }


  if ( strcmp(key,"SUBSURVEY") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.SUBSURVEY_NAME ); }

  else if ( strcmp(key,"SNID") == 0 ) {
     copy_str(copyFlag, stringVal, SNDATA.CCID ); 
     SNDATA.NOBS_STORE = 0 ; // must call select_MJD_SNDATA to set this
  }

  else if ( strcmp(key,"NAME_IAUC") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.NAME_IAUC ); }
  else if ( strcmp(key,"IAUC") == 0 )  // legacy key name (7/2024)
    { copy_str(copyFlag, stringVal, SNDATA.NAME_IAUC ); }  

  else if ( strcmp(key,"NAME_TRANSIENT") == 0 ) 
    { copy_str(copyFlag, stringVal, SNDATA.NAME_TRANSIENT ); }  

  else if ( strcmp(key,"FAKE") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.FAKE ); }

  else if ( strcmp(key,"MASK_FLUXCOR_SNANA") == 0 )
    { copy_int(copyFlag, parVal, &SNDATA.MASK_FLUXCOR ); } 

  else if ( strcmp(key,"RA") == 0 ) 
    { copy_dbl(copyFlag, parVal, &SNDATA.RA_AVG ); }
  else if ( strcmp(key,"DEC") == 0 ) 
    { copy_dbl(copyFlag, parVal, &SNDATA.DEC_AVG ); }

  else if ( strcmp(key,"PIXSIZE") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.PIXSIZE ); }
  else if ( strcmp(key,"NXPIX") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.NXPIX ); } 
  else if ( strcmp(key,"NYPIX") == 0 )
    { copy_int(copyFlag, parVal, &SNDATA.NYPIX ); } 

  else if ( strcmp(key,"DETNUM") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.DETNUM[0] ); } // should be obsolete

  else if ( strcmp(key,"SNTYPE") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.SNTYPE ); } 

  else if ( strcmp(key,"NOBS") == 0 ) { 
    copy_int(copyFlag, parVal, &SNDATA.NOBS ); 
    SNDATA.NOBS_STORE = -1 ; // must call select_MJD_SNDATA to set this
  } 

  else if ( strcmp(key,"MWEBV") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.MWEBV ); } 
  else if ( strcmp(key,"MWEBV_ERR") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.MWEBV_ERR ); } 

  else if ( strcmp(key,"REDSHIFT_HELIO") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.REDSHIFT_HELIO ); } 
  else if ( strcmp(key,"REDSHIFT_HELIO_ERR") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.REDSHIFT_HELIO_ERR ); } 

  else if ( strcmp(key,"REDSHIFT_FINAL") == 0 || 
	    strcmp(key,"REDSHIFT_CMB"  ) == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.REDSHIFT_FINAL ); } 
  else if ( strcmp(key,"REDSHIFT_FINAL_ERR") == 0 ||
	    strcmp(key,"REDSHIFT_CMB_ERR"  ) == 0 )  
    { copy_flt(copyFlag, parVal, &SNDATA.REDSHIFT_FINAL_ERR ); } 
  else if ( strcmp(key,"REDSHIFT_QUALITYFLAG") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.REDSHIFT_QUALITYFLAG ); }
  else if ( strcmp(key,"MASK_REDSHIFT_SOURCE") == 0 )
    { copy_int(copyFlag, parVal, &SNDATA.MASK_REDSHIFT_SOURCE ); }

  else if ( strcmp(key,"VPEC") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.VPEC ); } 
  else if ( strcmp(key,"VPEC_ERR") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.VPEC_ERR ); } 

  else if ( strcmp(key,"LENSDMU") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.LENSDMU ); } 
  else if ( strcmp(key,"LENSDMU_ERR") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.LENSDMU_ERR ); } 
  
  else if ( strstr(key,"MWXT_MAG") != NULL ) {
    for ( ifilt=0; ifilt < NFILT; ifilt++ ) {
      ifilt_obs  = SNDATA_FILTER.MAP[ifilt];
      sprintf(KEY_TEST, "MWXT_MAG_%c", FILTERSTRING[ifilt_obs]);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.MWXT_MAG[ifilt_obs]) ;  }
    }
  }

  else if ( strncmp(key,"HOSTGAL",7) == 0 ) {

    if ( strcmp(key,"HOSTGAL_NMATCH") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.HOSTGAL_NMATCH[0] ); } 
    else if ( strcmp(key,"HOSTGAL_NMATCH2") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.HOSTGAL_NMATCH[1] ); } 
    else if ( strcmp(key,"HOSTGAL_CONFUSION") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_CONFUSION ); } 

    if ( strstr(key,"SB_FLUXCAL") != NULL ) {
      for(ifilt=0; ifilt < NFILT; ifilt++ ) {
	ifilt_obs = SNDATA_FILTER.MAP[ifilt];
	sprintf(KEY_TEST,"HOSTGAL_SB_FLUXCAL_%c", FILTERSTRING[ifilt_obs]); 
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_SB_FLUXCAL[ifilt]); } 
      }
    }

    NGAL = MXHOSTGAL ;
    for(igal=0; igal < NGAL; igal++ ) {

      get_SNDATA_HOSTGAL_PREFIX(igal, PREFIX, PREFIXz); 

      sprintf(KEY_TEST,"%s_OBJID", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_lli(copyFlag, parVal, &SNDATA.HOSTGAL_OBJID[igal] ); } 

      sprintf(KEY_TEST,"%s_FLAG", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_int(copyFlag, parVal, &SNDATA.HOSTGAL_FLAG[igal] ); } 

      sprintf(KEY_TEST,"%s_PHOTOZ", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) { 
	copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_PHOTOZ[igal] ); 
      } 

      sprintf(KEY_TEST,"%s_PHOTOZ_ERR", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_PHOTOZ_ERR[igal] );   } 

      sprintf(KEY_TEST,"%s_SPECZ", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_SPECZ[igal] ); } 
     
      sprintf(KEY_TEST,"%s_SPECZ_ERR", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_SPECZ_ERR[igal] ); } 

      sprintf(KEY_TEST,"%s_RA", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.HOSTGAL_RA[igal] ); } 
      sprintf(KEY_TEST,"%s_DEC", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.HOSTGAL_DEC[igal] ); } 

      sprintf(KEY_TEST,"%s_SNSEP", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_SNSEP[igal] ); } 

      sprintf(KEY_TEST,"%s_DDLR", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_DDLR[igal] ); } 

      sprintf(KEY_TEST,"%s_LOGMASS", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_LOGMASS_OBS[igal] ); } 
      sprintf(KEY_TEST,"%s_LOGMASS_ERR", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_LOGMASS_ERR[igal] ); } 

      sprintf(KEY_TEST,"%s_LOGSFR", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_LOGSFR_OBS[igal] ); } 
      sprintf(KEY_TEST,"%s_LOGSFR_ERR", PREFIX); 
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_LOGSFR_ERR[igal] ); } 

      sprintf(KEY_TEST,"%s_LOGsSFR", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 )
        { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_LOGsSFR_OBS[igal] ); }
      sprintf(KEY_TEST,"%s_LOGsSFR_ERR", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 )
        { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_LOGsSFR_ERR[igal] ); }

      sprintf(KEY_TEST,"%s_COLOR", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 )
        { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_COLOR_OBS[igal] ); }
      sprintf(KEY_TEST,"%s_COLOR_ERR", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 )
        { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_COLOR_ERR[igal] ); }

      for(ifilt=0; ifilt < NFILT; ifilt++ ) {
	ifilt_obs = SNDATA_FILTER.MAP[ifilt];
	sprintf(KEY_TEST,"%s_MAG_%c", PREFIX, FILTERSTRING[ifilt_obs]); 
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_MAG[igal][ifilt]); } 
      }

      for(ifilt=0; ifilt < NFILT; ifilt++ ) {
	ifilt_obs = SNDATA_FILTER.MAP[ifilt];
	sprintf(KEY_TEST,"%s_MAGERR_%c", PREFIX, FILTERSTRING[ifilt_obs]); 
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.HOSTGAL_MAGERR[igal][ifilt]); } 
      }

      // - - - 
      if ( strstr(key,"QUANTILE") != NULL ) {
	HOSTGALz = &SNDATA.HOSTGALz_QUANTILE_ZPHOT[igal];		
	copy_HOSTGALz(copyFlag, key, parVal, HOSTGALz) ;
      }

      if ( strstr(key,"LOGMASS") != NULL ) {
	HOSTGALz = &SNDATA.HOSTGALz_LOGMASS[igal];	     
	copy_HOSTGALz(copyFlag, key, parVal, HOSTGALz) ;
      }

      // - - - -

    } // end igal

  }  // end "HOSTGAL"

  else if ( strcmp(key,"PEAKMJD") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.SEARCH_PEAKMJD) ; }  

  else if ( strcmp(key,"MJD_TRIGGER") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.MJD_TRIGGER) ; }  
  else if ( strcmp(key,"MJD_DETECT_FIRST") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.MJD_DETECT_FIRST) ; }  
  else if ( strcmp(key,"MJD_DETECT_LAST") == 0 ) 
    { copy_flt(copyFlag, parVal, &SNDATA.MJD_DETECT_LAST) ; }  

  else if ( strcmp(key,"SEARCH                       PATH_SEARCHEFF, logicFile, fnam_TYPE") == 0 ) 
    { copy_int(copyFlag, parVal, &SNDATA.SEARCH_TYPE) ; }  

  else if ( strncmp(key,"PRIVATE",7) == 0 ) {
    NVAR = SNDATA.NVAR_PRIVATE ;
    for(ivar=1; ivar <= NVAR; ivar++ ) {
      if ( strcmp(key,SNDATA.PRIVATE_KEYWORD[ivar]) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.PRIVATE_VALUE[ivar]) ; }  
    }    
  }

  else if ( strncmp(key,"SIM",3) == 0 ) {
    // ------ SIM ------- 

    if ( strcmp(key,"SIM_MODEL_NAME") == 0 ) 
      { copy_str(copyFlag, stringVal, SNDATA.SIM_MODEL_NAME ); }
    else if ( strcmp(key,"SIM_TYPE_NAME") == 0 ) 
      { copy_str(copyFlag, stringVal, SNDATA.SIM_TYPE_NAME ); }

    else if ( strcmp(key,"SIM_MODEL_INDEX") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_MODEL_INDEX) ; }  

    else if ( strcmp(key,"SIM_GENTYPE") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_GENTYPE) ; }  
    else if ( strcmp(key,"SIM_TYPE_INDEX") == 0 )  // legacy var name
      { copy_int(copyFlag, parVal, &SNDATA.SIM_GENTYPE) ; }  

    else if ( strcmp(key,"SIM_TEMPLATE_INDEX") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_TEMPLATE_INDEX) ; }  

    else if ( strcmp(key,"SIM_SUBSAMPLE_INDEX") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SUBSAMPLE_INDEX) ; }  

    else if ( strcmp(key,"SIM_LIBID") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_LIBID) ; }  

    else if ( strcmp(key,"SIM_NGEN_LIBID") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_NGEN_LIBID) ; }  

    else if ( strcmp(key,"SIM_NOBS_UNDEFINED") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_NOBS_UNDEFINED) ; }  

    else if ( strcmp(key,"SIM_SEARCHEFF_MASK") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_SEARCHEFF_MASK) ; }  

    else if ( strcmp(key,"SIM_REDSHIFT_HELIO") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_REDSHIFT_HELIO) ; }  
    else if ( strcmp(key,"SIM_REDSHIFT_CMB") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_REDSHIFT_CMB) ; }  
    else if ( strcmp(key,"SIM_REDSHIFT_HOST") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_REDSHIFT_HOST) ; }  
    else if ( strcmp(key,"SIM_REDSHIFT_HOST_MATCH") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_REDSHIFT_HOST_MATCH) ; }  
    else if ( strcmp(key,"SIM_REDSHIFT_FLAG") == 0 ) 
      { copy_int(copyFlag, parVal, &SNDATA.SIM_REDSHIFT_FLAG) ; }  
    else if ( strcmp(key,"SIM_VPEC") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_VPEC) ; }  

    else if ( strcmp(key,"SIM_HOSTLIB_GALID") == 0 ) 
      { copy_lli(copyFlag, parVal, &SNDATA.SIM_HOSTLIB_GALID) ; }  

    else if ( strncmp(key,"SIM_HOSTLIB",11) == 0 ) {
      igal = 0 ;
      for(ipar=0; ipar < SNDATA.NPAR_SIM_HOSTLIB; ipar++ ) {
	if ( strcmp(key,SNDATA.SIM_HOSTLIB_KEYWORD[ipar]) == 0 ) {
	  copy_flt(copyFlag, parVal, &SNDATA.SIM_HOSTLIB_PARVAL[ipar][igal]); 
	}
      }
    }

    else if ( strcmp(key,"SIM_SNHOST_DDLR") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_SNHOST_DDLR) ; }   // Oct 2025

    else if ( strcmp(key,"SIM_SNHOST_SEP") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_SNHOST_SEP) ; }    // Oct 2025

    else if ( strcmp(key,"SIM_DLMU") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_DLMU) ; }  

    else if ( strcmp(key,"SIM_LENSDMU") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_LENSDMU) ; }  


    else if ( strcmp(key,"SIM_MUSHIFT") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_MUSHIFT) ; }  

    else if ( strcmp(key,"SIM_RA") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_RA) ; }  

    else if ( strcmp(key,"SIM_DEC") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_DEC) ; }  

    else if ( strcmp(key,"SIM_MWEBV") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_MWEBV) ; }  

    else if ( strcmp(key,"SIM_PEAKMJD") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_PEAKMJD) ; }  

    else if ( strcmp(key,"SIM_MJD_EXPLODE") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_MJD_EXPLODE) ; }  

    else if ( strcmp(key,"SIM_MAGSMEAR_COH") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_MAGSMEAR_COH) ; }  

    else if ( strcmp(key,"SIM_WGT_POPULATION") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_WGT_POPULATION) ; }  

    else if ( strcmp(key,"SIM_AV") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_AV) ; }  
    else if ( strcmp(key,"SIM_RV") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_RV) ; }  

    else if ( strncmp(key,"SIM_SALT2",9) == 0 ) {
      if ( strcmp(key,"SIM_SALT2x0") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2x0) ; }  
      else if ( strcmp(key,"SIM_SALT2x1") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2x1) ; }  
      else if ( strcmp(key,"SIM_SALT2c") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2c) ; }  
      else if ( strcmp(key,"SIM_SALT2mB") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2mB) ; }  
      else if ( strcmp(key,"SIM_SALT2alpha") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2alpha) ; }  
      else if ( strcmp(key,"SIM_SALT2beta") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2beta) ; }  
      else if ( strcmp(key,"SIM_SALT2gammaDM") == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.SIM_SALT2gammaDM) ; }  
    }
    else if ( strcmp(key,"SIM_DELTA") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_DELTA) ; }  

    else if ( strcmp(key,"SIM_THETA") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_THETA) ; }  // Jun 2023

    else if ( strcmp(key,"SIM_STRETCH") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_STRETCH) ; }  

    else if ( strcmp(key,"SIM_DM15") == 0 ) 
      { copy_flt(copyFlag, parVal, &SNDATA.SIM_DM15) ; }  

    else if ( strncmp(key,"SIMSED",6) == 0 ) {
      for(ipar=0; ipar < SNDATA.NPAR_SIMSED; ipar++ ) { 
	sprintf(KEY_TEST, "%s", SNDATA.SIMSED_KEYWORD[ipar]) ;
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.SIMSED_PARVAL[ipar]) ; } 
      }
    }
    else if ( strncmp(key,"SIM_PEAKMAG",11) == 0 ) {
      for ( ifilt=0; ifilt < SNDATA_FILTER.NDEF; ifilt++ ) {
	ifilt_obs  = SNDATA_FILTER.MAP[ifilt];
	sprintf(KEY_TEST, "SIM_PEAKMAG_%c", FILTERSTRING[ifilt_obs]);
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.SIM_PEAKMAG[ifilt]) ; }
      }
    }
    else if ( strncmp(key,"SIM_TEMPLATEMAG",15) == 0 ) {
      for ( ifilt=0; ifilt < SNDATA_FILTER.NDEF; ifilt++ ) {
	ifilt_obs  = SNDATA_FILTER.MAP[ifilt];    
	sprintf(KEY_TEST, "SIM_TEMPLATEMAG_%c", FILTERSTRING[ifilt_obs]);
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.SIM_TEMPLATEMAG[ifilt]) ; }
      }
    }
    else if ( strncmp(key,"SIM_EXPOSURE",12) == 0 ) {
      for ( ifilt=0; ifilt < SNDATA_FILTER.NDEF; ifilt++ ) {
	ifilt_obs  = SNDATA_FILTER.MAP[ifilt];
	sprintf(KEY_TEST, "SIM_EXPOSURE_%c", FILTERSTRING[ifilt_obs]);
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.SIM_EXPOSURE_TIME[ifilt]) ; }
      }
    }
    else if ( strncmp(key,"SIM_GALFRAC",11) == 0 ) {
      for ( ifilt=0; ifilt < SNDATA_FILTER.NDEF; ifilt++ ) {
	ifilt_obs  = SNDATA_FILTER.MAP[ifilt];
	sprintf(KEY_TEST, "SIM_GALFRAC_%c", FILTERSTRING[ifilt_obs]);
	if ( strcmp(key,KEY_TEST) == 0 ) 
	  { copy_flt(copyFlag, parVal, &SNDATA.SIM_GALFRAC[ifilt]) ; }
      }
    }

    else if ( strncmp(key,"SIM_STRONGLENS",14) == 0 ) {
      // continue with SIM_STROGNLENS ...
      sprintf(PREFIX, "SIM_STRONGLENS") ;

      sprintf(KEY_TEST,"%s_ID", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_int(copyFlag, parVal, &SNDATA.SIM_SL_IDLENS); }

      sprintf(KEY_TEST,"%s_z", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.SIM_SL_zLENS); }

      sprintf(KEY_TEST,"%s_TDELAY", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.SIM_SL_TDELAY); }

      sprintf(KEY_TEST,"%s_MAGSHIFT", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.SIM_SL_MAGSHIFT); }

      sprintf(KEY_TEST,"%s_NIMG", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_int(copyFlag, parVal, &SNDATA.SIM_SL_NIMG); }

      sprintf(KEY_TEST,"%s_IMGNUM", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_int(copyFlag, parVal, &SNDATA.SIM_SL_IMGNUM); }

      sprintf(KEY_TEST,"%s_MINSEP", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.SIM_SL_MINSEP); }

      sprintf(KEY_TEST,"%s_LOGMASS", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.SIM_SL_LOGMASS); }

      sprintf(KEY_TEST,"%s_LOGMASS_ERR", PREFIX);
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_dbl(copyFlag, parVal, &SNDATA.SIM_SL_LOGMASS_ERR ); }

    }
    else {
      sprintf(c1err,"Unknown SIM key = '%s' (CCID=%s)", key, SNDATA.CCID );
      sprintf(c2err,"stringVal='%s'  parVal=%f", stringVal, parVal[0] );
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err);     
    }

  }

  // other SIM keys that don't start with SIM
  else if ( ncmp_PySEDMODEL==0 && len_PySEDMODEL > 2) {
    for(ipar=0; ipar < SNDATA.NPAR_PySEDMODEL; ipar++ ) { 
      sprintf(KEY_TEST, "%s", SNDATA.PySEDMODEL_KEYWORD[ipar]) ;
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.PySEDMODEL_PARVAL[ipar]) ;  } 
    }
  }

  else if ( strncmp(key,"LCLIB_PARAM",11) == 0 || 
	    strncmp(key,"LCLIB(",6) == 0 ) {    // read legacy PLASTICC data from 2018
    for(ipar=0; ipar < SNDATA.NPAR_LCLIB; ipar++ ) { 
      sprintf(KEY_TEST, "%s", SNDATA.LCLIB_KEYWORD[ipar]) ;
      if ( strcmp(key,KEY_TEST) == 0 ) 
	{ copy_flt(copyFlag, parVal, &SNDATA.LCLIB_PARVAL[ipar]) ; } 
    }
  }
  
  else {
    // error message
    sprintf(c1err,"Unknown key = '%s' (copyFlag=%d, CCID=%s)", key, copyFlag, SNDATA.CCID );
    sprintf(c2err,"stringVal='%s'  parVal=%f", stringVal, parVal[0] );
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);     
  }

  return ;

}  // end copy_SNDATA_HEAD



// = = = = = = = = = = = = = = = = = = = = = = = = 
int select_MJD_SNDATA(int OPTMASK, double *CUTWIN_MJD, char *CID) {

  // Created Feb 11 2021
  // Use input CUTWIN_MJD to select a subset of observations
  // for copy_SNDATA_OBS.  The sparse list OBS_STORE_LIST
  // enables fast copy by only looping over elements to keep.
  // Note that copy_SNDATA_OBS will abort if this function is not 
  // called for each event.
  //
  // Example: for a 10-year survey, a typical MJD window contains
  // 1 of the 10 seasons, and thus copy_SNDATA_OBS returns just 1 
  // season of data instead of all 10 seasons.
  //
  // Inputs:
  //   OPTMASK: options for what to store
  //        1 -> udpate SNDATA.NOBS_STORE
  //        2 -> udpate SNDATA.NOBS and SNDATA.NEPOCH
  //        3 -> update both
  //   CUTWIN_MJD:  MJD_RANGE to apply selection for NOBS
  //   CID:         for diagnostic dump 
  //
  // Output:
  //     Function returns SNDATA.NOBS_STORE
  //
  // -----------------------------
  //    HISTORY
  //
  // Aug 2026: pass OPTMASK and CID
  //

  int  UPDATE_NOBS_STORE = (OPTMASK & 1);
  int  UPDATE_NOBS       = (OPTMASK & 2);

  int  o, NOBS_STORE  = 0;
  int  NOBS = SNDATA.NOBS ;
  int  LDMP = 0;
  double MJD;

  char fnam[] = "select_MJD_SNDATA" ; (void)fnam;

  // ---------- BEGIN -------

  for(o=1; o <= NOBS; o++ ) {  // note fortran-like index
    MJD = SNDATA.MJD[o];
    if ( MJD < CUTWIN_MJD[0] ) { continue; }
    if ( MJD > CUTWIN_MJD[1] ) { continue; }
    SNDATA.OBS_STORE_LIST[NOBS_STORE] = o ;
    NOBS_STORE++ ;
  }

  if ( LDMP ) {
    printf(" xxx %s: CID=%s  CUTWIN_MJD = %.1f to %.1f  NOBS_STORE=%d -> %d\n", 
	   fnam, CID, CUTWIN_MJD[0], CUTWIN_MJD[1], NOBS, NOBS_STORE);
    fflush(stdout);
  }

  if ( UPDATE_NOBS_STORE ) 
    { SNDATA.NOBS_STORE = NOBS_STORE ; }  // should always do this for analysis

  if ( UPDATE_NOBS )
    { SNDATA.NOBS  = SNDATA.NEPOCH = NOBS_STORE ;  } // do this for modifying NOBS in reformat

  return(NOBS_STORE) ;

} // end select_MJD_SNDATA

int select_mjd_sndata__(int *OPTMASK, double *MJD_WINDOW, char *CID) 
{  return select_MJD_SNDATA(*OPTMASK, MJD_WINDOW, CID); }

// = = = = = = = = = = = = = = = = = = = = = = = =
void host_property_list_sndata(char *HOST_PROPERTY_LIST) {
  // Created Mar 14 2022
  // Return list of stored host property strings based on
  // true values, e.g,
  //   'LOGMASS,LOGsSFR'
  // Original intent is to tell analysis codes which properties
  // to store in output tables.

  double NOVAR = HOSTLIB_PROPERTY_UNDEFINED + 1.0;
  char fnam[] = "host_property_list_sndata"; (void)fnam;
  char TMPLIST[MXPATHLEN];
  // ----------- BEGIN -----------
  HOST_PROPERTY_LIST[0] = TMPLIST[0] = 0 ;

  if ( SNDATA.HOSTGAL_LOGMASS_TRUE[0] > NOVAR ) 
    { catVarList_with_comma(TMPLIST,HOSTGAL_PROPERTY_BASENAME_LOGMASS); }

  if ( SNDATA.HOSTGAL_LOGSFR_TRUE[0] > NOVAR ) 
    { catVarList_with_comma(TMPLIST,HOSTGAL_PROPERTY_BASENAME_LOGSFR); }

  if ( SNDATA.HOSTGAL_LOGsSFR_TRUE[0] > NOVAR ) 
    { catVarList_with_comma(TMPLIST,HOSTGAL_PROPERTY_BASENAME_LOGsSFR); }

  if ( SNDATA.HOSTGAL_COLOR_TRUE[0] > NOVAR ) 
    { catVarList_with_comma(TMPLIST,HOSTGAL_PROPERTY_BASENAME_COLOR); }

  sprintf(HOST_PROPERTY_LIST,"%s", TMPLIST);

  return;
} // end host_property_list_sndata

void host_property_list_sndata__(char *HOST_PROPERTY_LIST) 
{ host_property_list_sndata(HOST_PROPERTY_LIST); }

// = = = = = = = = = = = = = = = = = = = = = = = =
void copy_SNDATA_OBS(int copyFlag, char *key, int NVAL, 
		       char *stringVal, double *parVal ) {

  // Created Feb 2021:
  // For input *key, copy observations to/from SNDATA struct.
  // Note that select_MJD_SNDATA must be called first to 
  // select MJD subset; if not, this function aborts.
  //
  // Inputs:
  //  copyFlag : 
  //     +1 -> copy from string or parVal to SNDATA (prep  data write)
  //     -1 -> copy from SNDATA to string or parVal (after read data)
  //
  //   *key  : name of variable to copy to/from SNDATA struct
  //   NVAL  : number of values to copy
  // 
  // Apr 19 2025; fix to set SNDATA.FILTNAME[obs] for 'FLT' or 'BAND' with copyFlag>0

  int  NOBS_STORE = SNDATA.NOBS_STORE ;
  int  obs, OBS, NSPLIT, MSKOPT, NVAL_TMP ;
  char fnam[] = "copy_SNDATA_OBS" ; (void)fnam;

  // ------------- BEGIN ------------

  if(copyFlag<0) { sprintf(stringVal,"NOTSET");  parVal[0] = -999.0; }
  
  if ( NOBS_STORE < 0 ) {
    sprintf(c1err,"Must call select_MJD_SNDATA to set MJD window");
    sprintf(c2err,"for which obs to copy (CID=%s)", SNDATA.CCID );
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
  }

  if ( strcmp(key,"MJD") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {  // sparse index
      OBS = SNDATA.OBS_STORE_LIST[obs];     // index to full list
      copy_dbl(copyFlag, &parVal[obs], &SNDATA.MJD[OBS]) ; 
    }  
  } 
  else if ( strcmp(key,"FLT") == 0 || strcmp(key,"BAND") == 0 ) {

    if ( copyFlag > 0 ) {

      MSKOPT     = MSKOPT_PARSE_WORDS_STRING ;
      NVAL_TMP   = store_PARSE_WORDS(MSKOPT, stringVal, fnam);
      if ( NVAL != NVAL_TMP ) {
	print_preAbort_banner(fnam);
	printf("  %s stringVAL = \n%s \n", key, stringVal);
	sprintf(c1err,"Expected %d BAND names, but found %d", NVAL, NVAL_TMP);
	sprintf(c2err,"Check stringVal printed above.");
	errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
      }

      // load SNDATA struct for each obs
      for(obs=0; obs < NOBS_STORE; obs++ ) {
	OBS = SNDATA.OBS_STORE_LIST[obs]; // back to C index    
	get_PARSE_WORD(0, obs, SNDATA.FILTNAME[OBS], fnam);  
      }

    }
    else {

      // FILTCHAR_1D includes every observation; here we pick out subset
      // subset of FILTCHAR_1D that are on STORE_LIST
    
      stringVal[0] = 0 ;
      for(obs=0; obs < NOBS_STORE; obs++ ) { 
	OBS = SNDATA.OBS_STORE_LIST[obs]; // back to C index    
	catVarList_with_comma(stringVal, SNDATA.FILTNAME[OBS] );
      }
    } 

  }
  else if ( strcmp(key,"FIELD") == 0 ) {

    if ( copyFlag > 0 ) {
      sprintf(c1err,"key = %s doesn't work with copyFlag=%d", key, copyFlag);
      sprintf(c2err,"Needs a code fix here");
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
    }

    bool IS_FIELD = (strlen(SNDATA.FIELDNAME_1D) > 0); 

    if ( IS_FIELD ) {
      splitString(SNDATA.FIELDNAME_1D, COMMA, fnam, MXEPOCH,    // inputs    
		  &NSPLIT, &SNDATA.FIELDNAME[1] );            // outputs 
    }

    stringVal[0] = 0 ;
    for(obs=0; obs < NOBS_STORE; obs++ ) { 
      OBS = SNDATA.OBS_STORE_LIST[obs] ;    
      if ( !IS_FIELD ) { sprintf(SNDATA.FIELDNAME[OBS],FIELD_NONAME); }
      catVarList_with_comma(stringVal, SNDATA.FIELDNAME[OBS] );
    }

  }
  else if ( strcmp(key,"DETNUM") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_int(copyFlag, &parVal[obs], &SNDATA.DETNUM[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"IMGNUM") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_int(copyFlag, &parVal[obs], &SNDATA.IMGNUM[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"PHOTFLAG") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_int(copyFlag, &parVal[obs], &SNDATA.PHOTFLAG[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"PHOTPROB") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.PHOTPROB[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"FLUXCAL") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.FLUXCAL[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"FLUXCALERR") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.FLUXCAL_ERRTOT[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"PSF_SIG1") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.PSF_SIG1[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"PSF_SIG2") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.PSF_SIG2[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"PSF_RATIO") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.PSF_RATIO[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"PSF_NEA") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.PSF_NEA[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"SKY_SIG") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SKY_SIG[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"SKY_SIG_T") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SKY_SIG_T[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"ZEROPT") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.ZEROPT[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"ZEROPT_ERR") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.ZEROPT_ERR[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"TEXPOSE") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.TEXPOSE[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"GAIN") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.GAIN[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"XPIX") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.XPIX[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"YPIX") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.YPIX[OBS]) ; 
    }  
  }

  // - - - -  Atmos/DCR variables - - - - -
  else if ( strcmp(key,"dRA") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.dRA[OBS]) ; 
    }  
  }
  else if ( strcmp(key,"dDEC") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.dDEC[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"AIRMASS") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.AIRMASS[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"SIM_DCR_dRA") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SIMEPOCH_DCR_dRA[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"SIM_DCR_dDEC") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SIMEPOCH_DCR_dDEC[OBS]) ; 
    }  
  }

  else if ( strcmp(key,"SIM_DCR_dMAG") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SIMEPOCH_DCR_dMAG[OBS]) ; 
    }  
  }

  // - - - - 

  else if ( strcmp(key,"SIM_MAGOBS") == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SIMEPOCH_MAG[OBS]) ; 
    }  
  }

  else if ( strcmp(key,SNDATA.VARNAME_SNRMON) == 0 ) {
    for(obs=0; obs < NOBS_STORE; obs++ ) {
      OBS = SNDATA.OBS_STORE_LIST[obs];  
      copy_flt(copyFlag, &parVal[obs], &SNDATA.SIMEPOCH_SNRMON[OBS]) ; 
    }  
  }

  else {
    // error message
    sprintf(c1err,"Unknown key = %s (copyFlag=%d)", key, copyFlag);
    sprintf(c2err,"stringVal='%s'  parVal=%f", stringVal, parVal[0] );
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
  }

  if  ( NVAL != NOBS_STORE ) {
    sprintf(c1err,"Copied %d values (NOBS_STORE)", NOBS_STORE);
    sprintf(c2err,"but expected NVAL=%d", NVAL);
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);     
  }

  return ;

} // end copy_SNDATA_OBS


// ==========================================
void copy_GENSPEC(int copyFlag, char *key, int ispec, double *parVal ) {

  // Created Feb 18 2021
  // Return contents of GENSPEC structure; 
  // intended as fortran interface to read spectra from data.
  //
  // Inputs:
  //  copyFlag : 
  //     +1 -> copy from string or parVal to SNDATA (prep  data write)
  //     -1 -> copy from SNDATA to string or parVal (after read data)
  //

  int  NBLAM, ilam ;
  char fnam[] = "copy_GENSPEC" ; (void)fnam;

  // ------------ BEGIN ----------

  if ( copyFlag<0 ) {  parVal[0] = -999.0; }  // init outpuit

  if ( strcmp(key,"NSPECTRA") == 0 ) 
    { copy_int(copyFlag, parVal, &GENSPEC.NMJD_PROC );  }

  // - - - - - - -
  if ( ispec < 0 ) { return; }

  NBLAM = GENSPEC.NBLAM_VALID[ispec];

  // ispec-dependent info

  if ( strcmp(key,"ID") == 0 ) 
    { copy_int(copyFlag, parVal, &GENSPEC.ID_LIST[ispec] );  }

  else if ( strcmp(key,"MJD") == 0 ) 
    { copy_dbl(copyFlag, parVal, &GENSPEC.MJD_LIST[ispec] );  }

  else if ( strcmp(key,"NBLAM") == 0 ) 
    { copy_int(copyFlag, parVal, &GENSPEC.NBLAM_VALID[ispec] );  }

  else if ( strcmp(key,"TEXPOSE") == 0 ) 
    { copy_dbl(copyFlag, parVal, &GENSPEC.TEXPOSE_LIST[ispec] );  }

  // xxxxxxxxxxx
  // ?? no string passed ??
  //else if ( strcmp(key,"INSTRUMENT") == 0 ) {
  // copy_str(copyFlag, stringVal, GENSPEC.INSTRUMENT_LIST[ispec] ); 
  // xxxxx
  
  // lam-dependent arrays

  else if ( strcmp(key,"LAMMIN") == 0 ) {
    for(ilam=0; ilam  < NBLAM; ilam++ ) 
      { copy_dbl(copyFlag, &parVal[ilam], &GENSPEC.LAMMIN_LIST[ispec][ilam] ); }
  }
  else if ( strcmp(key,"LAMMAX") == 0 ) {
    for(ilam=0; ilam  < NBLAM; ilam++ ) 
      { copy_dbl(copyFlag, &parVal[ilam], &GENSPEC.LAMMAX_LIST[ispec][ilam] ); }
  }
  else if ( strcmp(key,"FLAM") == 0 ) {
    for(ilam=0; ilam  < NBLAM; ilam++ ) 
      { copy_dbl(copyFlag, &parVal[ilam], &GENSPEC.FLAM_LIST[ispec][ilam] ); }
  }
  else if ( strcmp(key,"FLAMERR") == 0 ) {
    for(ilam=0; ilam  < NBLAM; ilam++ ) 
      { copy_dbl(copyFlag, &parVal[ilam], &GENSPEC.FLAMERR_LIST[ispec][ilam]); }

  }
  else if ( strcmp(key,"SIM_FLAM") == 0 ) {
    for(ilam=0; ilam  < NBLAM; ilam++ ) 
      { copy_dbl(copyFlag, &parVal[ilam], &GENSPEC.GENFLAM_LIST[ispec][ilam]); }

  }

  return;

}  // end copy_GENSPEC

// ==========================================
void RD_PRIVATE_INIT(char *PRIVATE_VARNAME_LIST) {

  // Created Sep 2023
  // if input PRIVATE_VARNAME_LIST, parse this comma-sep list of
  // private variable names to keep, and re-make list of private vars
  // to read from data file. 
  // Initial goal here is to enable REFORMAT option to write out 
  // subset of PRIVATE variables.

  int NVAR_ORIG = SNDATA.NVAR_PRIVATE;
  int i0, i1, NVAR_LIST=0, NVAR_MATCH=0 ;
  int MEMC = sizeof(char)*40;
  char **ptr_VARNAME_LIST;
  char fnam[] = "RD_PRIVATE_INIT" ; (void)fnam;

  // --------- BEGIN --------

  if ( NVAR_ORIG == 0 ) { return ;}
  if ( strlen(PRIVATE_VARNAME_LIST) == 0 ) { return; }

  // allocate memory for each VARNAME
  ptr_VARNAME_LIST = (char**)malloc( MXVAR_PRIVATE*sizeof(char*));
  for(i0=0; i0 < MXVAR_PRIVATE; i0++ )
    { ptr_VARNAME_LIST[i0] = (char*)malloc(MEMC); }

  splitString(PRIVATE_VARNAME_LIST, COMMA, fnam, MXVAR_PRIVATE,    // inputs  
	      &NVAR_LIST, ptr_VARNAME_LIST );       // outputs             


  char *ptr_KEYWORD0, *ptr_VARNAME, KEYWORD1[100];
  bool MATCH ;

  for(i0=1; i0 <= NVAR_ORIG; i0++ ) {
    ptr_KEYWORD0 = SNDATA.PRIVATE_KEYWORD[i0];
    MATCH       = false;
    for ( i1=0; i1 < NVAR_LIST; i1++ ) {
      sprintf(KEYWORD1,"PRIVATE(%s)", ptr_VARNAME_LIST[i1]);
      if ( strcmp(ptr_KEYWORD0,KEYWORD1) == 0 ) 
	{ ptr_VARNAME = ptr_VARNAME_LIST[i1]; MATCH = true;  }
    }
    
    if ( MATCH ) {
      NVAR_MATCH++ ; 
      sprintf(SNDATA.PRIVATE_KEYWORD[NVAR_MATCH],"%s", ptr_KEYWORD0);
      sprintf(SNDATA.PRIVATE_VARNAME[NVAR_MATCH],"%s", ptr_VARNAME);
    }

  } // end i0

  if ( NVAR_MATCH != NVAR_LIST ) {
    print_preAbort_banner(fnam);
    printf("\t PRIVATE_VARNAME_LIST = %s \n", PRIVATE_VARNAME_LIST);
    for(i0=1; i0 <= NVAR_MATCH; i0++ ) {
      printf("\t Found match for %s \n", SNDATA.PRIVATE_KEYWORD[i0]);
    }

    sprintf(c1err,"expected to find NVAR_LIST=%d private-var matches", NVAR_LIST);
    sprintf(c2err,"but found %d matches.", NVAR_MATCH);
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);     
  }

  SNDATA.NVAR_PRIVATE = NVAR_MATCH;

  printf("\n %s: select %d of %d original PRIVATE variables. \n",
	 fnam, NVAR_MATCH, NVAR_ORIG); fflush(stdout);

  return ;

} // end RD_PRIVATE_INIT

// ==============================================
void RD_OVERRIDE_INIT(char *OVERRIDE_PATH, int REQUIRE_DOCANA) {

  // read and store columns from comma-sep list of  override files 
  // to override values in data headers (not photometry).
  // Allows float/double/int, but not strings
  // (e.g., cannot override SNID, FIELD, .. )
  //
  // Input *OVERRIDE_PATH is either a comma-sep list of files,
  // or a folder containint [OVERRIDE_PATH].LIST with list of override files.
  //
  // Oct 3 2023: add input REQUIRE_DOCANA
  // Feb 24 2026: abort if there is a mix of override files keyed by CID and GALID
  // Mar 20 2026: refactor to allow either file list or directory to be passed.
  // Sep 02 2026: check zHELERR and zCMBERR

  int NROW, ivar, igal, ifile, ICAST, IFILE, IVAR, NFILE = 0;
  int OPTMASK_SNTABLE = 4;           // append next file
  char **file_list, *ptrFile, *VARNAME_MATCH, *ptr_varname;
  char VARNAME[60], PREFIX[40], PREFIXz[40] ;
  char TABLE_NAME[] = "OVERRIDE" ;
  char VARLIST[]    = "ALL" ;  
  char fnam[]       = "RD_OVERRIDE_INIT" ; (void)fnam;
  int LTRACE = 0 ;

  // ----------- BEGIN -----------

  RD_OVERRIDE.USE = false;
  if ( IGNOREFILE(OVERRIDE_PATH) ) { return; }

  // init number of files matched by CID and by GALID
  RD_OVERRIDE.NMATCH_by_CID   = 0 ;
  RD_OVERRIDE.NMATCH_by_GALID = 0 ;
  RD_OVERRIDE.NVAR_NULL_ON_MISSING_EVENT = 0; // default is use data value if no override

  print_banner(fnam);

  if ( LTRACE ) { 
    printf(" xxx %s TRACE-1  len(OVERRIDE_PATH)=%lu\n", 
	   fnam, strlen(OVERRIDE_PATH) ); fflush(stdout); 
  }

  // get list of override files
  char *OVERRIDE_FILE_LIST = (char*)malloc(MXPATHLEN * 10 * sizeof(char) );
  get_override_file_list(OVERRIDE_PATH, OVERRIDE_FILE_LIST);

  if ( LTRACE ) { printf(" xxx %s TRACE-2 \n", fnam); fflush(stdout); }

  if ( strlen(OVERRIDE_FILE_LIST) < 3 )  { return; }

  // split comma-sep OVERRIDE_FILE 
  parse_commaSepList(fnam, OVERRIDE_FILE_LIST, MXFILE_OVERRIDE, MXPATHLEN,
		     &NFILE, &file_list ); // <== returned
  
  if ( LTRACE ) { printf(" xxx %s TRACE-3 \n", fnam); fflush(stdout); }

  SNTABLE_AUTOSTORE_RESET();

  for(ifile=0; ifile < NFILE; ifile++ ) {
    ptrFile = file_list[ifile] ; 
    ENVreplace(ptrFile, fnam, 1);
 
    if ( REQUIRE_DOCANA ) {
      int OPTMASK_OPEN = OPENMASK_REQUIRE_DOCANA, gzipFlag ;
      char fullName[MXPATHLEN], PATH_LIST[] = "" ;
      FILE *fp = snana_openTextFile (OPTMASK_OPEN, PATH_LIST, ptrFile, fullName, &gzipFlag );
      if ( !fp ) { abort_openTextFile("HEADER_OVERRIDE", PATH_LIST, ptrFile, fnam); }
      fclose(fp);
    }

    if ( LTRACE ) { printf(" xxx %s TRACE-4 \n", fnam); fflush(stdout); }

    // read entire table and store contents
    NROW = SNTABLE_AUTOSTORE_INIT(ptrFile, TABLE_NAME, VARLIST, OPTMASK_SNTABLE );

    // check option to NOT use data values for missing events in override
    init_override_missing_event(ifile, ptrFile);

    // store varname in 1st column used to match with data
    sprintf(RD_OVERRIDE.VARNAME_MATCH, "%s", READTABLE_POINTERS.VARNAME[0] ); //9.29.2025
    VARNAME_MATCH = RD_OVERRIDE.VARNAME_MATCH;
    if ( strcmp(VARNAME_MATCH,"HOSTGAL_OBJID") == 0 || 
	 strcmp(VARNAME_MATCH,"GALID") == 0 ) {
      RD_OVERRIDE.NMATCH_by_GALID++ ;
    }
    else {
      RD_OVERRIDE.NMATCH_by_CID++ ;
    }

    printf("   Stored %d rows of header-override data; match rows using %s\n", 
	   NROW, VARNAME_MATCH );

    if ( NROW == 0 ) {
      sprintf(c1err,"NROW=0 in HEADER_OVERRIDE_FILE");
      sprintf(c2err,"Check %s", ptrFile);
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
    }
  } // end ifile
  
  // Feb 24 2026: require all files to be keyed by CID or GALID, but mix is not allowed.
  int N_by_CID   = RD_OVERRIDE.NMATCH_by_CID ;
  int N_by_GALID = RD_OVERRIDE.NMATCH_by_GALID ;
  if ( N_by_CID > 0 && N_by_GALID > 0 ) {
    sprintf(c1err,"%d/%d HEADER_OVERRIDE files are keyed by CID/GALID;", N_by_CID, N_by_GALID);
    sprintf(c2err,"All OVERRIDE files must be keyed by CID or GALID; mix not allowed." );
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);       
  }

  // - - - - - - - - - - - - 
  RD_OVERRIDE.USE    = true ;
  RD_OVERRIDE.NFILE  = NFILE;
  for(ivar=0; ivar < IVARMAX_OVERRIDE ; ivar++ )
    { RD_OVERRIDE.NTOT_PER_VAR[ivar] = 0 ; }

  // - - - - - - - 
  // set z logicals in case zHEL <-> zCMB needs to be recomputed
  RD_OVERRIDE.IVAR_zCMB = RD_OVERRIDE.IVAR_zCMBERR = -9 ;
  RD_OVERRIDE.IVAR_zHEL = RD_OVERRIDE.IVAR_zHELERR = -9 ; 

  for(igal=0; igal < MXHOSTGAL; igal++ ) {
    RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT[igal]           = -9 ;
    RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT_ERR[igal]       = -9 ;
    RD_OVERRIDE.IVAR_HOSTGALz_QUANTILE_ZPHOT[igal] = -9 ;
    RD_OVERRIDE.IVAR_HOSTGALz_LOGMASS[igal]        = -9 ;
  }

  RD_OVERRIDE.IVAR_NAME_IAUC      = -9 ;
  RD_OVERRIDE.IVAR_NAME_TRANSIENT = -9 ;
    
  // - - - - - - - -
  if ( EXIST_VARNAME_AUTOSTORE("REDSHIFT_FINAL") ) 
    { RD_OVERRIDE.IVAR_zCMB = IVAR_VARNAME_AUTOSTORE("REDSHIFT_FINAL", &ICAST, &IFILE ); }

  if ( EXIST_VARNAME_AUTOSTORE("REDSHIFT_CMB") ) 
    { RD_OVERRIDE.IVAR_zCMB = IVAR_VARNAME_AUTOSTORE("REDSHIFT_CMB", &ICAST, &IFILE  ); }

  if ( EXIST_VARNAME_AUTOSTORE("REDSHIFT_CMB_ERR") ) 
    { RD_OVERRIDE.IVAR_zCMBERR = IVAR_VARNAME_AUTOSTORE("REDSHIFT_CMB_ERR", &ICAST, &IFILE  ); }

  if ( EXIST_VARNAME_AUTOSTORE("REDSHIFT_HELIO") ) 
    { RD_OVERRIDE.IVAR_zHEL = IVAR_VARNAME_AUTOSTORE("REDSHIFT_HELIO", &ICAST, &IFILE  ); }

  if ( EXIST_VARNAME_AUTOSTORE("REDSHIFT_HELIO_ERR") ) 
    { RD_OVERRIDE.IVAR_zHELERR = IVAR_VARNAME_AUTOSTORE("REDSHIFT_HELIO_ERR", &ICAST, &IFILE  ); }


  //check ZPHOT & host quantiles for all hosts
  for(igal=0; igal < MXHOSTGAL; igal++ ) {

    get_SNDATA_HOSTGAL_PREFIX(igal, PREFIX, PREFIXz);

    sprintf(VARNAME,"%s_PHOTOZ", PREFIX);
    if ( EXIST_VARNAME_AUTOSTORE(VARNAME) )  { 
      IVAR = IVAR_VARNAME_AUTOSTORE(VARNAME, &ICAST, &IFILE  );
      RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT[igal]  = IVAR;
    }

    sprintf(VARNAME,"%s_PHOTOZ_ERR", PREFIX);
    if ( EXIST_VARNAME_AUTOSTORE(VARNAME) ) {
      IVAR = IVAR_VARNAME_AUTOSTORE(VARNAME, &ICAST, &IFILE  );
      RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT_ERR[igal] = IVAR;
    }

    // read one row per "GALID z percent"
    ptr_varname = SNDATA.HOSTGALz_QUANTILE_ZPHOT[igal].VARNAME_Z ; 
    if ( EXIST_VARNAME_AUTOSTORE(ptr_varname) ) { 
      IVAR = IVAR_VARNAME_AUTOSTORE(ptr_varname, &ICAST, &IFILE  ) ;
      RD_OVERRIDE.IVAR_HOSTGALz_QUANTILE_ZPHOT[igal] = IVAR;
    }

    ptr_varname = SNDATA.HOSTGALz_LOGMASS[igal].VARNAME_Z ; 
    if ( EXIST_VARNAME_AUTOSTORE(ptr_varname) ) { 
      IVAR = IVAR_VARNAME_AUTOSTORE(ptr_varname, &ICAST, &IFILE  ) ;
      RD_OVERRIDE.IVAR_HOSTGALz_LOGMASS[igal] = IVAR;
    }

  } // end igal
  
  // check alternate override column name for quantile zphot
  if ( EXIST_VARNAME_AUTOSTORE(VARNAME_QZPHOT00) ) { 
    IVAR = IVAR_VARNAME_AUTOSTORE(VARNAME_QZPHOT00, &ICAST, &IFILE  ) ;
    RD_OVERRIDE.IVAR_HOSTGALz_QUANTILE_ZPHOT[0] = IVAR;
  }

  // check for implicit quantile zphot-list per GALID
  rd_override_qzphot_implicit(1, -9);

  if ( EXIST_VARNAME_AUTOSTORE("NAME_IAUC") ) 
    { RD_OVERRIDE.IVAR_NAME_IAUC = IVAR_VARNAME_AUTOSTORE("NAME_IAUC", &ICAST, &IFILE  ); }

  if ( EXIST_VARNAME_AUTOSTORE("NAME_TRANSIENT") ) 
    { RD_OVERRIDE.IVAR_NAME_TRANSIENT = IVAR_VARNAME_AUTOSTORE("NAME_TRANSIENT", &ICAST, &IFILE  ); }

  
  // check for varname mistakes
  rd_override_check_mistake("HOSTGAL_ZPHOT" ,    "HOSTGAL_PHOTOZ");  // 2nd one is correct; allow 1st one
  rd_override_check_mistake("HOSTGAL_ZPHOTERR" , "HOSTGAL_PHOTOZ_ERR");
  rd_override_check_mistake("HOSTGAL_ZPHOT_ERR", "HOSTGAL_PHOTOZ_ERR");

  rd_override_check_mistake("HOSTGAL_ZSPEC" ,    "HOSTGAL_SPECZ");
  rd_override_check_mistake("HOSTGAL_ZSPECERR" , "HOSTGAL_SPECZ_ERR");
  rd_override_check_mistake("HOSTGAL_ZSPEC_ERR", "HOSTGAL_SPECZ_ERR");


  // if both zCMB and zHEL are on header-override list,
  // turn them off since there is no need to POST-PROCESS.
  if ( RD_OVERRIDE.IVAR_zCMB >=0  && RD_OVERRIDE.IVAR_zHEL >= 0 ) 
    { RD_OVERRIDE.IVAR_zCMB = RD_OVERRIDE.IVAR_zHEL = -9; }


  RD_OVERRIDE.NVAR_USE    = 0;
  RD_OVERRIDE.ID_LAST[0]  = 0; 
  RD_OVERRIDE.CID_LAST[0] = 0; 
  RD_OVERRIDE.NEVT        = 0; 
  RD_OVERRIDE.N_HOSTGAL_PHOTOZ_REPLACE = 0 ;

  // Apr 12 2026: store if data is SNANA sim
  RD_OVERRIDE.IS_SIM = ( strcmp(SNDATA.DATATYPE,DATATYPE_SIM_SNANA) == 0 );


  printf("\n Finished %s\n\n", fnam);
  free(OVERRIDE_FILE_LIST);

  return ;

} // end RD_OVERRIDE_INIT


void init_override_missing_event(int IFILE, char *OVERRIDE_FILE) {

  // Created May 6 2026: 
  // check override file before VARNAMES key for NULL_ON_MISSING_EVENT key
  //
  // Inputs:
  //   IFILE  : sparse file index for list of OVERRIDE files
  //   OVERRIDE_FILE : name of OVERRIDE file to check for KEY_NULL_ON_MISSING_EVENT
  //
  
  char KEY_STOP_READ[] = "VARNAMES";  // stop reading when finding this key
  int  NULL_ON_MISSING_EVENT;

  int  ivar, NVAR = SNTABLE_AUTOSTORE[IFILE].NVAR ;
  int  NVAR_MISSING_EVENT = RD_OVERRIDE.NVAR_NULL_ON_MISSING_EVENT ;
  char *varname_override, varname_tmp[60], *VARLIST_MISSING_EVENT ;
  int  igal;
  bool IS_Q0, IS_Q;
  double val;
  char fnam[] = "init_override_missing_event";  (void)fnam;

  // ------------ BEGIN -----------

  read_YAML_VALS(OVERRIDE_FILE, KEY_NULL_ON_MISSING_EVENT, KEY_STOP_READ, fnam, &val);
  NULL_ON_MISSING_EVENT = (int)val;  // returns -999 if no key
  if ( NULL_ON_MISSING_EVENT < 0 ) { NULL_ON_MISSING_EVENT = 0; } 

  if ( NULL_ON_MISSING_EVENT == 0 ) { return; }

  // if we get here, beging storage.
  VARLIST_MISSING_EVENT = (char*)malloc( sizeof(char)*MXPATHLEN );
  VARLIST_MISSING_EVENT[0] = 0;

  HOSTGALz_DEF *HOSTGALz_Q0 = &SNDATA.HOSTGALz_QUANTILE_ZPHOT[0];

  for(ivar=0; ivar < NVAR; ivar++ ) {
    varname_override = SNTABLE_AUTOSTORE[IFILE].VARNAME[ivar]; 

    IS_Q0 = (strcmp(varname_override,VARNAME_QZPHOT00) == 0 ||      // first QZPHOT00
	     strcmp(varname_override,HOSTGALz_Q0->VARNAME_Z)  == 0 ); // or HOSTGALz_QUANTILE_ZPHOT[0]

    IS_Q  = (strstr(varname_override,PREFIX_QZPHOT) != NULL ) ||  // any QZPHOTmm
      (strstr(varname_override,SUFFIX_QUANTILE_ZPHOT) !=NULL );   // or any *QUANTILE_ZPHOT
    
    // if QZPHOT00 or HOSTGALz_QUANTILE_ZPHOT is on the list, 
    // auto-store all of the photo-z variables in the data stream
    if ( IS_Q0 ) {
      char PREFIX[20], PREFIXz[20];
      for(igal=0; igal < MXHOSTGAL; igal++ ) {
	HOSTGALz_DEF *HOSTGALz_Q = &SNDATA.HOSTGALz_QUANTILE_ZPHOT[igal];

	catVarList_with_comma(VARLIST_MISSING_EVENT, HOSTGALz_Q->VARNAME_Z);
	NVAR_MISSING_EVENT++ ;

	catVarList_with_comma(VARLIST_MISSING_EVENT, HOSTGALz_Q->VARNAME_VAL);
	NVAR_MISSING_EVENT++ ;

	get_SNDATA_HOSTGAL_PREFIX(igal, PREFIX, PREFIXz);
	sprintf(varname_tmp,"%s_PHOTOZ",     PREFIX); 
	catVarList_with_comma(VARLIST_MISSING_EVENT, varname_tmp);
	NVAR_MISSING_EVENT++ ;

	sprintf(varname_tmp,"%s_PHOTOZ_ERR", PREFIX); 
	catVarList_with_comma(VARLIST_MISSING_EVENT, varname_tmp);
	NVAR_MISSING_EVENT++ ;
      }
    }
    if ( IS_Q ) { continue; } // bail on any quantile to avoid duplicates

    catVarList_with_comma(VARLIST_MISSING_EVENT, varname_override);
    NVAR_MISSING_EVENT++ ;
  }

  // convert comma-sep list into char array for easier lookup
  float fmem; (void)fmem;
  int NSPLIT;
  fmem = malloc_strlist(+1, NVAR_MISSING_EVENT, 40, 
			&RD_OVERRIDE.VARNAMES_NULL_ON_MISSING_EVENT);

  splitString(VARLIST_MISSING_EVENT, COMMA, fnam, 50, &NSPLIT, 
	      RD_OVERRIDE.VARNAMES_NULL_ON_MISSING_EVENT );

  // print summary to stdout
  printf("\n  The following %s data variables remain NULL for missing override:\n",
	 KEY_NULL_ON_MISSING_EVENT);
  for(ivar=0; ivar < NSPLIT; ivar++ ) {
    printf("\t  %s \n", 
	   RD_OVERRIDE.VARNAMES_NULL_ON_MISSING_EVENT[ivar]); fflush(stdout);
  }

  // sanity check on number of NULL_ON_MISSING_EVENT variables
  if ( NSPLIT != NVAR_MISSING_EVENT ) {
    print_preAbort_banner(fnam);
    printf("  VARLIST_MISSING_EVENT = '%s' \n", VARLIST_MISSING_EVENT);
    sprintf(c1err,"NSPLIT(VARLIST_MISSING_EVENT) = %d but expected NVAR_MISSING_EVENT=%d",
	    NSPLIT, NVAR_MISSING_EVENT);
    sprintf(c2err,"Check string corruption in VARLIST_MISSING_EVENT");
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);       
  }
  // xxx printf(" xxx %s: VARLIST_MISSING_EVENT = \n  %s\n", fnam, VARLIST_MISSING_EVENT);



  RD_OVERRIDE.NVAR_NULL_ON_MISSING_EVENT = NVAR_MISSING_EVENT;
  free(VARLIST_MISSING_EVENT);

  // there is no utility to return list of variables found,
  // so need to search internal AUTOSTORE array

  //  debugexit(fnam);

  return;

} // end init_override_missing_event


bool match_override_missing_event(char *VARNAME) {

  // Created May 7 2026
  // Return true input *VARNAME matches any of the "NULL_ON_MISSING_EVENT"
  // variables in the OVERRIDE file(s).

  int ivar, NVAR_CHECK = RD_OVERRIDE.NVAR_NULL_ON_MISSING_EVENT;
  char *VARNAME_TMP;
  char fnam[] = "match_override_missing_event" ;  (void)fnam;

  // ------------ BEGIN ---------

  if ( NVAR_CHECK == 0 ) { return false; }

  for(ivar=0; ivar < NVAR_CHECK; ivar++ ) {
    VARNAME_TMP = RD_OVERRIDE.VARNAMES_NULL_ON_MISSING_EVENT[ivar];
    if ( strcmp(VARNAME,VARNAME_TMP) == 0 ) { return true; }
  }

  // if we get here there is no match so return false
  return false ;

}  // end match_override_missing_event


// ==============================================
bool ISRD_OVERRIDE_VARNAME(char *VARNAME) {
  bool ISOV = false;
  int  IVAR = -9, ICAST, IFILE;
  // Return True of this VARNAME is on override list
  IVAR = IVAR_VARNAME_AUTOSTORE(VARNAME, &ICAST, &IFILE  ) ;
  ISOV = (IVAR>=0 );
  return ISOV;
} // end ISRD_OVERRIDE_VARNAME
bool isrd_override_varname__(char *VARNAME) { return ISRD_OVERRIDE_VARNAME(VARNAME); }


void get_override_file_list(char *OVERRIDE_PATH, char *OVERRIDE_FILE_LIST) {

  // Created Mar 20 2026
  // For input OVERRIDE_PATH, return comma-sep list of files in
  // OVERRIDE_FILE_LIST. 
  // If *OVERRIDE_PATH is already a file list, return OVERRIDE_FILE_LIST = OVERRIDE_PATH.
  // If *OVERRIDE_PATH is a directory, read LIST file from directory that contains
  // list file override files.
  //
  // Jun 24 2026: allocate OVERRIDE_PATH_LOCAL to be same size as OVERRIDE_PATH

  bool IS_FILE = false ;
  bool IS_DIR  = false ;
  bool IS_LINK = false ;
  int  istat, istat_link; 
  
  int LEN_PATH = strlen(OVERRIDE_PATH);
  int MEMC     = sizeof(char) * ( LEN_PATH + 2*MXPATHLEN ) ; // give extra space for ENVreplace
  char *OVERRIDE_PATH_LOCAL = (char*)malloc(MEMC);

  struct stat statbuf, linkbuf ; 
  int LDMP = 0 ;
  char cWARN[20];
  char fnam[] = "get_override_file_list" ; (void)fnam;

  // ----------- BEGIN ---------

  OVERRIDE_FILE_LIST[0] = 0 ;

  sprintf(OVERRIDE_PATH_LOCAL, "%s", OVERRIDE_PATH);

  // if there is a comma, then it has to be a file list
  if (strstr(OVERRIDE_PATH_LOCAL,COMMA) != NULL ) {  
    IS_FILE = true ;  
  }
  else {
    // use stat function to determine file vs. path
    ENVreplace(OVERRIDE_PATH_LOCAL, fnam, 1);

    istat       =  stat(OVERRIDE_PATH_LOCAL, &statbuf);  (void)istat;
    istat_link  = lstat(OVERRIDE_PATH_LOCAL, &linkbuf);  (void)istat_link;
    IS_DIR      = S_ISDIR(statbuf.st_mode);
    IS_LINK     = S_ISLNK(linkbuf.st_mode);
    IS_FILE     = !IS_DIR ;
  }

  if ( LDMP ) {
    printf("\n xxx %s DUMP -------------------------------- \n", fnam );
    printf(" xxx %s: OVERRIDE_PATH = '%s' \n", fnam, OVERRIDE_PATH_LOCAL);
    printf(" xxx %s: IS[DIR,FILE,LINK] = %d  %d  %d\n", fnam, IS_DIR, IS_FILE, IS_LINK) ;
    fflush(stdout);
  }

  // - - - 
  if ( IS_FILE ) {
    sprintf(OVERRIDE_FILE_LIST, "%s", OVERRIDE_PATH_LOCAL);
  }
  else {
    // for /path/base, check list file with name  /path/base/base.LIST
    char *basename = strrchr(OVERRIDE_PATH_LOCAL, '/'); // basename include slash    
    char *LIST_FILE = (char*) malloc(2*MXPATHLEN * sizeof(char) );
    char *tmp_file  = (char*) malloc(2*MXPATHLEN * sizeof(char) );
    char *TMP_FILE  = (char*) malloc(2*MXPATHLEN * sizeof(char) );
    int i, NF;

    if ( IS_LINK ) { // show resolved symlink
      char symlink[MXPATHLEN];  ssize_t count;
      count = readlink(OVERRIDE_PATH_LOCAL, symlink, sizeof(symlink) - 1);
      symlink[count] = '\0'; // Manually null-terminate
      printf("  Resolve OVERRIDE symLink: %s -> %s\n", &basename[1],  symlink ); fflush(stdout);
    }
    sprintf(LIST_FILE, "%s/%s.LIST", OVERRIDE_PATH_LOCAL, &basename[1] );

    if ( LDMP ) {
      printf(" xxx %s: basename = %s \n", fnam, basename);
      printf(" xxx %s: LIST_FILE = %s \n", fnam, LIST_FILE);      
    }
    NF = store_PARSE_WORDS(MSKOPT_PARSE_WORDS_FILE, LIST_FILE, fnam);

    cWARN[0] = 0;    if ( NF == 0 ) { sprintf(cWARN,"WARNING:"); }

    printf("  %s Found %d OVERRIDE files in folder \n   %s : \n", cWARN, NF, OVERRIDE_PATH_LOCAL);
    for (i=0; i < NF; i++ ) {
      get_PARSE_WORD(LANGFLAG_PARSE_WORDS_C, i, tmp_file, fnam);
      sprintf(TMP_FILE, "%s/%s", OVERRIDE_PATH_LOCAL, tmp_file);
      catVarList_with_comma(OVERRIDE_FILE_LIST,TMP_FILE);
      printf("\t %s \n", tmp_file);
    }
    free(LIST_FILE); free(tmp_file); free(TMP_FILE);

  }

  if ( LDMP ) {
    printf(" xxx %s: final OVERRIDE_FILE_LIST = \n xxx %s \n", 
	   fnam, OVERRIDE_FILE_LIST); 
  }

  fflush(stdout);
  //debugexit(fnam); // xxx REMOVE
  free(OVERRIDE_PATH_LOCAL);

  return;

} // end get_override_file_list


// ==================================================
void rd_override_check_mistake(char *varname_mistake, char *varname_correct) {

  char fnam[] = "rd_override_check_mistake"; (void)fnam;

  // ------------ BEGIN ----------

  if ( EXIST_VARNAME_AUTOSTORE(varname_mistake) )  {
    sprintf(c1err,"Found invalid override varname = %s", varname_mistake);
    sprintf(c2err,"try '%s' instead", varname_correct);
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);       
  }

  return;

} // end rd_override_check_mistake


// ==================================================
int RD_OVERRIDE_FETCH(char *CID, long long int GALID, char *VARNAME, double *DVAL, char *STRVAL) {

  // Created Dec 2021
  // If CID (or GALID) and VARNAME is on override list, return DVAL
  // and function returns 1.
  // Function returns 0 if there is no override; else return length of DVAL
  //
  // July 25 2024: return *STRVAL if VARNAME cast is string (e.g., for IAUC)
  // Aug  07 2025: abort if none of the override vars are used.
  // Sep  29 2025: pass GALID and check option to match by GALID (HOSTGAL_OBJID) instead of by CID
  // Apr  11 2026: return DVAL array and return array length

  bool NEW_ID, NEW_CID, FOUND_VARNAME ;
  int  ISTAT, NRD, IVAR, ICAST, IFILE, NTOT_PER_VAR, ivar ;
  char ID_LOCAL[40], CID_LOCAL[40];

  int LDMP = 0 ;
  char fnam[] = "RD_OVERRIDE_FETCH"; (void)fnam;

  // ----------- BEGIN -----------
  DVAL[0] = 0.0;
  if ( !RD_OVERRIDE.USE ) { return 0; }

  // - - - - - -
  ID_LOCAL[0] = 0 ;
  sprintf(CID_LOCAL,"%s", CID);
  if ( RD_OVERRIDE.NMATCH_by_CID > 0 ) 
    { sprintf(ID_LOCAL,"%s", CID);  }
  else if ( GALID != 0 )
    { sprintf(ID_LOCAL,"%lld", GALID);  }

  if ( strlen(ID_LOCAL) == 0 ) { return 0; } // 9.29.2025: wait for VARNAME_MATCH to be read 

  IVAR = IVAR_VARNAME_AUTOSTORE(VARNAME, &ICAST, &IFILE );
  FOUND_VARNAME = ( IVAR >= 0 ) ;

  if ( IVAR >= IVARMAX_OVERRIDE ) {
    sprintf(c1err,"IVAR(%s) = %d exceeds bound of IVARMAX_OVERRIDE = %d",
	    VARNAME, IVAR, IVARMAX_OVERRIDE);
    sprintf(c2err,"May need to increase IVARMAX_OVERRIDE");
    errmsg(SEV_FATAL, 0, fnam, c1err, c2err);     
  }

  // check for NEW_ID. Always require NEW_CID, even if matching by GALID.
  // For latter, different GALIDs from multiple hosts may be called for
  // same event
  NEW_CID = ( strcmp(RD_OVERRIDE.CID_LAST, CID_LOCAL) != 0 );
  NEW_ID  = ( strcmp(RD_OVERRIDE.ID_LAST,  ID_LOCAL ) != 0 ) && NEW_CID;

  if ( NEW_ID ) {

      if ( LDMP ) {
	printf(" xxx %s: NEW_ID for ID_LOCAL(LAST,NOW) = %s , %s (CID=%s)\n", 
	       fnam, RD_OVERRIDE.ID_LAST, ID_LOCAL, SNDATA.CCID); 
	printf(" xxx %s: VARNAME='%s'  IVAR=%d  FOUND_VARNAME=%d \n",
	       fnam, VARNAME, IVAR, FOUND_VARNAME);
	printf(" xxx %s: NEVT=%d  NVAR_USE=%d \n", fnam, RD_OVERRIDE.NEVT, RD_OVERRIDE.NVAR_USE);
	fflush(stdout);
      }

    if ( RD_OVERRIDE.NEVT > 0 && RD_OVERRIDE.NVAR_USE == 0 ) {
      print_preAbort_banner(fnam);
      printf("\t RD_OVERRIDE.NEVT     = %d \n", RD_OVERRIDE.NEVT);
      printf("\t RD_OVERRIDE.NVAR_USE = %d \n", RD_OVERRIDE.NVAR_USE);
      printf("\t Current VARNAME      = %s (IVAR=%d) \n", VARNAME, IVAR);
      printf("\t CID=%s  GALID = %lld  \n",
	     SNDATA.CCID, SNDATA.HOSTGAL_OBJID[0] );
      sprintf(c1err,"No OVERRIDE variables are used for %s = %s ", 
	      RD_OVERRIDE.VARNAME_MATCH, ID_LOCAL);
      sprintf(c2err,"Make sure at least one override var matches varname in data file.");
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
    }
    RD_OVERRIDE.NVAR_USE = 0; RD_OVERRIDE.NEVT++ ; 

    for(ivar=0; ivar < IVARMAX_OVERRIDE; ivar++ ) { RD_OVERRIDE.NRD_PER_VAR[ivar] = 0 ; }

  } 
  sprintf(RD_OVERRIDE.ID_LAST,  "%s", ID_LOCAL );  // update last CID or GALID
  sprintf(RD_OVERRIDE.CID_LAST, "%s", CID_LOCAL);  // update last CID 

  // --------

  if ( !FOUND_VARNAME ) { return 0; }
  RD_OVERRIDE.NVAR_USE++ ; // for monitor only


  if ( LDMP ) {
    printf(" xxx %s: CID=%s  GALID=%lld  VARNAME='%s'  IVAR=%d  NVAR_USE=%d\n", 
	   fnam, SNDATA.CCID, SNDATA.HOSTGAL_OBJID[0], VARNAME, IVAR, RD_OVERRIDE.NVAR_USE); 
    fflush(stdout);
  }


  // read from override table; ISTAT and DVAL are returned
  NRD = SNTABLE_AUTOSTORE_READ(ID_LOCAL, VARNAME, &ISTAT, DVAL, STRVAL);  

  RD_OVERRIDE.NRD_PER_VAR[IVAR] = NRD; // Apr 13 2026

  // *ISTAT =  0  if ID is found; returned NRD>0
  // *ISTAT = -1  if ID is NOT found    
  // *ISTAT = -2  if VARNAME is NOT found

  if ( ISTAT == 0 ) {
    NTOT_PER_VAR = RD_OVERRIDE.NTOT_PER_VAR[IVAR] ;
    if ( NTOT_PER_VAR == 0 )  { 
      printf("\t Found override for %s  (ID=%s  NTOT_PER_VAR=%d IVAR=%d))\n", 
	     VARNAME, ID_LOCAL, NTOT_PER_VAR, IVAR );  fflush(stdout); 
    }

    RD_OVERRIDE.NTOT_PER_VAR[IVAR]++ ;
  }
 
  return NRD ;

} // end RD_OVERRIDE_FETCH



// =====================================
void RD_OVERRIDE_POSTPROC(void) {

  // Apr 12 2026: split rd_override_zcalc() into rd_override_zspec and rd_override_zphot.
  //
  // function tree:
  //
  // RD_OVERRIDE_POSTPROC
  //  -> rd_override_append
  //  -> rd_override_zspec
  //
  //  -> rd_override_qzphot_implicit(2,igal); // fill SNDATA.HOSTGALz as if EXPLICIT format   
  //  -> rd_override_zphot(igal);
  //        -> rd_override_hostgal2z
  //
  //  -> rd_override_logmass_grid
  //
  //  -> rd_override_name

  int igal;
  char fnam[] = "RD_OVERRIDE_POSTPROC" ; (void)fnam;
  
  // ------------ BEGIN --------------


  if ( !RD_OVERRIDE.USE ) { return; }

  // for text format, check for variables that are not in
  // the data files and thus header_override is an addition.
  if ( FORMAT_SNDATA_READ == FORMAT_SNDATA_TEXT ) 
    { rd_override_append(); }

  // check for redshift_helio update that forces zcmb to also change.
  rd_override_zspec();

  // check implicit quantile option (zq list per GALID)


  for(igal=0; igal< MXHOSTGAL; igal++ )  { 
    rd_override_qzphot_implicit(2,igal); // fill SNDATA.HOSTGALz as if EXPLICIT format 
    rd_override_zphot(igal); 
  }

  // check to override logmass grid for nbr hosts
  for(igal=0; igal< MXHOSTGAL; igal++ )  { rd_override_logmass_grid(igal); }

  // check NAME_IAUC or NAME_TRANSIENT column when
  // these variables don't exist in original file.
  rd_override_name();
  
  return ;

} // end RD_OVERRIDE_POSTPROC


void rd_override_append(void) {

  // Called only for TEXT format that might be missing
  // some variables.

#define NVAR_OVERRIDE_CHECK 16

  char VARNAME_CHECK[NVAR_OVERRIDE_CHECK][40] = {
    "VPEC", "VPEC_ERR", 
    "REDSHIFT_HELIO",  "REDSHIFT_HELIO_ERR",
    "REDSHIFT_FINAL",  "REDSHIFT_FINAL_ERR",
    "REDSHIFT_CMB",    "REDSHIFT_CMB_ERR",
    "HOSTGAL_LOGMASS", "HOSTGAL_LOGMASS_ERR", 
    "HOSTGAL_LOGSFR",  "HOSTGAL_LOGSFR_ERR", 
    "HOSTGAL_LOGsSFR", "HOSTGAL_LOGsSFR_ERR", 
    "HOSTGAL_COLOR",   "HOSTGAL_COLOR_ERR"
  };
  float *ptr_SNDATA[NVAR_OVERRIDE_CHECK] = {
    &SNDATA.VPEC,            &SNDATA.VPEC_ERR, 
    &SNDATA.REDSHIFT_HELIO,  &SNDATA.REDSHIFT_HELIO_ERR,
    &SNDATA.REDSHIFT_FINAL,  &SNDATA.REDSHIFT_FINAL_ERR,
    &SNDATA.REDSHIFT_FINAL,  &SNDATA.REDSHIFT_FINAL_ERR,
    &SNDATA.HOSTGAL_LOGMASS_OBS[0], &SNDATA.HOSTGAL_LOGMASS_ERR[0],
    &SNDATA.HOSTGAL_LOGSFR_OBS[0],  &SNDATA.HOSTGAL_LOGSFR_ERR[0],
    &SNDATA.HOSTGAL_LOGsSFR_OBS[0], &SNDATA.HOSTGAL_LOGsSFR_ERR[0],
    &SNDATA.HOSTGAL_COLOR_OBS[0],   &SNDATA.HOSTGAL_COLOR_ERR[0]
  } ;

  int ivar, NRD;   (void)NRD;
  double DVAL ;  
  char *varName, STRVAL[60] ;
  char fnam[] = "rd_override_append" ; (void)fnam;

  // --------- BEGIN --------

  for (ivar=0; ivar < NVAR_OVERRIDE_CHECK; ivar++ ) {
    varName = VARNAME_CHECK[ivar] ;
    if ( EXIST_VARNAME_AUTOSTORE(varName) ) { 
      NRD = RD_OVERRIDE_FETCH(SNDATA.CCID, SNDATA.HOSTGAL_OBJID[0], varName, &DVAL, STRVAL);
      *ptr_SNDATA[ivar] = (float)DVAL;

      if ( strstr(varName,"HOSTGAL") != NULL ) {
	SNDATA.HOSTGAL_NMATCH[0] = 1;
	SNDATA.HOSTGAL_NMATCH[1] = 1;  // fixed bug, 9.23.2022
      }

    }  // end exist varname in header overrid
  } // end ivar loop

  return;
} // end rd_override_append

void rd_override_zspec(void) {

  // If either zCMB or zHEL is on override list; recompute the other.
  // Sep 02 2026: check zHELERR and zCMBERR

  double RA  = SNDATA.RA_AVG ;
  double DEC = SNDATA.DEC_AVG ;
  bool FOUND_z     = ( RD_OVERRIDE.IVAR_zCMB    >=0 || RD_OVERRIDE.IVAR_zHEL    >= 0 );
  bool FOUND_zerr  = ( RD_OVERRIDE.IVAR_zCMBERR >=0 || RD_OVERRIDE.IVAR_zHELERR >= 0 );

  double zCMB, zHEL, zERR;
  char fnam[] = "rd_override_zspec" ;  (void)fnam;

  // ---------- BEGIN -------------

  if ( !(FOUND_z || FOUND_zerr) ) { return; }

  /* xxx
  printf(" xxx %s:  IVAR[zCMB,zHEL,zCMBERR,zHELERR] = %d  %d  %d  %d \n", 
	 fnam, 
	 RD_OVERRIDE.IVAR_zCMB, RD_OVERRIDE.IVAR_zHEL,
	 RD_OVERRIDE.IVAR_zCMBERR, RD_OVERRIDE.IVAR_zHELERR ); fflush(stdout);
  xxxxx */

  if ( RD_OVERRIDE.IVAR_zCMB >=0 ) {
    zCMB = (double)SNDATA.REDSHIFT_FINAL;
    zHEL = zhelio_zcmb_translator(zCMB,RA,DEC,COORDSYS_EQ,-1); 
    SNDATA.REDSHIFT_HELIO = (float)zHEL ;
  }
  else if ( RD_OVERRIDE.IVAR_zHEL >= 0 ) {
    zHEL = (double)SNDATA.REDSHIFT_HELIO ;
    zCMB = zhelio_zcmb_translator(zHEL,RA,DEC,COORDSYS_EQ,+1);
    SNDATA.REDSHIFT_FINAL = (float)zCMB ;
  }

  // - - - - - - - - - - -


  if ( RD_OVERRIDE.IVAR_zHELERR >= 0 ) {
    zERR = (double)SNDATA.REDSHIFT_HELIO_ERR ;
    SNDATA.REDSHIFT_FINAL_ERR = (float)zERR ;
  }
  else if ( RD_OVERRIDE.IVAR_zCMBERR >= 0 ) {
    zERR = (double)SNDATA.REDSHIFT_FINAL_ERR ;
    SNDATA.REDSHIFT_HELIO_ERR = (float)zERR ;
  }


  return ;

} // end rd_override_zspec

// ============================================
void rd_override_zphot(int igal) {

  // Created Apri 2026
  // Split zphot part from original rd_override_zcalc(),
  // Check for  point ZPHOT and also QUANTILE_ZPHOT, and also igal dependence
  // to enable overriding 2nd (3rd) host.
  //
  //
  // Code flow to see where we are:
  //
  //   -> RD_SNFITSIO_EVENT or RD_SNTEXTIO_EVENT
  //       -> RD_OVERRIDE_POSTPROC (called at end of LRD_HEAD block)
  //          -> rd_override_zphot (all hosts have been loaded)

  //
  double RA  = SNDATA.RA_AVG ;
  double DEC = SNDATA.DEC_AVG ;

  int  IVAR_HOSTGAL_ZPHOT    = RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT[igal];
  int  IVAR_HOSTGAL_QZPHOT   = RD_OVERRIDE.IVAR_HOSTGALz_QUANTILE_ZPHOT[igal];
  int  IVAR0_HOSTGAL_ZPHOT   = RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT[0];
  int  IVAR0_HOSTGAL_QZPHOT  = RD_OVERRIDE.IVAR_HOSTGALz_QUANTILE_ZPHOT[0];

  bool FOUND_ZPHOT      = false; // for current igal
  bool FOUND_QZPHOT     = false;
  bool FOUND0_ZPHOT     = false; // for igal=0
  bool FOUND0_QZPHOT    = false;

  bool MATCH_NBR_by_GALID  = (RD_OVERRIDE.NMATCH_by_GALID > 0 && igal > 0);
  bool FOUND_ANY_ZPHOT = false;

  HOSTGALz_DEF  *HOSTGAL0z = &SNDATA.HOSTGALz_QUANTILE_ZPHOT[0];
  HOSTGALz_DEF  *HOSTGALz  = &SNDATA.HOSTGALz_QUANTILE_ZPHOT[igal];

  if ( IVAR_HOSTGAL_ZPHOT >= 0 ) 
    { FOUND_ZPHOT   = RD_OVERRIDE.NRD_PER_VAR[IVAR_HOSTGAL_ZPHOT]   > 0 ; }
  if ( IVAR_HOSTGAL_QZPHOT >= 0 ) 
    { FOUND_QZPHOT = RD_OVERRIDE.NRD_PER_VAR[IVAR_HOSTGAL_QZPHOT] > 0 ; }

  if ( IVAR0_HOSTGAL_ZPHOT >= 0 ) 
    { FOUND0_ZPHOT   = RD_OVERRIDE.NRD_PER_VAR[IVAR0_HOSTGAL_ZPHOT]   > 0 ; }
  if ( IVAR0_HOSTGAL_QZPHOT >= 0 ) 
    { FOUND0_QZPHOT = RD_OVERRIDE.NRD_PER_VAR[IVAR0_HOSTGAL_QZPHOT] > 0 ; }

  int iz;
  double zCMB, zPHOT_SCALE_SIM = 1.0;
  char fnam[] = "rd_override_zphot" ; (void)fnam;

  // ---------- BEGIN -------------
  if ( FOUND_ZPHOT  )  { FOUND_ANY_ZPHOT = true; }
  if ( FOUND_QZPHOT )  { FOUND_ANY_ZPHOT = true; }
  if ( MATCH_NBR_by_GALID ) {
    if ( FOUND0_ZPHOT  ) { FOUND_ANY_ZPHOT = true; }
    if ( FOUND0_QZPHOT ) { FOUND_ANY_ZPHOT = true; }
  }


  if ( !FOUND_ANY_ZPHOT ) { return; }

  // continue here on refactor flag
  if ( RD_OVERRIDE.IS_SIM ) {
    // scale for true host is applied to ALL hosts
    zPHOT_SCALE_SIM = SNDATA.SIM_REDSHIFT_HELIO / SNDATA.SIM_REDSHIFT_HOST ;
  }

  // - - - - -

  if ( FOUND_ZPHOT ) {
    double zPHOT          = SNDATA.HOSTGAL_PHOTOZ[igal];
    double zPHOTERR       = SNDATA.HOSTGAL_PHOTOZ_ERR[igal];
    
    if ( igal == 0 ) {
      // update REDSHIFT_FINAL and REDSHIFT_HELIO if current value is NOT zSPEC;
      // i.e. only update if it's already a photo-z
      int  IS_ZHOST_SPEC = SNDATA.MASK_REDSHIFT_SOURCE & MASK_REDSHIFT_SOURCE_ZHOST_SPEC ;
      int  IS_ZSN_SPEC   = SNDATA.MASK_REDSHIFT_SOURCE & MASK_REDSHIFT_SOURCE_ZSN_SPEC ;
      double ZHOST_SPEC  = SNDATA.HOSTGAL_SPECZ[igal];
      bool IS_ZSPEC      = (IS_ZHOST_SPEC>0 || IS_ZSN_SPEC > 0 || ZHOST_SPEC>0.0 );
      bool UPD_zFINAL    = !IS_ZSPEC ;  // Update zFINAL if there is no zSPEC
      if ( UPD_zFINAL ) {    
	zCMB     = zhelio_zcmb_translator(zPHOT,RA,DEC,COORDSYS_EQ,+1);
	SNDATA.REDSHIFT_HELIO     = (float)zPHOT;
	SNDATA.REDSHIFT_HELIO_ERR = (float)zPHOTERR;
	SNDATA.REDSHIFT_FINAL     = (float)zCMB ;    
	SNDATA.REDSHIFT_FINAL_ERR = (float)zPHOTERR ;
      }
    }  
  
    if ( RD_OVERRIDE.IS_SIM ) { 
      zPHOT *= zPHOT_SCALE_SIM;  // do what sim would have done
    }

  } // end RD_OVERRIDE.FOUND_HOSTGAL_ZPHOT

  // - - - - - - - - -
  // for sim quantile override, scale by zPHOT_SCALE_SIM;
  // for data quantile override, do nothing.

  if ( RD_OVERRIDE.IS_SIM && FOUND_QZPHOT ) {
    // here on igal=0
    // beware that HOSTGALz->NZ is still zero, so loop over max number of z bins
    
    for(iz=0; iz < MXBIN_HOSTGALz_QUANTILE; iz++ ) 
      { HOSTGALz->Z_LIST[iz] *= zPHOT_SCALE_SIM ; } // do what the sim would have done.
  }

  // if event is matched by nearest GALID, check NBR host(s) even if they
  // are not explicitly defined in OVERRIDE file
  if ( MATCH_NBR_by_GALID  && RD_OVERRIDE.NQZPHOT_IMPLICIT==0 ) 
    { rd_override_hostgal2z(igal, HOSTGAL0z, HOSTGALz); }

  // for quantiles, update PHOTOZ[_ERR] = MEAN[STDDEV], unless zPHOT[ERR]
  // is already on the override list. MEAN and STD are computed only
  // from the grid points, and can differ slightly from the snana.exe
  // computation using splines and a finer grid. The snana.exe computation
  // overrides this compuation.
  // Note confusing logic: FOUND0_QZPHOT means that quantile override exists 
  // for igal=0, but current igal=1
  bool UPD_QZPHOT = (FOUND0_QZPHOT  && !FOUND_ZPHOT ) ;


  if ( UPD_QZPHOT ) {
    double sumz = 0.0, sumzsq=0.0, sumPz = 0.0, z, Pz, mean, std ;
    for(iz=0; iz < HOSTGALz->NZ; iz++ ) {
      z = HOSTGALz->Z_LIST[iz];
      if ( iz == 0 ) 
	{ Pz = HOSTGALz->VAL_LIST[0] ; }
      else if ( iz == HOSTGALz->NZ-1 ) 
	{ Pz = HOSTGALz->VAL_LIST[iz] - HOSTGALz->VAL_LIST[iz-1]; }
      else
	{ Pz = 0.5*( HOSTGALz->VAL_LIST[iz+1] - HOSTGALz->VAL_LIST[iz-1]) ; }

      sumz   += Pz * z ;
      sumzsq += Pz * z * z ;
      sumPz  += Pz;
    }
    if ( sumPz > 0.0 ) {
      int N_effective = (int)(sumPz + 0.5);
      mean = sumz / (double)N_effective ;
      std  = STD_from_SUMS(N_effective, sumz, sumzsq);
    }
    else {
      mean = std = -9.0 ; // set to null value if no valid quantile
    }

    SNDATA.HOSTGAL_PHOTOZ[igal]     = (float)mean ;
    SNDATA.HOSTGAL_PHOTOZ_ERR[igal] = (float)std;    
  }
  return ;

} // end rd_override_zphot


// =============================================
void rd_override_qzphot_implicit(int OPT, int IGAL) {

  // Input:
  //  OPT=1 --> init by determining NQZPHOT_IMPLICIT
  //  OPT=2 --> read qzphot values and store in SNDATA.HOSTGALz 
  //       as if EXPLICIT format was used.
  //
  //  IGAL = 0,1... is sparse galaxy index to fetch GALID (for OPT=2 only)

  int  NQZPHOT, NQ_OBSOLETE, q, NRD ;
  char PREFIX_OBSOLETE[] = "HOSTGAL_ZPHOT_Q" ;
  char *varName, STRDUM[60] ;
  char fnam[] = "rd_override_qzphot_implicit" ;  (void)fnam;

  // ------------- BEGIN -------------
    
  if ( OPT == 1 ) {
    char *VARSTRING = (char*) malloc(500*sizeof(char));

    NQ_OBSOLETE = NVAR_MATCH_AUTOSTORE(PREFIX_OBSOLETE, VARSTRING);
    if ( NQ_OBSOLETE > 0 ) {
      sprintf(c1err,"Found %d obsolete OVERRIDE colums with '%s' prefix; ", 
	      NQ_OBSOLETE, PREFIX_OBSOLETE);
      sprintf(c2err,"Replace with QZPHOT00 QZPHOT01 ... QZPHOT%2.2d", 
	      NQ_OBSOLETE-1);
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
    }

    NQZPHOT = NVAR_MATCH_AUTOSTORE(PREFIX_QZPHOT, VARSTRING); // implicit NZPHOT_Q = number of ZPHOT vars
    RD_OVERRIDE.NQZPHOT_IMPLICIT  = NQZPHOT ;

    if ( NQZPHOT == 0 ) { return ; }
    
    parse_commaSepList(fnam, VARSTRING, MXBIN_HOSTGALz_QUANTILE, 60,
		       &NQZPHOT, &RD_OVERRIDE.VARLIST_QZPHOT_IMPLICIT ); // <== returned

    printf("\n  Prepare %d IMPLICIT quantile overrides per GALID: %s ... %s\n", 
	   NQZPHOT, RD_OVERRIDE.VARLIST_QZPHOT_IMPLICIT[0], RD_OVERRIDE.VARLIST_QZPHOT_IMPLICIT[NQZPHOT-1]);
    
    free(VARSTRING);    
    fflush(stdout);
    //debugexit(fnam);

  } 
  else if ( OPT == 2 ) {

    NQZPHOT  = RD_OVERRIDE.NQZPHOT_IMPLICIT ;

    if ( NQZPHOT <= 0 ) { return; }

    double zq, PCT_LIST[MXBIN_HOSTGALz];
    int    NQ_VALID = 0 ;
    char   *CCID        = SNDATA.CCID;
    long long int GALID = SNDATA.HOSTGAL_OBJID[IGAL];
    
    for(q=0; q < NQZPHOT; q++ ) {
      varName = RD_OVERRIDE.VARLIST_QZPHOT_IMPLICIT[q];
      NRD = RD_OVERRIDE_FETCH(CCID, GALID, varName, &zq, STRDUM) ; // return zq
      if ( NRD == 0 ) { zq = -9.0; }
      if ( zq >= 0.0 ) { NQ_VALID++ ; }
      SNDATA.HOSTGALz_QUANTILE_ZPHOT[IGAL].Z_LIST[q] = zq;

      // abort on tiny negative redshifts (4.30.2026)
      if ( zq < 0.0 && zq > -0.02 ) {
	sprintf(c1err,"Invalid QZPHOT%2.2d = %f  for CID=%s, GALID=%lld", 
		q, zq, CCID, GALID);
	sprintf(c2err,"All QZPHOTnn must be > 0");
	errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
      }

      //printf(" xxx %s: cid=%s  igal=%d  GALID=%lld  q=%d  z=%.4f NRD=%d\n",
      //     fnam, SNDATA.CCID, IGAL, GALID, q, zq, NRD); fflush(stdout);
    }


    SNDATA.HOSTGALz_QUANTILE_ZPHOT[IGAL].NZ = NQ_VALID;
    compute_implicit_percentiles(NQZPHOT, NQ_VALID, PCT_LIST); // <== return PCT_LIST
    for(q=0; q < NQZPHOT; q++ ) 
      { SNDATA.HOSTGALz_QUANTILE_ZPHOT[IGAL].VAL_LIST[q] = PCT_LIST[q]; } 


  }  // end OPT if block

  return ;

} // end rd_override_qzphot_implicit


void rd_override_logmass_grid(int igal) {

  // Created Apri 2026
  // if matching by GALID, and LOGMASS grid override is enabled only for nearest host,
  // automatically match other NBR hosts by GALID.
  // This trick avoids multiple override files to match each host.

  bool MATCH_NBR_by_GALID    = (RD_OVERRIDE.NMATCH_by_GALID > 0 && igal > 0);
  //  int  IVAR_HOSTGAL_LOGMASS  = RD_OVERRIDE.IVAR_HOSTGALz_LOGMASS[igal];
  int  IVAR0_HOSTGAL_LOGMASS = RD_OVERRIDE.IVAR_HOSTGALz_LOGMASS[0];

  char fnam[] = "rd_override_logmass_grid" ; (void)fnam;

  // ------------- BEGIN ----------
  if ( MATCH_NBR_by_GALID && IVAR0_HOSTGAL_LOGMASS > 0 ) {
    HOSTGALz_DEF *HOSTGAL0z  = &SNDATA.HOSTGALz_LOGMASS[0];
    HOSTGALz_DEF *HOSTGALz   = &SNDATA.HOSTGALz_LOGMASS[igal];
    rd_override_hostgal2z(igal, HOSTGAL0z, HOSTGALz); 
  }

  return;

} // end rd_override_logmass_grid

void rd_override_hostgal2z(int igal, HOSTGALz_DEF *HOSTGAL0z, HOSTGALz_DEF *HOSTGALz) {

  // Created Apr 2026
  // Override igal>0 hosts using igal=0 override info;
  // this avoids the need for duplicate OVERRIDE files.
  // Although function name has "hostgal2z", it should work
  // for hostgal3z, hostgal4z, etc ... if MXHOSTGAL is increased.
  //
  // Inputs:
  //   igal      : sparse galaxy index (must be >0)
  //   HOSTGAL0z : HOSTGALz object for igal=0 (nearest host)
  //
  //  Output:
  //   HOSTGALz  : HOSTGALz object for other nearby host indicated by igal.
  //
  if ( igal == 0 ) { return; }  // only makes sense if igal>0

  char *CCID          = SNDATA.CCID;
  long long int GALID = SNDATA.HOSTGAL_OBJID[igal];
  bool USE_VAL2       = HOSTGAL0z->USE_VAL2 ;

  double DZ_LIST[MXBIN_HOSTGALz];
  double DVAL_LIST[MXBIN_HOSTGALz], DVAL2_LIST[MXBIN_HOSTGALz];
  char STRDUM[20];
  int  iz, NRD ;
  char fnam[] = "rd_override_hostgal2z" ; (void)fnam;

  // ------------ BEGIN -------------

  // always read from HOSTGALz OVERRIDE names corresponding to igal=0 ...
  NRD = RD_OVERRIDE_FETCH(CCID, GALID, HOSTGAL0z->VARNAME_Z,   DZ_LIST,    STRDUM ) ;
  NRD = RD_OVERRIDE_FETCH(CCID, GALID, HOSTGAL0z->VARNAME_VAL, DVAL_LIST,  STRDUM ) ;

  //.xyz
  if ( USE_VAL2 ) 
    {  NRD = RD_OVERRIDE_FETCH(CCID, GALID, HOSTGAL0z->VARNAME_VAL2, DVAL2_LIST, STRDUM ); }

  // ... but store in HOSTGALz corresponding to current igal
  if ( NRD > 0 ) {

    for(iz=0; iz < NRD; iz++ ) {
      HOSTGALz->Z_LIST[iz]   = (float)DZ_LIST[iz] ; // xxx NO: * zSCALE_SIM ; // 1 for data 
      HOSTGALz->VAL_LIST[iz] = (float)DVAL_LIST[iz]; 
      if ( USE_VAL2 ) { HOSTGALz->VAL2_LIST[iz] = (float)DVAL2_LIST[iz]; }
    }

    // count NZ with z>=0 (avoid possible pad values of -9)
    HOSTGALz->NZ = NZ_HOSTGALz(MXBIN_HOSTGALz, HOSTGALz->Z_LIST, SNDATA.CCID);  
  } // end NRD>0
  else {
    HOSTGALz->NZ = 0 ;
  }

  return;
} // end rd_override_hostgal2z

// =================================
void rd_override_name(void) {

  // Created Jul 26 2024
  // Check misc overrides that are not in original data file.

  double D_VAL = 0.0 ;
  long long int GALID_DUMMY = 999 ;
  int NRD;  (void)NRD;
  char fnam[] = "rd_override_name" ;  (void)fnam;
  
  // ---------- BEGIN -------------

  if ( RD_OVERRIDE.IVAR_NAME_IAUC >= 0 ) {
    NRD = RD_OVERRIDE_FETCH(SNDATA.CCID, GALID_DUMMY, "NAME_IAUC",
			    &D_VAL, SNDATA.NAME_IAUC) ;
  }

  if ( RD_OVERRIDE.IVAR_NAME_TRANSIENT >= 0 ) {
    NRD = RD_OVERRIDE_FETCH(SNDATA.CCID, GALID_DUMMY, "NAME_TRANSIENT",
			    &D_VAL, SNDATA.NAME_TRANSIENT) ;
  }
  
  return;
} // end rd_override_name

// - - - - - - - 
// mangled fortran functions

void copy_sndata_global__(int *copyFlag, char *key, int *NVAL, 
			  char *stringVal, double *parVal ) 
{ copy_SNDATA_GLOBAL(*copyFlag, key, *NVAL, stringVal, parVal); }

void copy_sndata_head__(int *copyFlag, char *key, int *NVAL, 
			char *stringVal, double *parVal ) 
{ copy_SNDATA_HEAD(*copyFlag, key, *NVAL, stringVal, parVal); }

void copy_sndata_obs__(int *copyFlag, char *key, int *NVAL, 
		       char *stringVal, double *parVal ) 
{ copy_SNDATA_OBS(*copyFlag, key, *NVAL, stringVal, parVal); }

void copy_genspec__(int *copyFlag, char *key, int *ispec, double *parVal ) 
{ copy_GENSPEC(*copyFlag, key, *ispec, parVal); }

void rd_override_init__(char *override_file, int *REQUIRE_DOCANA)
{ RD_OVERRIDE_INIT(override_file,*REQUIRE_DOCANA); }

void rd_private_init__(char *PRIVATE_VARNAME_LIST)
{ RD_PRIVATE_INIT(PRIVATE_VARNAME_LIST); }


// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@@@@@@@ LEGACY_QUANTILE_FUNCTIONS @@@@@@@@@@@@@@@@@
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

/* xxxxxx mark delete Apr 2026

void rd_override_zphot_legacy(void) {

  // Created Apri 2026
  // Split zphot part from original rd_override_zcalc(),
  // Check for  point ZPHOT and also QUANTILE_ZPHOT, and also igal dependence
  // to enable overriding 2nd (3rd) host.

  // @@@@@@@@@@ LEGACY @@@@@@@@@@

  double RA  = SNDATA.RA_AVG ;
  double DEC = SNDATA.DEC_AVG ;
  bool FOUND_zphot = ( RD_OVERRIDE.IVAR_HOSTGAL_ZPHOT[0] >= 0 ) ;

  double zCMB, zHEL, zHELERR ;
  char fnam[] = "rd_override_zphot_legacy" ;

  // ---------- BEGIN -------------

  if ( !FOUND_zphot ) { return; }

  // - - - - -
  // @@@@@@@@@@ LEGACY @@@@@@@@@@

  double zPHOT          = SNDATA.HOSTGAL_PHOTOZ[0];
  double zPHOTERR       = SNDATA.HOSTGAL_PHOTOZ_ERR[0];
  double zPHOT_ORIG     = RD_OVERRIDE.ORIG_HOSTGAL_PHOTOZ[0];
  double zPHOTERR_ORIG  = RD_OVERRIDE.ORIG_HOSTGAL_PHOTOZ_ERR[0];
  double zHEL_ORIG      = SNDATA.REDSHIFT_HELIO;
  double zHELERR_ORIG   = SNDATA.REDSHIFT_HELIO_ERR;
  bool UPD1_zFINAL, UPD2_zFINAL ;

  // update REDSHIFT_FINAL if current REDSHIFT_FINAL[HELIO] are not defined (-9),
  // or if REDSHIFT_HELIO is already equal to the old HOSTGAL_PHOTOZ value. 
  UPD1_zFINAL = ( zHEL_ORIG < 0.0 );
  UPD2_zFINAL = ( fabs(zHEL_ORIG-zPHOT_ORIG)<1.0E-4  && 
		  fabs(zHELERR_ORIG-zPHOTERR_ORIG)<1.0E-3 );
  
  // @@@@@@@@@@ LEGACY @@@@@@@@@@
   
  if ( UPD1_zFINAL || UPD2_zFINAL ) {    
    zCMB     = zhelio_zcmb_translator(zPHOT,RA,DEC,COORDSYS_EQ,+1);
    SNDATA.REDSHIFT_HELIO     = (float)zPHOT;
    SNDATA.REDSHIFT_HELIO_ERR = (float)zPHOTERR;
    SNDATA.REDSHIFT_FINAL     = (float)zCMB ;    
    SNDATA.REDSHIFT_FINAL_ERR = (float)zPHOTERR ;
  }
  
  // @@@@@@@@@@ LEGACY @@@@@@@@@@
  
  // Mar 7 2026: print a few diagnostic updates for this special case
  //        beware; this diagnostic dump has not been seen yet ??
  if ( UPD2_zFINAL ) {
    RD_OVERRIDE.N_HOSTGAL_PHOTOZ_REPLACE++ ;
    if ( RD_OVERRIDE.N_HOSTGAL_PHOTOZ_REPLACE < 10 ) {
      printf("\n HOSTGAL_PHOTOZ OVERRIDE UPDATE: REDSHIFT_HELIO=%.4f -> %.4f for CID=%s \n\n",
	     zHEL_ORIG, zPHOT, SNDATA.CCID); 
      //printf(" xxx OVERRIDE zPHOT_ORIG = %f +_ %f (CID=%s)\n", 
      //     zPHOT_ORIG, zPHOTERR_ORIG, SNDATA.CCID); // xxxx
      fflush(stdout);
    }
  }


  // @@@@@@@@@@ LEGACY @@@@@@@@@@

  return ;

} // end rd_override_zphot_legacy

// =============================================
void rd_override_zphot_q_legacy(int OPT) {

  // Input:
  //  OPT=1 --> init by determining NZPHOT_Q and PERCENTILES
  //             (called after reading global header)
  //  OPT=2 --> read zphot_q values
  //
  // @@@@@@@@@@@
  // TO-DO: make this work for optional 2nd HOSTGAL2_ZPHOT_Q ... .xyz ???
  // @@@@@@@@@@@
  //
  // Oct 14 2025: 
  //  + abort on mis-match number of quantiles in override file.
  //  + if override NZPHOT_Q = 0 (missing override), set all quantile values
  //    to -9 so that mean redshift is negative and fails CUTWIN_REDSHIFT cut.

  int  NZPHOT_Q, PCT, q, LEN_PREFIX, NRD ;
  char PREFIX[60], *varName, STRDUM[60] ;
  char fnam[] = "rd_override_zphot_q_legacy" ;

  // ------------- BEGIN -------------
    
  if ( OPT == 1 ) {
    char *VARSTRING = (char*) malloc(500*sizeof(char));
    sprintf(PREFIX,"HOSTGAL_%s", PREFIX_ZPHOT_Q);
    LEN_PREFIX = strlen(PREFIX);
    NZPHOT_Q = NVAR_MATCH_AUTOSTORE(PREFIX, VARSTRING); // implicit NZPHOT_Q = number of ZPHOT vars
    RD_OVERRIDE.NZPHOT_Q    = NZPHOT_Q ;
    SNDATA.HOSTGAL_NZPHOT_Q = NZPHOT_Q ;

    parse_commaSepList(fnam, VARSTRING, MXBIN_ZPHOT_Q, 60,
		       &NZPHOT_Q, &RD_OVERRIDE.VARLIST_ZPHOT_Q ); // <== returned
    free(VARSTRING);

    printf("\n  Prepare HOSTGAL_ZPHOT_Q quantile override with NZPHOT_Q = %d\n", 
	   NZPHOT_Q ); 
    fflush(stdout);

    for(q=0; q < NZPHOT_Q; q++ ) {
      varName = RD_OVERRIDE.VARLIST_ZPHOT_Q[q];
      sscanf(&varName[LEN_PREFIX], "%d", &PCT);
      SNDATA.HOSTGAL_PERCENTILE_ZPHOT_Q[q] = PCT;
      printf("\t Store Percentile = %d\n", PCT);
      fflush(stdout);
    }    

  } 
  else if ( OPT == 2 ) {
    double zq, d_nzphot_q = 0.0, zq_null = -9.0 ;
    int    IGAL = 0, OVERRIDE_NZPHOT_Q ;
    char   *CCID  =  SNDATA.CCID;
    long long int GALID = SNDATA.HOSTGAL_OBJID[0];
    bool MISSING_Q = false;

    NZPHOT_Q                = RD_OVERRIDE.NZPHOT_Q ;
    SNDATA.HOSTGAL_NZPHOT_Q = NZPHOT_Q ;

    // check if NZPHOT_Q in override file matches number of
    // ZPHOT_Q[nnn] that were found
    NRD = RD_OVERRIDE_FETCH(CCID, GALID, STRING_NZPHOT_Q, &d_nzphot_q, STRDUM ) ;
    OVERRIDE_NZPHOT_Q = (int)d_nzphot_q ;

    if ( OVERRIDE_NZPHOT_Q == 0 ) {
      MISSING_Q = true;
      OVERRIDE_NZPHOT_Q = NZPHOT_Q;  // force correct number of quantiles to have null values
    }

    if ( OVERRIDE_NZPHOT_Q != NZPHOT_Q ) {
      sprintf(c1err,"Override NZPHOT_Q=%d but there are %d HOSTGAL_ZPHOT_Q* override columns",
	      OVERRIDE_NZPHOT_Q, NZPHOT_Q );
      sprintf(c2err,"Check quantile override file: CID=%s  GALID=%lld", CCID, GALID);
      errmsg(SEV_FATAL, 0, fnam, c1err, c2err); 
    }

    for(q=0; q < NZPHOT_Q; q++ ) {
      zq = zq_null ;
      if ( !MISSING_Q ) {
	varName = RD_OVERRIDE.VARLIST_ZPHOT_Q[q];
	NRD = RD_OVERRIDE_FETCH(CCID, GALID, varName, &zq, STRDUM) ; // return zq      
      }
      SNDATA.HOSTGAL_ZPHOT_Q[IGAL][q] = zq ;
    }

  }  // end OPT if block

  return ;

} // end rd_override_zphot_q_legacy

void LOAD_VARNAME_ZPHOT_Q_LEGACY(char *PREFIX, int PCT, char *VARNAME) {
  sprintf(VARNAME,"%s_%s%3.3d", PREFIX, PREFIX_ZPHOT_Q, PCT);
}

xxxxxxxxxxxx end mark xxxxxxxxxx */

