import sys,json,hashlib
from pathlib import Path
import numpy as np
from scipy.stats import norm
repo=Path.cwd();sys.path.insert(0,str(repo/'studies/infrared/code'))
from bayesn_synthetic_retune_summary import score_draws
sys.path.insert(0,str(repo/'studies/infrared/code/bayesn_heldout'))
from score import monte_carlo_score
rng=np.random.default_rng(8273991);checks=[]
for n in [1,2,5,9]:
 for scale in [.01,1,10,100]:
  mu=rng.normal(size=(4,1000,n))*scale;y=rng.normal(size=n);err=np.exp(rng.normal(size=n))
  joint,new=score_draws(mu,y,err);reference=norm.logpdf(y,loc=mu,scale=err).sum(-1)
  old=monte_carlo_score(joint)
  assert np.allclose(joint,reference,rtol=1e-13,atol=1e-10)
  for key in new:
   assert np.allclose(new[key],old[key],rtol=1e-13,atol=1e-10),(n,scale,key,new[key],old[key])
  checks.append(dict(n=n,scale=scale,max_log_density_difference=float(abs(joint-reference).max())))
p=repo/'studies/infrared/code/bayesn_synthetic_retune_summary.py'
r=dict(status='passed_saved_draw_math',cases=checks,source_sha256={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest()},native_model_calls=0)
Path('.work/infrared/dense-summary-validation.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r))
