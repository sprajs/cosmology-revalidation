from pathlib import Path
import urllib.request,concurrent.futures,hashlib,json
base='https://irsa.ipac.caltech.edu/data/Herschel/HerMES/'
w=Path('.work/host-transport/help')
def get(name):
 p=w/name.split('/')[-1];u=base+name
 if not p.exists():
  with urllib.request.urlopen(u,timeout=60) as s,p.with_suffix('.part').open('wb') as f:
   while b:=s.read(4*1024**2):f.write(b)
  p.with_suffix('.part').rename(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 r={'path':str(p),'url':u,'sha256':h,'bytes':p.stat().st_size};print(r,flush=True);return r
names=[f'images/{folder}/{prefix}_image_{b}_SMAP_v6.0.fits' for folder,prefix in [('CDFS','CDFS-SWIRE-NEST'),('XMM-LSS','XMM-LSS-NEST')] for b in [250,350,500]]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:r=list(ex.map(get,names))
(w/'downloads.json').write_text(json.dumps(r,indent=2)+'\n')
