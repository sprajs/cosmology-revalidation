from pathlib import Path
import urllib.request,concurrent.futures,hashlib,json,datetime
base='https://desdr-server.ncsa.illinois.edu/despublic/y3a2_files/deepfields/Y3_DEEP_FIELDS_PHOTOM/'
def f(field):
 name=f'Y3_DEEP_FIELDS_PHOTOM-SN-{field}-0000.parquet';u=base+name;p=Path('.work/host-transport/des')/name
 if not p.exists():
  tmp=p.with_suffix('.part')
  with urllib.request.urlopen(u,timeout=60) as r,tmp.open('wb') as out:
   while b:=r.read(4*1024**2):out.write(b)
  tmp.rename(p)
 h=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();print(field,p.stat().st_size,h,flush=True)
 return {'path':str(p),'url':u,'sha256':h,'bytes':p.stat().st_size}
rows=list(concurrent.futures.ThreadPoolExecutor(3).map(f,['C3','E2','X3']))
Path('.work/host-transport/deep-downloads.json').write_text(json.dumps({'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows},indent=2)+'\n')
