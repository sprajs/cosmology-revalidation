from pathlib import Path
import ast, hashlib, json, shutil, datetime, urllib.parse

ROOT=Path('/home/szymon/Documents/ChatGPT/supernova')
DEST=ROOT/'research_clean'
ledger=[]; code=[]

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()

def asset(old,new,group,urls=None,kind='released measurement or model',note=None):
 source=ROOT/old; target=DEST/'data'/new
 target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 item=dict(path='data/'+new,source_path=old,sha256=sha(target),bytes=target.stat().st_size,group=group,kind=kind,urls=urls or [])
 if note:item['note']=note
 ledger.append(item)

def repo_asset(repo,commit,relative,new,group):
 directory={'CobayaSampler/sn_data':'CobayaSampler__sn_data','CobayaSampler/bao_data':'CobayaSampler__bao_data','PantheonPlusSH0ES/DataRelease':'PantheonPlusSH0ES__DataRelease@7fc6805','des-science/DES-SN5YR':'des-science__DES-SN5YR@1.3','djones1040/RAISIN_DataRelease':'djones1040__RAISIN_DataRelease@a383c4b'}[repo]
 enc=urllib.parse.quote(relative,safe='/')
 asset('sources/repos/'+directory+'/'+relative,new,group,[f'https://raw.githubusercontent.com/{repo}/{commit}/{enc}',f'https://media.githubusercontent.com/media/{repo}/{commit}/{enc}'])

sn='61d96434cafc2770928322c38e5a750e686368ae';bao='bb0c1c9009dc76d1391300e169e8df38fd1096db';pp='7fc680548d1ea9fe6ee983a89d8b5635bb5784a8';des='e3493cb3b9505fc1f3f392d887364b50dae21439';raisin='a383c4bd03c9fbfd64bf5bfda525aec38d32b39c'
for n in ['Pantheon+SH0ES.dat','Pantheon+SH0ES_STAT+SYS.cov']:
 repo_asset('CobayaSampler/sn_data',sn,'PantheonPlus/'+n,'distances/'+n,'distances')
for n in ['desi_gaussian_bao_ALL_GCcomb_mean.txt','desi_gaussian_bao_ALL_GCcomb_cov.txt']:
 repo_asset('CobayaSampler/bao_data',bao,'desi_bao_dr2/'+n,'bao/'+n,'bao')
for p in sorted((ROOT/'sources/repos/djones1040__RAISIN_DataRelease@a383c4b').rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(ROOT/'sources/repos/djones1040__RAISIN_DataRelease@a383c4b').as_posix()
 if rel.startswith(('distances/w/','photometry/RAISIN/')) or rel=='kcor/kcor_CSPDR3_BD17.fits':
  if p.suffix.lower() in {'.md','.pdf','.py'}:continue
  repo_asset('djones1040/RAISIN_DataRelease',raisin,rel,'raisin/'+rel,'raisin')
for i in [1,2]:asset(f'data/host_ages/chung2025/table{i}.dat',f'ages/table{i}.dat','ages',kind='extracted published supplementary table')
asset('data/host_ages/chung2025/staf497_supplemental_file.zip','ages/supplement.zip','ages',kind='published supplementary archive')
asset('runs/research_2026_09_26/csp_dr3_provenance/CSP_Photometry_DR3.tgz','csp/photometry.tgz','csp',['https://csp.obs.carnegiescience.edu/data/CSP_Photometry_DR3.tgz'])
for n in ['Jrc1_SWO_TAM_scan_atm.dat','J_DUP_TAM_scan_atm.dat','Jrc2_SWO_TAM_scan_atm.dat','H_SWO_TAM_scan_atm.dat','H_DUP_TAM_scan_atm.dat','Y_SWO_TAM_scan_atm.dat','Y_DUP_TAM_scan_atm.dat','README']:
 repo_asset('PantheonPlusSH0ES/DataRelease',pp,'Pantheon+_Data/2_CALIBRATION/filters/CSP_TAMU_20180316/'+n,'csp/filters/'+n,'csp')
for n in ['nir.FITRES.gz','optnir.FITRES.gz']:
 asset('runs/research_2026_09_26/astra_design/raisin_timing_assets/author_20211111/'+n,'timing/'+n,'timing',kind='archived author simulation fit table')
bundle=ROOT/'phase2/official/portable_pilot'
for p in sorted(bundle.glob('objective_*.npz')):asset(p.relative_to(ROOT).as_posix(),'des/objectives/'+p.name,'des_flux',kind='locally exported fixed flux objective')
for n in ['calibrated_observations.csv','snana_parameters.csv','double_parameters_and_hessian.json','published_predictions_and_mask.csv']:
 asset('phase2/official/portable_pilot/'+n,'des/objectives/'+n,'des_flux',kind='locally exported calibrated flux and native fitting reference')
for n in ['salt3_template_0.dat.gz','salt3_template_1.dat.gz','salt3_color_dispersion.dat.gz','salt3_color_correction.dat.gz','calib_DES-SN5YR_DES.fits.gz']:
 asset('phase2/official/portable_pilot/assets/'+n,'des/model/'+n,'des_flux',kind='frozen DES release model/calibration asset')
for n in ['salt3_lc_variance_0.dat.gz','salt3_lc_variance_1.dat.gz','salt3_lc_covariance_01.dat.gz']:
 repo_asset('des-science/DES-SN5YR',des,'2_LCFIT_MODEL/SALT3.DES5YR/'+n,'des/model/'+n,'des_flux')
for n in ['data.npz','rows.csv']:
 asset('phase2/hierarchy/data/conditioned-multistart-best/'+n,'des/predictors/'+n,'des_predictors',kind='locally derived fitted light-curve parameters and covariance')
asset('phase2/hierarchy/conditional-cohort.json','des/predictors/cohort.json','des_predictors',kind='frozen object/fold design')
for n in ['discovery-projected-modes.npz','validation-projected-modes.npz']:
 asset('runs/research_2026_09_26/astra_design/expanded12/'+n,'calibration/'+n,'calibration',kind='locally projected flux residual and response sufficient statistics')
asset('runs/research_2026_09_26/shared_distance_response_12/responses.npz','calibration/distance-responses.npz','calibration',kind='locally computed distance response to fixed shared modes')
base='runs/research_2026_09_26/raisin_hst_pixel_feasibility/pixel_execution'
for n in ['stage_a.json','operators.npz','source_masks.npz']:
 asset(base+'/'+n,'hst/'+n,'hst',kind='frozen geometry, source masking and aperture operator design')
state=json.loads((ROOT/base/'stage_a.json').read_text())
for row in state['exposures']:
 old=Path(row['path']).relative_to(ROOT).as_posix();n=row['filename']
 asset(old,'hst/exposures/'+n,'hst',[f'https://mast.stsci.edu/api/v0.1/Download/file?uri=mast:HST/product/{n}'],kind='current public calibrated HST exposure',note='Historical photometry processing is not reproduced by these current products.')

def extract(old,new,names,header,replacements=None):
 p=ROOT/old;s=p.read_text();tree=ast.parse(s);nodes={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef,ast.AsyncFunctionDef))}
 chunks=[];orig=[]
 for name in names:
  n=nodes[name];lo=min([n.lineno]+[d.lineno for d in n.decorator_list]);segment='\n'.join(s.splitlines()[lo-1:n.end_lineno]);chunks.append(segment);orig.append(dict(symbol=name,start_line=lo,end_line=n.end_lineno))
 text=header.rstrip()+'\n\n\n'+'\n\n\n'.join(chunks)+'\n'
 for a,b in (replacements or {}).items():text=text.replace(a,b)
 target=DEST/new;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
 code.append(dict(path=new,source_path=old,source_sha256=sha(p),retained_symbols=orig,adaptation='Numerical definitions retained; package imports, input paths and execution/provenance are rewritten.'))

extract('scripts/cosmology/core.py','lib/cosmology.py',['_check_qbin_domain','efunc','integral','mu','qvalue','interpolation_basis','Pantheon','BAO'],'''"""Dimensionless FLRW distances and released-product Gaussian likelihoods."""
import numpy as np
import pandas as pd
from scipy.interpolate import CubicSpline
from scipy.linalg import cho_factor, cho_solve
from numpy.polynomial.legendre import leggauss
from .paths import DATA
EDGES = np.array([0., .1, .3, .6, 1., 2.5])
GX, GW = leggauss(48)
''',{"ROOT/'sources/repos/CobayaSampler__sn_data/PantheonPlus'":"DATA/'distances'","ROOT/'sources/repos/CobayaSampler__bao_data/desi_bao_dr2'":"DATA/'bao'","self.inputs.append(Path(magnitude_table))":"self.inputs.append(magnitude_table)"})
extract('scripts/mapping/csfh_dtd.py','lib/populations.py',['csfh','clock','calculate'],'''"""Cosmic star formation convolved with a specified delay-time law."""
import numpy as np
import pandas as pd
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
HUBBLE_GYR = 977.7922216807892
COSMOS = {'lcdm_H70': dict(H0=70., Om0=.3, w0=-1., wa=0.),
          'son_cpl_H70': dict(H0=70., Om0=.353, w0=-.42, wa=-1.75),
          'son_cpl_H63p6': dict(H0=63.6, Om0=.353, w0=-.42, wa=-1.75)}
DTDS = {'C14_smooth': (.3, -1., 20.), 'cut300': (.3, -1., None), 'W26_cut40': (.04, -1.13, None)}
''')
extract('scripts/standardization/dust_identifiability.py','lib/dust.py',['slab','result'],'''"""Absorption-only slab attenuation; a constructed geometry, not a fitted law."""
import numpy as np
K = 2.5 / np.log(10)
''')
extract('scripts/age_signal/analyse.py','lib/ages.py',['read_age','mu','wls'],'''"""Published age-table extraction and explicitly conditional regression."""
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.linalg import cho_factor, cho_solve
''')
extract('scripts/research_2026_09_26/onefactor_sign_likelihood.py','lib/selection.py',['inverse_mills','nodes','log_orthant','log_gaussian','log_censored','log_positive_conditioned','decompose_covariance'],'''"""Bounded one-factor Gaussian sign/censor likelihood."""
from functools import lru_cache
import numpy as np
from scipy.special import erfcx, log_ndtr, logsumexp, roots_hermitenorm
''')
extract('scripts/research_2026_09_26/bao_shape.py','lib/bao_shape.py',['load_data','cone_matrices','Cone','tail','lcdm_vector'],'''"""Flat, nonaccelerating BAO shape cone with a free distance scale."""
import hashlib
import numpy as np
import pandas as pd
from scipy.integrate import quad
from scipy.linalg import solve_triangular
from scipy.optimize import nnls, minimize, LinearConstraint
from scipy.stats import beta
from .paths import DATA, ROOT
INPUT = DATA / 'bao'
def digest(data):
    return hashlib.sha256(data).hexdigest()
''')
extract('scripts/phase2/independent_flux/engine.py','lib/flux_engine.py',['grid','Engine','read_inputs','mask_observations'],'''"""Direct and sncosmo calibrated-flux integrations with frozen DES assets."""
import gzip
import hashlib
import json
import numpy as np
import pandas as pd
from astropy.io import fits
import extinction
import sncosmo
from scipy.interpolate import RectBivariateSpline, RegularGridInterpolator
from .paths import DATA
BUNDLE = DATA / 'des/objectives'
ASSETS = DATA / 'des/model'
RELEASE_MODEL = ASSETS
MAG_OFFSET = .27
LB, LV = 4302.57, 5428.55
''')
extract('scripts/phase2/independent_flux/fit.py','lib/flux_fit.py',['jacobian','hessian','normal_logpdf','Case'],'''"""Fixed-covariance calibrated-flux fits and conditional prediction."""
import numpy as np
from scipy.linalg import solve_triangular
from scipy.optimize import least_squares
from .flux_engine import BUNDLE
''')
extract('scripts/research_2026_09_26/raisin_flux_sign_audit.py','lib/photometry.py',['read_raisin'],'''"""Strict reader for the released SNANA text photometry tables."""
''')
extract('scripts/research_2026_09_26/csp_passband_contrast.py','lib/passbands.py',['counts'],'''"""Photon-count integrals on the union of piecewise-linear table knots."""
import numpy as np
from numpy.polynomial.legendre import leggauss
''')
extract('scripts/phase2/hierarchy/conditional.py','lib/predictors.py',['features','components','predictive','model','serial','convergence_diagnostics'],'''"""Selected-sample DES predictor comparison with enforced convergence gates."""
import numpy as np
import jax
import jax.numpy as jnp
import numpyro
import numpyro.distributions as dist
from numpyro.diagnostics import summary
jax.config.update('jax_enable_x64', True)
FEATURES=['x','c','host','host_colour','red_hinge','x_evolution','c_evolution','x_squared']
PRIORS={'x':(-.15,.2),'c':(3.,2.),'host':(0.,.3),'host_colour':(0.,2.),'red_hinge':(0.,2.),'x_evolution':(0.,.5),'c_evolution':(0.,3.),'x_squared':(0.,.1)}
MODELS={'none':[],'stretch':['x'],'colour':['c'],'tripp':['x','c'],'host':['x','c','host'],'host_colour':['x','c','host','host_colour'],'broken_colour':['x','c','host','red_hinge'],'evolution':['x','c','host','x_evolution','c_evolution'],'flexible':FEATURES}
KNOTS=jnp.array([.01,.10,.20,.35,.50,.70,.90,1.20])
''')

DEST.joinpath('provenance/inputs.json').write_text(json.dumps({'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':ledger},indent=2)+'\n')
DEST.joinpath('provenance/code-origin.json').write_text(json.dumps({'files':code},indent=2)+'\n')
print(json.dumps({'input_files':len(ledger),'input_bytes':sum(x['bytes'] for x in ledger),'kernel_modules':len(code)},indent=2))
