from pathlib import Path
import json,datetime,re,hashlib,subprocess,sys,shutil,tempfile,os
root=Path('/home/szymon/Documents/ChatGPT/supernova');clean=root/'research_clean';sys.path.insert(0,str(clean))
from research import WORKFLOWS,verify
from lib.records import sha256
# Existing scientific gates and exact run/code/output hashes for all 19 workflows.
subprocess.run([sys.executable,'/tmp/check_dark_curated.py'],check=True,env={**os.environ,'OPENBLAS_NUM_THREADS':'1'})
subprocess.run([sys.executable,'/tmp/finalize_clean_research.py'],check=True,env={**os.environ,'PYTHONPATH':str(clean)})
# Confirm new extraction works from a genuinely separate copied folder.
portable=Path(tempfile.mkdtemp(prefix='supernova-updated-portable-'))/'research_clean'
shutil.copytree(clean,portable,ignore=shutil.ignore_patterns('__pycache__','.ruff_cache','.venv','results'))
for name in ['hst-dark-raw','hst-dark-calibrated']:
 subprocess.run([sys.executable,str(portable/'research.py'),'run',name,'--name','portable-'+name],cwd=portable,check=True)
 original=json.loads((clean/'results'/name/'summary.json').read_text());copy=json.loads((portable/'results'/('portable-'+name)/'summary.json').read_text());assert copy==original,name
# Rerun provenance/path/document checks for this edition.
assert verify()['pass']
for p in list((clean/'lib').glob('*.py'))+list((clean/'workflows').glob('*.py'))+[clean/'research.py']:
 assert '/home/szymon/' not in p.read_text(),p
for p in clean.rglob('*.md'):
 for target in re.findall(r'\]\(([^)]+)\)',p.read_text()):
  if '://' not in target and not target.startswith('#'):
   assert (p.parent/target.split('#')[0]).exists(),(p,target)
for p in list(clean.rglob('__pycache__'))+list(clean.rglob('.ruff_cache')):shutil.rmtree(p)
vp=clean/'provenance/validation.json';v=json.loads(vp.read_text());checks=json.loads(Path('/tmp/clean-dark-checks.json').read_text())
v['extra_checks']['dark_reproduction']=checks
v['extra_checks']['portable_copy_new_dark_workflows']=True
v['one_time_curation']={'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'previous_edition_sha256':sha256(Path('/tmp/supernova-before-one-time-update/edition.json')),
 'source_hash_changes_in_previous_curated_code':[],
 'added_workflows':['hst-dark-raw','hst-dark-calibrated'],
 'selection':'Completed repeatable HST dark calculations added; BayeSN implementation/runtime checks and incomplete 64-draw timing diagnostics are outside completed scientific workflows.',
 'automation_id':'one-time-clean-research-update','monitor_status':'paused; no further runs scheduled'}
v['limits'].append('Calibrated HST dark scoring begins with frozen local CALWF3 3.7.3 FLTs; this edition does not rerun the native calibration build. Raw dark moments are freshly extracted from all fourteen original RAWs.')
vp.write_text(json.dumps(v,indent=2)+'\n')
ip=clean/'provenance/inputs.json';iv=json.loads(ip.read_text());iv['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();ip.write_text(json.dumps(iv,indent=2)+'\n')
paths=sorted(p for p in clean.rglob('*') if p.is_file() and p!=clean/'provenance/edition.json')
ed={'format':'supernova-research-edition-v1','files_sha256':{str(p.relative_to(clean)):sha256(p) for p in paths},'total_files_excluding_this_manifest':len(paths),'bytes_excluding_this_manifest':sum(p.stat().st_size for p in paths)}
(clean/'provenance/edition.json').write_text(json.dumps(ed,indent=2)+'\n')
for rel,h in ed['files_sha256'].items():assert sha256(clean/rel)==h,rel
print(json.dumps({'status':'passed','workflows':len(WORKFLOWS),'inputs':len(iv['files']),'inventory':v['inventory'],'edition_files':len(paths)+1,'edition_bytes':sum(p.stat().st_size for p in clean.rglob('*') if p.is_file()),'portable_copy':str(portable)},indent=2))
