from pathlib import Path
import json,hashlib,shutil,ast,csv
R=Path('/home/szymon/Documents/ChatGPT/supernova');D=R/'research_clean';p=D/'provenance/inputs.json';manifest=json.loads(p.read_text());ledger=manifest['files']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(old,new,group,urls=None,kind='released input'):
 q=D/'data'/new;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/old,q)
 ledger.append(dict(path='data/'+new,source_path=old,sha256=sha(q),bytes=q.stat().st_size,group=group,kind=kind,urls=urls or []))
for record in json.loads((R/'runs/research_2026_09_26/astra_design/raisin_timing_assets/historical-tables-acquisition.json').read_text()):
 for item in ledger:
  if item['path']=='data/timing/'+Path(record['path']).name:item['urls']=[record['url']]
base='runs/research_2026_09_26/raisin_hst_pixel_feasibility'
url=json.loads((R/base/'pixel_acquisition/pam_validation/acquisition.json').read_text())[0]['url']
add(base+'/pixel_acquisition/pam_validation/ir_wfc3_map.fits','hst/pam.fits','hst',[url])
rows=list(csv.DictReader((R/'runs/research_2026_09_26/astra_design/raisin_signed_refit/cohort.csv').open()))
acq=json.loads((R/'runs/research_2026_09_26/raisin_flux_sign_audit/author-acquisition.json').read_text())['records'];urls={x['path']:x['url'] for x in acq}
cohort=[]
for row in rows:
 name=Path(row['raw_path']).name;new='signed/'+name
 add(row['raw_path'],new,'signed',[urls['data/Photometry/DES/'+name]],'signed author precursor photometry')
 cohort.append(dict(CID=row['CID'],source_CID=row['source_CID'],raw_file=name,peak_header=float(row['peak_header']),zHEL=float(row['zHEL'])))
q=D/'data/signed/cohort.json';q.write_text(json.dumps(cohort,indent=2)+'\n');ledger.append(dict(path='data/signed/cohort.json',source_path='runs/research_2026_09_26/astra_design/raisin_signed_refit/cohort.csv',sha256=sha(q),bytes=q.stat().st_size,group='signed',kind='rewritten frozen ten-object identity design',urls=[]))
p.write_text(json.dumps(manifest,indent=2)+'\n')
# Retain the tested geometry mathematics; remove historical orchestration.
old=R/base/'pixel_execution/geometry.py';new=D/'lib/hst_geometry.py';new.write_text(old.read_text())
orig=json.loads((D/'provenance/code-origin.json').read_text());orig['files'].append(dict(path='lib/hst_geometry.py',source_path=old.relative_to(R).as_posix(),source_sha256=sha(old),adaptation='Geometry definitions retained unchanged; integrated into rewritten execution workflow.'))
old=R/base/'pixel_execution/run.py';source=old.read_text();tree=ast.parse(source);keep={'exposure_metadata','tangent_bounds_and_grid','make_source_mask','near_source','operator_validity','synthetic_operator_gate','stage_a'}
segments=[]
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in keep:segments.append(ast.get_source_segment(source,node))
header='''"""Rebuild frozen HST geometry and masks from the eight calibrated exposures."""
from __future__ import annotations
import json, math, time, zipfile
from pathlib import Path
import numpy as np
from astropy.io import fits
from astropy.wcs import WCS
from scipy.ndimage import convolve
from lib.hst_geometry import curvature_gate, make_operator, tangent, untangent
from lib.paths import DATA
from lib.records import sha256 as digest, write_json
BASE = DATA / 'hst/exposures'
PAM = DATA / 'hst/pam.fits'
RA0, DEC0 = 8.9685, -43.35812
NPIX = 1014
OPERATOR_FIELDS_CAP_BYTES = 50_000_000
DEFAULTS = {}
HERE = None

def verify_freeze():
    return json.loads((HERE/'input-freeze.json').read_text())

def read_design():
    return ({'lattice_spacing_arcsec':6}, {'secondary': {'aperture_min_PAMweighted_coverage':.9, 'annulus_min_native_area_coverage':.75}})
'''
footer='''
def run(out,config):
    global HERE
    HERE=out
    freeze={'files':[{'filename':p.name,'sha256':digest(p)} for p in sorted(BASE.glob('*_flt.fits'))], 'pam_sha256':digest(PAM)}
    write_json(out/'input-freeze.json',freeze)
    stage_a()
    result=json.loads((out/'stage_a.json').read_text())
    original=json.loads((DATA/'hst/stage_a.json').read_text())
    identity=lambda s:[(r['id'],r.get('strict',False),r.get('secondary',False)) for r in s['rows']]
    if identity(result)!=identity(original):
        raise RuntimeError('Rebuilt geometry support differs from frozen design')
    with np.load(out/'operators.npz') as rebuilt, np.load(DATA/'hst/operators.npz') as frozen:
        exact={k:np.array_equal(rebuilt[k],frozen[k]) for k in rebuilt.files}
    if not all(exact.values()):raise RuntimeError('Rebuilt aperture operators differ from frozen arrays')
    return {'geometry_candidates':result['n_geometry_grid'],'strict_support':result['n_strict'],'secondary_support':result['n_secondary'],
            'exact_operator_arrays':exact,'scope':'Rebuild of the fixed geometry, design-exposure source masks and quality support. Held-out aperture brightness sums are evaluated separately by hst-repeat.'}
'''
text=header+'\n\n'+'\n\n'.join(segments)+footer
(D/'workflows/hst_geometry.py').write_text(text)
orig['files'].append(dict(path='workflows/hst_geometry.py',source_path=old.relative_to(R).as_posix(),source_sha256=sha(old),retained_symbols=sorted(keep),adaptation='Historical release markers replaced by central input verification. Geometry/masks rebuilt into isolated output and compared with frozen arrays.'))
(D/'provenance/code-origin.json').write_text(json.dumps(orig,indent=2)+'\n')
print(len(ledger),'inputs')
