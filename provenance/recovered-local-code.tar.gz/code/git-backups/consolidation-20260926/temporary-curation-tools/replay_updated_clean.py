from pathlib import Path
import json,hashlib,shutil,subprocess,sys
root=Path('/home/szymon/Documents/ChatGPT/supernova');clean=root/'research_clean';sys.path.insert(0,str(clean))
from research import WORKFLOWS
base='runs/research_2026_09_26/raisin_hst_pixel_feasibility/'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
p=clean/'provenance/code-origin.json';origin=json.loads(p.read_text())
new={
 'lib/dark.py':[base+'dark_ramp_execution/fixed_mask.py',base+'dark_ramp_execution/dark_executor.py'],
 'workflows/hst_dark_raw.py':[base+'dark_ramp_execution/dark_executor.py','scripts/research_2026_09_26/verify_dark_raw_moments.py'],
 'workflows/hst_dark_calibrated.py':['scripts/research_2026_09_26/score_calwf3_dark_prefix.py',base+'calwf3_dark_prefix/independent-score-review/check.py']}
for name,sources in new.items():
 origin['files'].append({'path':name,'rewritten_from':[{'source_path':s,'source_sha256':sha(root/s)} for s in sources],
  'adaptation':'Rewritten standalone workflow; fixed estimands and support retained. Historical releases, experiment orchestration and review narrative excluded. See methods/hst-dark.md.', 'edition_sha256':sha(clean/name)})
for row in origin['files']:row['edition_sha256']=sha(clean/row['path'])
p.write_text(json.dumps(origin,indent=2)+'\n')
shutil.move(clean/'results',Path('/tmp/supernova-before-one-time-update/results'))
(clean/'results').mkdir()
for name in WORKFLOWS:
 print('REPLAY',name,flush=True)
 subprocess.run([sys.executable,str(clean/'research.py'),'run',name,'--name',name],cwd=clean,check=True)
print('ALL COMPLETE',flush=True)
