from pathlib import Path
import ast,json,hashlib,shutil,datetime
root=Path('/home/szymon/Documents/ChatGPT/supernova'); clean=root/'research_clean'; base=root/'runs/research_2026_09_26/raisin_hst_pixel_feasibility'; raw=base/'dark_ramp_execution'; native=base/'calwf3_dark_prefix'
def sha(p):
 with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def read(p): return json.loads(p.read_text())
def dump(p,j): p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(j,indent=2)+'\n')
manifest=read(clean/'provenance/inputs.json');origin=read(clean/'provenance/code-origin.json')
# Verify the previous deliverable before adding anything.
edition=read(clean/'provenance/edition.json')
for rel,h in edition['files_sha256'].items(): assert sha(clean/rel)==h,rel
backup=Path('/tmp/supernova-before-one-time-update');backup.mkdir(exist_ok=False)
for name in ['edition.json','validation.json','code-origin.json','inputs.json']:shutil.copy2(clean/'provenance'/name,backup/name)
changes=[]
for record in origin['files']:
 for src in ([record] if 'source_path' in record else record.get('rewritten_from',[])):
  if sha(root/src['source_path'])!=src['source_sha256']:changes.append(src['source_path'])
assert not changes,changes

def add(src,rel,group,kind,urls=()):
 target=clean/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,target)
 manifest['files'].append(dict(path=rel,source_path=str(src.relative_to(root)),sha256=sha(target),bytes=target.stat().st_size,group=group,kind=kind,urls=list(urls)))
 return manifest['files'][-1]
headers=read(raw/'header-gate.json')['records'];design_path=base/'pixel_design/variance-diagnostic-review/calwf3_read_matrix/dark-quality-design/experiment-protocol.json';design=read(design_path)
for r in headers:
 p=Path(r['path']);assert sha(p)==r['sha256'];name=p.name
 add(p,'data/hst-dark/raw/'+name,'hst_dark_raw','original MAST RAW detector data',['https://mast.stsci.edu/api/v0.1/Download/file?uri=mast%3AHST%2Fproduct%2F'+name])
for p in sorted((raw/'references').glob('*.fits')):add(p,'data/hst-dark/references/'+p.name,'hst_dark_geometry','released bad-pixel reference',['https://hst-crds.stsci.edu/unchecked_get/references/hst/'+p.name])
add(base/'quality_reference_audit/reference_files/t2c16200i_ccd.fits','data/hst-dark/references/t2c16200i_ccd.fits','hst_dark_raw','released gain reference',['https://hst-crds.stsci.edu/unchecked_get/references/hst/t2c16200i_ccd.fits'])
for n in ['idbx41onq','idbx43p7q']:add(native/'work'/n/(n+'_flt.fits'),'data/hst-dark/calibrated/'+n+'_flt.fits','hst_dark_calibrated','locally derived CALWF3 3.7.3 eight-read dark FLT')
# A compact numerical specification, preserving the original frozen design's provenance.
spec={k:design[k] for k in ['pairs','time_operator','spatial_operator']};spec['cohort']=[{k:r[k] for k in ['root','visit','EXPFLAG']} for r in design['cohort']];spec['source_path']=str(design_path.relative_to(root));spec['source_sha256']=sha(design_path)
p=clean/'data/hst-dark/design.json';dump(p,spec)
manifest['files'].append(dict(path=str(p.relative_to(clean)),source_path=str(design_path.relative_to(root)),source_sha256=sha(design_path),sha256=sha(p),bytes=p.stat().st_size,group='hst_dark_geometry',kind='rewritten numerical specification from frozen pre-outcome design',urls=[]))
# Retain only tested reusable geometry primitives, not orchestration/release history.
src=raw/'fixed_mask.py';tree=ast.parse(src.read_text());names=['map_bpixtab','quadrant_area','signed_area','pixel_circle_fraction'];parts=['"""Reference-only detector masks and exact circle/pixel area primitives."""\n\nimport math\nimport numpy as np\nfrom astropy.io import fits\nfrom pathlib import Path\n\nN = 1024\nACTIVE = slice(5,1019)\n'];symbols=[]
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in names:
  parts.append(ast.get_source_segment(src.read_text(),node)+'\n');symbols.append(dict(symbol=node.name,start_line=node.lineno,end_line=node.end_lineno))
p=clean/'lib/dark_geometry.py';p.write_text('\n\n'.join(parts));origin['files'].append(dict(path=str(p.relative_to(clean)),source_path=str(src.relative_to(root)),source_sha256=sha(src),retained_symbols=symbols,adaptation='Retain BPIXTAB mapping and exact circle primitives; reconstruct fixed support in reusable workflows.',edition_sha256=sha(p)))
# Capture native-output lineage as provenance; operational code uses only the bundled files.
lineage={ 'calwf3_version':'3.7.3','starting_point':'Frozen eight-read native FLT outputs; native calibration build and execution are outside this edition.', 'original_cohort_exposure_count':14,'native_pair':['idbx41onq','idbx43p7q'],'source_records':{str(p.relative_to(root)):sha(p) for p in [native/'constructor-protocol.json',native/'constructor-result.json',native/'dark-protocol.json',native/'dark-execution-result.json',native/'null-result.json',native/'template-null-review/result.json']},'execution':read(native/'dark-protocol.json'),'products':read(native/'dark-execution-result.json')['runs']}
dump(clean/'provenance/hst-dark-native.json',lineage);dump(clean/'provenance/inputs.json',manifest);dump(clean/'provenance/code-origin.json',origin)
print(json.dumps({'previous_source_changes':changes,'new_inputs':len(manifest['files'])-371,'data_bytes':sum(p.stat().st_size for p in (clean/'data/hst-dark').rglob('*') if p.is_file())}))
