from pathlib import Path
import json,datetime,csv
from research import ROOT,WORKFLOWS,verify
from lib.records import sha256
assert verify()['pass']
records=[]
for name in WORKFLOWS:
 folder=ROOT/'results'/name;r=json.loads((folder/'run.json').read_text());s=json.loads((folder/'summary.json').read_text())
 assert r['status']=='completed',name
 assert not r['source_changed_during_run'],name
 for rel,digest in r['code_sha256'].items():assert sha256(ROOT/rel)==digest,(name,rel)
 for rel,digest in r['outputs_sha256'].items():assert sha256(folder/rel)==digest,(name,rel)
 records.append({'workflow':name,'status':'passed','elapsed_seconds':r['elapsed_seconds'],'configuration':r['config'],
                 'run_record':'results/'+name+'/run.json','summary':'results/'+name+'/summary.json',
                 'run_sha256':sha256(folder/'run.json'),'summary_sha256':sha256(folder/'summary.json')})
checks=json.loads(Path('/tmp/supernova-clean-validation-checks.json').read_text())['checks']
ra=json.loads((ROOT/'results/raisin/summary.json').read_text())
parent=ROOT.parent/'runs/research_2026_09_26/raisin_differential/paired-contrasts.csv'
old=list(csv.DictReader(parent.open()))
for row in ra['contrasts']:
 match=[x for x in old if x['branch_minus_nir']==row['branch_minus_nir'] and x['correction_variant']==row['variant'] and x['split']=='all']
 assert len(match)==1
 assert abs(row['high_minus_low_mag']-float(match[0]['contrast_mag']))<1e-12
assert ra['photometry_totals']['rows']==23007 and ra['photometry_totals']['negative']==0
csp=json.loads((ROOT/'results/csp-lineage/summary.json').read_text());assert csp['raw_NIR_rows']==5491 and csp['raw_to_snpy_exact_after_label_merge']
hst=json.loads((ROOT/'results/hst-repeat/summary.json').read_text());assert hst['masked_secondary_support']==170 and hst['strict_support']==0
assert abs(hst['visits']['search']['sum_d2_over_sum_V']-.7082532851787586)<1e-8
assert abs(hst['visits']['template']['sum_d2_over_sum_V']-.7287245592928685)<1e-8
base=json.loads((ROOT/'results/signed-baseline/summary.json').read_text());assert base['cuts']['180']['rows']==3476
cos=json.loads((ROOT/'results/cosmology/summary.json').read_text());assert cos['valid_for_posterior_summary'] and abs(cos['mode'][0]-.3315758)<1e-6
pred=json.loads((ROOT/'results/des-predictors/summary.json').read_text());assert pred['convergence']['valid_for_scoring']
checks['parent_result_landmarks']=True
checks['paired_contrasts_parent_table_sha256']=sha256(parent)
paths=[p for p in ROOT.rglob('*') if p.is_file() and not any(x in p.parts for x in ['.venv','__pycache__','.ruff_cache'])]
md=[p for p in paths if p.suffix=='.md'];py=[p for p in paths if p.suffix=='.py']
report={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'passed','workflow_count':len(records),
        'all_primary_workflows_reexecuted':True,'extra_checks':checks,'runs':records,
        'limits':['Replays begin at the explicitly documented input levels. Frozen DES derivatives are not regenerated from raw detector data.',
                  'Successful computation does not certify physical identification, real-noise independence, selection closure or every optional configuration.',
                  'Independent numerical checks supplement the code-level gates; they are not independent observational datasets.'],
        'inventory':{'python_files':len(py),'python_physical_lines':sum(len(p.read_text().splitlines()) for p in py),'markdown_files':len(md),
                     'markdown_words_whitespace_approx':sum(len(p.read_text().split()) for p in md),'frozen_inputs':len(json.loads((ROOT/'provenance/inputs.json').read_text())['files']),
                     'data_bytes':sum(p.stat().st_size for p in (ROOT/'data').rglob('*') if p.is_file())}}
(ROOT/'provenance/validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'workflows':len(records),'elapsed_all_primary_seconds':sum(r['elapsed_seconds'] for r in records),'inventory':report['inventory']},indent=2))
