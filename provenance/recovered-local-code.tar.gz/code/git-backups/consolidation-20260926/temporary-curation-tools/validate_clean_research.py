import json,sys,tempfile,subprocess,shutil,hashlib,datetime,re,ast
from pathlib import Path
import numpy as np
from astropy.cosmology import Flatw0waCDM
R=Path('/home/szymon/Documents/ChatGPT/supernova/research_clean');sys.path.insert(0,str(R))
from lib.cosmology import mu,integral,qvalue
from lib.dust import slab
from lib.records import sha256
checks={}
z=np.array([.01,.1,.8,2.3]);errs=[]
for t in [[.3,-1.,0.],[.353,-.42,-1.75],[.02,-2.9,1.9]]:
 ref=Flatw0waCDM(H0=70,Om0=t[0],w0=t[1],wa=t[2],Tcmb0=0).distmod(z).value-5*np.log10(299792.458/70)-25
 errs.append(float(np.max(abs(mu(z,t)[0]-ref))))
assert max(errs)<1e-7;checks['three_independent_astropy_distance_cases_max_mag']=max(errs)
for q in [-1.,0.,.5]:
 ref=np.log1p(z) if q==0 else ((1+z)**(-q)-1)/(-q)
 assert np.max(abs(integral(z,[q]*5,'qbins')[0]-ref))<1e-12
checks['piecewise_q_analytic_limits']=True
for zbad in [-.1,2.5001,np.nan,np.inf]:
 try:integral([zbad],[0.]*5,'qbins')
 except ValueError:pass
 else:raise AssertionError('q-bin domain not enforced')
assert float(slab(0))==0
for bad in [-1.,np.nan,np.inf]:
 try:slab(bad)
 except ValueError:pass
 else:raise AssertionError('slab domain not enforced')
checks['distance_and_slab_domain_rejections']=True
# Independent NumPy covariance projection and finite-difference derivative
# challenge the repaired JAX compilation path, including mixed x/c terms.
import jax,jax.numpy as jnp
from lib.predictors import components
rng=np.random.default_rng(82291);n=7;y=rng.normal(size=(n,3));A=rng.normal(size=(n,3,3));cov=A@A.transpose(0,2,1)+.2*np.eye(3)
data={'y':jnp.array(y),'cov':jnp.array(cov),'z':jnp.linspace(.02,.9,n),'distance_reference':jnp.linspace(35,44,n)}
params={'M':-19.3,'offsets':jnp.zeros(7),'coefficients':jnp.array([-.15,3.]),'scatter':jnp.array([.1,.2])}
fn=jax.jit(lambda b:components({**params,'coefficients':b},data,'tripp')[1])
b=np.array([-.15,3.]);v=np.tile([1.,-b[0],-b[1]],(n,1));base=np.einsum('ni,nij,nj->n',v,cov,v)
ref=np.stack([base+.01,base+.04],axis=1);error=float(np.max(abs(np.asarray(fn(jnp.array(b)))-ref)))
assert error<1e-10
jgrad=np.asarray(jax.jit(jax.grad(lambda bb:fn(bb).sum()))(jnp.array(b)))
def npvalue(bb):
 vv=np.tile([1.,-bb[0],-bb[1]],(n,1));return 2*np.einsum('ni,nij,nj->',vv,cov,vv)+n*.05
fd=np.array([(npvalue(b+np.eye(2)[i]*1e-5)-npvalue(b-np.eye(2)[i]*1e-5))/2e-5 for i in range(2)])
assert np.max(abs(jgrad-fd))<1e-6
checks['compiled_covariance_numpy_error']=error;checks['compiled_projection_gradient_fd_error']=float(np.max(abs(jgrad-fd)))
# A complete copy has no symlinks or dependency on the original data paths.
T=Path(tempfile.mkdtemp(prefix='supernova-research-portable-'))
for name in ['lib','workflows','data','provenance']:
 shutil.copytree(R/name,T/name,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['research.py','uv.lock']:shutil.copyfile(R/name,T/name)
for cmd in [['verify'],['run','raisin','--name','portability-raisin'],['run','hst-repeat','--name','portability-hst']]:
 p=subprocess.run([sys.executable,str(T/'research.py'),*cmd],cwd=T,capture_output=True,text=True)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
checks['portable_copy_raisin_and_hst']=True
# Exercise the actual downloader on a missing public file in the portable copy.
pth='data/bao/desi_gaussian_bao_ALL_GCcomb_mean.txt';dest=T/pth;before=sha256(dest);dest.unlink()
p=subprocess.run([sys.executable,str(T/'research.py'),'fetch','--path',pth],cwd=T,capture_output=True,text=True)
checks['public_download_stdout']=p.stdout.strip()
if p.returncode:raise RuntimeError(p.stdout+p.stderr)
assert sha256(dest)==before;checks['public_download_exact_sha256']=before
# Mismatched input must be rejected before a result directory is created.
dest.write_text('intentionally invalid integrity-check input\n')
p=subprocess.run([sys.executable,str(T/'research.py'),'run','bao-shape','--name','must-not-run'],cwd=T,capture_output=True,text=True)
assert p.returncode!=0 and not (T/'results/must-not-run').exists()
checks['corrupt_input_stops_before_analysis']=True
# Scan only executable source for paths that could reach back into the archive.
for p in [*R.glob('lib/*.py'),*R.glob('workflows/*.py'),R/'research.py']:
 assert '/home/szymon/Documents/ChatGPT/supernova' not in p.read_text(),p
checks['no_legacy_absolute_paths_in_executable_code']=True
# All documentation links resolve; network links are attributed source pointers.
broken=[]
for p in R.rglob('*.md'):
 if '.venv' in p.parts:continue
 for match in re.finditer(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',p.read_text()):
  url=match.group(1).split('#')[0]
  if not url or '://' in url:continue
  if not (p.parent/url).exists():broken.append((str(p.relative_to(R)),url))
# Validation record itself is produced after all checks.
broken=[x for x in broken if x[1]!='provenance/validation.json']
assert not broken,broken
checks['local_document_links']=True
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pass':True,'checks':checks,'portable_test_directory':str(T)}
Path('/tmp/supernova-clean-validation-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
