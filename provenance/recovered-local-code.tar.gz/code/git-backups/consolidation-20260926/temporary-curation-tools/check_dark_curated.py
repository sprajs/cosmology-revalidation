from pathlib import Path
import json,csv,hashlib
import numpy as np
root=Path('/home/szymon/Documents/ChatGPT/supernova');c=root/'research_clean';b=root/'runs/research_2026_09_26/raisin_hst_pixel_feasibility';raw=b/'dark_ramp_execution';cal=b/'calwf3_dark_prefix';checks={}
def rows(p):return list(csv.DictReader(p.open()))
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def compare(label,actual,expected,rtol=1e-10,atol=1e-10):
 a,e=np.asarray(actual,float),np.asarray(expected,float);assert a.shape==e.shape,(label,a.shape,e.shape)
 assert np.allclose(a,e,rtol=rtol,atol=atol),(label,np.max(abs(a-e)))
 checks[label]={'scalars':a.size,'max_absolute_difference':float(np.max(abs(a-e))),'rtol':rtol,'atol':atol}
for k in ['quadrant_gamma','quadrant_mean','block_gamma','block_mean']:
 compare('raw_'+k,np.load(c/'results/hst-dark-raw/read-matrix.npz')[k],np.load(raw/'read-matrix.npz')[k],atol=1e-8)
for name,orig,keys,fields in [
 ('quadrants','pair-quadrant-power',['pair','quadrant','scope','power'],['n','dn2_per_nominal_s2','electron2_per_nominal_s2']),
 ('blocks','block-pair-power',['pair','block_y','block_x'],['n','primary_dn2_per_nominal_s2']),
 ('apertures','aperture-pair-power',['pair','x','y','power'],['signed_dn_per_nominal_s','half_squared_dn2_per_nominal_s2']),
 ('categories','raw-dq-digital-contributions',['pair','category'],['selected_pixels','half_squared_slope_contribution'])]:
 def key(r):return tuple(str(float(r[k])) if k in ['power','x','y','block_y','block_x'] else r[k] for k in keys)
 expected={key(r):r for r in rows(raw/(orig+'.csv'))};actual=rows(c/'results/hst-dark-raw'/(name+'.csv'));assert len(actual)==len(expected)
 compare('raw_'+name,[[r[f] for f in fields] for r in actual],[[expected[key(r)][f] for f in fields] for r in actual])
for name,orig,fields in [
 ('regions','independent-calibrated-quadrants',['pixels','signed_mean','sum_squared_difference','sum_quoted_pair_variance','repeat_to_quoted_ratio']),
 ('blocks','independent-calibrated-blocks',['pixels','signed_mean','sum_squared_difference','sum_quoted_pair_variance','repeat_to_quoted_ratio']),
 ('apertures','independent-calibrated-apertures',['raw_x','raw_y','difference_dn_per_nominal_s','quoted_diagonal_pair_variance','squared_difference'])]:
 actual=rows(c/'results/hst-dark-calibrated'/(name+'.csv'));expected=rows(cal/'independent-score-review'/(orig+'.csv'))
 compare('calibrated_'+name,[[r[f] for f in fields] for r in actual],[[r[f] for f in fields] for r in expected])
s=json.loads((c/'results/hst-dark-calibrated/summary.json').read_text());assert s['largest_pixel']['raw_x']==506 and s['largest_pixel']['raw_y']==945 and s['largest_pixel']['absolute_aperture_weight']==0
assert s['DQ32']['pixels']==4;compare('calibrated_influence',[s['largest_pixel']['fraction_of_total'],s['DQ32']['sum_squared_difference']],[.8286405754140713,8305.450122881031])
# Independent scalar quadrature for every distinct fractional geometry cell.
import sys;sys.path.insert(0,str(c))
from lib.dark import support,design
from lib.dark_geometry import pixel_circle_fraction
from scipy.integrate import quad
errors=[]
for r in design()['spatial_operator']['radii_pixels']:
 for x in range(17):
  for y in range(17):
   lo,hi=max(-r,x-.5),min(r,x+.5)
   if hi<=lo: expected=0.
   else:
    def f(u):
     v=np.sqrt(max(0.,r*r-u*u));return max(0.,min(y+.5,v)-max(y-.5,-v))
    split=[lo,hi]
    for v in [y-.5,y+.5]:
     if abs(v)<r:
      u=np.sqrt(r*r-v*v)
      split += [w for w in [-u,u] if lo<w<hi]
    split=sorted(set(split));expected=sum(quad(f,a,b,epsabs=1e-11,epsrel=1e-11)[0] for a,b in zip(split[:-1],split[1:]))
   errors.append(abs(pixel_circle_fraction(x,y,r)-expected))
assert max(errors)<1e-10,max(errors)
checks['independent_circle_quadrature']={'cells':len(errors),'max_absolute_difference':max(errors)}
checks['reference_results_sha256']={str(p.relative_to(root)):sha(p) for p in [raw/'read-matrix.npz',raw/'pair-quadrant-power.csv',raw/'block-pair-power.csv',raw/'aperture-pair-power.csv',cal/'independent-score-review/result.json']}
Path('/tmp/clean-dark-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
