import os, re, json, ast, tokenize, io, hashlib, collections, datetime
from pathlib import Path
from markdown_it import MarkdownIt

ROOT=Path('/home/szymon/Documents/ChatGPT/supernova')
OUT=Path('/home/szymon/.codex/visualizations/2026/09/26/01a0dce0-7477-7542-a1d6-9210aff32a07/project-inventory')
parser=MarkdownIt('commonmark').enable('table')
excluded=[]; files=[]
prefixes=['sources','data','papers','phase2/classification/python','phase2/official/build','phase2/official/inputs/SNDATA_ROOT','runs/research_2026_09_26/deps']
skipnames={'.git','.venv','__pycache__','node_modules','.pytest_cache','.ruff_cache','sources','official-code','legacy-code','raisin_cosmo','acquired'}
for root,ds,fs in os.walk(ROOT):
 p=Path(root); rel=p.relative_to(ROOT).as_posix()
 reason=None
 if rel in prefixes:reason='Downloaded evidence, runtime, dependency, or upstream build'
 elif 'pyvenv.cfg' in fs:reason='Python environment'
 elif p.name in skipnames or p.name.startswith('sources-'):reason='Dependency, cache, or acquired source directory'
 elif 'src' in ds and 'doc' in ds:reason='SNANA source/build tree'
 if reason:excluded.append({'path':rel,'reason':reason});ds[:]=[];continue
 for f in fs:
  q=p/f
  if q.is_symlink() or q.suffix in {'.pyc','.pyo'}:continue
  files.append(q)

def digest(b):return hashlib.sha256(b).hexdigest()
def md_stats(s):
 tokens=parser.parse(s); chunks=[]; diagrams=[]; images=[]
 for t in tokens:
  if t.type in {'fence','code_block'}:
   if t.info.split(' ')[0].lower() in {'mermaid','dot','graphviz','plantuml','d2'}:diagrams.append(t.info)
   else:chunks.append(t.content)
  elif t.type=='inline':
   for c in t.children or []:
    if c.type in {'text','code_inline'}:chunks.append(c.content)
    elif c.type=='image':images.append(c.attrGet('src'));chunks.append(c.content)
 text=' '.join(chunks)
 # Unicode word-like tokens; compound words, numbers, and inline code count as words.
 words=len(re.findall(r"\w+(?:['’.-]\w+)*",text))
 return dict(words=words,diagrams=diagrams,image_references=images)

md=[]; code=[]; extensions=collections.Counter(); images=[]; otherdesign=[]
codeext={'.py','.sh','.c','.h','.f','.f90','.pl','.r','.js','.ts','.cpp','.hpp'}
for p in sorted(files):
 rel=p.relative_to(ROOT).as_posix();ext=p.suffix.lower();extensions[ext or '[none]']+=1
 if ext in {'.md','.markdown'}:
  b=p.read_bytes();s=b.decode('utf-8');item=dict(path=rel,lines=len(s.splitlines()),sha256=digest(b),**md_stats(s))
  item['group']='Primary documentation' if len(p.relative_to(ROOT).parts)==1 or rel.startswith(('docs/','catalog/')) else 'Run and phase2 documentation'
  md.append(item)
 if ext in codeext:
  b=p.read_bytes();s=b.decode('utf-8',errors='replace');lines=s.splitlines()
  item=dict(path=rel,lines=len(lines),nonblank=sum(bool(x.strip()) for x in lines),sha256=digest(b))
  if ext=='.py':
   docspans=[]
   try:
    tree=ast.parse(s)
    for n in ast.walk(tree):
     if isinstance(n,(ast.Module,ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and n.body and isinstance(n.body[0],ast.Expr) and isinstance(n.body[0].value,ast.Constant) and isinstance(n.body[0].value.value,str):
      v=n.body[0].value;docspans.append(((v.lineno,v.col_offset),(v.end_lineno,v.end_col_offset)))
    hits=set()
    for t in tokenize.generate_tokens(io.StringIO(s).readline):
     if t.type in {tokenize.COMMENT,tokenize.NL,tokenize.NEWLINE,tokenize.INDENT,tokenize.DEDENT,tokenize.ENDMARKER,tokenize.ENCODING}:continue
     if any(a<=t.start and t.end<=z for a,z in docspans):continue
     for n in range(t.start[0],t.end[0]+1):
      if n<=len(lines) and lines[n-1].strip():hits.add(n)
    item['code_lines']=len(hits)
   except Exception as e:item['parse_error']=str(e)
  elif ext=='.sh':item['code_lines']=sum(bool(x.strip()) and not x.lstrip().startswith('#') for x in lines)
  code.append(item)
 if ext in {'.png','.jpg','.jpeg','.gif','.webp','.svg','.tif','.tiff','.bmp','.avif'}:images.append(rel)
 if ext in {'.drawio','.fig','.sketch','.mmd','.mermaid','.dot','.puml','.plantuml','.tex','.ipynb','.pptx','.docx','.odg','.d2'}:otherdesign.append(rel)

def summarize(items,keys):return dict(files=len(items),**{k:sum(x.get(k,0) for x in items) for k in keys})
primary=[x for x in code if x['path'].startswith('scripts/')]
othercode=[x for x in code if not x['path'].startswith('scripts/')]
figure_paths=[x for x in images]
# A PDF with a matching image stem is an alternate export of that figure.
pdfs=[p.relative_to(ROOT).as_posix() for p in files if p.suffix.lower()=='.pdf']
image_stems={str(Path(x).with_suffix('')) for x in images}
figure_pdfs=[x for x in pdfs if str(Path(x).with_suffix('')) in image_stems]
summary=dict(timestamp=datetime.datetime.now().astimezone().isoformat(),root=str(ROOT),
 total_scoped_files=len(files),extensions=dict(extensions.most_common()),
 primary_code=summarize(primary,['lines','nonblank','code_lines']),
 supporting_code=summarize(othercode,['lines','nonblank']),
 primary_code_by_extension={e:summarize([x for x in primary if Path(x['path']).suffix==e],['lines','code_lines']) for e in ['.py','.sh']},
 markdown=summarize(md,['lines','words']),
 markdown_groups={g:summarize([x for x in md if x['group']==g],['lines','words']) for g in sorted({x['group'] for x in md})},
 unique_markdown_contents=len({x['sha256'] for x in md}),
 images=dict(collections.Counter(Path(x).suffix for x in images)),image_files=len(images),figure_pdf_exports=len(figure_pdfs),figure_stems=len(image_stems),
 embedded_diagrams=sum(len(x['diagrams']) for x in md),image_references=sum(len(x['image_references']) for x in md),
 other_design_files=otherdesign,other_pdfs=[x for x in pdfs if x not in figure_pdfs],parse_errors=[x for x in code if 'parse_error' in x])
payload=dict(summary=summary,markdown=md,code=code,images=images,figure_pdf_exports=figure_pdfs,excluded_directories=excluded,
 all_scoped_files=[p.relative_to(ROOT).as_posix() for p in sorted(files)])
OUT.joinpath('inventory.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(summary,indent=2))
